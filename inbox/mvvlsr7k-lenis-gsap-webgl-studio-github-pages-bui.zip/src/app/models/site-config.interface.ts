export type WebglEffectType = 
  | 'wave-mesh' 
  | 'cosmic-particles' 
  | 'torus-knot' 
  | 'liquid-aurora' 
  | 'interactive-ripples';

export interface ProjectItem {
  id: string;
  title: string;
  category: string;
  description: string;
  image: string;
  year: string;
  link: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  desc: string;
  icon: string;
}

export interface StatItem {
  id: string;
  value: string;
  label: string;
}

export interface SiteConfig {
  siteType: string;
  brandName: string;
  heroTitle: string;
  heroSubtitle: string;
  ctaText: string;
  ctaLink: string;
  language: 'fa' | 'en';
  theme: {
    name: string;
    primaryColor: string;
    secondaryColor: string;
    accentColor: string;
    bgColor: string;
    surfaceColor: string;
    textColor: string;
    fontPairing: 'vazir-syne' | 'space-grotesk' | 'editorial-serif' | 'cyber-mono';
  };
  webglEffect: WebglEffectType;
  webglConfig: {
    particleCount: number;
    speed: number;
    reactToMouse: boolean;
    wireframe: boolean;
    glowIntensity: number;
  };
  lenisConfig: {
    lerp: number; // e.g. 0.08
    smoothWheel: boolean;
    smoothTouch: boolean;
    touchMultiplier: number;
    direction: 'vertical' | 'horizontal';
  };
  gsapConfig: {
    splitTextAnimation: boolean;
    parallaxImages: boolean;
    magneticCursor: boolean;
    magneticButtons: boolean;
    pinnedHorizontalProjects: boolean;
    counterStats: boolean;
    cardTiltHover: boolean;
  };
  sections: {
    showHero: boolean;
    showAbout: boolean;
    showProjects: boolean;
    showServices: boolean;
    showStats: boolean;
    showContact: boolean;
  };
  about: {
    title: string;
    tagline: string;
    description: string;
    image: string;
  };
  projects: ProjectItem[];
  services: ServiceItem[];
  stats: StatItem[];
  contact: {
    title: string;
    email: string;
    phone: string;
    location: string;
    socials: { name: string; url: string }[];
  };
  githubPagesConfig: {
    repositoryName: string;
    cname: string;
    include404: boolean;
    includeReadme: boolean;
    singleFileMode: boolean;
  };
}
