import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SiteStateService } from './services/site-state.service';
import { QuestionnaireComponent } from './components/questionnaire/questionnaire.component';
import { PreviewFrameComponent } from './components/preview-frame/preview-frame.component';
import { CodeViewerComponent } from './components/code-viewer/code-viewer.component';
import { PromptGeneratorComponent } from './components/prompt-generator/prompt-generator.component';
import { GithubGuideComponent } from './components/github-guide/github-guide.component';
import { SITE_PRESETS } from './data/presets.data';
import { CodeGeneratorService } from './services/code-generator.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    QuestionnaireComponent,
    PreviewFrameComponent,
    CodeViewerComponent,
    PromptGeneratorComponent,
    GithubGuideComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly state = inject(SiteStateService);
  private readonly generator = inject(CodeGeneratorService);

  readonly presets = SITE_PRESETS;
  readonly isSplitView = signal<boolean>(false);
  readonly copyNotification = signal<boolean>(false);

  toggleSplitView() {
    this.isSplitView.update(v => !v);
  }

  setTab(tab: 'wizard' | 'preview' | 'code' | 'github' | 'prompt') {
    this.state.activeTab.set(tab);
  }

  onPresetChange(event: Event) {
    const target = event.target as HTMLSelectElement;
    if (target && target.value) {
      this.state.applyPreset(target.value);
    }
  }

  downloadStandalone() {
    const config = this.state.config();
    const html = this.generator.generateSingleHtml(config);
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'index.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  async copyAllCode() {
    try {
      const config = this.state.config();
      const html = this.generator.generateSingleHtml(config);
      await navigator.clipboard.writeText(html);
      this.copyNotification.set(true);
      setTimeout(() => this.copyNotification.set(false), 2200);
    } catch {
      // Fallback
    }
  }
}
