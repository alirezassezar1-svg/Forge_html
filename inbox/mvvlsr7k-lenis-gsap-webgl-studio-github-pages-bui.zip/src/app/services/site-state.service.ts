import { Injectable, computed, signal } from '@angular/core';
import { SiteConfig } from '../models/site-config.interface';
import { INITIAL_CONFIG, SITE_PRESETS, THEME_PRESETS } from '../data/presets.data';

@Injectable({
  providedIn: 'root',
})
export class SiteStateService {
  readonly config = signal<SiteConfig>(structuredClone(INITIAL_CONFIG));
  readonly activeTab = signal<'wizard' | 'preview' | 'code' | 'github' | 'prompt'>('wizard');
  readonly currentStep = signal<number>(1);
  readonly isAiLoading = signal<boolean>(false);
  readonly previewViewport = signal<'desktop' | 'tablet' | 'mobile'>('desktop');
  readonly previewKey = signal<number>(1);

  readonly totalSteps = 8;

  // Computed helper for quick access
  readonly siteType = computed(() => this.config().siteType);
  readonly brandName = computed(() => this.config().brandName);
  readonly language = computed(() => this.config().language);
  readonly theme = computed(() => this.config().theme);

  updateConfig(updater: (prev: SiteConfig) => SiteConfig) {
    this.config.update(prev => {
      const updated = updater(structuredClone(prev));
      return updated;
    });
    this.refreshPreview();
  }

  setField<K extends keyof SiteConfig>(key: K, value: SiteConfig[K]) {
    this.config.update(prev => ({
      ...prev,
      [key]: value,
    }));
    this.refreshPreview();
  }

  applyPreset(presetId: string) {
    const preset = SITE_PRESETS.find(p => p.id === presetId);
    if (preset) {
      this.config.update(prev => ({
        ...prev,
        ...preset.config,
      }));
      this.refreshPreview();
    }
  }

  applyTheme(themeId: string) {
    const theme = THEME_PRESETS.find(t => t.id === themeId);
    if (theme) {
      this.config.update(prev => ({
        ...prev,
        theme: { ...theme },
      }));
      this.refreshPreview();
    }
  }

  nextStep() {
    if (this.currentStep() < this.totalSteps) {
      this.currentStep.update(s => s + 1);
    }
  }

  prevStep() {
    if (this.currentStep() > 1) {
      this.currentStep.update(s => s - 1);
    }
  }

  goToStep(step: number) {
    if (step >= 1 && step <= this.totalSteps) {
      this.currentStep.set(step);
    }
  }

  refreshPreview() {
    this.previewKey.update(k => k + 1);
  }

  resetToDefault() {
    this.config.set(structuredClone(INITIAL_CONFIG));
    this.currentStep.set(1);
    this.refreshPreview();
  }
}
