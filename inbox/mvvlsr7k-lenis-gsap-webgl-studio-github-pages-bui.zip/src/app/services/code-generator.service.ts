import { Injectable } from '@angular/core';
import { SiteConfig, WebglEffectType } from '../models/site-config.interface';

@Injectable({
  providedIn: 'root',
})
export class CodeGeneratorService {

  /**
   * Generates a 100% standalone, zero-dependency, single-file index.html
   * completely compatible with GitHub Pages out of the box.
   */
  generateSingleHtml(config: SiteConfig): string {
    const isRtl = config.language === 'fa';
    const dir = isRtl ? 'rtl' : 'ltr';
    const lang = config.language;

    const cssContent = this.generateCss(config);
    const jsContent = this.generateJs(config);
    const jsonConfigStr = JSON.stringify(config, null, 2);

    return `<!DOCTYPE html>
<html lang="${lang}" dir="${dir}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${this.escapeHtml(config.brandName)} | ${this.escapeHtml(config.heroTitle)}</title>
  <meta name="description" content="${this.escapeHtml(config.heroSubtitle)}">
  <meta property="og:title" content="${this.escapeHtml(config.brandName)}">
  <meta property="og:description" content="${this.escapeHtml(config.heroSubtitle)}">
  <meta property="og:type" content="website">

  <!-- Modern Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&family=Space+Grotesk:wght@500;700&family=Syne:wght@700;800&family=Vazirmatn:wght@300;400;600;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

  <!-- Core Libraries via CDN for GitHub Pages -->
  <!-- Lenis Smooth Scroll -->
  <script src="https://unpkg.com/lenis@1.1.20/dist/lenis.min.js"></script>
  <!-- GSAP & ScrollTrigger -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/ScrollTrigger.min.js"></script>
  <!-- Three.js for WebGL 3D Canvas -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>

  <style>
${cssContent}
  </style>

  <!-- Vanilla JSON Config Script -->
  <script id="site-config-data" type="application/json">
${jsonConfigStr}
  </script>
</head>
<body>

  <!-- WebGL Background Canvas -->
  <canvas id="webgl-canvas"></canvas>

  <!-- Interactive Magnetic Cursor -->
  <div class="cursor-dot"></div>
  <div class="cursor-outline"></div>

  <!-- Scroll Progress Indicator -->
  <div class="scroll-progress-bar"></div>

  <!-- Top Glass Navigation Bar -->
  <header class="site-header">
    <div class="header-container">
      <a href="#" class="brand-logo magnetic-target">
        <span class="logo-symbol">❖</span>
        <span class="brand-text">${this.escapeHtml(config.brandName)}</span>
      </a>

      <nav class="nav-links">
        ${config.sections.showHero ? `<a href="#hero" class="nav-link magnetic-target">${isRtl ? 'خانه' : 'Home'}</a>` : ''}
        ${config.sections.showAbout ? `<a href="#about" class="nav-link magnetic-target">${isRtl ? 'درباره ما' : 'About'}</a>` : ''}
        ${config.sections.showProjects ? `<a href="#projects" class="nav-link magnetic-target">${isRtl ? 'پروژه‌ها' : 'Work'}</a>` : ''}
        ${config.sections.showServices ? `<a href="#services" class="nav-link magnetic-target">${isRtl ? 'خدمات' : 'Services'}</a>` : ''}
        ${config.sections.showContact ? `<a href="#contact" class="nav-link magnetic-target">${isRtl ? 'ارتباط' : 'Contact'}</a>` : ''}
      </nav>

      <a href="${config.ctaLink}" class="header-cta magnetic-btn">
        <span>${this.escapeHtml(config.ctaText)}</span>
        <span class="material-icons cta-icon">${isRtl ? 'arrow_backward' : 'arrow_forward'}</span>
      </a>
    </div>
  </header>

  <!-- Main Content Wrap for Smooth Scroll -->
  <main class="page-content">

    <!-- HERO SECTION -->
    ${config.sections.showHero ? `
    <section id="hero" class="hero-section">
      <div class="hero-inner">
        <div class="hero-badge reveal-elem">
          <span class="badge-dot"></span>
          <span>${isRtl ? 'طراحی تعاملی با WebGL و Lenis' : 'Interactive WebGL & Kinetic UI'}</span>
        </div>

        <h1 class="hero-title" data-split="chars">
          ${this.splitHeadline(config.heroTitle)}
        </h1>

        <p class="hero-subtitle reveal-elem">
          ${this.escapeHtml(config.heroSubtitle)}
        </p>

        <div class="hero-actions reveal-elem">
          <a href="${config.ctaLink}" class="btn-primary magnetic-btn">
            <span class="btn-text">${this.escapeHtml(config.ctaText)}</span>
            <span class="material-icons">${isRtl ? 'arrow_downward' : 'north_east'}</span>
          </a>
          <a href="#about" class="btn-secondary magnetic-btn">
            <span>${isRtl ? 'کشف تجربه دیجیتال' : 'Explore Concept'}</span>
          </a>
        </div>

        <div class="hero-scroll-cue">
          <div class="mouse-icon">
            <div class="wheel"></div>
          </div>
          <span class="scroll-label">${isRtl ? 'به پایین اسکرول کنید' : 'Scroll to explore'}</span>
        </div>
      </div>
    </section>
    ` : ''}

    <!-- ABOUT SECTION -->
    ${config.sections.showAbout ? `
    <section id="about" class="about-section">
      <div class="section-container">
        <div class="about-grid">
          <div class="about-content">
            <div class="section-tag">${isRtl ? '// هویت و فلسفه' : '// OUR PHILOSOPHY'}</div>
            <h2 class="section-heading gsap-reveal-heading">${this.escapeHtml(config.about.title)}</h2>
            <h3 class="about-tagline">${this.escapeHtml(config.about.tagline)}</h3>
            <p class="about-text">${this.escapeHtml(config.about.description)}</p>

            <div class="about-highlights">
              <div class="highlight-item">
                <span class="highlight-num">01</span>
                <span class="highlight-title">${isRtl ? 'شیدرهای سه‌بعدی بلادرنگ' : 'Real-time GLSL Shaders'}</span>
              </div>
              <div class="highlight-item">
                <span class="highlight-num">02</span>
                <span class="highlight-title">${isRtl ? 'محاسبه اینرسی و لختی Lenis' : 'Inertial Fluid Scrolling'}</span>
              </div>
              <div class="highlight-item">
                <span class="highlight-num">03</span>
                <span class="highlight-title">${isRtl ? 'بهینه‌سازی ۱۰۰٪ گیت‌هاب پیج' : 'Static Zero-Latency Deploy'}</span>
              </div>
            </div>
          </div>

          <div class="about-media">
            <div class="media-frame tilt-card">
              <img src="${config.about.image}" alt="About Visual" class="parallax-img" loading="lazy">
              <div class="media-overlay"></div>
              <div class="floating-badge">
                <span class="material-icons">auto_awesome</span>
                <span>${isRtl ? 'نوآوری در تعامل' : 'Visual Alchemy'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    ` : ''}

    <!-- STATS SECTION -->
    ${config.sections.showStats ? `
    <section class="stats-section">
      <div class="section-container">
        <div class="stats-grid">
          ${config.stats.map(s => `
          <div class="stat-card">
            <div class="stat-val counter-target" data-target="${s.value}">${s.value}</div>
            <div class="stat-lbl">${this.escapeHtml(s.label)}</div>
          </div>
          `).join('')}
        </div>
      </div>
    </section>
    ` : ''}

    <!-- PROJECTS SHOWCASE -->
    ${config.sections.showProjects ? `
    <section id="projects" class="projects-section ${config.gsapConfig.pinnedHorizontalProjects ? 'pin-horizontal-section' : ''}">
      <div class="section-container">
        <div class="section-header-row">
          <div>
            <div class="section-tag">${isRtl ? '// نمونه آثار و پروژه‌ها' : '// SELECTED WORKS'}</div>
            <h2 class="section-heading">${isRtl ? 'شاهکارهای تعاملی' : 'Featured Creations'}</h2>
          </div>
          <div class="section-meta-info">
            <span>[ ${config.projects.length} ${isRtl ? 'پروژه منتخب' : 'PROJECTS'} ]</span>
          </div>
        </div>

        <div class="projects-wrapper ${config.gsapConfig.pinnedHorizontalProjects ? 'horizontal-track' : 'projects-grid'}">
          ${config.projects.map((p, idx) => `
          <article class="project-card tilt-card" data-idx="${idx + 1}">
            <div class="project-img-box">
              <img src="${p.image}" alt="${this.escapeHtml(p.title)}" class="parallax-img" loading="lazy">
              <div class="project-category-tag">${this.escapeHtml(p.category)}</div>
            </div>
            <div class="project-info">
              <div class="project-meta">
                <span class="project-year">${p.year}</span>
                <span class="project-num">0${idx + 1}</span>
              </div>
              <h3 class="project-title">${this.escapeHtml(p.title)}</h3>
              <p class="project-desc">${this.escapeHtml(p.description)}</p>
              <a href="${p.link}" class="project-link magnetic-btn">
                <span>${isRtl ? 'مشاهده جزئیات' : 'Explore Case'}</span>
                <span class="material-icons">${isRtl ? 'arrow_backward' : 'arrow_forward'}</span>
              </a>
            </div>
          </article>
          `).join('')}
        </div>
      </div>
    </section>
    ` : ''}

    <!-- SERVICES / CAPABILITIES -->
    ${config.sections.showServices ? `
    <section id="services" class="services-section">
      <div class="section-container">
        <div class="section-tag">${isRtl ? '// مهارت‌ها و قابلیت‌ها' : '// CAPABILITIES'}</div>
        <h2 class="section-heading">${isRtl ? 'تخصص‌های مهندسی وب خلاق' : 'Engineering Aesthetics'}</h2>

        <div class="services-grid">
          ${config.services.map((svc, idx) => `
          <div class="service-card tilt-card">
            <div class="service-card-glow"></div>
            <div class="service-header">
              <span class="service-idx">0${idx + 1}</span>
              <span class="material-icons service-icon">${svc.icon || 'star'}</span>
            </div>
            <h3 class="service-title">${this.escapeHtml(svc.title)}</h3>
            <p class="service-desc">${this.escapeHtml(svc.desc)}</p>
            <div class="service-footer">
              <span class="service-pill">GSAP + WebGL</span>
            </div>
          </div>
          `).join('')}
        </div>
      </div>
    </section>
    ` : ''}

    <!-- CONTACT SECTION -->
    ${config.sections.showContact ? `
    <section id="contact" class="contact-section">
      <div class="section-container">
        <div class="contact-box">
          <div class="contact-glow"></div>
          <div class="section-tag">${isRtl ? '// آغاز همکاری' : '// GET IN TOUCH'}</div>
          <h2 class="contact-title">${this.escapeHtml(config.contact.title)}</h2>
          <p class="contact-subtitle">
            ${isRtl ? 'برای خلق یک وب‌سایت استثنایی و برنده جوایز بین‌المللی با ما در ارتباط باشید.' : 'Drop us a message to transform your vision into an interactive reality.'}
          </p>

          <div class="contact-details-grid">
            <div class="contact-detail-item">
              <span class="material-icons">mail</span>
              <a href="mailto:${config.contact.email}" class="contact-link">${config.contact.email}</a>
            </div>
            <div class="contact-detail-item">
              <span class="material-icons">phone</span>
              <a href="tel:${config.contact.phone}" class="contact-link">${config.contact.phone}</a>
            </div>
            <div class="contact-detail-item">
              <span class="material-icons">place</span>
              <span>${config.contact.location}</span>
            </div>
          </div>

          <div class="socials-list">
            ${config.contact.socials.map(s => `
            <a href="${s.url}" target="_blank" rel="noopener noreferrer" class="social-btn magnetic-btn">
              <span>${this.escapeHtml(s.name)}</span>
              <span class="material-icons">north_east</span>
            </a>
            `).join('')}
          </div>
        </div>
      </div>
    </section>
    ` : ''}

  </main>

  <!-- FOOTER -->
  <footer class="site-footer">
    <div class="footer-container">
      <div class="footer-left">
        <span class="footer-brand">${this.escapeHtml(config.brandName)}</span>
        <span class="footer-copy">© 2025. ${isRtl ? 'تمامی حقوق محفوظ است.' : 'All rights reserved.'}</span>
      </div>

      <div class="footer-center">
        <span class="tech-pill">Lenis Smooth Scroll</span>
        <span class="tech-pill">GSAP & ScrollTrigger</span>
        <span class="tech-pill">WebGL / Three.js</span>
        <span class="tech-pill">GitHub Pages Ready</span>
      </div>

      <div class="footer-right">
        <button id="back-to-top-btn" class="back-to-top magnetic-btn">
          <span class="material-icons">arrow_upward</span>
          <span>${isRtl ? 'بالای صفحه' : 'Back to top'}</span>
        </button>
      </div>
    </div>
  </footer>

  <!-- SCRIPT INITIALIZATION -->
  <script>
${jsContent}
  </script>
</body>
</html>`;
  }

  /**
   * Generates custom CSS tailored to theme & responsiveness
   */
  generateCss(config: SiteConfig): string {
    const isRtl = config.language === 'fa';
    const primary = config.theme.primaryColor;
    const secondary = config.theme.secondaryColor;
    const accent = config.theme.accentColor;
    const bg = config.theme.bgColor;
    const surface = config.theme.surfaceColor;
    const text = config.theme.textColor;

    return `/* ==========================================================================
   Lenis & GSAP WebGL Studio - GitHub Pages Ready Stylesheet
   ========================================================================== */

:root {
  --primary: ${primary};
  --secondary: ${secondary};
  --accent: ${accent};
  --bg: ${bg};
  --surface: ${surface};
  --text: ${text};
  --text-muted: #94a3b8;
  --border: rgba(255, 255, 255, 0.1);
  --border-glow: rgba(${this.hexToRgb(primary)}, 0.35);
  --glass-bg: rgba(${this.hexToRgb(surface)}, 0.65);
  --font-main: ${isRtl ? "'Vazirmatn', sans-serif" : "'Plus Jakarta Sans', sans-serif"};
  --font-display: ${isRtl ? "'Vazirmatn', 'Syne', sans-serif" : "'Syne', 'Space Grotesk', sans-serif"};
  --font-mono: 'JetBrains Mono', monospace;
}

*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

html {
  font-size: 16px;
  background-color: var(--bg);
  color: var(--text);
  font-family: var(--font-main);
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  overflow-x: hidden;
}

/* ==========================================================================
   Lenis Smooth Scroll Recommended Styles
   ========================================================================== */
html.lenis, html.lenis body {
  height: auto;
}

.lenis.lenis-smooth {
  scroll-behavior: auto !important;
}

.lenis.lenis-smooth [data-lenis-prevent] {
  overscroll-behavior: contain;
}

.lenis.lenis-stopped {
  overflow: hidden;
}

.lenis.lenis-smooth iframe {
  pointer-events: none;
}

body {
  position: relative;
  background-color: var(--bg);
  color: var(--text);
  line-height: 1.6;
  min-height: 100vh;
  overflow-x: hidden;
}

/* Selection */
::selection {
  background: rgba(${this.hexToRgb(primary)}, 0.3);
  color: #ffffff;
}

/* ==========================================================================
   WebGL Canvas
   ========================================================================== */
#webgl-canvas {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  pointer-events: none;
  z-index: 0;
}

/* ==========================================================================
   Scroll Progress Bar
   ========================================================================== */
.scroll-progress-bar {
  position: fixed;
  top: 0;
  left: 0;
  width: 0%;
  height: 3px;
  background: linear-gradient(90deg, var(--primary), var(--secondary), var(--accent));
  z-index: 9999;
  transition: width 0.05s linear;
  box-shadow: 0 0 10px var(--primary);
}

/* ==========================================================================
   Magnetic Custom Cursor
   ========================================================================== */
.cursor-dot {
  position: fixed;
  top: 0;
  left: 0;
  width: 8px;
  height: 8px;
  background-color: var(--primary);
  border-radius: 50%;
  pointer-events: none;
  z-index: 9998;
  transform: translate(-50%, -50%);
  transition: transform 0.08s ease-out, opacity 0.3s;
}

.cursor-outline {
  position: fixed;
  top: 0;
  left: 0;
  width: 36px;
  height: 36px;
  border: 1.5px solid rgba(${this.hexToRgb(primary)}, 0.5);
  border-radius: 50%;
  pointer-events: none;
  z-index: 9997;
  transform: translate(-50%, -50%);
  transition: width 0.25s ease-out, height 0.25s ease-out, border-color 0.25s ease-out, background-color 0.25s;
}

.cursor-hover .cursor-outline {
  width: 60px;
  height: 60px;
  border-color: var(--accent);
  background-color: rgba(${this.hexToRgb(primary)}, 0.15);
  backdrop-filter: invert(0.2);
}

@media (pointer: coarse) {
  .cursor-dot, .cursor-outline {
    display: none !important;
  }
}

/* ==========================================================================
   Header & Navigation
   ========================================================================== */
.site-header {
  position: fixed;
  top: 1.25rem;
  left: 50%;
  transform: translateX(-50%);
  width: calc(100% - 2.5rem);
  max-width: 1200px;
  z-index: 1000;
}

.header-container {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0.75rem 1.5rem;
  background: var(--glass-bg);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  border: 1px solid var(--border);
  border-radius: 9999px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.4);
}

.brand-logo {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  text-decoration: none;
  color: var(--text);
  font-weight: 800;
  font-size: 1.15rem;
  letter-spacing: -0.02em;
}

.logo-symbol {
  color: var(--primary);
  font-size: 1.3rem;
  display: inline-block;
  animation: pulse-symbol 4s infinite ease-in-out;
}

@keyframes pulse-symbol {
  0%, 100% { transform: scale(1) rotate(0deg); opacity: 0.9; }
  50% { transform: scale(1.15) rotate(180deg); opacity: 1; filter: drop-shadow(0 0 8px var(--primary)); }
}

.nav-links {
  display: flex;
  align-items: center;
  gap: 1.75rem;
}

.nav-link {
  color: var(--text-muted);
  text-decoration: none;
  font-size: 0.9rem;
  font-weight: 500;
  transition: color 0.25s;
  position: relative;
}

.nav-link:hover {
  color: var(--primary);
}

.header-cta {
  display: flex;
  align-items: center;
  gap: 0.4rem;
  padding: 0.5rem 1.25rem;
  background: linear-gradient(135deg, var(--primary), var(--secondary));
  color: #000;
  font-weight: 700;
  font-size: 0.85rem;
  text-decoration: none;
  border-radius: 9999px;
  transition: transform 0.25s, box-shadow 0.25s;
  box-shadow: 0 4px 15px rgba(${this.hexToRgb(primary)}, 0.35);
}

.header-cta:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 22px rgba(${this.hexToRgb(primary)}, 0.6);
}

.cta-icon {
  font-size: 1rem;
}

@media (max-width: 768px) {
  .nav-links { display: none; }
  .header-container { padding: 0.6rem 1rem; }
}

/* ==========================================================================
   Page Content & Layout
   ========================================================================== */
.page-content {
  position: relative;
  z-index: 10;
}

.section-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 6rem 1.5rem;
}

.section-tag {
  font-family: var(--font-mono);
  font-size: 0.85rem;
  color: var(--primary);
  text-transform: uppercase;
  letter-spacing: 0.1em;
  margin-bottom: 0.75rem;
  font-weight: 600;
}

.section-heading {
  font-family: var(--font-display);
  font-size: clamp(2rem, 4vw, 3.25rem);
  font-weight: 800;
  line-height: 1.15;
  margin-bottom: 2rem;
  background: linear-gradient(180deg, #ffffff 40%, rgba(255, 255, 255, 0.7) 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}

/* ==========================================================================
   HERO SECTION
   ========================================================================== */
.hero-section {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  padding: 8rem 1.5rem 4rem;
  text-align: center;
}

.hero-inner {
  max-width: 950px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.hero-badge {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.4rem 1rem;
  background: var(--glass-bg);
  border: 1px solid var(--border-glow);
  border-radius: 9999px;
  font-size: 0.85rem;
  font-weight: 600;
  color: var(--primary);
  margin-bottom: 1.75rem;
  backdrop-filter: blur(10px);
}

.badge-dot {
  width: 7px;
  height: 7px;
  background: var(--primary);
  border-radius: 50%;
  box-shadow: 0 0 10px var(--primary);
  animation: blink 2s infinite ease-in-out;
}

@keyframes blink {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.4; transform: scale(0.8); }
}

.hero-title {
  font-family: var(--font-display);
  font-size: clamp(2.5rem, 6.5vw, 5.25rem);
  font-weight: 900;
  line-height: 1.08;
  letter-spacing: -0.03em;
  margin-bottom: 1.5rem;
  text-transform: uppercase;
  word-break: break-word;
}

.hero-title .char {
  display: inline-block;
  transform-origin: center bottom;
  will-change: transform, opacity;
}

.hero-subtitle {
  font-size: clamp(1rem, 1.8vw, 1.25rem);
  color: var(--text-muted);
  max-width: 680px;
  margin-bottom: 2.5rem;
  line-height: 1.7;
}

.hero-actions {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 1.25rem;
  flex-wrap: wrap;
  margin-bottom: 4rem;
}

.btn-primary {
  display: inline-flex;
  align-items: center;
  gap: 0.6rem;
  padding: 0.9rem 2.2rem;
  background: linear-gradient(135deg, var(--primary), var(--secondary));
  color: #040810;
  font-weight: 800;
  font-size: 1rem;
  text-decoration: none;
  border-radius: 9999px;
  transition: transform 0.25s, box-shadow 0.25s;
  box-shadow: 0 8px 25px rgba(${this.hexToRgb(primary)}, 0.4);
}

.btn-primary:hover {
  transform: translateY(-3px) scale(1.02);
  box-shadow: 0 12px 35px rgba(${this.hexToRgb(primary)}, 0.6);
}

.btn-secondary {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.9rem 2rem;
  background: var(--glass-bg);
  border: 1px solid var(--border);
  color: var(--text);
  font-weight: 600;
  font-size: 1rem;
  text-decoration: none;
  border-radius: 9999px;
  backdrop-filter: blur(12px);
  transition: background 0.25s, border-color 0.25s, transform 0.25s;
}

.btn-secondary:hover {
  background: rgba(255, 255, 255, 0.1);
  border-color: rgba(255, 255, 255, 0.3);
  transform: translateY(-2px);
}

.hero-scroll-cue {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 0.6rem;
  opacity: 0.7;
}

.mouse-icon {
  width: 22px;
  height: 36px;
  border: 2px solid var(--primary);
  border-radius: 12px;
  display: flex;
  justify-content: center;
  padding-top: 5px;
}

.wheel {
  width: 4px;
  height: 8px;
  background: var(--primary);
  border-radius: 2px;
  animation: mouse-wheel 1.6s infinite ease-in-out;
}

@keyframes mouse-wheel {
  0% { transform: translateY(0); opacity: 1; }
  100% { transform: translateY(12px); opacity: 0; }
}

.scroll-label {
  font-family: var(--font-mono);
  font-size: 0.75rem;
  letter-spacing: 0.15em;
  text-transform: uppercase;
}

/* ==========================================================================
   ABOUT SECTION
   ========================================================================== */
.about-grid {
  display: grid;
  grid-template-columns: 1.2fr 0.8fr;
  gap: 4rem;
  align-items: center;
}

@media (max-width: 900px) {
  .about-grid { grid-template-columns: 1fr; gap: 3rem; }
}

.about-tagline {
  font-size: 1.35rem;
  font-weight: 700;
  color: var(--accent);
  margin-bottom: 1.25rem;
}

.about-text {
  color: var(--text-muted);
  font-size: 1.05rem;
  line-height: 1.8;
  margin-bottom: 2rem;
}

.about-highlights {
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
}

.highlight-item {
  display: flex;
  align-items: center;
  gap: 1.25rem;
  padding: 1rem 1.5rem;
  background: var(--glass-bg);
  border: 1px solid var(--border);
  border-radius: 12px;
  transition: transform 0.3s, border-color 0.3s;
}

.highlight-item:hover {
  transform: translateX(${isRtl ? '-8px' : '8px'});
  border-color: var(--primary);
}

.highlight-num {
  font-family: var(--font-mono);
  font-size: 1.1rem;
  color: var(--primary);
  font-weight: 700;
}

.highlight-title {
  font-weight: 600;
  font-size: 0.95rem;
}

.media-frame {
  position: relative;
  border-radius: 20px;
  overflow: hidden;
  border: 1px solid var(--border-glow);
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.6);
  aspect-ratio: 4/5;
  transform-style: preserve-3d;
}

.media-frame img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.6s ease-out;
}

.media-overlay {
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, transparent 40%, rgba(0, 0, 0, 0.8) 100%);
}

.floating-badge {
  position: absolute;
  bottom: 1.5rem;
  left: 1.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  padding: 0.6rem 1.2rem;
  background: rgba(0, 0, 0, 0.7);
  border: 1px solid var(--primary);
  border-radius: 9999px;
  font-size: 0.85rem;
  font-weight: 700;
  backdrop-filter: blur(12px);
  color: var(--primary);
}

/* ==========================================================================
   STATS SECTION
   ========================================================================== */
.stats-section {
  border-top: 1px solid var(--border);
  border-bottom: 1px solid var(--border);
  background: rgba(0, 0, 0, 0.3);
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 2rem;
  text-align: center;
}

.stat-card {
  padding: 1.5rem;
}

.stat-val {
  font-family: var(--font-display);
  font-size: clamp(2.5rem, 4vw, 3.5rem);
  font-weight: 900;
  color: var(--primary);
  margin-bottom: 0.4rem;
  text-shadow: 0 0 20px rgba(${this.hexToRgb(primary)}, 0.4);
}

.stat-lbl {
  color: var(--text-muted);
  font-size: 0.95rem;
  font-weight: 500;
}

/* ==========================================================================
   PROJECTS SHOWCASE
   ========================================================================== */
.section-header-row {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  margin-bottom: 3.5rem;
}

.section-meta-info {
  font-family: var(--font-mono);
  color: var(--text-muted);
  font-size: 0.9rem;
}

.projects-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
  gap: 2.5rem;
}

.project-card {
  background: var(--glass-bg);
  border: 1px solid var(--border);
  border-radius: 20px;
  overflow: hidden;
  transition: transform 0.4s ease-out, border-color 0.4s, box-shadow 0.4s;
  display: flex;
  flex-direction: column;
}

.project-card:hover {
  border-color: var(--primary);
  box-shadow: 0 15px 40px rgba(${this.hexToRgb(primary)}, 0.2);
  transform: translateY(-8px);
}

.project-img-box {
  position: relative;
  aspect-ratio: 16/10;
  overflow: hidden;
}

.project-img-box img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.7s cubic-bezier(0.16, 1, 0.3, 1);
}

.project-card:hover .project-img-box img {
  transform: scale(1.08);
}

.project-category-tag {
  position: absolute;
  top: 1rem;
  ${isRtl ? 'right: 1rem;' : 'left: 1rem;'}
  padding: 0.35rem 0.85rem;
  background: rgba(0, 0, 0, 0.75);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 9999px;
  font-size: 0.75rem;
  font-weight: 600;
  backdrop-filter: blur(8px);
  color: var(--accent);
}

.project-info {
  padding: 1.75rem;
  display: flex;
  flex-direction: column;
  flex: 1;
}

.project-meta {
  display: flex;
  justify-content: space-between;
  font-family: var(--font-mono);
  font-size: 0.85rem;
  color: var(--text-muted);
  margin-bottom: 0.75rem;
}

.project-num {
  color: var(--primary);
  font-weight: 700;
}

.project-title {
  font-family: var(--font-display);
  font-size: 1.4rem;
  font-weight: 800;
  margin-bottom: 0.75rem;
  color: #fff;
}

.project-desc {
  color: var(--text-muted);
  font-size: 0.9rem;
  line-height: 1.6;
  margin-bottom: 1.5rem;
  flex: 1;
}

.project-link {
  display: inline-flex;
  align-items: center;
  gap: 0.5rem;
  color: var(--primary);
  text-decoration: none;
  font-weight: 700;
  font-size: 0.9rem;
  transition: gap 0.25s, color 0.25s;
}

.project-link:hover {
  color: #fff;
  gap: 0.8rem;
}

/* ==========================================================================
   SERVICES SECTION
   ========================================================================== */
.services-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  margin-top: 2.5rem;
}

.service-card {
  position: relative;
  background: var(--glass-bg);
  border: 1px solid var(--border);
  border-radius: 20px;
  padding: 2.5rem 2rem;
  overflow: hidden;
  transition: transform 0.35s, border-color 0.35s;
}

.service-card:hover {
  transform: translateY(-6px);
  border-color: var(--secondary);
}

.service-card-glow {
  position: absolute;
  top: -50px;
  ${isRtl ? 'left: -50px;' : 'right: -50px;'}
  width: 120px;
  height: 120px;
  background: radial-gradient(circle, rgba(${this.hexToRgb(secondary)}, 0.4) 0%, transparent 70%);
  opacity: 0;
  transition: opacity 0.4s;
  pointer-events: none;
}

.service-card:hover .service-card-glow {
  opacity: 1;
}

.service-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1.75rem;
}

.service-idx {
  font-family: var(--font-mono);
  font-size: 1.1rem;
  font-weight: 700;
  color: var(--primary);
}

.service-icon {
  font-size: 2.2rem;
  color: var(--accent);
}

.service-title {
  font-family: var(--font-display);
  font-size: 1.35rem;
  font-weight: 700;
  margin-bottom: 1rem;
  color: #fff;
}

.service-desc {
  color: var(--text-muted);
  font-size: 0.95rem;
  line-height: 1.7;
  margin-bottom: 2rem;
}

.service-pill {
  display: inline-block;
  padding: 0.3rem 0.8rem;
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid var(--border);
  border-radius: 9999px;
  font-size: 0.75rem;
  font-family: var(--font-mono);
  color: var(--text-muted);
}

/* ==========================================================================
   CONTACT SECTION
   ========================================================================== */
.contact-box {
  position: relative;
  background: radial-gradient(circle at center, rgba(${this.hexToRgb(surface)}, 0.9) 0%, var(--surface) 100%);
  border: 1px solid var(--border-glow);
  border-radius: 30px;
  padding: 4.5rem 2.5rem;
  text-align: center;
  overflow: hidden;
  box-shadow: 0 25px 60px rgba(0, 0, 0, 0.5);
}

.contact-glow {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 400px;
  height: 400px;
  background: radial-gradient(circle, rgba(${this.hexToRgb(primary)}, 0.15) 0%, transparent 70%);
  pointer-events: none;
}

.contact-title {
  font-family: var(--font-display);
  font-size: clamp(2rem, 4vw, 3.25rem);
  font-weight: 900;
  margin-bottom: 1rem;
}

.contact-subtitle {
  color: var(--text-muted);
  font-size: 1.1rem;
  max-width: 600px;
  margin: 0 auto 3rem;
}

.contact-details-grid {
  display: flex;
  justify-content: center;
  gap: 2.5rem;
  flex-wrap: wrap;
  margin-bottom: 3rem;
}

.contact-detail-item {
  display: flex;
  align-items: center;
  gap: 0.6rem;
  color: var(--text-muted);
  font-size: 1rem;
}

.contact-detail-item .material-icons {
  color: var(--primary);
}

.contact-link {
  color: var(--text);
  text-decoration: none;
  font-weight: 600;
  transition: color 0.2s;
}

.contact-link:hover {
  color: var(--primary);
}

.socials-list {
  display: flex;
  justify-content: center;
  gap: 1rem;
  flex-wrap: wrap;
}

.social-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  padding: 0.6rem 1.4rem;
  background: var(--glass-bg);
  border: 1px solid var(--border);
  border-radius: 9999px;
  color: var(--text);
  text-decoration: none;
  font-size: 0.9rem;
  font-weight: 600;
  transition: all 0.25s;
}

.social-btn .material-icons {
  font-size: 1rem;
}

.social-btn:hover {
  background: var(--primary);
  color: #000;
  border-color: var(--primary);
  transform: translateY(-2px);
}

/* ==========================================================================
   FOOTER
   ========================================================================== */
.site-footer {
  border-top: 1px solid var(--border);
  padding: 2.5rem 1.5rem;
  background: #020408;
  position: relative;
  z-index: 10;
}

.footer-container {
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  gap: 1.5rem;
}

.footer-brand {
  font-weight: 800;
  margin-right: 1rem;
  color: #fff;
}

.footer-copy {
  color: var(--text-muted);
  font-size: 0.85rem;
}

.footer-center {
  display: flex;
  gap: 0.5rem;
  flex-wrap: wrap;
}

.tech-pill {
  padding: 0.25rem 0.65rem;
  background: rgba(255, 255, 255, 0.05);
  border-radius: 6px;
  font-family: var(--font-mono);
  font-size: 0.75rem;
  color: var(--text-muted);
}

.back-to-top {
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  background: transparent;
  border: 1px solid var(--border);
  color: var(--text-muted);
  padding: 0.5rem 1rem;
  border-radius: 9999px;
  font-size: 0.85rem;
  cursor: pointer;
  transition: all 0.25s;
}

.back-to-top:hover {
  border-color: var(--primary);
  color: var(--primary);
}
`;
  }

  /**
   * Generates pure Vanilla JavaScript controlling Lenis, GSAP, and WebGL
   */
  generateJs(config: SiteConfig): string {
    const webglCode = this.generateWebglScript(config.webglEffect, config);

    return `/* ==========================================================================
   Lenis Smooth Scroll + GSAP ScrollTrigger + WebGL Controller
   Pure Vanilla JS - 100% Zero-Build Standalone for GitHub Pages
   ========================================================================== */

(function () {
  'use strict';

  // 1. Initialize Lenis Smooth Scroll
  let lenis = null;
  if (typeof Lenis !== 'undefined') {
    lenis = new Lenis({
      lerp: ${config.lenisConfig.lerp},
      smoothWheel: ${config.lenisConfig.smoothWheel},
      syncTouch: ${config.lenisConfig.smoothTouch},
      touchMultiplier: ${config.lenisConfig.touchMultiplier},
      direction: '${config.lenisConfig.direction}',
      infinite: false,
    });

    // Back to top smooth trigger
    const bttBtn = document.getElementById('back-to-top-btn');
    if (bttBtn) {
      bttBtn.addEventListener('click', () => {
        lenis.scrollTo(0, { duration: 1.5 });
      });
    }

    // Anchor links smooth scroll
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        const targetId = this.getAttribute('href');
        if (targetId && targetId !== '#') {
          const targetEl = document.querySelector(targetId);
          if (targetEl) {
            e.preventDefault();
            lenis.scrollTo(targetEl, { offset: -60, duration: 1.2 });
          }
        }
      });
    });
  }

  // 2. Synchronize Lenis with GSAP ScrollTrigger
  if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
    gsap.registerPlugin(ScrollTrigger);

    if (lenis) {
      lenis.on('scroll', ScrollTrigger.update);

      gsap.ticker.add((time) => {
        lenis.raf(time * 1000);
      });

      gsap.ticker.lagSmoothing(0);
    } else {
      // Fallback RAF if Lenis fails to load
      function raf(time) {
        requestAnimationFrame(raf);
      }
      requestAnimationFrame(raf);
    }

    // Scroll progress bar indicator
    const progressBar = document.querySelector('.scroll-progress-bar');
    if (progressBar) {
      window.addEventListener('scroll', () => {
        const scrollTop = window.scrollY || document.documentElement.scrollTop;
        const docHeight = document.documentElement.scrollHeight - window.innerHeight;
        const progress = (scrollTop / (docHeight || 1)) * 100;
        progressBar.style.width = progress + '%';
      });
    }

    // GSAP Split Headline Reveal
    ${config.gsapConfig.splitTextAnimation ? `
    const heroChars = document.querySelectorAll('.hero-title .char');
    if (heroChars.length > 0) {
      gsap.fromTo(heroChars, 
        { y: 60, opacity: 0, rotateZ: 5 },
        { 
          y: 0, 
          opacity: 1, 
          rotateZ: 0, 
          duration: 1, 
          stagger: 0.03, 
          ease: 'power3.out',
          delay: 0.2
        }
      );
    }
    ` : ''}

    // General reveal elements in Hero
    gsap.fromTo('.reveal-elem', 
      { y: 30, opacity: 0 },
      { y: 0, opacity: 1, duration: 0.8, stagger: 0.15, ease: 'power2.out', delay: 0.5 }
    );

    // GSAP ScrollTrigger Heading Reveals
    document.querySelectorAll('.section-heading').forEach(heading => {
      gsap.fromTo(heading, 
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.9,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: heading,
            start: 'top 85%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    });

    // Parallax Image Effect
    ${config.gsapConfig.parallaxImages ? `
    document.querySelectorAll('.parallax-img').forEach(img => {
      gsap.fromTo(img, 
        { yPercent: -12, scale: 1.05 },
        {
          yPercent: 12,
          ease: 'none',
          scrollTrigger: {
            trigger: img.parentElement,
            start: 'top bottom',
            end: 'bottom top',
            scrub: true
          }
        }
      );
    });
    ` : ''}

    // Animated Number Counters
    ${config.gsapConfig.counterStats ? `
    document.querySelectorAll('.counter-target').forEach(counter => {
      const rawText = counter.getAttribute('data-target') || counter.innerText;
      const numMatch = rawText.match(/[\\d\\.]+/);
      if (numMatch) {
        const finalNum = parseFloat(numMatch[0]);
        const prefix = rawText.split(numMatch[0])[0] || '';
        const suffix = rawText.split(numMatch[0])[1] || '';
        const obj = { val: 0 };

        gsap.to(obj, {
          val: finalNum,
          duration: 2,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: counter,
            start: 'top 85%',
            once: true
          },
          onUpdate: function () {
            counter.innerText = prefix + (Number.isInteger(finalNum) ? Math.floor(obj.val) : obj.val.toFixed(1)) + suffix;
          }
        });
      }
    });
    ` : ''}
  }

  // 3. Magnetic Custom Cursor
  ${config.gsapConfig.magneticCursor ? `
  const cursorDot = document.querySelector('.cursor-dot');
  const cursorOutline = document.querySelector('.cursor-outline');

  if (cursorDot && cursorOutline && window.matchMedia('(pointer: fine)').matches) {
    let mouseX = window.innerWidth / 2;
    let mouseY = window.innerHeight / 2;
    let outlineX = mouseX;
    let outlineY = mouseY;

    window.addEventListener('mousemove', (e) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      cursorDot.style.left = mouseX + 'px';
      cursorDot.style.top = mouseY + 'px';
    });

    function animateCursor() {
      outlineX += (mouseX - outlineX) * 0.15;
      outlineY += (mouseY - outlineY) * 0.15;
      cursorOutline.style.left = outlineX + 'px';
      cursorOutline.style.top = outlineY + 'px';
      requestAnimationFrame(animateCursor);
    }
    requestAnimationFrame(animateCursor);

    // Interactive Hover Elements
    const hoverTargets = document.querySelectorAll('a, button, .tilt-card, .magnetic-btn, .magnetic-target');
    hoverTargets.forEach(el => {
      el.addEventListener('mouseenter', () => document.body.classList.add('cursor-hover'));
      el.addEventListener('mouseleave', () => document.body.classList.remove('cursor-hover'));
    });
  }
  ` : ''}

  // 4. Magnetic Buttons Attraction
  ${config.gsapConfig.magneticButtons ? `
  document.querySelectorAll('.magnetic-btn').forEach(btn => {
    btn.addEventListener('mousemove', function (e) {
      const rect = this.getBoundingClientRect();
      const x = e.clientX - rect.left - rect.width / 2;
      const y = e.clientY - rect.top - rect.height / 2;
      this.style.transform = \`translate(\${x * 0.28}px, \${y * 0.28}px)\`;
    });
    btn.addEventListener('mouseleave', function () {
      this.style.transform = 'translate(0px, 0px)';
      this.style.transition = 'transform 0.5s cubic-bezier(0.2, 1, 0.3, 1)';
    });
    btn.addEventListener('mouseenter', function () {
      this.style.transition = 'none';
    });
  });
  ` : ''}

  // 5. 3D Tilt Card on Mousemove
  ${config.gsapConfig.cardTiltHover ? `
  document.querySelectorAll('.tilt-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      const rotateX = ((y - centerY) / centerY) * -7;
      const rotateY = ((x - centerX) / centerX) * 7;
      card.style.transform = \`perspective(1000px) rotateX(\${rotateX}deg) rotateY(\${rotateY}deg) translateY(-4px)\`;
    });

    card.addEventListener('mouseleave', () => {
      card.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateY(0px)';
      card.style.transition = 'transform 0.5s ease-out';
    });

    card.addEventListener('mouseenter', () => {
      card.style.transition = 'none';
    });
  });
  ` : ''}

  // 6. Initialize WebGL Shader / Three.js Canvas
  ${webglCode}

})();
`;
  }

  /**
   * Generates the WebGL script code based on selected effect
   */
  private generateWebglScript(effect: WebglEffectType, config: SiteConfig): string {
    const primaryHex = config.theme.primaryColor;
    const secondaryHex = config.theme.secondaryColor;
    const speed = config.webglConfig.speed || 1;
    const count = config.webglConfig.particleCount || 1500;

    switch (effect) {
      case 'wave-mesh':
        return `
    // WebGL Three.js Wave Grid Mesh
    try {
      const canvas = document.getElementById('webgl-canvas');
      if (canvas && typeof THREE !== 'undefined') {
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(65, window.innerWidth / window.innerHeight, 0.1, 1000);
        camera.position.set(0, 8, 20);
        camera.lookAt(0, 0, 0);

        const renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true, antialias: true, powerPreference: 'high-performance' });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

        const width = 60;
        const height = 45;
        const segmentsW = 50;
        const segmentsH = 40;
        const geometry = new THREE.PlaneGeometry(width, height, segmentsW, segmentsH);

        const material = new THREE.MeshBasicMaterial({
          color: new THREE.Color('${primaryHex}'),
          wireframe: true,
          transparent: true,
          opacity: 0.35,
        });

        const plane = new THREE.Mesh(geometry, material);
        plane.rotation.x = -Math.PI / 2.3;
        plane.position.y = -4;
        scene.add(plane);

        // Ambient glow points
        const pointGeo = new THREE.BufferGeometry();
        const positions = new Float32Array(${count} * 3);
        for (let i = 0; i < ${count} * 3; i += 3) {
          positions[i] = (Math.random() - 0.5) * 80;
          positions[i + 1] = (Math.random() - 0.5) * 40;
          positions[i + 2] = (Math.random() - 0.5) * 60;
        }
        pointGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        const pointMat = new THREE.PointsMaterial({
          color: new THREE.Color('${secondaryHex}'),
          size: 0.15,
          transparent: true,
          opacity: 0.5,
        });
        const particles = new THREE.Points(pointGeo, pointMat);
        scene.add(particles);

        let mouseX = 0;
        let mouseY = 0;
        window.addEventListener('mousemove', (e) => {
          mouseX = (e.clientX / window.innerWidth) * 2 - 1;
          mouseY = -(e.clientY / window.innerHeight) * 2 + 1;
        });

        let clock = new THREE.Clock();
        const posAttr = geometry.attributes.position;
        const origZ = [];
        for (let i = 0; i < posAttr.count; i++) {
          origZ.push(posAttr.getZ(i));
        }

        function renderWebGL() {
          const t = clock.getElapsedTime() * ${speed};

          // Sinusoidal wave propagation
          for (let i = 0; i < posAttr.count; i++) {
            const u = posAttr.getX(i);
            const v = posAttr.getY(i);
            const z = Math.sin(u * 0.2 + t) * 1.5 + Math.cos(v * 0.25 + t * 0.8) * 1.2;
            posAttr.setZ(i, z);
          }
          posAttr.needsUpdate = true;

          // Parallax camera easing
          camera.position.x += (mouseX * 4 - camera.position.x) * 0.05;
          camera.position.y += (8 + mouseY * 2 - camera.position.y) * 0.05;
          camera.lookAt(0, 0, 0);

          particles.rotation.y = t * 0.05;

          renderer.render(scene, camera);
          requestAnimationFrame(renderWebGL);
        }
        renderWebGL();

        window.addEventListener('resize', () => {
          camera.aspect = window.innerWidth / window.innerHeight;
          camera.updateProjectionMatrix();
          renderer.setSize(window.innerWidth, window.innerHeight);
        });
      }
    } catch (e) {
      console.warn('WebGL init skipped:', e);
    }
        `;

      case 'cosmic-particles':
        return `
    // WebGL Cosmic Particle Field
    try {
      const canvas = document.getElementById('webgl-canvas');
      if (canvas && typeof THREE !== 'undefined') {
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 1, 1000);
        camera.position.z = 250;

        const renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true, antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

        const pCount = ${count};
        const geometry = new THREE.BufferGeometry();
        const positions = new Float32Array(pCount * 3);
        const colors = new Float32Array(pCount * 3);
        const col1 = new THREE.Color('${primaryHex}');
        const col2 = new THREE.Color('${secondaryHex}');

        for (let i = 0; i < pCount; i++) {
          positions[i * 3] = (Math.random() - 0.5) * 600;
          positions[i * 3 + 1] = (Math.random() - 0.5) * 600;
          positions[i * 3 + 2] = (Math.random() - 0.5) * 600;

          const mixed = col1.clone().lerp(col2, Math.random());
          colors[i * 3] = mixed.r;
          colors[i * 3 + 1] = mixed.g;
          colors[i * 3 + 2] = mixed.b;
        }

        geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

        const material = new THREE.PointsMaterial({
          size: 2.2,
          vertexColors: true,
          transparent: true,
          opacity: 0.75,
          blending: THREE.AdditiveBlending,
        });

        const particles = new THREE.Points(geometry, material);
        scene.add(particles);

        let mouseX = 0, mouseY = 0;
        window.addEventListener('mousemove', (e) => {
          mouseX = (e.clientX - window.innerWidth / 2) * 0.1;
          mouseY = (e.clientY - window.innerHeight / 2) * 0.1;
        });

        let clock = new THREE.Clock();
        function animate() {
          const t = clock.getElapsedTime() * ${speed};
          particles.rotation.x = t * 0.05;
          particles.rotation.y = t * 0.08;

          camera.position.x += (mouseX - camera.position.x) * 0.04;
          camera.position.y += (-mouseY - camera.position.y) * 0.04;

          renderer.render(scene, camera);
          requestAnimationFrame(animate);
        }
        animate();

        window.addEventListener('resize', () => {
          camera.aspect = window.innerWidth / window.innerHeight;
          camera.updateProjectionMatrix();
          renderer.setSize(window.innerWidth, window.innerHeight);
        });
      }
    } catch (e) {
      console.warn('WebGL Cosmic Particles init error:', e);
    }
        `;

      case 'torus-knot':
        return `
    // WebGL 3D Holographic Torus Knot
    try {
      const canvas = document.getElementById('webgl-canvas');
      if (canvas && typeof THREE !== 'undefined') {
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 100);
        camera.position.z = 18;

        const renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true, antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

        const geometry = new THREE.TorusKnotGeometry(4.8, 1.4, 128, 32, 2, 3);
        const material = new THREE.MeshBasicMaterial({
          color: new THREE.Color('${primaryHex}'),
          wireframe: true,
          transparent: true,
          opacity: 0.35,
        });

        const torus = new THREE.Mesh(geometry, material);
        torus.position.set(0, 0, 0);
        scene.add(torus);

        // Core glow sphere
        const coreGeo = new THREE.IcosahedronGeometry(2.5, 3);
        const coreMat = new THREE.MeshBasicMaterial({
          color: new THREE.Color('${secondaryHex}'),
          wireframe: true,
          transparent: true,
          opacity: 0.25,
        });
        const coreMesh = new THREE.Mesh(coreGeo, coreMat);
        scene.add(coreMesh);

        let mouseX = 0, mouseY = 0;
        window.addEventListener('mousemove', (e) => {
          mouseX = (e.clientX / window.innerWidth) * 2 - 1;
          mouseY = -(e.clientY / window.innerHeight) * 2 + 1;
        });

        let clock = new THREE.Clock();
        function loop() {
          const t = clock.getElapsedTime() * ${speed};
          torus.rotation.x = t * 0.35 + mouseY * 0.5;
          torus.rotation.y = t * 0.45 + mouseX * 0.5;

          coreMesh.rotation.x = -t * 0.2;
          coreMesh.rotation.y = -t * 0.3;

          camera.position.x += (mouseX * 2 - camera.position.x) * 0.05;
          camera.position.y += (mouseY * 2 - camera.position.y) * 0.05;
          camera.lookAt(0, 0, 0);

          renderer.render(scene, camera);
          requestAnimationFrame(loop);
        }
        loop();

        window.addEventListener('resize', () => {
          camera.aspect = window.innerWidth / window.innerHeight;
          camera.updateProjectionMatrix();
          renderer.setSize(window.innerWidth, window.innerHeight);
        });
      }
    } catch (e) {
      console.warn('WebGL Torus Knot init error:', e);
    }
        `;

      case 'liquid-aurora':
      case 'interactive-ripples':
      default:
        return `
    // WebGL Dynamic Fluid Aurora Shader
    try {
      const canvas = document.getElementById('webgl-canvas');
      if (canvas && typeof THREE !== 'undefined') {
        const scene = new THREE.Scene();
        const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
        const renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

        const material = new THREE.ShaderMaterial({
          uniforms: {
            u_time: { value: 0 },
            u_resolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
            u_mouse: { value: new THREE.Vector2(0.5, 0.5) },
            u_color1: { value: new THREE.Color('${primaryHex}') },
            u_color2: { value: new THREE.Color('${secondaryHex}') },
          },
          vertexShader: \`
            varying vec2 vUv;
            void main() {
              vUv = uv;
              gl_Position = vec4(position, 1.0);
            }
          \`,
          fragmentShader: \`
            uniform float u_time;
            uniform vec2 u_resolution;
            uniform vec2 u_mouse;
            uniform vec3 u_color1;
            uniform vec3 u_color2;
            varying vec2 vUv;

            void main() {
              vec2 st = gl_FragCoord.xy / u_resolution.xy;
              float t = u_time * 0.3 * ${speed};

              // Organic wave noise
              float q = sin(st.x * 3.0 + t + sin(st.y * 2.5 - t * 0.7));
              float p = cos(st.y * 3.5 - t * 0.9 + cos(st.x * 2.0 + t));
              float wave = sin((q + p + st.x * 2.0) * 3.1415);

              // Mouse ripple proximity
              float dist = distance(st, u_mouse);
              float ripple = sin(dist * 18.0 - t * 4.0) * exp(-dist * 3.0);

              vec3 finalColor = mix(u_color1, u_color2, (wave + 1.0) * 0.5);
              float alpha = 0.18 + ripple * 0.08 + (wave * 0.08);

              gl_FragColor = vec4(finalColor, clamp(alpha, 0.05, 0.35));
            }
          \`,
          transparent: true,
        });

        const plane = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), material);
        scene.add(plane);

        window.addEventListener('mousemove', (e) => {
          material.uniforms.u_mouse.value.x = e.clientX / window.innerWidth;
          material.uniforms.u_mouse.value.y = 1.0 - (e.clientY / window.innerHeight);
        });

        let clock = new THREE.Clock();
        function draw() {
          material.uniforms.u_time.value = clock.getElapsedTime();
          renderer.render(scene, camera);
          requestAnimationFrame(draw);
        }
        draw();

        window.addEventListener('resize', () => {
          renderer.setSize(window.innerWidth, window.innerHeight);
          material.uniforms.u_resolution.value.set(window.innerWidth, window.innerHeight);
        });
      }
    } catch (e) {
      console.warn('WebGL Aurora init error:', e);
    }
        `;
    }
  }

  /**
   * Generates separate index.html referencing style.css and script.js
   */
  generateIndexHtml(config: SiteConfig): string {
    const singleHtml = this.generateSingleHtml(config);
    // Replace inline style and script with external links
    let modularHtml = singleHtml.replace(
      /<style>[\s\S]*?<\/style>/,
      '<link rel="stylesheet" href="style.css">'
    );
    modularHtml = modularHtml.replace(
      /<script>\s*\/\* ==========================================================================\s*Lenis Smooth Scroll[\s\S]*?<\/script>/,
      '<script src="script.js"></script>'
    );
    return modularHtml;
  }

  /**
   * Generates the GitHub Pages README.md file
   */
  generateReadme(config: SiteConfig): string {
    return `# ${config.brandName} - GitHub Pages Website

> Built with **Lenis Smooth Scroll**, **GSAP ScrollTrigger**, **WebGL Shaders (Three.js)**, **HTML5**, **CSS3**, and **Vanilla JS**.

## 🚀 نحوه راه‌اندازی سریع در GitHub Pages (در کمتر از ۲ دقیقه)

این پروژه به گونه‌ای ساخته شده است که کاملاً مستقل (Zero-Build) و استاتیک است و به هیچ وابستگی یا دستور نصب Node.js در سرور گیتهاب نیاز ندارد.

### روش ۱: آپلود مستقیم در وب‌سایت گیت‌هاب (ساده‌ترین روش)
1. در حساب [GitHub.com](https://github.com) خود، یک مخزن جدید (New Repository) با نام دلخواه (مثلاً \`${config.githubPagesConfig.repositoryName}\`) بسازید.
2. روی **Upload files** کلیک کنید و فایل‌های \`index.html\` (یا پکیج کامل شامل \`style.css\` و \`script.js\`) را به مخزن Drag & Drop کنید.
3. دکمه **Commit changes** را بزنید.
4. به تب **Settings** مخزن بروید و از منوی سمت چپ گزینه **Pages** را انتخاب کنید.
5. در بخش **Build and deployment**:
   - زیر عنوان **Source** گزینه **Deploy from a branch** را انتخاب کنید.
   - زیر عنوان **Branch** شاخه \`main\` و پوشه \`/ (root)\` را انتخاب کرده و دکمه **Save** را بزنید.
6. پس از حدود ۳۰ الی ۶۰ ثانیه، لینک وب‌سایت زنده شما آماده خواهد بود:
   \`\`\`
   https://<your-username>.github.io/${config.githubPagesConfig.repositoryName}/
   \`\`\`

---

### روش ۲: از طریق ترمینال (Git CLI)
\`\`\`bash
# مقداردهی اولیه مخزن
git init

# افزودن فایل‌ها
git add .
git commit -m "feat: initial interactive Lenis + GSAP + WebGL website"

# اتصال به مخزن گیت‌هاب و ارسال
git branch -M main
git remote add origin https://github.com/<your-username>/${config.githubPagesConfig.repositoryName}.git
git push -u origin main
\`\`\`

---

## 🛠 تکنولوژی‌های استفاده شده (Tech Stack)
- **Lenis Smooth Scroll:** نرخ فریم هماهنگ با سخت‌افزار برای اسکرول فوق‌العاده نرم و سینمایی.
- **GSAP & ScrollTrigger:** انیمیشن‌های زنجیره‌ای حروف تیتر (Split Text)، ترنزیشن‌های اسکرول و پارالاکس.
- **WebGL / Three.js:** پس‌زمینه زنده گرافیکی و تعاملی متناسب با حرکت ماوس.
- **Vanilla JSON Script:** ذخیره و خواندن آسان داده‌های سایت از تگ کانفیگ JSON بدون وابستگی به فریم‌ورک‌های سنگین.
`;
  }

  /**
   * Generates custom 404 page for GitHub Pages
   */
  generate404Html(config: SiteConfig): string {
    const isRtl = config.language === 'fa';
    return `<!DOCTYPE html>
<html lang="${config.language}" dir="${isRtl ? 'rtl' : 'ltr'}">
<head>
  <meta charset="UTF-8">
  <title>404 | ${this.escapeHtml(config.brandName)}</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      margin: 0;
      background: ${config.theme.bgColor};
      color: ${config.theme.textColor};
      font-family: sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      text-align: center;
      padding: 1rem;
    }
    h1 {
      font-size: 6rem;
      margin: 0;
      color: ${config.theme.primaryColor};
    }
    p {
      color: #94a3b8;
      font-size: 1.25rem;
      margin-bottom: 2rem;
    }
    a {
      padding: 0.8rem 1.8rem;
      background: ${config.theme.primaryColor};
      color: #000;
      text-decoration: none;
      font-weight: 700;
      border-radius: 9999px;
    }
  </style>
</head>
<body>
  <h1>404</h1>
  <p>${isRtl ? 'صفحه مورد نظر یافت نشد!' : 'Page not found!'}</p>
  <a href="./">${isRtl ? 'بازگشت به صفحه اصلی' : 'Back to Home'}</a>
</body>
</html>`;
  }

  /**
   * Generates the ultimate prompt requested by the user
   */
  generateAiPrompt(config: SiteConfig): string {
    return `پرامپت جامع، مهندسی‌شده و استاندارد برای ساخت وبسایت‌های تعاملی Awwwards با Lenis + GSAP + WebGL:

---
«یک وب‌سایت مدرن، تعاملی، مینیمال و برنده جوایز بین‌المللی (Award-Winning Style) به صورت ۱۰۰٪ مستقل (Zero-Build Static) و کاملاً سازگار با GitHub Pages برای استودیو/برند "${config.brandName}" طراحی کن و تمام کدهای HTML5, CSS3 و Vanilla JavaScript را در قالب یک فایل منسجم و بی‌نقص تحویل بده.

مشخصات فنی و الزامات معماری:
۱. روان‌سازی اسکرول با Lenis (@studio-freight/lenis):
   - استفاده از آخرین نسخه CDN لِنیس بدون وابستگی به بیلد
   - تنظیم lerp روی ${config.lenisConfig.lerp} برای ایجاد حسی سینمایی و سیال
   - همگام‌سازی بی‌نقص حلقه انیمیشن Lenis با GSAP ticker (عدم ایجاد پرش یا stutter)
   - پشتیبانی از اسکرول تاچ موبایل و دکمه بازگشت نرم به بالای صفحه

۲. انیمیشن‌های تعاملی با GSAP و ScrollTrigger:
   - افکت Split Text حروف تیتر قهرمان (Hero Title) با ورود زنجیره‌ای (Stagger)
   - افکت ماسک و بزرگ‌نمایی پارالاکس (Parallax Zoom) برای تصاویر در هنگام اسکرول
   - دکمه‌ها و المان‌های جاذب مغناطیسی (Magnetic Buttons) که با حرکت کرسر ماوس جذب می‌شوند
   - کرسر سفارشی با قابلیت تعقیب نرم (Smooth Follower) و بزرگ شدن در هاور کارت‌ها
   - چرخش ۳ بعدی پرسپکتیو کارت‌ها (3D Card Tilt) متناسب با مختصات ماوس
   - شمارنده اعدادی پویا (Count-Up Animation) برای آمارهای کلیدی

۳. پس‌زمینه سه‌بعدی و شیدر WebGL با Three.js:
   - یک بوم تمام‌صفحه تعاملی WebGL از نوع "${config.webglEffect}"
   - واکنش بلادرنگ موج‌ها یا ذرات به حرکت ماوس و اسکرول
   - متریال درخشان با پالت رنگی اختصاصی (رنگ اصلی: ${config.theme.primaryColor}، رنگ ثانویه: ${config.theme.secondaryColor})
   - بهینه‌سازی دقیق پرفورمنس جهت حفظ فریم‌ریت ثابت ۶۰ الی ۱۲۰ FPS

۴. زبان و ساختار داده:
   - زبان: ${config.language === 'fa' ? 'فارسی RTL با تایپوگرافی شکیل و فونت وزیرمتن' : 'انگلیسی LTR با فونت مدرن ادیتوریال'}
   - تفکیک پیکربندی در یک تگ JSON با نام "site-config-data" تا بدون تغییر کدها بتوان مشخصات سایت را دگرگون کرد.

۵. سازگاری ۱۰۰٪ با GitHub Pages:
   - بدون نیاز به سرور یا فرآیند کامپایل npm/vite/webpack
   - تمامی کتابخانه‌ها از CDNهای پرسرعت و معتبر با HTTPS لود شوند
   - ساختار کامپکت و آماده بارگذاری مستقیم روی شاخه gh-pages یا root.»
`;
  }

  private splitHeadline(text: string): string {
    return text
      .split(' ')
      .map(word => {
        const chars = word
          .split('')
          .map(c => `<span class="char">${c}</span>`)
          .join('');
        return `<span class="word" style="display:inline-block; margin: 0 0.15em;">${chars}</span>`;
      })
      .join(' ');
  }

  private escapeHtml(str: string): string {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  private hexToRgb(hex: string): string {
    if (!hex) return '6, 182, 212';
    let c = hex.replace('#', '');
    if (c.length === 3) {
      c = c.split('').map(x => x + x).join('');
    }
    const num = parseInt(c, 16);
    return `${(num >> 16) & 255}, ${(num >> 8) & 255}, ${num & 255}`;
  }
}
