import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';
import { SiteStateService } from '../../services/site-state.service';
import { CodeGeneratorService } from '../../services/code-generator.service';

@Component({
  selector: 'app-preview-frame',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full h-full flex flex-col bg-slate-950 p-2 sm:p-4">
      
      <!-- Preview Header Controls Bar -->
      <div class="flex items-center justify-between bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 mb-3 shadow-md">
        <!-- Left: Device simulator switches -->
        <div class="flex items-center gap-1.5">
          <span class="text-xs font-mono text-slate-400 ml-2 hidden sm:inline">حالت نمایش:</span>
          
          <button 
            (click)="setViewport('desktop')"
            class="px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer"
            [class.bg-cyan-500]="state.previewViewport() === 'desktop'"
            [class.text-slate-950]="state.previewViewport() === 'desktop'"
            [class.text-slate-300]="state.previewViewport() !== 'desktop'"
            [class.bg-slate-800]="state.previewViewport() !== 'desktop'">
            <span class="material-icons text-xs">desktop_windows</span>
            <span class="hidden md:inline">دسکتاپ (100%)</span>
          </button>

          <button 
            (click)="setViewport('tablet')"
            class="px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer"
            [class.bg-cyan-500]="state.previewViewport() === 'tablet'"
            [class.text-slate-950]="state.previewViewport() === 'tablet'"
            [class.text-slate-300]="state.previewViewport() !== 'tablet'"
            [class.bg-slate-800]="state.previewViewport() !== 'tablet'">
            <span class="material-icons text-xs">tablet_mac</span>
            <span class="hidden md:inline">تبلت (768px)</span>
          </button>

          <button 
            (click)="setViewport('mobile')"
            class="px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer"
            [class.bg-cyan-500]="state.previewViewport() === 'mobile'"
            [class.text-slate-950]="state.previewViewport() === 'mobile'"
            [class.text-slate-300]="state.previewViewport() !== 'mobile'"
            [class.bg-slate-800]="state.previewViewport() !== 'mobile'">
            <span class="material-icons text-xs">phone_iphone</span>
            <span class="hidden md:inline">موبایل (375px)</span>
          </button>
        </div>

        <!-- Center: Status badges -->
        <div class="hidden lg:flex items-center gap-2">
          <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-mono bg-cyan-950/70 text-cyan-300 border border-cyan-800/60">
            <span class="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
            Lenis: lerp {{ state.config().lenisConfig.lerp }}
          </span>
          <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-mono bg-violet-950/70 text-violet-300 border border-violet-800/60">
            WebGL: {{ state.config().webglEffect }}
          </span>
          <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-mono bg-emerald-950/70 text-emerald-300 border border-emerald-800/60">
            GitHub Pages: 100% Ready
          </span>
        </div>

        <!-- Right: Actions -->
        <div class="flex items-center gap-2">
          <button 
            (click)="reloadPreview()"
            class="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition-colors cursor-pointer"
            title="رفرش مجدد پیش‌نمایش">
            <span class="material-icons text-sm">refresh</span>
          </button>
          
          <button 
            (click)="openInNewTab()"
            class="px-3 py-1 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 rounded-lg text-xs font-semibold flex items-center gap-1 transition-all cursor-pointer">
            <span class="material-icons text-sm">open_in_new</span>
            <span>باز کردن در تب جدید</span>
          </button>
        </div>
      </div>

      <!-- Iframe viewport wrapper -->
      <div class="flex-1 w-full flex items-center justify-center overflow-hidden bg-slate-950/90 rounded-2xl border border-slate-800 relative shadow-inner p-2">
        <div 
          class="h-full bg-black transition-all duration-300 rounded-xl overflow-hidden shadow-2xl border border-slate-800 relative flex flex-col"
          [style.width]="viewportWidth">
          
          <!-- Mock browser address bar -->
          <div class="h-7 bg-slate-900/90 border-b border-slate-800 px-3 flex items-center justify-between text-[11px] font-mono text-slate-400 select-none">
            <div class="flex items-center gap-1.5">
              <span class="w-2.5 h-2.5 rounded-full bg-rose-500/80"></span>
              <span class="w-2.5 h-2.5 rounded-full bg-amber-500/80"></span>
              <span class="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></span>
            </div>
            <div class="bg-slate-950/80 px-4 py-0.5 rounded text-[10px] text-slate-400 border border-slate-800 truncate max-w-[280px]">
              https://{{ state.config().githubPagesConfig.repositoryName }}.github.io/
            </div>
            <span class="material-icons text-xs text-slate-500">lock</span>
          </div>

          <!-- The Live Interactive Iframe -->
          <iframe 
            #previewIframe
            [srcdoc]="safeHtmlContent()"
            class="w-full flex-1 border-0 bg-black"
            sandbox="allow-scripts allow-same-origin allow-popups"
            title="Interactive Website Preview">
          </iframe>
        </div>
      </div>

    </div>
  `,
})
export class PreviewFrameComponent {
  readonly state = inject(SiteStateService);
  private readonly generator = inject(CodeGeneratorService);
  private readonly sanitizer = inject(DomSanitizer);

  get viewportWidth(): string {
    switch (this.state.previewViewport()) {
      case 'mobile': return '375px';
      case 'tablet': return '768px';
      case 'desktop':
      default:
        return '100%';
    }
  }

  readonly safeHtmlContent = computed(() => {
    // depend on previewKey to force recompute if reloaded
    this.state.previewKey();
    const rawHtml = this.generator.generateSingleHtml(this.state.config());
    return this.sanitizer.bypassSecurityTrustHtml(rawHtml);
  });

  setViewport(vp: 'desktop' | 'tablet' | 'mobile') {
    this.state.previewViewport.set(vp);
  }

  reloadPreview() {
    this.state.refreshPreview();
  }

  openInNewTab() {
    const rawHtml = this.generator.generateSingleHtml(this.state.config());
    const blob = new Blob([rawHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  }
}
