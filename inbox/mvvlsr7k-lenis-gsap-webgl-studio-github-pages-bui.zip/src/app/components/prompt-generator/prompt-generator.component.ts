import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SiteStateService } from '../../services/site-state.service';
import { CodeGeneratorService } from '../../services/code-generator.service';

@Component({
  selector: 'app-prompt-generator',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full max-w-4xl mx-auto py-4 px-2 sm:px-4 space-y-6">
      
      <!-- Header Banner -->
      <div class="bg-gradient-to-r from-cyan-950/40 via-violet-950/40 to-slate-900 border border-cyan-800/60 rounded-2xl p-5 sm:p-6 backdrop-blur-xl shadow-xl">
        <div class="flex items-center gap-3 mb-2">
          <div class="p-2 bg-cyan-500/10 text-cyan-400 rounded-xl material-icons text-xl">auto_awesome</div>
          <div>
            <div class="text-xs font-mono uppercase tracking-wider text-cyan-400 font-semibold">
              پرامپت‌های مهندسی‌شده طلایی
            </div>
            <h2 class="text-xl font-bold text-white">
              پرامپت کامل و توپ برای هوش مصنوعی (AI Prompt)
            </h2>
          </div>
        </div>
        <p class="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl mt-1">
          این پرامپت‌ها دقیقاً با مهندسی پرامپت استانداردهای Awwwards و GitHub Pages تدوین شده‌اند. می‌توانید هر یک را با یک کلیک کپی کرده و به مدل‌های هوش مصنوعی (ChatGPT، Claude، Gemini و غیره) بدهید تا بلافاصله بهترین خروجی را به شما ارائه دهند.
        </p>
      </div>

      <!-- Prompt Selection Tabs -->
      <div class="flex items-center gap-2 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800 overflow-x-auto">
        <button 
          (click)="selectedPromptType.set('website')"
          class="px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          [class.bg-cyan-500]="selectedPromptType() === 'website'"
          [class.text-slate-950]="selectedPromptType() === 'website'"
          [class.text-slate-300]="selectedPromptType() !== 'website'">
          <span class="material-icons text-xs">web</span>
          <span>۱. پرامپت ساخت سایت برنده Awwwards (سفارشی شده)</span>
        </button>

        <button 
          (click)="selectedPromptType.set('builder-tool')"
          class="px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          [class.bg-cyan-500]="selectedPromptType() === 'builder-tool'"
          [class.text-slate-950]="selectedPromptType() === 'builder-tool'"
          [class.text-slate-300]="selectedPromptType() !== 'builder-tool'">
          <span class="material-icons text-xs">build</span>
          <span>۲. پرامپت ساخت خود این ابزار سازنده با چند سوال</span>
        </button>

        <button 
          (click)="selectedPromptType.set('webgl-shaders')"
          class="px-4 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          [class.bg-cyan-500]="selectedPromptType() === 'webgl-shaders'"
          [class.text-slate-950]="selectedPromptType() === 'webgl-shaders'"
          [class.text-slate-300]="selectedPromptType() !== 'webgl-shaders'">
          <span class="material-icons text-xs">view_in_ar</span>
          <span>۳. پرامپت تخصصی شیدرهای سه‌بعدی WebGL</span>
        </button>
      </div>

      <!-- Prompt Card Display -->
      <div class="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
        <div class="px-5 py-3.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span class="text-xs font-semibold text-slate-300">{{ getPromptLabel() }}</span>
            <span class="text-[11px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40">آماده کپی و اجرا</span>
          </div>

          <button 
            (click)="copyPrompt()"
            class="px-4 py-1.5 bg-gradient-to-r from-cyan-400 to-cyan-500 hover:from-cyan-300 hover:to-cyan-400 text-slate-950 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all shadow-md shadow-cyan-500/20 cursor-pointer">
            <span class="material-icons text-sm">{{ isCopied() ? 'check' : 'content_copy' }}</span>
            <span>{{ isCopied() ? 'کپی شد!' : 'کپی پرامپت طلایی' }}</span>
          </button>
        </div>

        <div class="p-5 text-xs sm:text-sm font-sans leading-relaxed text-slate-200 whitespace-pre-line bg-[#07090e] max-h-[500px] overflow-y-auto select-text">
          {{ activePromptText() }}
        </div>
      </div>

      <!-- Quick Explanation Grid -->
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div class="p-4 bg-slate-900/60 border border-slate-800 rounded-xl">
          <div class="text-cyan-400 font-bold text-xs mb-1 flex items-center gap-1">
            <span class="material-icons text-sm">speed</span>
            <span>چرا Lenis؟</span>
          </div>
          <p class="text-[11px] text-slate-400 leading-relaxed">
            لِنیس استاندارد طلایی اسکرول نرم در سایت‌های جوایز Awwwards است و با مدیریت دقیق نرخ فریم بدون مسدودسازی تاچ موبایل کار می‌کند.
          </p>
        </div>

        <div class="p-4 bg-slate-900/60 border border-slate-800 rounded-xl">
          <div class="text-violet-400 font-bold text-xs mb-1 flex items-center gap-1">
            <span class="material-icons text-sm">animation</span>
            <span>چرا GSAP و ScrollTrigger؟</span>
          </div>
          <p class="text-[11px] text-slate-400 leading-relaxed">
            امکان پیاده‌سازی انیمیشن‌های ورود حروف، پارالاکس و دکمه‌های مغناطیسی با کمترین بار پردازشی روی مرورگر.
          </p>
        </div>

        <div class="p-4 bg-slate-900/60 border border-slate-800 rounded-xl">
          <div class="text-emerald-400 font-bold text-xs mb-1 flex items-center gap-1">
            <span class="material-icons text-sm">cloud_done</span>
            <span>چرا ۱۰۰٪ GitHub Pages؟</span>
          </div>
          <p class="text-[11px] text-slate-400 leading-relaxed">
            کدهای تولید شده کاملاً استاتیک و بدون نیاز به بیلد (Zero-Build) هستند و به محض آپلود روی هاست رایگان گیت‌هاب اجرا می‌شوند.
          </p>
        </div>
      </div>

    </div>
  `,
})
export class PromptGeneratorComponent {
  readonly state = inject(SiteStateService);
  private readonly generator = inject(CodeGeneratorService);

  readonly selectedPromptType = signal<'website' | 'builder-tool' | 'webgl-shaders'>('website');
  readonly isCopied = signal<boolean>(false);

  readonly activePromptText = computed(() => {
    const config = this.state.config();
    const type = this.selectedPromptType();

    if (type === 'website') {
      return this.generator.generateAiPrompt(config);
    }

    if (type === 'builder-tool') {
      return `«یک اپلیکیشن وب و ابزار هوشمند، مدرن و تعاملی بساز که کارش "ساخت خودکار سایت‌های خلاقانه و تعاملی با پشته تکنولوژی:
• Lenis Smooth Scroll
• GSAP + ScrollTrigger
• WebGL / Three.js 3D Canvas Shaders
• HTML5 سمانتیک + CSS3 مدرن + Vanilla JavaScript
• اسکریپت کانفیگ JSON خالص (Vanilla JSON Script)" باشد.

این اپلیکیشن باید از طریق یک پرسشنامه چند مرحله‌ای و تعاملی (Wizard با چند سوال کامل) از کاربر موارد زیر را بپرسد:
۱. موضوع و سبک وبسایت (استودیو خلاقانه، پورتفولیو برنامه‌نویس، برند لوکس، هوش مصنوعی)
۲. نام برند، تیتر اصلی و شعار تبلیغاتی
۳. نوع جلوه سه‌بعدی و شیدر WebGL (شبکه موج‌دار Wave Mesh، ذرات کیهانی Starfield، گره هولوگرافیک Torus Knot، شفق قطبی مایع Aurora)
۴. میزان نرمی و اینرسی اسکرول لِنیس (lerp از ۰.۰۵ تا ۰.۱۵)
۵. انیمیشن‌های تعاملی GSAP (ورود حروف Split Text، زوم پارالاکس تصاویر، دکمه‌های مغناطیسی، کرسر سفارشی، چرخش ۳ بعدی کارت‌ها)
۶. پالت رنگی و استایل دارک
۷. سکشن‌های مورد نظر صفحه (Hero, About, Projects, Services, Stats, Contact)
۸. نحوه خروجی سازگار با GitHub Pages (تک فایل مستقل single index.html یا پکیج زیپ چند فایلی)

قابلیت‌های حیاتی اپلیکیشن:
- پیش‌نمایش زنده در لحظه (Live Interactive Preview با قابلیت تغییر سایز دسکتاپ/تبلت/موبایل)
- نمایش کدهای خروجی در تب‌های مجزا با قابلیت کپی سریع و دانلود مستقیم تک‌فایل و پکیج زیپ
- راهنمای گام‌به‌گام استقرار روی GitHub Pages در ۶۰ ثانیه
- تضمین ۱۰۰٪ سازگاری با GitHub Pages بدون نیاز به Node.js یا فرآیند بیلد!»`;
    }

    // webgl-shaders
    return `«یک ماژول کد خالص جاوااسکریپت (Vanilla JS) برای پس‌زمینه تعاملی سه‌بعدی WebGL با Three.js یا شیدر خام GLSL بنویس که:
۱. کاملاً ریسپانسیو باشد و تمام صفحه را بپوشاند: canvas با position: fixed و z-index: 0
۲. دارای جلوه گرافیکی خیره‌کننده "${config.webglEffect}" باشد که با مختصات ماوس کاربر (mousemove با افکت lerp نرم) زاویه دوربین و حرکت موج‌ها یا مدار ذرات را تغییر دهد.
۳. رنگ‌های اصلی ${config.theme.primaryColor} و ثانویه ${config.theme.secondaryColor} را در متریال خود اعمال کند.
۴. حلقه رندرینگ آن (requestAnimationFrame) با لِنیس (Lenis Smooth Scroll) تداخل نداشته باشد و مصرف حافظه و GPU را بهینه نگه دارد تا فریم‌ریت ثابت ۶۰ الی ۱۲۰ FPS حفظ شود.
۵. کد باید کاملاً سازگار با مرورگر و بدون نیاز به وب‌پک یا ایمپورت‌های ماژولار بوده و از طریق CDN لود شود.»`;
  });

  getPromptLabel(): string {
    switch (this.selectedPromptType()) {
      case 'website': return 'پرامپت ساخت سایت سفارشی Awwwards';
      case 'builder-tool': return 'پرامپت ساخت ابزار سایت‌ساز با پرسشنامه';
      case 'webgl-shaders': return 'پرامپت توسعه شیدرهای سه‌بعدی WebGL';
    }
  }

  async copyPrompt() {
    try {
      await navigator.clipboard.writeText(this.activePromptText());
      this.isCopied.set(true);
      setTimeout(() => this.isCopied.set(false), 2000);
    } catch {
      // Fallback
    }
  }
}
