import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SiteStateService } from '../../services/site-state.service';
import { THEME_PRESETS, SITE_PRESETS } from '../../data/presets.data';
import { SiteConfig, WebglEffectType } from '../../models/site-config.interface';

@Component({
  selector: 'app-questionnaire',
  standalone: true,
  imports: [CommonModule, FormsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full max-w-4xl mx-auto py-4 px-2 sm:px-4">
      
      <!-- Progress Stepper Header -->
      <div class="mb-8 bg-slate-900/80 border border-slate-800 rounded-2xl p-4 sm:p-6 backdrop-blur-xl shadow-xl">
        <div class="flex items-center justify-between mb-4">
          <div>
            <div class="text-xs font-mono uppercase tracking-wider text-cyan-400 font-semibold">
              گام {{ state.currentStep() }} از {{ state.totalSteps }}
            </div>
            <h2 class="text-lg sm:text-xl font-bold text-white mt-1">
              {{ getStepTitle(state.currentStep()) }}
            </h2>
          </div>

          <div class="flex items-center gap-2">
            <button
              type="button"
              (click)="openAiPromptModal()"
              class="px-3 py-1.5 text-xs font-semibold text-cyan-300 bg-cyan-950/60 border border-cyan-800/80 rounded-xl hover:bg-cyan-900/60 transition-all flex items-center gap-1.5 cursor-pointer shadow-sm">
              <span class="material-icons text-sm">auto_awesome</span>
              <span>پرامپت طلایی AI</span>
            </button>
            <button
              type="button"
              (click)="state.activeTab.set('preview')"
              class="px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800/80 border border-slate-700 rounded-xl hover:bg-slate-700 transition-all flex items-center gap-1.5 cursor-pointer">
              <span class="material-icons text-sm">visibility</span>
              <span>پیش‌نمایش</span>
            </button>
          </div>
        </div>

        <!-- Progress bar -->
        <div class="w-full bg-slate-800/80 rounded-full h-2 overflow-hidden">
          <div 
            class="bg-gradient-to-r from-cyan-500 via-violet-500 to-fuchsia-500 h-2 rounded-full transition-all duration-300 shadow-sm shadow-cyan-500/50"
            [style.width.%]="(state.currentStep() / state.totalSteps) * 100">
          </div>
        </div>

        <!-- Step Pills / Navigation -->
        <div class="flex items-center justify-between mt-4 overflow-x-auto pb-1 gap-1">
          @for (s of stepNumbers; track s) {
            <button
              type="button"
              (click)="state.goToStep(s)"
              class="flex-1 min-w-[2.2rem] py-1.5 px-1 rounded-lg text-xs font-mono font-medium transition-all text-center cursor-pointer"
              [class.bg-cyan-500]="state.currentStep() === s"
              [class.text-slate-950]="state.currentStep() === s"
              [class.font-bold]="state.currentStep() === s"
              [class.bg-slate-800]="state.currentStep() !== s && s < state.currentStep()"
              [class.text-cyan-400]="state.currentStep() !== s && s < state.currentStep()"
              [class.bg-slate-800/40]="state.currentStep() !== s && s > state.currentStep()"
              [class.text-slate-400]="state.currentStep() !== s && s > state.currentStep()">
              {{ s }}
            </button>
          }
        </div>
      </div>

      <!-- STEP CONTENTS -->
      <div class="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 sm:p-8 backdrop-blur-xl shadow-2xl min-h-[480px] flex flex-col justify-between">
        
        <!-- STEP 1: Website Concept & Preset Archetype -->
        @if (state.currentStep() === 1) {
          <div class="space-y-6">
            <div class="space-y-1">
              <h3 class="text-xl font-bold text-white flex items-center gap-2">
                <span class="p-1.5 bg-cyan-500/10 text-cyan-400 rounded-lg material-icons text-base">category</span>
                سوال ۱: وبسایت شما در چه زمینه و سبکی است؟
              </h3>
              <p class="text-sm text-slate-400">
                یک الگو انتخاب کنید تا بهترین تنظیمات لِنیس، انیمیشن‌های GSAP و شیدرهای WebGL به طور خودکار بارگذاری شوند.
              </p>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
              @for (preset of sitePresets; track preset.id) {
                <button 
                  type="button"
                  (click)="state.applyPreset(preset.id)"
                  class="group relative p-5 rounded-2xl border transition-all cursor-pointer text-right flex flex-col justify-between w-full"
                  [class.border-cyan-500]="state.config().siteType === preset.config.siteType"
                  [class.bg-cyan-950/20]="state.config().siteType === preset.config.siteType"
                  [class.shadow-lg]="state.config().siteType === preset.config.siteType"
                  [class.shadow-cyan-500/10]="state.config().siteType === preset.config.siteType"
                  [class.border-slate-800]="state.config().siteType !== preset.config.siteType"
                  [class.bg-slate-900/40]="state.config().siteType !== preset.config.siteType"
                  [class.hover:border-slate-700]="state.config().siteType !== preset.config.siteType">
                  
                  <div class="w-full">
                    <div class="flex items-center justify-between mb-2">
                      <span class="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                        {{ preset.badge }}
                      </span>
                      @if (state.config().siteType === preset.config.siteType) {
                        <span class="material-icons text-cyan-400 text-lg">check_circle</span>
                      }
                    </div>
                    <h4 class="font-bold text-base text-white group-hover:text-cyan-300 transition-colors">
                      {{ preset.name }}
                    </h4>
                    <p class="text-xs text-slate-400 mt-2 leading-relaxed">
                      {{ preset.desc }}
                    </p>
                  </div>

                  <div class="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono text-slate-400 w-full">
                    <span>Lenis + GSAP + WebGL</span>
                    <span class="text-cyan-400 group-hover:translate-x-[-4px] transition-transform">انتخاب الگو ←</span>
                  </div>
                </button>
              }
            </div>
          </div>
        }

        <!-- STEP 2: Branding & Hero Content -->
        @if (state.currentStep() === 2) {
          <div class="space-y-6">
            <div class="space-y-1">
              <h3 class="text-xl font-bold text-white flex items-center gap-2">
                <span class="p-1.5 bg-cyan-500/10 text-cyan-400 rounded-lg material-icons text-base">edit_note</span>
                سوال ۲: نام برند، تیتر اصلی و زبان سایت چیست؟
              </h3>
              <p class="text-sm text-slate-400">
                این عناوین با انیمیشن ورود حروف GSAP (Split-Text Stagger) و ترنزیشن‌های سینمایی ظاهر می‌شوند.
              </p>
            </div>

            <div class="space-y-4">
              <!-- Language Toggle -->
              <div class="flex items-center justify-between p-3.5 bg-slate-950/60 rounded-xl border border-slate-800">
                <div>
                  <div class="text-sm font-semibold text-white">جهت و زبان وبسایت</div>
                  <div class="text-xs text-slate-400">فونت و دایرکشن RTL/LTR متناسب با زبان تنظیم می‌شود</div>
                </div>
                <div class="flex bg-slate-800 p-1 rounded-xl">
                  <button 
                    type="button"
                    (click)="updateLanguage('fa')"
                    class="px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer"
                    [class.bg-cyan-500]="state.config().language === 'fa'"
                    [class.text-slate-950]="state.config().language === 'fa'"
                    [class.text-slate-300]="state.config().language !== 'fa'">
                    فارسی (RTL)
                  </button>
                  <button 
                    type="button"
                    (click)="updateLanguage('en')"
                    class="px-3 py-1 text-xs font-bold rounded-lg transition-all cursor-pointer"
                    [class.bg-cyan-500]="state.config().language === 'en'"
                    [class.text-slate-950]="state.config().language === 'en'"
                    [class.text-slate-300]="state.config().language !== 'en'">
                    English (LTR)
                  </button>
                </div>
              </div>

              <!-- Brand Name -->
              <div>
                <span class="block text-xs font-semibold text-slate-300 mb-1.5">نام برند یا سایت</span>
                <input 
                  type="text" 
                  aria-label="نام برند یا سایت"
                  [ngModel]="state.config().brandName"
                  (ngModelChange)="updateBrandName($event)"
                  placeholder="مثال: NEXUS STUDIO"
                  class="w-full px-4 py-2.5 bg-slate-950/70 border border-slate-800 rounded-xl text-white text-sm focus:outline-none focus:border-cyan-500 font-bold" />
              </div>

              <!-- Hero Headline -->
              <div>
                <div class="flex items-center justify-between mb-1.5">
                  <span class="text-xs font-semibold text-slate-300">تیتر اصلی بخش قهرمان (Hero Headline)</span>
                  <span class="text-xs text-cyan-400 font-mono">انیمیشن Split Text روی کلمات</span>
                </div>
                <input 
                  type="text" 
                  aria-label="تیتر اصلی بخش قهرمان"
                  [ngModel]="state.config().heroTitle"
                  (ngModelChange)="updateHeroTitle($event)"
                  placeholder="مثال: CRAFTING DIGITAL WONDERS"
                  class="w-full px-4 py-2.5 bg-slate-950/70 border border-slate-800 rounded-xl text-white text-sm focus:outline-none focus:border-cyan-500 font-bold" />
              </div>

              <!-- Hero Subtitle -->
              <div>
                <span class="block text-xs font-semibold text-slate-300 mb-1.5">توضیح کوتاه و شعار تبلیغاتی</span>
                <textarea 
                  rows="2"
                  aria-label="توضیح کوتاه و شعار تبلیغاتی"
                  [ngModel]="state.config().heroSubtitle"
                  (ngModelChange)="updateHeroSubtitle($event)"
                  placeholder="توضیح جذابی که با انیمیشن رو به بالا نمایش داده می‌شود..."
                  class="w-full px-4 py-2 bg-slate-950/70 border border-slate-800 rounded-xl text-white text-sm focus:outline-none focus:border-cyan-500 resize-none"></textarea>
              </div>

              <!-- CTA Text & Link -->
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <span class="block text-xs font-semibold text-slate-300 mb-1.5">متن دکمه اصلی (CTA Text)</span>
                  <input 
                    type="text" 
                    aria-label="متن دکمه اصلی"
                    [ngModel]="state.config().ctaText"
                    (ngModelChange)="updateCtaText($event)"
                    placeholder="مشاهده پروژه‌ها"
                    class="w-full px-4 py-2.5 bg-slate-950/70 border border-slate-800 rounded-xl text-white text-sm focus:outline-none focus:border-cyan-500" />
                </div>
                <div>
                  <span class="block text-xs font-semibold text-slate-300 mb-1.5">لینک دکمه (CTA Link)</span>
                  <input 
                    type="text" 
                    aria-label="لینک دکمه"
                    [ngModel]="state.config().ctaLink"
                    (ngModelChange)="updateCtaLink($event)"
                    placeholder="#projects یا لینک دلخواه"
                    class="w-full px-4 py-2.5 bg-slate-950/70 border border-slate-800 rounded-xl text-white text-sm focus:outline-none focus:border-cyan-500" />
                </div>
              </div>
            </div>
          </div>
        }

        <!-- STEP 3: WebGL & Three.js 3D Shaders -->
        @if (state.currentStep() === 3) {
          <div class="space-y-6">
            <div class="space-y-1">
              <h3 class="text-xl font-bold text-white flex items-center gap-2">
                <span class="p-1.5 bg-cyan-500/10 text-cyan-400 rounded-lg material-icons text-base">view_in_ar</span>
                سوال ۳: کدام جلوه سه‌بعدی و شیدر WebGL را برای پس‌زمینه می‌پسندید؟
              </h3>
              <p class="text-sm text-slate-400">
                این شیدرهای گرافیکی با GPU رندر می‌شوند و مستقیماً به حرکت ماوس و اسکرول واکنش نشان می‌دهند.
              </p>
            </div>

            <!-- Effect Cards -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <button 
                type="button"
                (click)="setWebglEffect('wave-mesh')"
                class="p-4 rounded-xl border transition-all cursor-pointer flex items-start gap-3.5 text-right w-full"
                [class.border-cyan-500]="state.config().webglEffect === 'wave-mesh'"
                [class.bg-cyan-950/20]="state.config().webglEffect === 'wave-mesh'"
                [class.border-slate-800]="state.config().webglEffect !== 'wave-mesh'"
                [class.bg-slate-950/50]="state.config().webglEffect !== 'wave-mesh'">
                <div class="p-2.5 bg-cyan-500/10 text-cyan-400 rounded-xl material-icons">waves</div>
                <div>
                  <div class="font-bold text-sm text-white">شبکه موج‌دار نئونی (Wave Grid Mesh)</div>
                  <div class="text-xs text-slate-400 mt-1">امواج سینوسی درخشان با عمق پرسپکتیو و تعقیب ماوس</div>
                </div>
              </button>

              <button 
                type="button"
                (click)="setWebglEffect('cosmic-particles')"
                class="p-4 rounded-xl border transition-all cursor-pointer flex items-start gap-3.5 text-right w-full"
                [class.border-cyan-500]="state.config().webglEffect === 'cosmic-particles'"
                [class.bg-cyan-950/20]="state.config().webglEffect === 'cosmic-particles'"
                [class.border-slate-800]="state.config().webglEffect !== 'cosmic-particles'"
                [class.bg-slate-950/50]="state.config().webglEffect !== 'cosmic-particles'">
                <div class="p-2.5 bg-violet-500/10 text-violet-400 rounded-xl material-icons">blur_on</div>
                <div>
                  <div class="font-bold text-sm text-white">میدان ذرات کیهانی (Cosmic Starfield)</div>
                  <div class="text-xs text-slate-400 mt-1">هزاران ذره درخشان شناور که با حرکت ماوس تغییر مدار می‌دهند</div>
                </div>
              </button>

              <button 
                type="button"
                (click)="setWebglEffect('torus-knot')"
                class="p-4 rounded-xl border transition-all cursor-pointer flex items-start gap-3.5 text-right w-full"
                [class.border-cyan-500]="state.config().webglEffect === 'torus-knot'"
                [class.bg-cyan-950/20]="state.config().webglEffect === 'torus-knot'"
                [class.border-slate-800]="state.config().webglEffect !== 'torus-knot'"
                [class.bg-slate-950/50]="state.config().webglEffect !== 'torus-knot'">
                <div class="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl material-icons">adjust</div>
                <div>
                  <div class="font-bold text-sm text-white">گره هندسی سه‌بعدی هولوگرافیک (Torus Knot)</div>
                  <div class="text-xs text-slate-400 mt-1">آبجکت سه‌بعدی وایرفریم چرخان با هسته نورانی مرکزی</div>
                </div>
              </button>

              <button 
                type="button"
                (click)="setWebglEffect('liquid-aurora')"
                class="p-4 rounded-xl border transition-all cursor-pointer flex items-start gap-3.5 text-right w-full"
                [class.border-cyan-500]="state.config().webglEffect === 'liquid-aurora'"
                [class.bg-cyan-950/20]="state.config().webglEffect === 'liquid-aurora'"
                [class.border-slate-800]="state.config().webglEffect !== 'liquid-aurora'"
                [class.bg-slate-950/50]="state.config().webglEffect !== 'liquid-aurora'">
                <div class="p-2.5 bg-fuchsia-500/10 text-fuchsia-400 rounded-xl material-icons">gradient</div>
                <div>
                  <div class="font-bold text-sm text-white">شیدر شفق قطبی مایع (Fluid Aurora GLSL)</div>
                  <div class="text-xs text-slate-400 mt-1">اعوجاج سیال رنگ‌ها با امواج نویز ارگانیک و امواج ریپل ماوس</div>
                </div>
              </button>
            </div>

            <!-- Parameters tuning -->
            <div class="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-4">
              <div class="text-xs font-semibold text-slate-300">تنظیمات پیشرفته شیدر WebGL</div>

              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <div class="flex justify-between text-xs text-slate-400 mb-1">
                    <span>سرعت چرخش و شبیه‌سازی:</span>
                    <span class="font-mono text-cyan-400">{{ state.config().webglConfig.speed }}x</span>
                  </div>
                  <input 
                    type="range" 
                    min="0.5" 
                    max="2.5" 
                    step="0.1"
                    aria-label="سرعت چرخش و شبیه‌سازی"
                    [ngModel]="state.config().webglConfig.speed"
                    (ngModelChange)="updateWebglSpeed($event)"
                    class="w-full accent-cyan-400 cursor-pointer" />
                </div>

                <div>
                  <div class="flex justify-between text-xs text-slate-400 mb-1">
                    <span>تراکم ذرات / رزولوشن مش:</span>
                    <span class="font-mono text-cyan-400">{{ state.config().webglConfig.particleCount }}</span>
                  </div>
                  <input 
                    type="range" 
                    min="800" 
                    max="3000" 
                    step="100"
                    aria-label="تراکم ذرات و رزولوشن مش"
                    [ngModel]="state.config().webglConfig.particleCount"
                    (ngModelChange)="updateWebglCount($event)"
                    class="w-full accent-cyan-400 cursor-pointer" />
                </div>
              </div>

              <div class="flex items-center justify-between pt-2 border-t border-slate-800/80">
                <span class="text-xs text-slate-300">واکنش بلادرنگ به موقعیت ماوس (Parallax Interaction)</span>
                <input 
                  type="checkbox"
                  aria-label="واکنش بلادرنگ به موقعیت ماوس"
                  [ngModel]="state.config().webglConfig.reactToMouse"
                  (ngModelChange)="updateWebglMouse($event)"
                  class="w-4 h-4 accent-cyan-500 rounded cursor-pointer" />
              </div>
            </div>
          </div>
        }

        <!-- STEP 4: Lenis Smooth Scroll Engine -->
        @if (state.currentStep() === 4) {
          <div class="space-y-6">
            <div class="space-y-1">
              <h3 class="text-xl font-bold text-white flex items-center gap-2">
                <span class="p-1.5 bg-cyan-500/10 text-cyan-400 rounded-lg material-icons text-base">touch_app</span>
                سوال ۴: میزان نرمی و رفتار اسکرول لِنیس (Lenis) چگونه باشد؟
              </h3>
              <p class="text-sm text-slate-400">
                لِنیس نرخ فریم اسکرول را با سخت‌افزار سینک کرده و حرکت چرخ ماوس و تاچ‌پد را به شکلی سینمایی تبدیل می‌کند.
              </p>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <button 
                type="button"
                (click)="setLenisLerp(0.05)"
                class="p-4 rounded-xl border text-center transition-all cursor-pointer w-full"
                [class.border-cyan-500]="state.config().lenisConfig.lerp === 0.05"
                [class.bg-cyan-950/20]="state.config().lenisConfig.lerp === 0.05"
                [class.border-slate-800]="state.config().lenisConfig.lerp !== 0.05"
                [class.bg-slate-950/40]="state.config().lenisConfig.lerp !== 0.05">
                <div class="font-bold text-sm text-white">فوق روان و سینمایی</div>
                <div class="font-mono text-xs text-cyan-400 mt-1">lerp: 0.05</div>
                <div class="text-[11px] text-slate-400 mt-2">حرکت شناور ابریشمی با لختی بالا (حالت Awwwards)</div>
              </button>

              <button 
                type="button"
                (click)="setLenisLerp(0.08)"
                class="p-4 rounded-xl border text-center transition-all cursor-pointer w-full"
                [class.border-cyan-500]="state.config().lenisConfig.lerp === 0.08"
                [class.bg-cyan-950/20]="state.config().lenisConfig.lerp === 0.08"
                [class.border-slate-800]="state.config().lenisConfig.lerp !== 0.08"
                [class.bg-slate-950/40]="state.config().lenisConfig.lerp !== 0.08">
                <div class="font-bold text-sm text-white">متعادل و ایده‌آل (پیش‌فرض)</div>
                <div class="font-mono text-xs text-cyan-400 mt-1">lerp: 0.08</div>
                <div class="text-[11px] text-slate-400 mt-2">تعادل عالی میان سرعت پاسخ‌دهی کاربر و نرمی حرکت</div>
              </button>

              <button 
                type="button"
                (click)="setLenisLerp(0.15)"
                class="p-4 rounded-xl border text-center transition-all cursor-pointer w-full"
                [class.border-cyan-500]="state.config().lenisConfig.lerp === 0.15"
                [class.bg-cyan-950/20]="state.config().lenisConfig.lerp === 0.15"
                [class.border-slate-800]="state.config().lenisConfig.lerp !== 0.15"
                [class.bg-slate-950/40]="state.config().lenisConfig.lerp !== 0.15">
                <div class="font-bold text-sm text-white">واکنش سریع و اسپرت</div>
                <div class="font-mono text-xs text-cyan-400 mt-1">lerp: 0.15</div>
                <div class="text-[11px] text-slate-400 mt-2">اسکرول سبک با واکنش بلافاصله و حداقل لختی</div>
              </button>
            </div>

            <!-- Custom Lerp Tuning -->
            <div class="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-4">
              <div>
                <div class="flex justify-between text-xs text-slate-400 mb-1.5">
                  <span>تنظیم دقیق ضریب اینرسی (Lerp Multiplier):</span>
                  <span class="font-mono text-cyan-400 font-bold">{{ state.config().lenisConfig.lerp }}</span>
                </div>
                <input 
                  type="range" 
                  min="0.03" 
                  max="0.25" 
                  step="0.01"
                  aria-label="تنظیم دقیق ضریب اینرسی اسکرول"
                  [ngModel]="state.config().lenisConfig.lerp"
                  (ngModelChange)="updateLenisCustomLerp($event)"
                  class="w-full accent-cyan-400 cursor-pointer" />
              </div>

              <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-slate-800/80">
                <label class="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
                  <span>فعال‌سازی Smooth Wheel چرخ ماوس</span>
                  <input 
                    type="checkbox"
                    [ngModel]="state.config().lenisConfig.smoothWheel"
                    (ngModelChange)="updateLenisWheel($event)"
                    class="w-4 h-4 accent-cyan-500 rounded cursor-pointer" />
                </label>
                <label class="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
                  <span>روان‌سازی لمس در گوشی (Smooth Touch)</span>
                  <input 
                    type="checkbox"
                    [ngModel]="state.config().lenisConfig.smoothTouch"
                    (ngModelChange)="updateLenisTouch($event)"
                    class="w-4 h-4 accent-cyan-500 rounded cursor-pointer" />
                </label>
              </div>
            </div>
          </div>
        }

        <!-- STEP 5: GSAP & ScrollTrigger Animations -->
        @if (state.currentStep() === 5) {
          <div class="space-y-6">
            <div class="space-y-1">
              <h3 class="text-xl font-bold text-white flex items-center gap-2">
                <span class="p-1.5 bg-cyan-500/10 text-cyan-400 rounded-lg material-icons text-base">auto_awesome</span>
                سوال ۵: کدام انیمیشن‌های تعاملی GSAP در سایت فعال باشند؟
              </h3>
              <p class="text-sm text-slate-400">
                انیمیشن‌های تعاملی ارزش بصری سایت را چند برابر کرده و حس پرمیوم به کاربر منتقل می‌کنند.
              </p>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <!-- Split text -->
              <label class="p-4 rounded-xl border border-slate-800 bg-slate-950/50 flex items-start gap-3 cursor-pointer hover:border-slate-700 transition-colors">
                <input 
                  type="checkbox" 
                  [ngModel]="state.config().gsapConfig.splitTextAnimation"
                  (ngModelChange)="toggleGsap('splitTextAnimation', $event)"
                  class="mt-1 w-4 h-4 accent-cyan-500 rounded cursor-pointer" />
                <div>
                  <div class="font-bold text-sm text-white">انیمیشن Split Text حروف تیتر قهرمان</div>
                  <div class="text-xs text-slate-400 mt-0.5">ظهور پلکانی و چرخش ظریف تک‌تک حروف با GSAP Stagger</div>
                </div>
              </label>

              <!-- Parallax -->
              <label class="p-4 rounded-xl border border-slate-800 bg-slate-950/50 flex items-start gap-3 cursor-pointer hover:border-slate-700 transition-colors">
                <input 
                  type="checkbox" 
                  [ngModel]="state.config().gsapConfig.parallaxImages"
                  (ngModelChange)="toggleGsap('parallaxImages', $event)"
                  class="mt-1 w-4 h-4 accent-cyan-500 rounded cursor-pointer" />
                <div>
                  <div class="font-bold text-sm text-white">ماسک و زوم پارالاکس تصاویر (Parallax Scrub)</div>
                  <div class="text-xs text-slate-400 mt-0.5">حرکت نرم لایه‌های عکس متناسب با سرعت اسکرول کاربر</div>
                </div>
              </label>

              <!-- Magnetic Cursor -->
              <label class="p-4 rounded-xl border border-slate-800 bg-slate-950/50 flex items-start gap-3 cursor-pointer hover:border-slate-700 transition-colors">
                <input 
                  type="checkbox" 
                  [ngModel]="state.config().gsapConfig.magneticCursor"
                  (ngModelChange)="toggleGsap('magneticCursor', $event)"
                  class="mt-1 w-4 h-4 accent-cyan-500 rounded cursor-pointer" />
                <div>
                  <div class="font-bold text-sm text-white">کرسر سفارشی با اینرسی ماوس</div>
                  <div class="text-xs text-slate-400 mt-0.5">نقطه مرکزی و دایره تعقیب‌کننده با افکت بزرگ‌نمایی در هاور لینک‌ها</div>
                </div>
              </label>

              <!-- Magnetic Buttons -->
              <label class="p-4 rounded-xl border border-slate-800 bg-slate-950/50 flex items-start gap-3 cursor-pointer hover:border-slate-700 transition-colors">
                <input 
                  type="checkbox" 
                  [ngModel]="state.config().gsapConfig.magneticButtons"
                  (ngModelChange)="toggleGsap('magneticButtons', $event)"
                  class="mt-1 w-4 h-4 accent-cyan-500 rounded cursor-pointer" />
                <div>
                  <div class="font-bold text-sm text-white">دکمه‌های مغناطیسی جاذب (Magnetic Buttons)</div>
                  <div class="text-xs text-slate-400 mt-0.5">جذب فیزیکی دکمه‌ها به سمت نشانگر ماوس در شعاع اطراف</div>
                </div>
              </label>

              <!-- 3D Card Tilt -->
              <label class="p-4 rounded-xl border border-slate-800 bg-slate-950/50 flex items-start gap-3 cursor-pointer hover:border-slate-700 transition-colors">
                <input 
                  type="checkbox" 
                  [ngModel]="state.config().gsapConfig.cardTiltHover"
                  (ngModelChange)="toggleGsap('cardTiltHover', $event)"
                  class="mt-1 w-4 h-4 accent-cyan-500 rounded cursor-pointer" />
                <div>
                  <div class="font-bold text-sm text-white">چرخش ۳ بعدی پرسپکتیو کارت‌ها (3D Tilt)</div>
                  <div class="text-xs text-slate-400 mt-0.5">تغییر زاویه و ژرفای کارت‌های پروژه‌ها و مهارت‌ها با زاویه ماوس</div>
                </div>
              </label>

              <!-- Counter Stats -->
              <label class="p-4 rounded-xl border border-slate-800 bg-slate-950/50 flex items-start gap-3 cursor-pointer hover:border-slate-700 transition-colors">
                <input 
                  type="checkbox" 
                  [ngModel]="state.config().gsapConfig.counterStats"
                  (ngModelChange)="toggleGsap('counterStats', $event)"
                  class="mt-1 w-4 h-4 accent-cyan-500 rounded cursor-pointer" />
                <div>
                  <div class="font-bold text-sm text-white">شمارنده انیمیشنی ارقام (Animated Counter)</div>
                  <div class="text-xs text-slate-400 mt-0.5">شمارش نرم و پلکانی اعداد آمارها هنگام ورود به کادر دید</div>
                </div>
              </label>
            </div>
          </div>
        }

        <!-- STEP 6: Color Theme & Typography -->
        @if (state.currentStep() === 6) {
          <div class="space-y-6">
            <div class="space-y-1">
              <h3 class="text-xl font-bold text-white flex items-center gap-2">
                <span class="p-1.5 bg-cyan-500/10 text-cyan-400 rounded-lg material-icons text-base">palette</span>
                سوال ۶: پالت رنگی و استایل دارک وبسایت را انتخاب کنید
              </h3>
              <p class="text-sm text-slate-400">
                تمامی رنگ‌ها در متغیرهای CSS و نورپردازی شیدرهای WebGL هماهنگ خواهند شد.
              </p>
            </div>

            <!-- Theme Presets -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              @for (thm of themePresets; track thm.id) {
                <button 
                  type="button"
                  (click)="state.applyTheme(thm.id)"
                  class="p-4 rounded-xl border transition-all cursor-pointer text-right w-full"
                  [class.border-cyan-500]="state.config().theme.name === thm.name"
                  [class.bg-slate-950]="state.config().theme.name === thm.name"
                  [class.border-slate-800]="state.config().theme.name !== thm.name"
                  [class.bg-slate-950/40]="state.config().theme.name !== thm.name">
                  <div class="flex items-center justify-between mb-3">
                    <span class="font-bold text-sm text-white">{{ thm.name }}</span>
                    <div class="flex gap-1.5">
                      <span class="w-4 h-4 rounded-full border border-white/20" [style.background]="thm.primaryColor"></span>
                      <span class="w-4 h-4 rounded-full border border-white/20" [style.background]="thm.secondaryColor"></span>
                      <span class="w-4 h-4 rounded-full border border-white/20" [style.background]="thm.bgColor"></span>
                    </div>
                  </div>
                  <div class="text-xs font-mono text-slate-400 flex items-center justify-between">
                    <span>رنگ اصلی: {{ thm.primaryColor }}</span>
                    @if (state.config().theme.name === thm.name) {
                      <span class="text-cyan-400 font-bold">فعال ✓</span>
                    }
                  </div>
                </button>
              }
            </div>

            <!-- Custom Color Pickers -->
            <div class="p-4 bg-slate-950/70 border border-slate-800 rounded-xl">
              <div class="text-xs font-semibold text-slate-300 mb-3">سفارشی‌سازی اختصاصی کد رنگ‌ها (HEX)</div>
              <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                <div>
                  <span class="block text-[11px] text-slate-400 mb-1">رنگ اصلی (Primary)</span>
                  <input 
                    type="color" 
                    aria-label="رنگ اصلی"
                    [ngModel]="state.config().theme.primaryColor"
                    (ngModelChange)="updateColor('primaryColor', $event)"
                    class="w-full h-9 rounded-lg bg-transparent cursor-pointer border border-slate-700" />
                  <span class="text-[11px] font-mono text-slate-400">{{ state.config().theme.primaryColor }}</span>
                </div>
                <div>
                  <span class="block text-[11px] text-slate-400 mb-1">رنگ ثانویه (Secondary)</span>
                  <input 
                    type="color" 
                    aria-label="رنگ ثانویه"
                    [ngModel]="state.config().theme.secondaryColor"
                    (ngModelChange)="updateColor('secondaryColor', $event)"
                    class="w-full h-9 rounded-lg bg-transparent cursor-pointer border border-slate-700" />
                  <span class="text-[11px] font-mono text-slate-400">{{ state.config().theme.secondaryColor }}</span>
                </div>
                <div>
                  <span class="block text-[11px] text-slate-400 mb-1">پس‌زمینه (Background)</span>
                  <input 
                    type="color" 
                    aria-label="رنگ پس‌زمینه"
                    [ngModel]="state.config().theme.bgColor"
                    (ngModelChange)="updateColor('bgColor', $event)"
                    class="w-full h-9 rounded-lg bg-transparent cursor-pointer border border-slate-700" />
                  <span class="text-[11px] font-mono text-slate-400">{{ state.config().theme.bgColor }}</span>
                </div>
                <div>
                  <span class="block text-[11px] text-slate-400 mb-1">کارت‌ها (Surface)</span>
                  <input 
                    type="color" 
                    aria-label="رنگ کارت‌ها"
                    [ngModel]="state.config().theme.surfaceColor"
                    (ngModelChange)="updateColor('surfaceColor', $event)"
                    class="w-full h-9 rounded-lg bg-transparent cursor-pointer border border-slate-700" />
                  <span class="text-[11px] font-mono text-slate-400">{{ state.config().theme.surfaceColor }}</span>
                </div>
              </div>
            </div>
          </div>
        }

        <!-- STEP 7: Sections & Content Builder -->
        @if (state.currentStep() === 7) {
          <div class="space-y-6">
            <div class="space-y-1">
              <h3 class="text-xl font-bold text-white flex items-center gap-2">
                <span class="p-1.5 bg-cyan-500/10 text-cyan-400 rounded-lg material-icons text-base">dashboard_customize</span>
                سوال ۷: کدام سکشن‌ها در صفحه وجود داشته باشند؟
              </h3>
              <p class="text-sm text-slate-400">
                سکشن‌های دلخواه را فعال کنید؛ همچنین می‌توانید نمونه پروژه‌ها را ویرایش یا اضافه نمایید.
              </p>
            </div>

            <!-- Section switches -->
            <div class="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              @for (sec of sectionToggles; track sec.key) {
                <label class="p-3 bg-slate-950/60 border border-slate-800 rounded-xl flex items-center justify-between cursor-pointer hover:border-slate-700 transition-colors">
                  <span class="text-xs font-semibold text-white">{{ sec.label }}</span>
                  <input 
                    type="checkbox" 
                    [ngModel]="getSectionValue(sec.key)"
                    (ngModelChange)="setSectionValue(sec.key, $event)"
                    class="w-4 h-4 accent-cyan-500 rounded cursor-pointer" />
                </label>
              }
            </div>

            <!-- Projects Quick Manager -->
            @if (state.config().sections.showProjects) {
              <div class="p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-3">
                <div class="flex items-center justify-between">
                  <div class="text-xs font-semibold text-white flex items-center gap-1.5">
                    <span class="material-icons text-cyan-400 text-sm">work</span>
                    <span>پروژه‌های شاخص در ویترین (تعداد: {{ state.config().projects.length }})</span>
                  </div>
                  <button 
                    type="button"
                    (click)="addSampleProject()"
                    class="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1 cursor-pointer">
                    <span class="material-icons text-xs">add</span>
                    <span>افزودن پروژه جدید</span>
                  </button>
                </div>

                <div class="space-y-2 max-h-52 overflow-y-auto pr-1">
                  @for (proj of state.config().projects; track proj.id; let idx = $index) {
                    <div class="p-2.5 bg-slate-900/60 border border-slate-800 rounded-lg flex items-center justify-between text-xs">
                      <div class="flex items-center gap-2">
                        <span class="font-mono text-cyan-400">0{{ idx + 1 }}</span>
                        <input 
                          type="text" 
                          aria-label="عنوان پروژه"
                          [ngModel]="proj.title"
                          (ngModelChange)="updateProjectTitle(idx, $event)"
                          class="bg-transparent text-white font-bold text-xs focus:outline-none focus:border-b border-cyan-400" />
                        <span class="text-slate-400">({{ proj.category }})</span>
                      </div>
                      <button 
                        type="button"
                        (click)="removeProject(idx)"
                        class="text-slate-500 hover:text-rose-400 material-icons text-sm cursor-pointer"
                        title="حذف پروژه">
                        delete
                      </button>
                    </div>
                  }
                </div>
              </div>
            }
          </div>
        }

        <!-- STEP 8: GitHub Pages Configuration & Deployment -->
        @if (state.currentStep() === 8) {
          <div class="space-y-6">
            <div class="space-y-1">
              <h3 class="text-xl font-bold text-white flex items-center gap-2">
                <span class="p-1.5 bg-cyan-500/10 text-cyan-400 rounded-lg material-icons text-base">rocket_launch</span>
                سوال ۸: ساختار خروجی و نام مخزن گیت‌هاب پیج
              </h3>
              <p class="text-sm text-slate-400">
                این سایت ۱۰۰٪ استاتیک و بدون نیاز به بیلد (Zero-Build) آماده انتشار روی دامنه رایگان github.io شماست.
              </p>
            </div>

            <div class="space-y-4">
              <!-- Output Mode -->
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button 
                  type="button"
                  (click)="setSingleFileMode(true)"
                  class="p-4 rounded-xl border transition-all cursor-pointer text-right w-full"
                  [class.border-cyan-500]="state.config().githubPagesConfig.singleFileMode"
                  [class.bg-cyan-950/20]="state.config().githubPagesConfig.singleFileMode"
                  [class.border-slate-800]="!state.config().githubPagesConfig.singleFileMode"
                  [class.bg-slate-950/40]="!state.config().githubPagesConfig.singleFileMode">
                  <div class="flex items-center justify-between mb-1">
                    <span class="font-bold text-sm text-white">تک فایل مستقل (Single index.html)</span>
                    <span class="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono">پیشنهادی</span>
                  </div>
                  <p class="text-xs text-slate-400 leading-relaxed">
                    تمامی استایل‌ها، اسکریپت‌ها، شیدرهای WebGL و لودرهای CDN در یک فایل جامع index.html تجمیع شده‌اند. کافیست در مخزن آپلود کنید و تمام!
                  </p>
                </button>

                <button 
                  type="button"
                  (click)="setSingleFileMode(false)"
                  class="p-4 rounded-xl border transition-all cursor-pointer text-right w-full"
                  [class.border-cyan-500]="!state.config().githubPagesConfig.singleFileMode"
                  [class.bg-cyan-950/20]="!state.config().githubPagesConfig.singleFileMode"
                  [class.border-slate-800]="state.config().githubPagesConfig.singleFileMode"
                  [class.bg-slate-950/40]="state.config().githubPagesConfig.singleFileMode">
                  <div class="font-bold text-sm text-white mb-1">پکیج تفکیک شده (Modular Bundle)</div>
                  <p class="text-xs text-slate-400 leading-relaxed">
                    فایل‌های مجزا شامل index.html, style.css, script.js, site-config.json و README.md برای برنامه‌نویسانی که ویرایش تفکیک شده را ترجیح می‌دهند.
                  </p>
                </button>
              </div>

              <!-- Repo Name Input -->
              <div>
                <span class="block text-xs font-semibold text-slate-300 mb-1.5">نام مخزن گیت‌هاب (Repository Name)</span>
                <div class="flex items-center gap-2">
                  <span class="font-mono text-xs text-slate-400 bg-slate-950 px-3 py-2.5 rounded-xl border border-slate-800">
                    https://username.github.io/
                  </span>
                  <input 
                    type="text" 
                    aria-label="نام مخزن گیت‌هاب"
                    [ngModel]="state.config().githubPagesConfig.repositoryName"
                    (ngModelChange)="updateRepoName($event)"
                    class="flex-1 px-4 py-2.5 bg-slate-950/70 border border-slate-800 rounded-xl text-white text-sm focus:outline-none focus:border-cyan-500 font-mono" />
                </div>
              </div>

              <!-- Deployment Checklist Highlights -->
              <div class="p-4 bg-emerald-950/20 border border-emerald-900/60 rounded-xl flex items-start gap-3">
                <span class="material-icons text-emerald-400 text-lg mt-0.5">verified</span>
                <div class="text-xs text-emerald-200/90 leading-relaxed">
                  <strong>تأییدیه سازگاری ۱۰۰٪ با GitHub Pages:</strong>
                  مسیردهی‌های نسبی، استفاده از CDNهای HTTPS بدون اختلال CORS، و اسکریپت کانفیگ JSON خالص بدون وابستگی به وب‌پک یا بیلد سیستم.
                </div>
              </div>
            </div>
          </div>
        }

        <!-- NAVIGATION ACTIONS BOTTOM BAR -->
        <div class="mt-8 pt-5 border-t border-slate-800/80 flex items-center justify-between">
          <div>
            @if (state.currentStep() > 1) {
              <button 
                type="button"
                (click)="state.prevStep()"
                class="px-4 py-2 text-xs font-semibold text-slate-300 bg-slate-800/80 hover:bg-slate-700 rounded-xl transition-all flex items-center gap-1 cursor-pointer">
                <span class="material-icons text-sm">arrow_forward</span>
                <span>سوال قبلی</span>
              </button>
            }
          </div>

          <div class="flex items-center gap-3">
            @if (state.currentStep() < state.totalSteps) {
              <button 
                type="button"
                (click)="state.nextStep()"
                class="px-6 py-2.5 text-xs font-bold text-slate-950 bg-gradient-to-r from-cyan-400 to-cyan-500 hover:from-cyan-300 hover:to-cyan-400 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-lg shadow-cyan-500/20">
                <span>سوال بعدی</span>
                <span class="material-icons text-sm">arrow_backward</span>
              </button>
            } @else {
              <button 
                type="button"
                (click)="state.activeTab.set('code')"
                class="px-6 py-2.5 text-xs font-bold text-slate-950 bg-gradient-to-r from-cyan-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-lg shadow-emerald-500/20">
                <span class="material-icons text-sm">code</span>
                <span>تکمیل و مشاهده کدهای نهایی</span>
              </button>
            }
          </div>
        </div>

      </div>
    </div>
  `,
})
export class QuestionnaireComponent {
  readonly state = inject(SiteStateService);

  readonly stepNumbers = [1, 2, 3, 4, 5, 6, 7, 8];
  readonly themePresets = THEME_PRESETS;
  readonly sitePresets = SITE_PRESETS;

  readonly sectionToggles = [
    { key: 'showHero' as const, label: 'بخش قهرمان (Hero)' },
    { key: 'showAbout' as const, label: 'درباره ما (About)' },
    { key: 'showProjects' as const, label: 'پروژه‌ها (Projects)' },
    { key: 'showServices' as const, label: 'خدمات (Services)' },
    { key: 'showStats' as const, label: 'آمارها (Stats)' },
    { key: 'showContact' as const, label: 'فرم ارتباط (Contact)' },
  ];

  getStepTitle(step: number): string {
    switch (step) {
      case 1: return 'هدف و الگو (Site Archetype)';
      case 2: return 'هویت و تیتر قهرمان (Branding & Hero)';
      case 3: return 'موتور سه‌بعدی و شیدر WebGL';
      case 4: return 'تنظیمات اسکرول نرم لِنیس (Lenis)';
      case 5: return 'انیمیشن‌های تعاملی GSAP';
      case 6: return 'پالت رنگ و استایل دارک';
      case 7: return 'سکشن‌ها و نمونه پروژه‌ها';
      case 8: return 'پیکربندی و خروجی GitHub Pages';
      default: return '';
    }
  }

  updateLanguage(lang: 'fa' | 'en') {
    this.state.updateConfig(cfg => ({ ...cfg, language: lang }));
  }

  updateBrandName(val: string) {
    this.state.updateConfig(cfg => ({ ...cfg, brandName: val }));
  }

  updateHeroTitle(val: string) {
    this.state.updateConfig(cfg => ({ ...cfg, heroTitle: val }));
  }

  updateHeroSubtitle(val: string) {
    this.state.updateConfig(cfg => ({ ...cfg, heroSubtitle: val }));
  }

  updateCtaText(val: string) {
    this.state.updateConfig(cfg => ({ ...cfg, ctaText: val }));
  }

  updateCtaLink(val: string) {
    this.state.updateConfig(cfg => ({ ...cfg, ctaLink: val }));
  }

  setWebglEffect(eff: WebglEffectType) {
    this.state.updateConfig(cfg => ({ ...cfg, webglEffect: eff }));
  }

  updateWebglSpeed(speed: number) {
    this.state.updateConfig(cfg => ({
      ...cfg,
      webglConfig: { ...cfg.webglConfig, speed: Number(speed) },
    }));
  }

  updateWebglCount(count: number) {
    this.state.updateConfig(cfg => ({
      ...cfg,
      webglConfig: { ...cfg.webglConfig, particleCount: Number(count) },
    }));
  }

  updateWebglMouse(react: boolean) {
    this.state.updateConfig(cfg => ({
      ...cfg,
      webglConfig: { ...cfg.webglConfig, reactToMouse: react },
    }));
  }

  setLenisLerp(lerp: number) {
    this.state.updateConfig(cfg => ({
      ...cfg,
      lenisConfig: { ...cfg.lenisConfig, lerp },
    }));
  }

  updateLenisCustomLerp(lerp: number) {
    this.state.updateConfig(cfg => ({
      ...cfg,
      lenisConfig: { ...cfg.lenisConfig, lerp: Number(lerp) },
    }));
  }

  updateLenisWheel(smoothWheel: boolean) {
    this.state.updateConfig(cfg => ({
      ...cfg,
      lenisConfig: { ...cfg.lenisConfig, smoothWheel },
    }));
  }

  updateLenisTouch(smoothTouch: boolean) {
    this.state.updateConfig(cfg => ({
      ...cfg,
      lenisConfig: { ...cfg.lenisConfig, smoothTouch },
    }));
  }

  toggleGsap(key: keyof SiteConfig['gsapConfig'], val: boolean) {
    this.state.updateConfig(cfg => ({
      ...cfg,
      gsapConfig: { ...cfg.gsapConfig, [key]: val },
    }));
  }

  updateColor(key: 'primaryColor' | 'secondaryColor' | 'bgColor' | 'surfaceColor', val: string) {
    this.state.updateConfig(cfg => ({
      ...cfg,
      theme: { ...cfg.theme, [key]: val },
    }));
  }

  getSectionValue(key: keyof SiteConfig['sections']): boolean {
    return this.state.config().sections[key];
  }

  setSectionValue(key: keyof SiteConfig['sections'], val: boolean) {
    this.state.updateConfig(cfg => ({
      ...cfg,
      sections: { ...cfg.sections, [key]: val },
    }));
  }

  addSampleProject() {
    this.state.updateConfig(cfg => {
      const newProj = {
        id: 'p_' + Date.now(),
        title: 'PROJECT SPECTRA ' + (cfg.projects.length + 1),
        category: 'WebGL & Interactive Design',
        description: 'طراحی تجربی با شیدرهای سه‌بعدی و انیمیشن‌های لِنیس برای نمایش محصولات آینده.',
        image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1000&q=80',
        year: '2025',
        link: '#',
      };
      return {
        ...cfg,
        projects: [...cfg.projects, newProj],
      };
    });
  }

  updateProjectTitle(index: number, title: string) {
    this.state.updateConfig(cfg => {
      const copy = [...cfg.projects];
      if (copy[index]) {
        copy[index] = { ...copy[index], title };
      }
      return { ...cfg, projects: copy };
    });
  }

  removeProject(index: number) {
    this.state.updateConfig(cfg => {
      const copy = cfg.projects.filter((_, i) => i !== index);
      return { ...cfg, projects: copy };
    });
  }

  setSingleFileMode(val: boolean) {
    this.state.updateConfig(cfg => ({
      ...cfg,
      githubPagesConfig: { ...cfg.githubPagesConfig, singleFileMode: val },
    }));
  }

  updateRepoName(name: string) {
    this.state.updateConfig(cfg => ({
      ...cfg,
      githubPagesConfig: { ...cfg.githubPagesConfig, repositoryName: name },
    }));
  }

  openAiPromptModal() {
    this.state.activeTab.set('prompt');
  }
}
