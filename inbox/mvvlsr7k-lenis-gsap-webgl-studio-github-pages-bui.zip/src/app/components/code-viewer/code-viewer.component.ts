import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SiteStateService } from '../../services/site-state.service';
import { CodeGeneratorService } from '../../services/code-generator.service';
import JSZip from 'jszip';

@Component({
  selector: 'app-code-viewer',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full max-w-5xl mx-auto py-4 px-2 sm:px-4 space-y-4">
      
      <!-- Top Actions Bar -->
      <div class="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-3 shadow-xl">
        <div>
          <div class="text-xs font-mono uppercase tracking-wider text-cyan-400 font-semibold">
            خروجی سازگار با GitHub Pages
          </div>
          <h2 class="text-lg font-bold text-white mt-0.5">
            کدهای تولید شده و پکیج استاتیک
          </h2>
        </div>

        <div class="flex items-center gap-2 flex-wrap">
          <!-- Copy code button -->
          <button 
            (click)="copyActiveCode()"
            class="px-3.5 py-2 text-xs font-bold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-sm">
            <span class="material-icons text-sm">{{ copySuccess() ? 'check' : 'content_copy' }}</span>
            <span>{{ copySuccess() ? 'کپی شد!' : 'کپی کد این تب' }}</span>
          </button>

          <!-- Download single index.html -->
          <button 
            (click)="downloadSingleFile()"
            class="px-3.5 py-2 text-xs font-bold text-cyan-300 bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-800/80 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-sm">
            <span class="material-icons text-sm">download</span>
            <span>دانلود index.html تک‌فایل</span>
          </button>

          <!-- Download complete ZIP bundle -->
          <button 
            (click)="downloadZipBundle()"
            [disabled]="isZipping()"
            class="px-4 py-2 text-xs font-bold text-slate-950 bg-gradient-to-r from-cyan-400 to-emerald-400 hover:from-cyan-300 hover:to-emerald-300 rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-lg shadow-emerald-500/20 disabled:opacity-50">
            <span class="material-icons text-sm">{{ isZipping() ? 'hourglass_top' : 'folder_zip' }}</span>
            <span>{{ isZipping() ? 'در حال زیپ...' : 'دانلود پکیج کامل (ZIP)' }}</span>
          </button>
        </div>
      </div>

      <!-- File Tabs Switcher -->
      <div class="flex items-center gap-1 bg-slate-900/80 p-1.5 rounded-xl border border-slate-800 overflow-x-auto">
        <button 
          (click)="activeFile.set('index.html')"
          class="px-4 py-2 rounded-lg text-xs font-mono font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          [class.bg-cyan-500]="activeFile() === 'index.html'"
          [class.text-slate-950]="activeFile() === 'index.html'"
          [class.text-slate-300]="activeFile() !== 'index.html'"
          [class.hover:bg-slate-800]="activeFile() !== 'index.html'">
          <span class="material-icons text-xs">html</span>
          <span>index.html</span>
          <span class="text-[10px] px-1.5 py-0.2 bg-black/20 rounded">
            {{ state.config().githubPagesConfig.singleFileMode ? 'Standalone' : 'Modular' }}
          </span>
        </button>

        <button 
          (click)="activeFile.set('style.css')"
          class="px-4 py-2 rounded-lg text-xs font-mono font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          [class.bg-cyan-500]="activeFile() === 'style.css'"
          [class.text-slate-950]="activeFile() === 'style.css'"
          [class.text-slate-300]="activeFile() !== 'style.css'"
          [class.hover:bg-slate-800]="activeFile() !== 'style.css'">
          <span class="material-icons text-xs">css</span>
          <span>style.css</span>
        </button>

        <button 
          (click)="activeFile.set('script.js')"
          class="px-4 py-2 rounded-lg text-xs font-mono font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          [class.bg-cyan-500]="activeFile() === 'script.js'"
          [class.text-slate-950]="activeFile() === 'script.js'"
          [class.text-slate-300]="activeFile() !== 'script.js'"
          [class.hover:bg-slate-800]="activeFile() !== 'script.js'">
          <span class="material-icons text-xs">javascript</span>
          <span>script.js (Lenis + GSAP + WebGL)</span>
        </button>

        <button 
          (click)="activeFile.set('site-config.json')"
          class="px-4 py-2 rounded-lg text-xs font-mono font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          [class.bg-cyan-500]="activeFile() === 'site-config.json'"
          [class.text-slate-950]="activeFile() === 'site-config.json'"
          [class.text-slate-300]="activeFile() !== 'site-config.json'"
          [class.hover:bg-slate-800]="activeFile() !== 'site-config.json'">
          <span class="material-icons text-xs">data_object</span>
          <span>site-config.json</span>
        </button>

        <button 
          (click)="activeFile.set('README.md')"
          class="px-4 py-2 rounded-lg text-xs font-mono font-semibold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          [class.bg-cyan-500]="activeFile() === 'README.md'"
          [class.text-slate-950]="activeFile() === 'README.md'"
          [class.text-slate-300]="activeFile() !== 'README.md'"
          [class.hover:bg-slate-800]="activeFile() !== 'README.md'">
          <span class="material-icons text-xs">description</span>
          <span>README.md (آموزش گیتهاب)</span>
        </button>
      </div>

      <!-- Code Box -->
      <div class="relative bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
        <div class="flex items-center justify-between px-4 py-2.5 bg-slate-900 border-b border-slate-800 text-xs font-mono text-slate-400">
          <div class="flex items-center gap-2">
            <span class="w-3 h-3 rounded-full bg-slate-700"></span>
            <span>{{ activeFile() }}</span>
            <span class="text-slate-400">({{ currentCodeLength }} کاراکتر)</span>
          </div>
          <button 
            (click)="copyActiveCode()"
            class="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer">
            <span class="material-icons text-xs">content_copy</span>
            <span>کپی مستقیم</span>
          </button>
        </div>

        <div class="p-4 overflow-x-auto max-h-[580px] overflow-y-auto text-xs font-mono leading-relaxed text-slate-300 select-text bg-[#07090e]">
          <pre class="font-mono whitespace-pre text-left" dir="ltr"><code>{{ currentCodeContent() }}</code></pre>
        </div>
      </div>

      <!-- Helpful tips footer -->
      <div class="bg-cyan-950/20 border border-cyan-900/50 rounded-xl p-4 flex items-start gap-3 text-xs text-cyan-200/90 leading-relaxed">
        <span class="material-icons text-cyan-400 text-base mt-0.5">lightbulb</span>
        <div>
          <strong>نکته طلایی انتشار در GitHub Pages:</strong>
          اگر گزینه <em>تک فایل مستقل (Single index.html)</em> را دانلود کرده‌اید، فقط کافیست آن را به عنوان فایل <code>index.html</code> در شاخه اصلی (Root) مخزن گیت‌هاب قرار دهید و در تنظیمات مخزن، منوی <strong>Pages</strong> را روی شاخه <code>main</code> فعال کنید تا در عرض ۱ دقیقه سایت شما با تمام شیدرهای سه‌بعدی و اسکرول نرم لود شود!
        </div>
      </div>

    </div>
  `,
})
export class CodeViewerComponent {
  readonly state = inject(SiteStateService);
  private readonly generator = inject(CodeGeneratorService);

  readonly activeFile = signal<'index.html' | 'style.css' | 'script.js' | 'site-config.json' | 'README.md'>('index.html');
  readonly copySuccess = signal<boolean>(false);
  readonly isZipping = signal<boolean>(false);

  readonly currentCodeContent = computed(() => {
    const config = this.state.config();
    const file = this.activeFile();

    switch (file) {
      case 'index.html':
        return config.githubPagesConfig.singleFileMode
          ? this.generator.generateSingleHtml(config)
          : this.generator.generateIndexHtml(config);
      case 'style.css':
        return this.generator.generateCss(config);
      case 'script.js':
        return this.generator.generateJs(config);
      case 'site-config.json':
        return JSON.stringify(config, null, 2);
      case 'README.md':
        return this.generator.generateReadme(config);
      default:
        return '';
    }
  });

  get currentCodeLength(): number {
    return this.currentCodeContent().length;
  }

  async copyActiveCode() {
    try {
      await navigator.clipboard.writeText(this.currentCodeContent());
      this.copySuccess.set(true);
      setTimeout(() => this.copySuccess.set(false), 2000);
    } catch {
      // Fallback
    }
  }

  downloadSingleFile() {
    const config = this.state.config();
    const content = this.generator.generateSingleHtml(config);
    this.triggerDownload(content, 'index.html', 'text/html');
  }

  async downloadZipBundle() {
    this.isZipping.set(true);
    try {
      const config = this.state.config();
      const zip = new JSZip();

      // Always include standalone index.html
      zip.file('index.html', this.generator.generateSingleHtml(config));
      // Also include modular files in a 'modular-src' folder
      const modularFolder = zip.folder('modular-source');
      if (modularFolder) {
        modularFolder.file('index.html', this.generator.generateIndexHtml(config));
        modularFolder.file('style.css', this.generator.generateCss(config));
        modularFolder.file('script.js', this.generator.generateJs(config));
        modularFolder.file('site-config.json', JSON.stringify(config, null, 2));
      }

      zip.file('404.html', this.generator.generate404Html(config));
      zip.file('README.md', this.generator.generateReadme(config));
      zip.file('site-config.json', JSON.stringify(config, null, 2));

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${config.githubPagesConfig.repositoryName || 'lenis-webgl-site'}-ghpages.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('ZIP generation error:', err);
    } finally {
      this.isZipping.set(false);
    }
  }

  private triggerDownload(content: string, filename: string, type: string) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}
