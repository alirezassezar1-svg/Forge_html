import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SiteStateService } from '../../services/site-state.service';

@Component({
  selector: 'app-github-guide',
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="w-full max-w-4xl mx-auto py-4 px-2 sm:px-4 space-y-6">
      
      <!-- Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xl">
        <div class="flex items-center gap-3 mb-2">
          <div class="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl material-icons text-xl">cloud_upload</div>
          <div>
            <div class="text-xs font-mono uppercase tracking-wider text-emerald-400 font-semibold">
              استقرار رایگان در کمتر از ۲ دقیقه
            </div>
            <h2 class="text-xl font-bold text-white">
              راهنمای راه‌اندازی در GitHub Pages
            </h2>
          </div>
        </div>
        <p class="text-xs sm:text-sm text-slate-300 leading-relaxed mt-1">
          سایت شما با آدرس رایگان 
          <span class="font-mono text-cyan-400 font-bold">https://username.github.io/{{ state.config().githubPagesConfig.repositoryName }}/</span>
          بدون پرداخت هیچ هزینه‌ای و با نهایت سرعت CDN جهانی گیت‌هاب در دسترس همگان خواهد بود.
        </p>
      </div>

      <!-- Quick Steps Timeline -->
      <div class="space-y-4">
        <!-- Step 1 -->
        <div class="bg-slate-950 border border-slate-800 rounded-2xl p-5 flex items-start gap-4">
          <div class="w-8 h-8 rounded-full bg-cyan-500 text-slate-950 font-bold flex items-center justify-center text-sm font-mono shrink-0">
            1
          </div>
          <div class="space-y-1.5 flex-1">
            <h3 class="text-base font-bold text-white">دانلود فایل index.html یا پکیج ZIP</h3>
            <p class="text-xs text-slate-400 leading-relaxed">
              از منوی بالا دکمه <strong>«دانلود index.html تک‌فایل»</strong> را بزنید. این فایل حاوی تمام استایل‌های CSS، لودرهای Lenis، کدهای GSAP و بوم سه‌بعدی WebGL در یک پکیج آماده است.
            </p>
          </div>
        </div>

        <!-- Step 2 -->
        <div class="bg-slate-950 border border-slate-800 rounded-2xl p-5 flex items-start gap-4">
          <div class="w-8 h-8 rounded-full bg-cyan-500 text-slate-950 font-bold flex items-center justify-center text-sm font-mono shrink-0">
            2
          </div>
          <div class="space-y-2 flex-1">
            <h3 class="text-base font-bold text-white">ساخت مخزن در GitHub و آپلود فایل</h3>
            <p class="text-xs text-slate-400 leading-relaxed">
              وارد سایت <strong>GitHub.com</strong> شوید و یک مخزن جدید (New Repository) با نام 
              <span class="font-mono text-cyan-400 font-bold">{{ state.config().githubPagesConfig.repositoryName }}</span>
              به صورت Public بسازید. سپس روی گزینه <em>Upload files</em> کلیک کرده و فایل <code>index.html</code> را Drag & Drop کنید و دکمه سبز رنگ <strong>Commit changes</strong> را بزنید.
            </p>
          </div>
        </div>

        <!-- Step 3 -->
        <div class="bg-slate-950 border border-slate-800 rounded-2xl p-5 flex items-start gap-4">
          <div class="w-8 h-8 rounded-full bg-cyan-500 text-slate-950 font-bold flex items-center justify-center text-sm font-mono shrink-0">
            3
          </div>
          <div class="space-y-2 flex-1">
            <h3 class="text-base font-bold text-white">فعال‌سازی GitHub Pages در تنظیمات مخزن</h3>
            <p class="text-xs text-slate-400 leading-relaxed">
              در بالای صفحه مخزن گیت‌هاب روی تب <strong>Settings</strong> کلیک کنید. از ستون سمت چپ گزینه <strong>Pages</strong> را انتخاب کنید. سپس در بخش <em>Build and deployment</em>:
            </p>
            <div class="bg-slate-900 border border-slate-800 rounded-xl p-3 font-mono text-xs text-slate-300 space-y-1">
              <div>Source: <strong>Deploy from a branch</strong></div>
              <div>Branch: <strong>main</strong> / Folder: <strong>/ (root)</strong></div>
            </div>
            <p class="text-xs text-slate-400">
              دکمه <strong>Save</strong> را بزنید. بعد از حدود ۶۰ ثانیه، لینک سایت زنده شما با تیک سبز نمایان می‌شود!
            </p>
          </div>
        </div>
      </div>

      <!-- Git CLI Commands Box -->
      <div class="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div class="px-5 py-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs font-mono text-slate-300">
          <span>دستورات سریع برای برنامه‌نویسان (Git CLI)</span>
          <span class="text-cyan-400 font-mono">Terminal Bash</span>
        </div>
        <div class="p-4 font-mono text-xs text-slate-300 bg-[#07090e] leading-loose text-left" dir="ltr">
<pre><code># ۱. مقداردهی اولیه مخزن لوکال
git init
git add .
git commit -m "feat: initial interactive Lenis + GSAP + WebGL website"

# ۲. اتصال به گیت‌هاب و ارسال کدهای استاتیک
git branch -M main
git remote add origin https://github.com/&lt;YOUR-USERNAME&gt;/{{ state.config().githubPagesConfig.repositoryName }}.git
git push -u origin main</code></pre>
        </div>
      </div>

      <!-- Compatibility Matrix -->
      <div class="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 space-y-3">
        <h3 class="text-sm font-bold text-white flex items-center gap-2">
          <span class="material-icons text-emerald-400 text-base">verified</span>
          چک‌لیست سازگاری ۱۰۰٪ با استاندارد GitHub Pages
        </h3>
        
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
          <div class="flex items-center gap-2 p-2.5 bg-slate-950/60 rounded-xl border border-slate-800">
            <span class="material-icons text-emerald-400 text-sm">check_circle</span>
            <span class="text-slate-300">بدون نیاز به پکیج‌های نود یا سرور Node.js</span>
          </div>
          <div class="flex items-center gap-2 p-2.5 bg-slate-950/60 rounded-xl border border-slate-800">
            <span class="material-icons text-emerald-400 text-sm">check_circle</span>
            <span class="text-slate-300">لود ایمن کتابخانه‌ها از CDN معتبر با پروتکل HTTPS</span>
          </div>
          <div class="flex items-center gap-2 p-2.5 bg-slate-950/60 rounded-xl border border-slate-800">
            <span class="material-icons text-emerald-400 text-sm">check_circle</span>
            <span class="text-slate-300">ساختار مسیردهی نسبی برای ساب‌پوشه‌ها و دامنه‌های فرعی</span>
          </div>
          <div class="flex items-center gap-2 p-2.5 bg-slate-950/60 rounded-xl border border-slate-800">
            <span class="material-icons text-emerald-400 text-sm">check_circle</span>
            <span class="text-slate-300">تگ پیکربندی وانیلا JSON اسکریپت بدون اختلال بیلد</span>
          </div>
        </div>
      </div>

    </div>
  `,
})
export class GithubGuideComponent {
  readonly state = inject(SiteStateService);
}
