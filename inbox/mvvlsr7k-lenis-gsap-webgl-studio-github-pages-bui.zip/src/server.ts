import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

/**
 * Gemini AI Enhancement API endpoint
 */
app.post('/api/ai/enhance', async (req, res) => {
  try {
    const { prompt, siteType, language } = req.body || {};
    const apiKey = process.env['GEMINI_API_KEY'];

    if (!apiKey) {
      return res.status(200).json({
        fallback: true,
        message: 'No API key provided, fallback to client generator',
      });
    }

    const { GoogleGenAI } = await import('@google/genai');
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const aiResponse = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `You are an elite creative technologist & Awwwards design judge.
Generate creative content for an ultra-modern website built with Lenis Smooth Scroll, GSAP, WebGL and pure Vanilla JS/HTML5/CSS3.
User prompt / intent: "${prompt || siteType}"
Target site style/niche: "${siteType || 'Creative Studio'}"
Language: "${language || 'fa'}" (If 'fa', provide fluent, evocative Persian copywriting; if 'en', provide sleek English copywriting).

Respond ONLY with valid JSON having this exact structure:
{
  "brandName": "Short distinctive name",
  "heroTitle": "3 to 5 striking words separated by spaces",
  "heroSubtitle": "A poetic and compelling 1-2 sentence tagline",
  "ctaText": "Short action label",
  "aboutTitle": "About section heading",
  "aboutDescription": "Engaging modern narrative about craft, innovation, and digital aesthetics",
  "projects": [
    {"title": "Project Name 1", "category": "Interactive 3D / WebGL", "description": "High-impact description", "year": "2025"},
    {"title": "Project Name 2", "category": "Creative Direction", "description": "High-impact description", "year": "2025"},
    {"title": "Project Name 3", "category": "Digital Experience", "description": "High-impact description", "year": "2024"}
  ],
  "services": [
    {"title": "Creative Development", "desc": "Lenis smooth scroll and GSAP micro-interactions"},
    {"title": "WebGL & Shaders", "desc": "Custom fragment shaders and real-time GPU canvas rendering"},
    {"title": "Spatial Branding", "desc": "Kinetic typography and responsive art direction"}
  ],
  "stats": [
    {"value": "99.8%", "label": "Smooth Frame Rate"},
    {"value": "120 FPS", "label": "WebGL Performance"},
    {"value": "100%", "label": "GitHub Pages Ready"}
  ]
}`,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(aiResponse.text || '{}');
    return res.status(200).json({ success: true, data: parsed });
  } catch (error: unknown) {
    console.error('AI enhance endpoint error:', error);
    return res.status(200).json({
      fallback: true,
      error: (error as Error)?.message || 'Server error',
    });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
