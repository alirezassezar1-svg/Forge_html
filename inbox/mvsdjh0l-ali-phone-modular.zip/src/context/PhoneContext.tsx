import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useMemo,
  type ReactNode,
} from 'react';
import type {
  TitaniumFinish,
  CustomApp,
  ProductItem,
  NoteItem,
  PhotoItem,
  ContactItem,
  DynamicIslandState,
  AppLanguage,
  AppRegion,
  CalendarType,
  NumberSystem,
} from '../types/phone';
import {
  DEFAULT_WALLPAPERS,
  INITIAL_PRODUCTS,
  INITIAL_CUSTOM_APPS,
  INITIAL_NOTES,
  INITIAL_CONTACTS,
  INITIAL_PHOTOS,
} from '../utils/defaultData';
import { loadLocal, saveLocal } from '../hooks/useLocalStorage';
import {
  useBattery,
  useNetwork,
  useIsNative,
  useTorch,
  useWakeLock,
  useInstallPrompt,
} from '../utils/device';
import { audioEngine } from '../utils/audioEngine';
import { soundEffects } from '../utils/soundEffects';
import { t } from '../utils/i18n';

const STORAGE_PREFIX = 'aliphone_';

function load<T>(key: string, fallback: T): T {
  return loadLocal(`${STORAGE_PREFIX}${key}`, fallback);
}

function save(key: string, value: unknown) {
  saveLocal(`${STORAGE_PREFIX}${key}`, value);
}

export interface ActiveCall {
  name: string;
  number: string;
  duration: number;
}

export interface PhoneContextValue {
  // OS navigation
  isLocked: boolean;
  setIsLocked: (v: boolean) => void;
  currentApp: string | null;
  setCurrentApp: (id: string | null) => void;
  openApp: (id: string) => void;
  closeApp: () => void;
  controlCenterOpen: boolean;
  setControlCenterOpen: (v: boolean) => void;
  siriOpen: boolean;
  setSiriOpen: (v: boolean) => void;

  // Dynamic Island
  dynamicIsland: DynamicIslandState;
  setDynamicIsland: React.Dispatch<React.SetStateAction<DynamicIslandState>>;

  // Hardware & appearance
  titaniumFinish: TitaniumFinish;
  setTitaniumFinish: (f: TitaniumFinish) => void;
  wallpaperUrl: string;
  setWallpaperUrl: (url: string) => void;

  // Locale
  language: AppLanguage;
  setLanguage: (l: AppLanguage) => void;
  region: AppRegion;
  setRegion: (r: AppRegion) => void;
  calendarType: CalendarType;
  setCalendarType: (c: CalendarType) => void;
  numberSystem: NumberSystem;
  setNumberSystem: (n: NumberSystem) => void;

  // Data stores
  installedApps: CustomApp[];
  setInstalledApps: React.Dispatch<React.SetStateAction<CustomApp[]>>;
  products: ProductItem[];
  setProducts: React.Dispatch<React.SetStateAction<ProductItem[]>>;
  notes: NoteItem[];
  setNotes: React.Dispatch<React.SetStateAction<NoteItem[]>>;
  contacts: ContactItem[];
  photos: PhotoItem[];
  setPhotos: React.Dispatch<React.SetStateAction<PhotoItem[]>>;

  // System toggles
  brightness: number;
  setBrightness: (v: number) => void;
  volume: number;
  setVolume: (v: number) => void;
  flashlightOn: boolean;
  setFlashlightOn: React.Dispatch<React.SetStateAction<boolean>>;
  lowPowerMode: boolean;
  setLowPowerMode: (v: boolean) => void;
  darkMode: boolean;
  setDarkMode: (v: boolean) => void;
  wifiEnabled: boolean;
  setWifiEnabled: (v: boolean) => void;
  bluetoothEnabled: boolean;
  setBluetoothEnabled: (v: boolean) => void;
  airplaneMode: boolean;
  setAirplaneMode: (v: boolean) => void;
  soundEnabled: boolean;
  setSoundEnabled: (v: boolean) => void;

  // Media & call
  isMusicPlaying: boolean;
  setIsMusicPlaying: (v: boolean) => void;
  currentTrackTitle: string;
  setCurrentTrackTitle: (v: string) => void;
  activeCall: ActiveCall | null;
  setActiveCall: React.Dispatch<React.SetStateAction<ActiveCall | null>>;
  handleToggleMusic: () => void;
  handleStartCall: (name: string, number: string) => void;
  handleEndCall: () => void;
  handleStartTimer: (seconds: number) => void;

  // Device hooks (real hardware when available)
  isNative: boolean;
  battery: ReturnType<typeof useBattery>;
  network: ReturnType<typeof useNetwork>;
  pwa: ReturnType<typeof useInstallPrompt>;
  currentTime: Date;

  // Actions
  handlePowerClick: () => void;
  handlePowerLongPress: () => void;
  handleCapturePhoto: (photoUrl: string) => void;
  handleExecuteAction: (action: string) => void;
  handleResetData: () => void;
}

const PhoneContext = createContext<PhoneContextValue | null>(null);

export function PhoneProvider({ children }: { children: ReactNode }) {
  // OS
  const [isLocked, setIsLocked] = useState(false);
  const [currentApp, setCurrentApp] = useState<string | null>(null);
  const [controlCenterOpen, setControlCenterOpen] = useState(false);
  const [siriOpen, setSiriOpen] = useState(false);

  const [dynamicIsland, setDynamicIsland] = useState<DynamicIslandState>({
    type: 'idle',
    expanded: false,
  });

  // Appearance
  const [titaniumFinish, setTitaniumFinish] = useState<TitaniumFinish>(() =>
    load('titanium_finish', 'desert')
  );
  const [wallpaperUrl, setWallpaperUrl] = useState<string>(() => {
    const saved = load('wallpaper_url', DEFAULT_WALLPAPERS[0]?.url ?? DEFAULT_WALLPAPERS[0].url);
    // Migrate old aistudio paths to local wallpapers
    if (saved.includes('/assets/aistudio/')) {
      return DEFAULT_WALLPAPERS[0]?.url ?? DEFAULT_WALLPAPERS[0].url;
    }
    return saved || DEFAULT_WALLOPERS_FALLBACK();
  });

  // Locale
  const [language, setLanguage] = useState<AppLanguage>(() => load('language', 'fa'));
  const [region, setRegion] = useState<AppRegion>(() => load('region', 'IR'));
  const [calendarType, setCalendarType] = useState<CalendarType>(() =>
    load('calendar_type', 'persian')
  );
  const [numberSystem, setNumberSystem] = useState<NumberSystem>(() =>
    load('number_system', 'persian')
  );

  // Data
  const [installedApps, setInstalledApps] = useState<CustomApp[]>(() =>
    load('installed_apps', INITIAL_CUSTOM_APPS)
  );
  const [products, setProducts] = useState<ProductItem[]>(() =>
    load('products', INITIAL_PRODUCTS)
  );
  const [notes, setNotes] = useState<NoteItem[]>(() => load('notes', INITIAL_NOTES));
  const [contacts] = useState<ContactItem[]>(INITIAL_CONTACTS);
  const [photos, setPhotos] = useState<PhotoItem[]>(() => load('photos', INITIAL_PHOTOS));

  // System
  const [brightness, setBrightness] = useState(100);
  const [volume, setVolume] = useState(85);
  const [flashlightOn, setFlashlightOn] = useState(false);
  const [lowPowerMode, setLowPowerMode] = useState(false);
  const [darkMode, setDarkMode] = useState(true);
  const [wifiEnabled, setWifiEnabled] = useState(true);
  const [bluetoothEnabled, setBluetoothEnabled] = useState(true);
  const [airplaneMode, setAirplaneMode] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Media
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const [currentTrackTitle, setCurrentTrackTitle] = useState(
    'ALI Spatial Audio - Titanium Vibes'
  );
  const [activeCall, setActiveCall] = useState<ActiveCall | null>(null);

  // Device
  const isNative = useIsNative();
  const battery = useBattery();
  const network = useNetwork();
  const pwa = useInstallPrompt();
  useTorch(flashlightOn && currentApp !== 'camera');
  useWakeLock(!isLocked);

  const [currentTime, setCurrentTime] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  // Persist
  useEffect(() => save('titanium_finish', titaniumFinish), [titaniumFinish]);
  useEffect(() => save('wallpaper_url', wallpaperUrl), [wallpaperUrl]);
  useEffect(() => save('language', language), [language]);
  useEffect(() => save('region', region), [region]);
  useEffect(() => save('calendar_type', calendarType), [calendarType]);
  useEffect(() => save('number_system', numberSystem), [numberSystem]);
  useEffect(() => save('installed_apps', installedApps), [installedApps]);
  useEffect(() => save('products', products), [products]);
  useEffect(() => save('notes', notes), [notes]);
  useEffect(() => save('photos', photos), [photos]);

  // Audio engine sync
  useEffect(() => {
    const unsub = audioEngine.subscribe((playing) => setIsMusicPlaying(playing));
    return unsub;
  }, []);

  // Navigation helpers
  const openApp = useCallback((id: string) => {
    setIsLocked(false);
    setCurrentApp(id);
    setControlCenterOpen(false);
    setSiriOpen(false);
  }, []);

  const closeApp = useCallback(() => {
    setCurrentApp(null);
  }, []);

  const handlePowerClick = useCallback(() => {
    soundEffects.lock(soundEnabled);
    if (isLocked) {
      setIsLocked(false);
    } else {
      setIsLocked(true);
      setCurrentApp(null);
      setControlCenterOpen(false);
      setSiriOpen(false);
    }
  }, [isLocked, soundEnabled]);

  const handlePowerLongPress = useCallback(() => {
    setSiriOpen(true);
  }, []);

  const handleToggleMusic = useCallback(() => {
    audioEngine.toggle();
  }, []);

  const handleStartCall = useCallback((name: string, number: string) => {
    setActiveCall({ name, number, duration: 0 });
    setDynamicIsland({ type: 'call', title: name, expanded: false });
  }, []);

  const handleEndCall = useCallback(() => {
    setActiveCall(null);
    setDynamicIsland({ type: 'idle' });
  }, []);

  const handleStartTimer = useCallback(
    (seconds: number) => {
      setDynamicIsland({
        type: 'timer',
        title: t('clock', language),
        remainingSeconds: seconds,
        expanded: false,
      });
      let remaining = seconds;
      const interval = setInterval(() => {
        remaining -= 1;
        if (remaining <= 0) {
          clearInterval(interval);
          soundEffects.notification(soundEnabled);
          setDynamicIsland({ type: 'idle' });
        } else {
          setDynamicIsland((prev) =>
            prev.type === 'timer' ? { ...prev, remainingSeconds: remaining } : prev
          );
        }
      }, 1000);
    },
    [language, soundEnabled]
  );

  const handleCapturePhoto = useCallback((photoUrl: string) => {
    const newPhoto: PhotoItem = {
      id: `photo_${Date.now()}`,
      url: photoUrl,
      title: `iPhone 16 Pro Max 48MP - ${new Date().toLocaleString()}`,
      date: new Date().toISOString(),
      isFavorite: false,
    };
    setPhotos((prev) => [newPhoto, ...prev]);
    soundEffects.cameraShutter(soundEnabled);
  }, [soundEnabled]);

  const handleExecuteAction = useCallback(
    (actionStr: string) => {
      if (actionStr.startsWith('open_app:')) {
        openApp(actionStr.replace('open_app:', ''));
      } else if (actionStr === 'flashlight:toggle') {
        setFlashlightOn((prev) => !prev);
      } else if (actionStr === 'take_photo') {
        openApp('camera');
      }
    },
    [openApp]
  );

  const handleResetData = useCallback(() => {
    Object.keys(localStorage)
      .filter((k) => k.startsWith(STORAGE_PREFIX))
      .forEach((k) => localStorage.removeItem(k));
    setInstalledApps(INITIAL_CUSTOM_APPS);
    setProducts(INITIAL_PRODUCTS);
    setNotes(INITIAL_NOTES);
    setPhotos(INITIAL_PHOTOS);
    setTitaniumFinish('desert');
    setWallpaperUrl(DEFAULT_WALLPAPERS[0]?.url ?? DEFAULT_WALLOPERS_FALLBACK());
    setLanguage('fa');
    setRegion('IR');
    setCalendarType('persian');
    setNumberSystem('persian');
    soundEffects.notification(soundEnabled);
  }, [soundEnabled]);

  const value = useMemo<PhoneContextValue>(
    () => ({
      isLocked,
      setIsLocked,
      currentApp,
      setCurrentApp,
      openApp,
      closeApp,
      controlCenterOpen,
      setControlCenterOpen,
      siriOpen,
      setSiriOpen,
      dynamicIsland,
      setDynamicIsland,
      titaniumFinish,
      setTitaniumFinish,
      wallpaperUrl,
      setWallpaperUrl,
      language,
      setLanguage,
      region,
      setRegion,
      calendarType,
      setCalendarType,
      numberSystem,
      setNumberSystem,
      installedApps,
      setInstalledApps,
      products,
      setProducts,
      notes,
      setNotes,
      contacts,
      photos,
      setPhotos,
      brightness,
      setBrightness,
      volume,
      setVolume,
      flashlightOn,
      setFlashlightOn,
      lowPowerMode,
      setLowPowerMode,
      darkMode,
      setDarkMode,
      wifiEnabled,
      setWifiEnabled,
      bluetoothEnabled,
      setBluetoothEnabled,
      airplaneMode,
      setAirplaneMode,
      soundEnabled,
      setSoundEnabled,
      isMusicPlaying,
      setIsMusicPlaying,
      currentTrackTitle,
      setCurrentTrackTitle,
      activeCall,
      setActiveCall,
      handleToggleMusic,
      handleStartCall,
      handleEndCall,
      handleStartTimer,
      isNative,
      battery,
      network,
      pwa,
      currentTime,
      handlePowerClick,
      handlePowerLongPress,
      handleCapturePhoto,
      handleExecuteAction,
      handleResetData,
    }),
    [
      isLocked,
      currentApp,
      openApp,
      closeApp,
      controlCenterOpen,
      siriOpen,
      dynamicIsland,
      titaniumFinish,
      wallpaperUrl,
      language,
      region,
      calendarType,
      numberSystem,
      installedApps,
      products,
      notes,
      contacts,
      photos,
      brightness,
      volume,
      flashlightOn,
      lowPowerMode,
      darkMode,
      wifiEnabled,
      bluetoothEnabled,
      airplaneMode,
      soundEnabled,
      isMusicPlaying,
      currentTrackTitle,
      activeCall,
      handleToggleMusic,
      handleStartCall,
      handleEndCall,
      handleStartTimer,
      isNative,
      battery,
      network,
      pwa,
      currentTime,
      handlePowerClick,
      handlePowerLongPress,
      handleCapturePhoto,
      handleExecuteAction,
      handleResetData,
    ]
  );

  return <PhoneContext.Provider value={value}>{children}</PhoneContext.Provider>;
}

function DEFAULT_WALLOPERS_FALLBACK() {
  return '/wallpapers/iphone16_titanium_desert_1792636480310.jpg';
}

export function usePhone(): PhoneContextValue {
  const ctx = useContext(PhoneContext);
  if (!ctx) {
    throw new Error('usePhone must be used within PhoneProvider');
  }
  return ctx;
}
