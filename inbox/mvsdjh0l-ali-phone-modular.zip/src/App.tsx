import React from 'react';
import {
  Palette,
  Lock,
  Unlock,
  Cpu,
  Wifi,
  Radio,
} from 'lucide-react';
import { PhoneProvider, usePhone } from './context/PhoneContext';
import { SUPPORTED_LANGUAGES, t } from './utils/i18n';
import { soundEffects } from './utils/soundEffects';
import type { TitaniumFinish } from './types/phone';

import { IPhoneChassis } from './components/hardware/IPhoneChassis';
import { DynamicIsland } from './components/os/DynamicIsland';
import { ControlCenter } from './components/os/ControlCenter';
import { SiriOverlay } from './components/os/SiriOverlay';
import { InstallPrompt } from './components/os/InstallPrompt';
import { AppRenderer } from './components/os/AppRenderer';

/**
 * Root App — thin shell.
 * All state lives in PhoneContext.
 * App switching lives in AppRenderer.
 * Terminal / code execution remain isolated on the server (sandboxDir).
 */
export default function App() {
  return (
    <PhoneProvider>
      <AppShell />
    </PhoneProvider>
  );
}

function AppShell() {
  const phone = usePhone();
  const {
    isNative,
    isLocked,
    currentApp,
    openApp,
    closeApp,
    controlCenterOpen,
    setControlCenterOpen,
    siriOpen,
    setSiriOpen,
    dynamicIsland,
    setDynamicIsland,
    titaniumFinish,
    setTitaniumFinish,
    language,
    brightness,
    volume,
    setBrightness,
    setVolume,
    wifiEnabled,
    setWifiEnabled,
    bluetoothEnabled,
    setBluetoothEnabled,
    airplaneMode,
    setAirplaneMode,
    flashlightOn,
    setFlashlightOn,
    lowPowerMode,
    setLowPowerMode,
    darkMode,
    setDarkMode,
    soundEnabled,
    isMusicPlaying,
    currentTrackTitle,
    handleToggleMusic,
    handlePowerClick,
    handlePowerLongPress,
    handleExecuteAction,
    products,
    installedApps,
    battery,
    network,
    pwa,
    currentTime,
  } = phone;

  const isRTL = SUPPORTED_LANGUAGES.find((l) => l.code === language)?.dir === 'rtl';

  const screenContent = (
    <div
      className="relative flex flex-col h-full w-full overflow-hidden bg-black"
      style={{ filter: `brightness(${brightness}%)` }}
    >
      {/* Dynamic Island */}
      <div className="pointer-events-auto absolute top-0 left-0 right-0 z-50 flex justify-center pt-[max(env(safe-area-inset-top),12px)]">
        <div className="pointer-events-auto relative">
          <DynamicIsland
            state={dynamicIsland}
            onUpdateState={(next) => setDynamicIsland((prev) => ({ ...prev, ...next }))}
            onOpenApp={openApp}
            isMusicPlaying={isMusicPlaying}
            onToggleMusic={handleToggleMusic}
            currentTrackTitle={currentTrackTitle}
            soundEnabled={soundEnabled}
          />
        </div>
      </div>

      {/* Active screen */}
      <div
        key={currentApp || (isLocked ? 'locked' : 'home')}
        className="flex-1 relative overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-200 ease-out"
      >
        <AppRenderer />
      </div>

      {/* Home indicator */}
      <div
        onClick={() => {
          soundEffects.click(soundEnabled);
          closeApp();
        }}
        className="absolute left-0 right-0 h-7 flex items-center justify-center cursor-pointer group z-40"
        style={{ bottom: isNative ? 'calc(env(safe-area-inset-bottom) * 0.35 + 4px)' : 6 }}
        onContextMenu={(e) => {
          e.preventDefault();
          setSiriOpen(true);
        }}
        title="Home Bar"
      >
        <div className="w-34 h-1 bg-white/70 group-hover:bg-white rounded-full transition-all group-active:w-28" />
      </div>

      {/* Control Center */}
      <ControlCenter
        isOpen={controlCenterOpen}
        onClose={() => setControlCenterOpen(false)}
        brightness={brightness}
        setBrightness={setBrightness}
        volume={volume}
        setVolume={setVolume}
        wifiEnabled={wifiEnabled}
        setWifiEnabled={setWifiEnabled}
        bluetoothEnabled={bluetoothEnabled}
        setBluetoothEnabled={setBluetoothEnabled}
        airplaneMode={airplaneMode}
        setAirplaneMode={setAirplaneMode}
        flashlightOn={flashlightOn}
        setFlashlightOn={setFlashlightOn}
        lowPowerMode={lowPowerMode}
        setLowPowerMode={setLowPowerMode}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        onOpenApp={openApp}
        isMusicPlaying={isMusicPlaying}
        onToggleMusic={handleToggleMusic}
        currentTrackTitle={currentTrackTitle}
        soundEnabled={soundEnabled}
        language={language}
      />

      {/* ALI Intelligence (Siri-like) */}
      <SiriOverlay
        isOpen={siriOpen}
        onClose={() => setSiriOpen(false)}
        onExecuteAction={handleExecuteAction}
        soundEnabled={soundEnabled}
        phoneContext={{
          productsCount: products.length,
          installedAppsCount: installedApps.length,
          titaniumFinish,
          brightness,
          isLocked,
          currentApp,
          language,
        }}
      />
    </div>
  );

  // Native / PWA fullscreen
  if (isNative) {
    return (
      <div
        dir={isRTL ? 'rtl' : 'ltr'}
        className="fixed inset-0 bg-black text-white overflow-hidden"
      >
        {screenContent}
        <InstallPrompt
          variant="banner"
          canInstall={pwa.canInstall}
          installed={pwa.installed}
          iosManual={pwa.iosManual}
          onInstall={pwa.install}
        />
      </div>
    );
  }

  // Desktop studio view with chassis
  return (
    <div
      dir={isRTL ? 'rtl' : 'ltr'}
      className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans select-none overflow-x-hidden"
    >
      <header className="h-14 border-b border-neutral-800 bg-neutral-900/80 backdrop-blur-md px-4 sm:px-8 flex items-center justify-between gap-4 z-40 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-600 flex items-center justify-center font-bold text-black text-xs shadow-md shadow-amber-500/20">
            ALI
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-tight">ALI phone</h1>
            <p className="text-[10px] text-neutral-500 leading-none">
              iPhone 16 Pro Max · A18 Pro · Modular Build
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 text-xs text-neutral-400">
          <span className="hidden sm:inline-flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-amber-400" />
            {battery.level != null ? `${Math.round(battery.level * 100)}%` : '—'}
          </span>
          <span className="hidden sm:inline-flex items-center gap-1.5">
            {network.online ? (
              <Wifi className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <Radio className="w-3.5 h-3.5 text-red-400" />
            )}
            {network.online ? 'Online' : 'Offline'}
          </span>
          <span className="tabular-nums">
            {currentTime.toLocaleTimeString(language === 'fa' ? 'fa-IR' : 'en-US', {
              hour: '2-digit',
              minute: '2-digit',
            })}
          </span>
        </div>
      </header>

      <main className="flex-1 flex flex-col lg:flex-row items-center justify-center gap-8 p-4 sm:p-8 overflow-auto">
        {/* Phone chassis */}
        <div className="relative shrink-0">
          <IPhoneChassis
            finish={titaniumFinish}
            onPowerClick={handlePowerClick}
            onPowerLongPress={handlePowerLongPress}
            onActionButtonClick={() => setControlCenterOpen(true)}
            onCameraControlClick={() => openApp('camera')}
            onVolumeUp={() => setVolume(Math.min(100, volume + 5))}
            onVolumeDown={() => setVolume(Math.max(0, volume - 5))}
            soundEnabled={soundEnabled}
            brightness={brightness}
            flashlightOn={flashlightOn}
          >
            {screenContent}
          </IPhoneChassis>
        </div>

        {/* Side panel – hardware controls */}
        <div className="w-full max-w-xs space-y-4">
          <div className="p-4 rounded-3xl bg-neutral-900/90 border border-neutral-800 shadow-xl space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Palette className="w-4 h-4 text-sky-400" />
              <span>{t('set_hardware_color', language)}</span>
            </h3>

            <div className="grid grid-cols-4 gap-2">
              {(['desert', 'black', 'natural', 'white'] as TitaniumFinish[]).map((f) => (
                <button
                  key={f}
                  onClick={() => {
                    soundEffects.click(soundEnabled);
                    setTitaniumFinish(f);
                  }}
                  className={`p-2 rounded-2xl border text-center transition-all ${
                    titaniumFinish === f
                      ? 'border-amber-400 bg-white/10 font-bold'
                      : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white'
                  }`}
                >
                  <span
                    className={`block w-5 h-5 rounded-full mx-auto mb-1 border border-white/20 ${
                      f === 'desert'
                        ? 'bg-[#B48860]'
                        : f === 'black'
                        ? 'bg-[#383735]'
                        : f === 'natural'
                        ? 'bg-[#98928A]'
                        : 'bg-[#E5E5EA]'
                    }`}
                  />
                  <span className="text-[10px] block truncate capitalize">{f}</span>
                </button>
              ))}
            </div>

            <div className="pt-2 flex items-center justify-between text-xs text-neutral-400">
              <button
                onClick={handlePowerClick}
                className="flex items-center gap-1.5 hover:text-white"
              >
                {isLocked ? (
                  <Unlock className="w-4 h-4 text-emerald-400" />
                ) : (
                  <Lock className="w-4 h-4 text-amber-400" />
                )}
                <span>{isLocked ? 'Unlock' : 'Lock'}</span>
              </button>

              <button
                onClick={() => setControlCenterOpen(true)}
                className="text-blue-400 hover:underline"
              >
                Control Center
              </button>
            </div>
          </div>

          <InstallPrompt
            variant="card"
            canInstall={pwa.canInstall}
            installed={pwa.installed}
            iosManual={pwa.iosManual}
            onInstall={pwa.install}
          />
        </div>
      </main>
    </div>
  );
}
