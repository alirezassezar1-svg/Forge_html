import React, { useState, useEffect } from 'react';
import {
  Play,
  RotateCcw,
  Code2,
  Terminal,
  ExternalLink,
  ChevronLeft,
  Smartphone,
  Laptop,
  Globe,
  Layers,
  Sparkles,
  Save,
  Check,
  Package,
  Activity,
  Server,
  Zap,
  ArrowUpRight,
} from 'lucide-react';
import { soundEffects } from '../../utils/soundEffects';
import { AppLanguage, CustomApp, DevProject } from '../../types/phone';

interface ProjectRunnerAppProps {
  projectId: string;
  soundEnabled: boolean;
  language: AppLanguage;
  onBack: () => void;
  onInstallToHomeScreen: (app: CustomApp) => void;
}

export const ProjectRunnerApp: React.FC<ProjectRunnerAppProps> = ({
  projectId,
  soundEnabled,
  language,
  onBack,
  onInstallToHomeScreen,
}) => {
  const [activeTab, setActiveTab] = useState<'preview' | 'code' | 'logs' | 'artisan'>('preview');
  const [isRunning, setIsRunning] = useState(true);
  const [logs, setLogs] = useState<string[]>([]);
  const [code, setCode] = useState<string>('');
  const [installed, setInstalled] = useState(false);
  const [commandInput, setCommandInput] = useState('');
  const [reactCounter, setReactCounter] = useState(3);

  // Determine project type
  const isReact = projectId.toLowerCase().includes('react') || projectId.toLowerCase().includes('froshgahi');
  const isLaravel = projectId.toLowerCase().includes('laravel') || projectId.toLowerCase().includes('php');
  const isPython = projectId.toLowerCase().includes('python') || projectId.toLowerCase().includes('deepseek') || projectId.toLowerCase().includes('qwen') || projectId.toLowerCase().includes('crawler');
  const isNode = projectId.toLowerCase().includes('node');
  const isWindows = projectId.toLowerCase().includes('windows');
  const isSamsung = projectId.toLowerCase().includes('samsung') || projectId.toLowerCase().includes('apk');

  useEffect(() => {
    // Initial logs based on framework
    if (isReact) {
      setCode(`import React, { useState } from 'react';

export default function Storefront() {
  const [cart, setCart] = useState(3);
  return (
    <div className="p-4 bg-slate-900 text-white rounded-2xl border border-sky-500/30">
      <h2 className="text-xl font-bold text-sky-400">⚡ React 19 Storefront</h2>
      <p className="text-xs text-slate-400 mt-1">Live execution on A18 Pro Bionic</p>
      <div className="mt-4 flex items-center gap-3">
        <button 
          onClick={() => setCart(c => c + 1)}
          className="px-4 py-2 bg-sky-500 hover:bg-sky-400 text-white rounded-xl font-bold text-sm"
        >
          افزودن به سبد کالا: {cart}
        </button>
      </div>
    </div>
  );
}`);
      setLogs([
        '⚡ Vite v6.1.1 building for production...',
        '✓ 142 modules transformed.',
        '🚀 Local dev server running on http://localhost:5173',
        '✨ HMR connected. Ready in 18ms on Apple A18 Pro.',
      ]);
    } else if (isLaravel) {
      setCode(`<?php
use Illuminate\\Support\\Facades\\Route;

Route::get('/api/products', function () {
    return response()->json([
        'status' => 'success',
        'framework' => 'Laravel 11.28 on ALI OS',
        'database' => 'SQLite /dev/shm',
        'products' => [
            ['id' => 1, 'name' => 'iPhone 16 Pro Max Desert Titanium', 'price' => 118000000],
            ['id' => 2, 'name' => 'MacBook Pro 16 M4 Max', 'price' => 245000000]
        ]
    ]);
});
`);
      setLogs([
        '   INFO  Server running on [http://127.0.0.1:8000].',
        '   Press Ctrl+C to stop the server',
        '2026-10-24 14:00:01 .................... ~ 8ms',
        'GET /api/products ...................... 200 OK',
        'POST /api/orders/checkout .............. 201 Created',
      ]);
    } else if (isPython) {
      setCode(`# Python 3.10 FastAPI Microservice
import json
import time

print("🐍 Python 3.10 running on ALI Phone A18 Pro")
print("FastAPI app initialized with 4 routes")
data = {
    "engine": "Python 3.10.12",
    "status": "healthy",
    "chip": "Apple A18 Pro Titanium",
    "uptime": "99.98%",
    "active_users": 1420
}
print("Endpoint /api/health Response:")
print(json.dumps(data, indent=2, ensure_ascii=False))
`);
      runPythonCode();
    } else if (isNode) {
      setCode(`// Node.js Express API on ALI Phone
const os = require('os');

console.log("🟢 Node.js v" + process.version + " Express Server");
console.log("Listening on port 4000");
console.log("Free RAM: " + Math.round(os.freemem() / 1024 / 1024) + " MB");
`);
      runNodeCode();
    } else {
      setLogs([`🚀 Project ${projectId} initialized and running.`]);
    }
  }, [projectId]);

  const runPythonCode = async () => {
    try {
      const res = await fetch('/api/projects/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ framework: 'python', code }),
      });
      const data = await res.json();
      setLogs([
        '🚀 Python 3.10.12 subprocess launched...',
        data.stdout || '',
        data.stderr ? `Error: ${data.stderr}` : '✅ Finished with exit code 0.',
      ]);
    } catch (err: any) {
      setLogs((prev) => [...prev, `Execution error: ${err.message}`]);
    }
  };

  const runNodeCode = async () => {
    try {
      const res = await fetch('/api/projects/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ framework: 'nodejs', code }),
      });
      const data = await res.json();
      setLogs([
        '🟢 Node.js v22.23.3 subprocess started...',
        data.stdout || '',
        data.stderr ? `Error: ${data.stderr}` : '✅ Process completed.',
      ]);
    } catch (err: any) {
      setLogs((prev) => [...prev, `Execution error: ${err.message}`]);
    }
  };

  const handleRunArtisan = async (cmd: string) => {
    soundEffects.click(soundEnabled);
    try {
      const res = await fetch('/api/projects/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ framework: 'laravel', command: cmd }),
      });
      const data = await res.json();
      setLogs((prev) => [...prev, `> ${cmd}`, data.stdout]);
    } catch (err: any) {
      setLogs((prev) => [...prev, `> ${cmd}`, `Error: ${err.message}`]);
    }
  };

  const handleInstallToHome = () => {
    soundEffects.click(soundEnabled);
    let appColor = 'from-blue-600 to-indigo-800';
    let iconName = 'Layers';

    if (isReact) {
      appColor = 'from-cyan-500 to-blue-600';
      iconName = 'Layers';
    } else if (isLaravel) {
      appColor = 'from-rose-500 to-red-700';
      iconName = 'Globe';
    } else if (isPython) {
      appColor = 'from-emerald-500 to-teal-700';
      iconName = 'Terminal';
    } else if (isNode) {
      appColor = 'from-green-600 to-emerald-800';
      iconName = 'Code2';
    } else if (isWindows) {
      appColor = 'from-blue-600 to-sky-800';
      iconName = 'Laptop';
    } else if (isSamsung) {
      appColor = 'from-indigo-600 to-violet-800';
      iconName = 'Smartphone';
    }

    const newApp: CustomApp = {
      id: `proj_${projectId.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
      name: projectId,
      nameFa: projectId,
      iconName,
      color: appColor,
      category: 'tools',
      type: 'product_catalog',
      url: `/project/${projectId}`,
    };

    onInstallToHomeScreen(newApp);
    setInstalled(true);
    setTimeout(() => setInstalled(false), 3000);
  };

  return (
    <div className="h-full flex flex-col bg-slate-950 text-white select-none overflow-hidden font-sans">
      {/* iOS Top Bar Navigation */}
      <div className="pt-12 px-4 pb-2 bg-neutral-900/90 backdrop-blur-xl border-b border-white/10 flex items-center justify-between z-20">
        <button
          onClick={() => {
            soundEffects.click(soundEnabled);
            onBack();
          }}
          className="flex items-center gap-1 text-blue-400 hover:text-blue-300 font-semibold text-xs py-1 px-2 rounded-xl hover:bg-white/10 transition-colors"
        >
          <ChevronLeft className="w-5 h-5" />
          <span>{language === 'fa' ? 'فایل‌ها' : 'Files'}</span>
        </button>

        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-xs font-bold text-white tracking-tight truncate max-w-[140px]">
            {projectId}
          </span>
          <span className="px-1.5 py-0.5 rounded-full bg-blue-500/20 text-blue-400 text-[9px] font-bold border border-blue-500/30">
            {isReact
              ? 'REACT'
              : isLaravel
              ? 'LARAVEL'
              : isPython
              ? 'PYTHON 3'
              : isNode
              ? 'NODE.JS'
              : isWindows
              ? 'WINDOWS'
              : isSamsung
              ? 'SAMSUNG APK'
              : 'PROJECT'}
          </span>
        </div>

        {/* Action: Install to Home Screen */}
        <button
          onClick={handleInstallToHome}
          className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold transition-all ${
            installed
              ? 'bg-emerald-600 text-white'
              : 'bg-blue-600 hover:bg-blue-500 text-white shadow-md active:scale-95'
          }`}
          title="نصب آیکون اختصاصی در صفحه اصلی آیفون"
        >
          {installed ? <Check className="w-3.5 h-3.5" /> : <ArrowUpRight className="w-3.5 h-3.5" />}
          <span>{installed ? 'نصب شد' : 'افزودن به هوم'}</span>
        </button>
      </div>

      {/* Tabs Bar */}
      <div className="px-4 py-2 bg-neutral-900/60 flex items-center gap-1.5 border-b border-white/10 text-xs">
        <button
          onClick={() => setActiveTab('preview')}
          className={`flex-1 py-1.5 rounded-xl font-semibold transition-all ${
            activeTab === 'preview' ? 'bg-blue-600 text-white shadow' : 'bg-neutral-800 text-neutral-400'
          }`}
        >
          اجرای زنده (Preview)
        </button>
        <button
          onClick={() => setActiveTab('code')}
          className={`flex-1 py-1.5 rounded-xl font-semibold transition-all ${
            activeTab === 'code' ? 'bg-blue-600 text-white shadow' : 'bg-neutral-800 text-neutral-400'
          }`}
        >
          کد منبع (Code)
        </button>
        <button
          onClick={() => setActiveTab('logs')}
          className={`flex-1 py-1.5 rounded-xl font-semibold transition-all ${
            activeTab === 'logs' ? 'bg-blue-600 text-white shadow' : 'bg-neutral-800 text-neutral-400'
          }`}
        >
          ترمینال (Logs)
        </button>
        {isLaravel && (
          <button
            onClick={() => setActiveTab('artisan')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-all ${
              activeTab === 'artisan' ? 'bg-red-600 text-white shadow' : 'bg-neutral-800 text-neutral-400'
            }`}
          >
            Artisan
          </button>
        )}
      </div>

      {/* Main View Area */}
      <div className="flex-1 overflow-y-auto p-4 no-scrollbar">
        {activeTab === 'preview' && (
          <div>
            {isReact ? (
              /* React Live Preview */
              <div className="space-y-4">
                <div className="p-4 rounded-3xl bg-neutral-900/90 border border-sky-500/30 shadow-2xl">
                  <div className="flex items-center justify-between pb-3 border-b border-white/10">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-cyan-400 animate-spin" style={{ animationDuration: '6s' }} />
                      <span className="text-xs font-bold text-sky-400">React 19 Interactive Live Sandbox</span>
                    </div>
                    <span className="text-[10px] text-neutral-400 font-mono">Port: 5173</span>
                  </div>

                  {/* Interactive Store Component */}
                  <div className="mt-4 p-4 rounded-2xl bg-black/50 border border-white/10 space-y-3">
                    <h3 className="text-base font-bold text-white">فروشگاه تیتانیوم علی‌فون (React)</h3>
                    <p className="text-xs text-neutral-300">
                      این کامپوننت مستقیماً در حافظه دستگاه پردازش و اجرا می‌شود.
                    </p>

                    <div className="p-3 rounded-xl bg-neutral-800/80 flex items-center justify-between">
                      <div>
                        <p className="text-xs font-bold text-amber-400">آیفون ۱۶ پرو مکس (Desert Titanium)</p>
                        <p className="text-[10px] text-neutral-400">قیمت: ۱۱۸,۰۰۰,۰۰۰ تومان</p>
                      </div>
                      <button
                        onClick={() => {
                          soundEffects.click(soundEnabled);
                          setReactCounter((c) => c + 1);
                        }}
                        className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow active:scale-95 transition-all"
                      >
                        + خرید (تعداد: {reactCounter})
                      </button>
                    </div>

                    <div className="text-[11px] text-emerald-400 font-mono flex items-center justify-between">
                      <span>مجموع سبد خرید:</span>
                      <span className="font-bold">{(reactCounter * 118000000).toLocaleString('fa-IR')} تومان</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : isLaravel ? (
              /* Laravel API Preview */
              <div className="space-y-4">
                <div className="p-4 rounded-3xl bg-neutral-900/90 border border-red-500/30 shadow-2xl">
                  <div className="flex items-center justify-between pb-3 border-b border-white/10">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded-lg bg-red-600 text-[10px] font-black text-white">LARAVEL 11</span>
                      <span className="text-xs font-bold text-white">PHP 8.3 REST API Endpoints</span>
                    </div>
                    <span className="text-[10px] text-neutral-400 font-mono">Port: 8000</span>
                  </div>

                  <div className="mt-4 space-y-2">
                    <button
                      onClick={() => handleRunArtisan('php artisan route:list')}
                      className="w-full text-right p-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold flex items-center justify-between border border-white/5"
                    >
                      <span>GET /api/products</span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono">200 OK</span>
                    </button>
                    <button
                      onClick={() => handleRunArtisan('php artisan migrate')}
                      className="w-full text-right p-3 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold flex items-center justify-between border border-white/5"
                    >
                      <span>POST /api/orders/checkout</span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 font-mono">201 CREATED</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : isWindows ? (
              /* Windows App Simulation */
              <div className="rounded-2xl bg-neutral-900 border border-sky-400/30 overflow-hidden shadow-2xl">
                {/* Classic Windows Title Bar */}
                <div className="bg-gradient-to-r from-blue-900 to-indigo-900 p-2 px-3 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <Laptop className="w-4 h-4 text-sky-300" />
                    <span className="font-semibold text-white">Windows Tools · Notepad & Diagnostics</span>
                  </div>
                  <div className="flex items-center gap-2 text-neutral-400 font-mono text-[10px]">
                    <span>_</span>
                    <span>□</span>
                    <span className="text-rose-400">✕</span>
                  </div>
                </div>
                <div className="p-4 bg-black/70 space-y-3 font-mono text-xs">
                  <p className="text-sky-400">Microsoft Windows Subsystem on A18 Pro</p>
                  <div className="p-3 bg-neutral-900 rounded-xl border border-white/10 text-neutral-300 text-[11px]">
                    <p>• Executable: {projectId}.exe</p>
                    <p>• Architecture: x86_64 translated via Rosetta Silicon</p>
                    <p>• Memory: 2,048 MB allocated</p>
                    <p className="text-emerald-400 mt-2">✓ Application running smoothly inside ALI phone.</p>
                  </div>
                </div>
              </div>
            ) : isSamsung ? (
              /* Samsung One UI Android App Simulation */
              <div className="rounded-3xl bg-neutral-900 border border-violet-500/30 overflow-hidden shadow-2xl">
                {/* Samsung Top Header */}
                <div className="bg-neutral-800 p-2.5 px-4 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-violet-400" />
                    <span className="font-bold text-white">Samsung One UI 6.1 · {projectId}</span>
                  </div>
                  <span className="text-[10px] text-violet-300 font-bold px-2 py-0.5 rounded-full bg-violet-600/30">
                    APK ACTIVE
                  </span>
                </div>
                <div className="p-4 bg-neutral-950 space-y-3">
                  <div className="p-4 rounded-2xl bg-neutral-900 border border-white/10 flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-sm text-white">{projectId}</h4>
                      <p className="text-xs text-neutral-400 mt-0.5">Android Package Sideloaded</p>
                    </div>
                    <span className="px-3 py-1 rounded-full bg-emerald-500 text-black font-black text-xs">
                      اجرا شد
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              /* Python / Node script preview */
              <div className="p-4 rounded-3xl bg-neutral-900 border border-white/15 space-y-3 font-mono text-xs">
                <div className="flex items-center justify-between pb-2 border-b border-white/10">
                  <span className="text-emerald-400 font-bold">Subprocess Monitor</span>
                  <span className="text-[10px] text-neutral-400">Status: Running</span>
                </div>
                <div className="p-3 rounded-xl bg-black border border-white/10 space-y-1 text-neutral-300 text-[11px]">
                  {logs.map((log, idx) => (
                    <p key={idx} className="whitespace-pre-wrap">{log}</p>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'code' && (
          <div className="h-full flex flex-col space-y-2">
            <div className="flex items-center justify-between pb-1">
              <span className="text-xs text-neutral-400 font-mono">Source Editor</span>
              <button
                onClick={() => {
                  soundEffects.click(soundEnabled);
                  if (isPython) runPythonCode();
                  else if (isNode) runNodeCode();
                }}
                className="px-3 py-1 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1"
              >
                <Play className="w-3 h-3" />
                <span>اجرای مجدد کد</span>
              </button>
            </div>
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-full h-80 p-3 rounded-2xl bg-black font-mono text-xs text-emerald-400 focus:outline-none border border-white/15 resize-none"
              spellCheck={false}
            />
          </div>
        )}

        {activeTab === 'logs' && (
          <div className="space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between">
              <span className="text-neutral-400 font-bold">Terminal Logs</span>
              <button
                onClick={() => setLogs([])}
                className="text-[11px] text-rose-400 hover:underline"
              >
                پاکسازی لاگ
              </button>
            </div>
            <div className="p-3 rounded-2xl bg-black border border-white/15 max-h-96 overflow-y-auto space-y-1.5 text-[11px]">
              {logs.map((log, idx) => (
                <div key={idx} className="text-emerald-400 whitespace-pre-wrap">
                  {log}
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'artisan' && isLaravel && (
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-neutral-300">دستورات سریع Artisan:</h4>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleRunArtisan('php artisan route:list')}
                className="p-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-right"
              >
                route:list
              </button>
              <button
                onClick={() => handleRunArtisan('php artisan migrate')}
                className="p-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-right"
              >
                migrate
              </button>
              <button
                onClick={() => handleRunArtisan('php artisan config:cache')}
                className="p-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-right"
              >
                config:cache
              </button>
              <button
                onClick={() => handleRunArtisan('php artisan view:clear')}
                className="p-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-right"
              >
                view:clear
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
