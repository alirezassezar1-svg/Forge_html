import React, { useState, useEffect } from 'react';
import {
  Folder,
  FileCode,
  FileText,
  File,
  ChevronLeft,
  ChevronRight,
  Search,
  MoreHorizontal,
  LayoutGrid,
  List,
  Play,
  Plus,
  Trash2,
  Download,
  Share2,
  Clock,
  FolderOpen,
  Check,
  ExternalLink,
  Laptop,
  Smartphone,
  Save,
  Sparkles,
  ArrowUpRight,
  Code2,
  Globe,
} from 'lucide-react';
import { soundEffects } from '../../utils/soundEffects';
import { AppLanguage, CustomApp } from '../../types/phone';

interface FilesAppProps {
  soundEnabled: boolean;
  language: AppLanguage;
  onOpenProjectRunner: (projectId: string) => void;
  onInstallAppToHomeScreen: (app: CustomApp) => void;
  onBackToHome: () => void;
}

interface FileItem {
  name: string;
  path: string;
  size: number;
  updatedAt: string;
  isDirectory: boolean;
  badge?: string;
  framework?: 'react' | 'laravel' | 'python' | 'nodejs' | 'windows' | 'samsung' | 'html' | 'php';
}

export const FilesApp: React.FC<FilesAppProps> = ({
  soundEnabled,
  language,
  onOpenProjectRunner,
  onInstallAppToHomeScreen,
  onBackToHome,
}) => {
  const [currentPath, setCurrentPath] = useState<string>('');
  const [history, setHistory] = useState<string[]>(['']);
  const [historyIndex, setHistoryIndex] = useState<number>(0);
  const [files, setFiles] = useState<FileItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('list');
  const [activeTab, setActiveTab] = useState<'recents' | 'shared' | 'browse'>('browse');
  const [selectedFile, setSelectedFile] = useState<{ path: string; name: string; content: string } | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [showOptionsMenu, setShowOptionsMenu] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [executingFile, setExecutingFile] = useState<string | null>(null);
  const [executionOutput, setExecutionOutput] = useState<{ stdout: string; stderr: string } | null>(null);

  const fetchFiles = async (folderPath: string = '') => {
    try {
      const res = await fetch(`/api/terminal/files?path=${encodeURIComponent(folderPath)}`);
      const data = await res.json();
      if (data.files) {
        // Tag project directories
        const enhanced: FileItem[] = data.files.map((f: any) => {
          let framework: FileItem['framework'] = undefined;
          let badge: string | undefined = undefined;

          if (f.name.includes('React') || f.name.includes('vibe') || f.name.includes('Froshgahi')) {
            framework = 'react';
            badge = 'REACT';
          } else if (f.name.includes('Laravel') || f.name.includes('api')) {
            framework = 'laravel';
            badge = 'PHP/LARAVEL';
          } else if (f.name.includes('Python') || f.name.includes('deepseek') || f.name.includes('crawler') || f.name.endsWith('.py')) {
            framework = 'python';
            badge = 'PYTHON 3';
          } else if (f.name.includes('Node') || f.name.endsWith('.js')) {
            framework = 'nodejs';
            badge = 'NODE.JS';
          } else if (f.name.includes('Windows')) {
            framework = 'windows';
            badge = 'WINDOWS';
          } else if (f.name.includes('Samsung') || f.name.includes('APK') || f.name.endsWith('.apk')) {
            framework = 'samsung';
            badge = 'SAMSUNG APK';
          } else if (f.name.endsWith('.html')) {
            framework = 'html';
            badge = 'WEB';
          }

          return { ...f, framework, badge };
        });
        setFiles(enhanced);
      }
    } catch (err) {
      console.error('Failed to fetch files:', err);
    }
  };

  useEffect(() => {
    fetchFiles(currentPath);
  }, [currentPath]);

  const notify = (msg: string) => {
    setStatusMessage(msg);
    setTimeout(() => setStatusMessage(''), 3000);
  };

  const navigateTo = (newPath: string) => {
    soundEffects.click(soundEnabled);
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(newPath);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
    setCurrentPath(newPath);
    setSelectedFile(null);
    setExecutionOutput(null);
  };

  const handleBack = () => {
    if (historyIndex > 0) {
      soundEffects.click(soundEnabled);
      const prev = history[historyIndex - 1];
      setHistoryIndex(historyIndex - 1);
      setCurrentPath(prev);
      setSelectedFile(null);
      setExecutionOutput(null);
    }
  };

  const handleForward = () => {
    if (historyIndex < history.length - 1) {
      soundEffects.click(soundEnabled);
      const next = history[historyIndex + 1];
      setHistoryIndex(historyIndex + 1);
      setCurrentPath(next);
      setSelectedFile(null);
      setExecutionOutput(null);
    }
  };

  const handleOpenFile = async (file: FileItem) => {
    soundEffects.click(soundEnabled);
    if (file.isDirectory) {
      navigateTo(file.path);
      return;
    }

    try {
      const res = await fetch(`/api/terminal/file?path=${encodeURIComponent(file.path)}`);
      const data = await res.json();
      if (data.content !== undefined) {
        setSelectedFile({ path: file.path, name: file.name, content: data.content });
      }
    } catch {
      notify(language === 'fa' ? 'خطا در بارگذاری فایل' : 'Failed to read file');
    }
  };

  const handleSaveFile = async () => {
    if (!selectedFile) return;
    soundEffects.click(soundEnabled);
    setIsSaving(true);
    try {
      const res = await fetch('/api/terminal/file', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: selectedFile.path, content: selectedFile.content }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        notify(data.message || (res.status === 413 ? (language === 'fa' ? 'حجم فایل بیش از حد مجاز است' : 'File too large') : (language === 'fa' ? 'خطا در ذخیره فایل' : 'Failed to save')));
        return;
      }
      notify(language === 'fa' ? 'فایل با موفقیت ذخیره شد' : 'File saved successfully');
    } catch {
      notify(language === 'fa' ? 'خطا در ذخیره فایل' : 'Failed to save');
    } finally {
      setIsSaving(false);
    }
  };

  const handleRunFile = async () => {
    if (!selectedFile) return;
    soundEffects.click(soundEnabled);
    setExecutingFile(selectedFile.name);
    setExecutionOutput(null);

    let framework = 'bash';
    if (selectedFile.name.endsWith('.py')) framework = 'python';
    else if (selectedFile.name.endsWith('.js')) framework = 'nodejs';
    else if (selectedFile.name.endsWith('.php')) framework = 'laravel';

    try {
      const res = await fetch('/api/projects/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          framework,
          code: selectedFile.content,
          fileName: selectedFile.name,
        }),
      });
      const data = await res.json();
      setExecutionOutput({ stdout: data.stdout || '', stderr: data.stderr || '' });
    } catch (err: any) {
      setExecutionOutput({ stdout: '', stderr: err.message || 'Execution error' });
    } finally {
      setExecutingFile(null);
    }
  };

  const handleInstallToHomeScreen = (item: FileItem) => {
    soundEffects.click(soundEnabled);
    let appColor = 'from-blue-600 to-indigo-800';
    let iconName = 'FileCode';
    let category: CustomApp['category'] = 'tools';

    if (item.framework === 'react') {
      appColor = 'from-cyan-500 to-blue-600';
      iconName = 'Layers';
    } else if (item.framework === 'laravel' || item.framework === 'php') {
      appColor = 'from-red-500 to-rose-700';
      iconName = 'Globe';
    } else if (item.framework === 'python') {
      appColor = 'from-emerald-500 to-teal-700';
      iconName = 'Terminal';
    } else if (item.framework === 'nodejs') {
      appColor = 'from-green-600 to-emerald-800';
      iconName = 'Code2';
    } else if (item.framework === 'windows') {
      appColor = 'from-blue-700 to-sky-900';
      iconName = 'Laptop';
    } else if (item.framework === 'samsung') {
      appColor = 'from-indigo-600 to-violet-900';
      iconName = 'Smartphone';
    }

    const newApp: CustomApp = {
      id: `proj_${item.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}`,
      name: item.name,
      nameFa: item.name,
      iconName,
      color: appColor,
      category,
      type: 'product_catalog',
      url: `/project/${item.name}`,
    };

    onInstallAppToHomeScreen(newApp);
    notify(language === 'fa' ? `آیکون «${item.name}» به صفحه اصلی آیفون اضافه شد!` : `App icon added to Home Screen!`);
  };

  const filteredFiles = files.filter((f) =>
    f.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const currentFolderDisplayName = currentPath
    ? currentPath.split('/').pop()
    : language === 'fa'
    ? 'Local'
    : 'Local';

  return (
    <div className="h-full flex flex-col bg-black text-white select-none overflow-hidden font-sans">
      {/* iOS Navigation Header */}
      <div className="pt-12 px-4 pb-2 bg-neutral-900/90 backdrop-blur-xl border-b border-white/10 flex items-center justify-between z-20">
        <div className="flex items-center gap-1">
          <button
            onClick={handleBack}
            disabled={historyIndex === 0}
            className={`p-1.5 rounded-full transition-opacity ${
              historyIndex > 0 ? 'text-blue-400 hover:bg-white/10' : 'text-neutral-600'
            }`}
            title="Back"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={handleForward}
            disabled={historyIndex >= history.length - 1}
            className={`p-1.5 rounded-full transition-opacity ${
              historyIndex < history.length - 1 ? 'text-blue-400 hover:bg-white/10' : 'text-neutral-600'
            }`}
            title="Forward"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
          <span className="text-xs font-semibold text-neutral-400 truncate max-w-[120px]">
            {currentPath ? `< ${currentPath}` : ''}
          </span>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setViewMode(viewMode === 'list' ? 'grid' : 'list')}
            className="p-1.5 rounded-full hover:bg-white/10 text-blue-400"
            title="Toggle View"
          >
            {viewMode === 'list' ? <LayoutGrid className="w-5 h-5" /> : <List className="w-5 h-5" />}
          </button>

          <div className="relative">
            <button
              onClick={() => setShowOptionsMenu(!showOptionsMenu)}
              className="p-1.5 rounded-full bg-neutral-800 text-blue-400 hover:bg-neutral-700"
              title="Options"
            >
              <MoreHorizontal className="w-5 h-5" />
            </button>

            {showOptionsMenu && (
              <div className="absolute left-0 mt-2 w-48 rounded-2xl bg-neutral-800/95 backdrop-blur-xl border border-white/15 shadow-2xl p-1 z-50 text-xs">
                <button
                  onClick={() => {
                    setShowOptionsMenu(false);
                    onOpenProjectRunner(currentPath || 'React-Storefront');
                  }}
                  className="w-full text-right px-3 py-2 rounded-xl hover:bg-blue-600/30 text-sky-400 flex items-center justify-between"
                >
                  <span>اجرای پروژه جاری</span>
                  <Play className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => {
                    setShowOptionsMenu(false);
                    fetchFiles(currentPath);
                  }}
                  className="w-full text-right px-3 py-2 rounded-xl hover:bg-white/10 flex items-center justify-between text-neutral-200"
                >
                  <span>بروزرسانی فایل‌ها</span>
                  <FolderOpen className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Large Title & Search Bar (Exact iOS Files Style) */}
      <div className="px-4 pt-2 pb-2 bg-neutral-900/60 backdrop-blur-md">
        <div className="flex items-baseline justify-between">
          <h1 className="text-2xl font-black tracking-tight text-white">
            {currentFolderDisplayName}
          </h1>
          <span className="text-xs text-neutral-400">
            {filteredFiles.length} {language === 'fa' ? 'مورد' : 'Items'}
          </span>
        </div>

        {/* Search Field */}
        <div className="mt-2 relative">
          <Search className="w-4 h-4 text-neutral-400 absolute right-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={language === 'fa' ? 'جستجو در فایل‌ها...' : 'Search files...'}
            className="w-full pl-3 pr-9 py-1.5 rounded-xl bg-neutral-800/80 text-xs text-white placeholder-neutral-500 focus:outline-none focus:ring-1 focus:ring-blue-500 border border-white/10"
          />
        </div>
      </div>

      {/* Notification Toast */}
      {statusMessage && (
        <div className="px-4 py-1.5 bg-blue-600 text-white text-xs font-medium text-center animate-pulse">
          {statusMessage}
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-4 no-scrollbar">
        {selectedFile ? (
          /* File Editor / Viewer */
          <div className="h-full flex flex-col bg-neutral-900 rounded-2xl border border-white/15 p-3">
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center gap-2">
                <FileCode className="w-4 h-4 text-sky-400" />
                <span className="text-xs font-bold text-white truncate max-w-[150px]">
                  {selectedFile.name}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={handleRunFile}
                  disabled={executingFile !== null}
                  className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-[11px] font-bold text-white flex items-center gap-1"
                >
                  <Play className="w-3 h-3" />
                  <span>{executingFile ? 'در حال اجرا…' : 'اجرا'}</span>
                </button>
                <button
                  onClick={handleSaveFile}
                  disabled={isSaving}
                  className="px-2.5 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 text-[11px] font-bold text-white flex items-center gap-1"
                >
                  <Save className="w-3 h-3" />
                  <span>ذخیره</span>
                </button>
                <button
                  onClick={() => setSelectedFile(null)}
                  className="px-2 py-1 rounded-lg bg-neutral-800 text-[11px] text-neutral-400"
                >
                  ✕
                </button>
              </div>
            </div>

            <textarea
              value={selectedFile.content}
              onChange={(e) => setSelectedFile({ ...selectedFile, content: e.target.value })}
              className="flex-1 mt-2 w-full bg-black/60 rounded-xl p-2.5 font-mono text-[11px] text-emerald-400 focus:outline-none resize-none border border-white/10"
              spellCheck={false}
            />

            {/* Execution Output Console */}
            {executionOutput && (
              <div className="mt-2 p-2.5 rounded-xl bg-black border border-white/20 max-h-36 overflow-y-auto text-xs font-mono">
                <div className="text-[10px] text-neutral-400 font-bold mb-1">خروجی ترمینال اجرای فایل:</div>
                {executionOutput.stdout && (
                  <pre className="text-emerald-400 whitespace-pre-wrap">{executionOutput.stdout}</pre>
                )}
                {executionOutput.stderr && (
                  <pre className="text-rose-400 whitespace-pre-wrap">{executionOutput.stderr}</pre>
                )}
              </div>
            )}
          </div>
        ) : viewMode === 'list' ? (
          /* iOS List View */
          <div className="space-y-1.5">
            {filteredFiles.map((file) => (
              <div
                key={file.path}
                className="group p-2.5 rounded-2xl bg-neutral-900/40 hover:bg-neutral-900/80 border border-white/5 hover:border-white/15 transition-all flex items-center justify-between"
              >
                <div
                  onClick={() => handleOpenFile(file)}
                  className="flex items-center gap-3 cursor-pointer flex-1 overflow-hidden"
                >
                  {file.isDirectory ? (
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-500 to-sky-400 flex items-center justify-center text-white shadow-md flex-shrink-0">
                      <Folder className="w-5 h-5 fill-white/80" />
                    </div>
                  ) : (
                    <div className="w-10 h-10 rounded-xl bg-neutral-800 flex items-center justify-center text-neutral-300 shadow-md flex-shrink-0">
                      {file.name.endsWith('.py') ? (
                        <Code2 className="w-5 h-5 text-emerald-400" />
                      ) : file.name.endsWith('.js') ? (
                        <FileCode className="w-5 h-5 text-amber-400" />
                      ) : file.name.endsWith('.html') ? (
                        <Globe className="w-5 h-5 text-sky-400" />
                      ) : (
                        <FileText className="w-5 h-5 text-neutral-400" />
                      )}
                    </div>
                  )}

                  <div className="truncate">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-white tracking-tight truncate">
                        {file.name}
                      </span>
                      {file.badge && (
                        <span className="px-1.5 py-0.5 rounded-full bg-blue-500/20 text-blue-400 text-[9px] font-bold border border-blue-500/30">
                          {file.badge}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-neutral-400">
                      {file.isDirectory ? (language === 'fa' ? 'پوشه پروژه' : 'Folder') : `${Math.round(file.size / 1024)} KB`}
                    </span>
                  </div>
                </div>

                {/* Quick Action Buttons */}
                <div className="flex items-center gap-1.5 opacity-80 group-hover:opacity-100">
                  {file.isDirectory && (
                    <button
                      onClick={() => handleInstallToHomeScreen(file)}
                      title="افزودن آیکون به صفحه اصلی آیفون"
                      className="p-1.5 rounded-xl bg-blue-600/30 hover:bg-blue-600 text-blue-300 hover:text-white transition-colors"
                    >
                      <ArrowUpRight className="w-4 h-4" />
                    </button>
                  )}
                  {file.isDirectory && (
                    <button
                      onClick={() => onOpenProjectRunner(file.name)}
                      title="اجرای پروژه"
                      className="p-1.5 rounded-xl bg-emerald-600/30 hover:bg-emerald-600 text-emerald-300 hover:text-white transition-colors"
                    >
                      <Play className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* iOS Grid View */
          <div className="grid grid-cols-3 gap-3">
            {filteredFiles.map((file) => (
              <div
                key={file.path}
                onClick={() => handleOpenFile(file)}
                className="p-3 rounded-2xl bg-neutral-900/50 hover:bg-neutral-900/90 border border-white/10 flex flex-col items-center justify-between text-center cursor-pointer group transition-all h-28"
              >
                {file.isDirectory ? (
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-500 to-sky-400 flex items-center justify-center text-white shadow-lg group-hover:scale-105 transition-transform">
                    <Folder className="w-6 h-6 fill-white/80" />
                  </div>
                ) : (
                  <div className="w-12 h-12 rounded-2xl bg-neutral-800 flex items-center justify-center text-neutral-300 shadow-lg group-hover:scale-105 transition-transform">
                    <FileText className="w-6 h-6 text-neutral-400" />
                  </div>
                )}
                <span className="text-[11px] font-medium text-neutral-200 truncate w-full mt-1">
                  {file.name}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Bottom iOS Files Tab Bar (Recents, Shared, Browse) */}
      <div className="h-14 bg-neutral-900/90 backdrop-blur-2xl border-t border-white/10 flex items-center justify-around px-6 z-20 pb-1">
        <button
          onClick={() => {
            soundEffects.click(soundEnabled);
            setActiveTab('recents');
          }}
          className={`flex flex-col items-center gap-0.5 ${
            activeTab === 'recents' ? 'text-blue-400' : 'text-neutral-500'
          }`}
        >
          <Clock className="w-5 h-5" />
          <span className="text-[10px] font-medium">{language === 'fa' ? 'اخیر' : 'Recents'}</span>
        </button>

        <button
          onClick={() => {
            soundEffects.click(soundEnabled);
            setActiveTab('shared');
          }}
          className={`flex flex-col items-center gap-0.5 ${
            activeTab === 'shared' ? 'text-blue-400' : 'text-neutral-500'
          }`}
        >
          <Share2 className="w-5 h-5" />
          <span className="text-[10px] font-medium">{language === 'fa' ? 'اشتراک' : 'Shared'}</span>
        </button>

        <button
          onClick={() => {
            soundEffects.click(soundEnabled);
            setActiveTab('browse');
          }}
          className={`flex flex-col items-center gap-0.5 ${
            activeTab === 'browse' ? 'text-blue-400' : 'text-neutral-500'
          }`}
        >
          <Folder className="w-5 h-5 fill-current" />
          <span className="text-[10px] font-medium">{language === 'fa' ? 'مرور' : 'Browse'}</span>
        </button>
      </div>
    </div>
  );
};
