import React, { useState, useEffect, useMemo } from 'react';
import {
  Cpu,
  Smartphone,
  Laptop,
  Monitor,
  Terminal,
  Layers,
  Code2,
  Play,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Download,
  FolderTree,
  FileCode,
  FileText,
  Boxes,
  Zap,
  Activity,
  Maximize2,
  Minimize2,
  ChevronRight,
  ChevronDown,
  Sparkles,
  Sliders,
  Share2,
  Wrench,
  Search,
  ExternalLink,
  ShieldCheck,
  Gauge,
  Radio,
  Wifi,
  HardDrive,
  RefreshCw,
  Box,
  Eye,
  Settings2,
  SlidersHorizontal,
  X,
} from 'lucide-react';
import { AppLanguage } from '../../types/phone';
import { soundEffects } from '../../utils/soundEffects';
import JSZip from 'jszip';
import { executeCodeInBrowser, ExecutionResult } from '../../utils/codeRunner';

interface EngineeringStudioAppProps {
  soundEnabled: boolean;
  language: AppLanguage;
  onBack: () => void;
}

export type PlatformTarget = 'samsung' | 'apple' | 'windows' | 'linux';

interface ProjectFile {
  name: string;
  path: string;
  language: string;
  size: string;
  content: string;
}

interface PlatformBlueprint {
  id: PlatformTarget;
  name: string;
  nameFa: string;
  vendor: string;
  iconName: string;
  badge: string;
  primaryColor: string;
  accentBg: string;
  borderColor: string;
  glowColor: string;
  targetOs: string;
  architectures: string[];
  toolchains: string[];
  packageFormat: string;
  templates: {
    id: string;
    title: string;
    titleFa: string;
    desc: string;
    descFa: string;
    files: ProjectFile[];
    previewComponent: string;
  }[];
}

export const EngineeringStudioApp: React.FC<EngineeringStudioAppProps> = ({
  soundEnabled,
  language,
  onBack,
}) => {
  const isPersian = language === 'fa';

  // Active platform
  const [selectedPlatform, setSelectedPlatform] = useState<PlatformTarget>('samsung');
  const [selectedTemplateIndex, setSelectedTemplateIndex] = useState<number>(0);
  const [activeFileIndex, setActiveFileIndex] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<'editor' | 'preview' | 'pipeline' | 'scaffold' | 'telemetry'>('editor');

  // Code editor state
  const [editableCode, setEditableCode] = useState<string>('');
  const [copiedCode, setCopiedCode] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Compiler / Build Pipeline State
  const [isBuilding, setIsBuilding] = useState(false);
  const [buildLogs, setBuildLogs] = useState<string[]>([]);
  const [buildProgress, setBuildProgress] = useState(0);
  const [buildArtifact, setBuildArtifact] = useState<{ name: string; size: string; ready: boolean } | null>(null);

  // Live Interactive Preview State
  const [previewScale, setPreviewScale] = useState<'compact' | 'full'>('compact');
  const [sensorValues, setSensorValues] = useState({
    cpu: 24,
    ram: 42,
    fps: 120,
    temp: 34.2,
    battery: 94,
    networkLatency: 14,
  });
  const [simulatedInputState, setSimulatedInputState] = useState<{
    counter: number;
    toggle1: boolean;
    toggle2: boolean;
    textInput: string;
    selectedViewMode: string;
  }>({
    counter: 7,
    toggle1: true,
    toggle2: false,
    textInput: isPersian ? 'سیستم یکپارچه فعال است' : 'ALI Engineering Suite v4.5',
    selectedViewMode: 'dashboard',
  });

  // Scaffold Prompt State
  const [customScaffoldPrompt, setCustomScaffoldPrompt] = useState('');
  const [scaffoldGenerating, setScaffoldGenerating] = useState(false);
  const [scaffoldSuccessMessage, setScaffoldSuccessMessage] = useState<string | null>(null);

  // Live WebAssembly / Sandbox Code Execution & ZIP Export
  const [isExportingZip, setIsExportingZip] = useState(false);
  const [isRunningCode, setIsRunningCode] = useState(false);
  const [liveExecutionResult, setLiveExecutionResult] = useState<ExecutionResult | null>(null);
  const [showLiveConsole, setShowLiveConsole] = useState(false);

  // Platform Blueprints Definition
  const PLATFORMS: Record<PlatformTarget, PlatformBlueprint> = useMemo(
    () => ({
      samsung: {
        id: 'samsung',
        name: 'Samsung Galaxy / One UI & Tizen',
        nameFa: 'سامسونگ (One UI 6.1 · اندروید ۱۵ · تیزن)',
        vendor: 'Samsung Electronics / One UI Team',
        iconName: 'Smartphone',
        badge: 'Android 15 / One UI 6.1',
        primaryColor: 'text-cyan-400',
        accentBg: 'from-cyan-950 via-slate-900 to-blue-950',
        borderColor: 'border-cyan-500/40',
        glowColor: 'shadow-cyan-500/20',
        targetOs: 'One UI 6.1 (API Level 35) + Tizen Wearable 8.0',
        architectures: ['arm64-v8a', 'x86_64', 'Samsung Knox Vault', 'NPU 45 TOPS'],
        toolchains: ['Gradle 8.7.2', 'Android SDK 35', 'Jetpack Compose 1.7', 'NDK r27b', 'R8 ProGuard'],
        packageFormat: '.apk / .aab / .tpk (Samsung Knox Signed)',
        templates: [
          {
            id: 'samsung_oneui_health',
            title: 'Galaxy BioActive Sensor & AI Health Hub',
            titleFa: 'هاب هوشمند سلامت و حسگر بایواکتیو گلکسی S24 Ultra',
            desc: 'Jetpack Compose with Material You dynamic color, Health Connect SDK & Samsung Knox secure enclave.',
            descFa: 'رابط کاربری Jetpack Compose با رنگ‌بندی داینامیک One UI، اتصال به حسگرهای بیومتریک و امنیت ناکس.',
            previewComponent: 'samsung_health',
            files: [
              {
                name: 'MainActivity.kt',
                path: 'app/src/main/java/com/samsung/ali/studio/MainActivity.kt',
                language: 'kotlin',
                size: '4.2 KB',
                content: `package com.samsung.ali.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.samsung.android.knox.KnoxEnclave
import com.samsung.health.sensors.BioActiveManager

class MainActivity : ComponentActivity() {
    private val bioManager = BioActiveManager.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        KnoxEnclave.verifyHardwareSecurity(this)

        setContent {
            SamsungOneUITheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BioActiveDashboard(bioManager)
                }
            }
        }
    }
}

@Composable
fun BioActiveDashboard(manager: BioActiveManager) {
    var heartRate by remember { mutableStateOf(74) }
    var spo2 by remember { mutableStateOf(99) }
    var stressLevel by remember { mutableStateOf("Low (Normal)") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // One UI Header
        Text(
            text = "سامسونگ هلث پرو · One UI 6.1",
            style = MaterialTheme.typography.headlineMedium,
            color = Color(0xFF00E5FF)
        )
        Text(
            text = "Galaxy S24 Ultra BioActive Sensor v4",
            style = MaterialTheme.typography.bodySmall,
            color = Color.LightGray
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Metrics Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MetricCard(
                title = "ضربان قلب",
                value = "$heartRate BPM",
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = "اکسیژن خون SpO2",
                value = "$spo2 %",
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { heartRate += (1..3).random() },
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0077FF))
        ) {
            Text("پایش بلادرنگ سنسورها (Live Scan)")
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = title, color = Color.Gray)
            Text(text = value, style = MaterialTheme.typography.titleLarge, color = Color.White)
        }
    }
}`,
              },
              {
                name: 'build.gradle.kts',
                path: 'app/build.gradle.kts',
                language: 'kotlin',
                size: '2.1 KB',
                content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.compose.compiler)
}

android {
    namespace = "com.samsung.ali.studio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.samsung.ali.studio"
        minSdk = 28
        targetSdk = 35
        versionCode = 405
        versionName = "4.5.0-oneui"

        ndk {
            abiFilters.addAll(listOf("arm64-v8a", "x86_64"))
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("samsungKnoxRelease")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.compose.ui:ui:1.7.5")
    implementation("androidx.compose.material3:material3:1.3.1")
    implementation("com.samsung.android.sdk:health-data:2.1.0")
    implementation("com.samsung.knox:knox-sdk:3.10")
}`,
              },
              {
                name: 'AndroidManifest.xml',
                path: 'app/src/main/AndroidManifest.xml',
                language: 'xml',
                size: '1.8 KB',
                content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <uses-permission android:name="android.permission.BODY_SENSORS" />
    <uses-permission android:name="android.permission.HIGH_SAMPLING_RATE_SENSORS" />
    <uses-permission android:name="com.samsung.android.knox.permission.KNOX_INTEGRITY" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Galaxy Studio Pro"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:theme="@style/Theme.SamsungOneUI">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|smallestScreenSize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
            <!-- Samsung DeX Multi-Window Support -->
            <meta-data android:name="com.samsung.android.keepalive.density" android:value="true" />
            <meta-data android:name="com.sec.android.support.multiwindow" android:value="true" />
        </activity>
    </application>
</manifest>`,
              },
            ],
          },
          {
            id: 'samsung_dex_productivity',
            title: 'Samsung DeX Multi-Window Desktop Workspace',
            titleFa: 'استودیو دسکتاپ و مانیتور خارجی سامسونگ دکس (DeX)',
            desc: 'Adaptive multi-window layout with stylus S-Pen pressure engine and desktop taskbar integration.',
            descFa: 'رابط دسکتاپ تطبیقی سامسونگ با پشتیبانی از قلم هوشمند S-Pen و حالت مانیتور اکسترنال.',
            previewComponent: 'samsung_dex',
            files: [
              {
                name: 'DeXCanvasView.kt',
                path: 'app/src/main/java/com/samsung/ali/dex/DeXCanvasView.kt',
                language: 'kotlin',
                size: '3.1 KB',
                content: `package com.samsung.ali.dex

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View

class DeXCanvasView(context: Context) : View(context) {
    private val paint = Paint().apply {
        color = 0xFF00E5FF.toInt()
        strokeWidth = 6f
        isAntiAlias = true
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        // Handle S-Pen precision pressure
        val pressure = event.pressure
        paint.strokeWidth = 3f + (pressure * 14f)
        invalidate()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawCircle(width / 2f, height / 2f, 120f, paint)
    }
}`,
              },
            ],
          },
        ],
      },
      apple: {
        id: 'apple',
        name: 'Apple iOS, macOS, watchOS & visionOS',
        nameFa: 'اپل (iOS 18 · macOS سه‌کویا · visionOS)',
        vendor: 'Apple Inc. / Worldwide Developer Relations',
        iconName: 'Laptop',
        badge: 'iOS 18 / macOS 15 M4 Max',
        primaryColor: 'text-sky-400',
        accentBg: 'from-blue-950 via-slate-900 to-indigo-950',
        borderColor: 'border-sky-500/40',
        glowColor: 'shadow-sky-500/20',
        targetOs: 'iOS 18.2 / macOS Sequoia 15.1 / visionOS 2.1',
        architectures: ['arm64e (Apple Silicon A18 Pro / M4)', 'Metal 3 GPU Shaders', 'Apple Neural Engine'],
        toolchains: ['Xcodebuild 16.2', 'Swift 6.0', 'SwiftUI', 'Clang / LLVM 18', 'ActivityKit', 'RealityKit'],
        packageFormat: '.ipa / .app / .pkg (Apple Notarized & CodeSigned)',
        templates: [
          {
            id: 'apple_dynamic_island_swiftui',
            title: 'SwiftUI 6 Dynamic Island Live Activity & Widget',
            titleFa: 'برنامه سوئیفت‌یو‌آی با داینامیک آیلند تعاملی و ویجت',
            desc: 'ActivityKit Live Activity, Dynamic Island expanded/minimal views, and Liquid Retina layout.',
            descFa: 'رابط کاربری پیشرفته سوئیفت ۶ با داینامیک آیلند زنده، انیمیشن‌های سیال فیزیک‌محور اپل.',
            previewComponent: 'apple_dynamic_island',
            files: [
              {
                name: 'ContentView.swift',
                path: 'AliAppleStudio/Sources/Views/ContentView.swift',
                language: 'swift',
                size: '3.8 KB',
                content: `import SwiftUI
import ActivityKit

struct ContentView: View {
    @State private var telemetryActive = true
    @State private var cpuCoreUsage: Double = 0.28
    @State private var neuralEngineTokens = 1420

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                
                VStack(spacing: 20) {
                    // Apple Dynamic Island Live Preview
                    HStack {
                        Image(systemName: "applelogo")
                            .font(.title2)
                            .foregroundColor(.white)
                        Text("Apple Engineering Studio")
                            .font(.headline)
                            .fontWeight(.semibold)
                            .foregroundColor(.white)
                        Spacer()
                        Text("M4 MAX")
                            .font(.caption2)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.white.opacity(0.15))
                            .clipShape(Capsule())
                    }
                    .padding(.horizontal)

                    // Glassmorphic Card
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Circle()
                                .fill(Color.green)
                                .frame(width: 8, height: 8)
                            Text("Apple Neural Engine Active")
                                .font(.subheadline)
                                .foregroundColor(.green)
                            Spacer()
                            Text("\\(neuralEngineTokens) tok/s")
                                .font(.system(.caption, design: .monospaced))
                                .foregroundColor(.secondary)
                        }

                        ProgressView(value: cpuCoreUsage)
                            .tint(.blue)

                        Text("A18 Pro Bionic 6-Core GPU · Metal 3 Pipeline")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                    .padding()
                    .background(.ultraThinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 22, style: .continuous)
                            .stroke(Color.white.opacity(0.12), lineWidth: 1)
                    )
                    .padding(.horizontal)

                    Button(action: {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.7)) {
                            cpuCoreUsage = Double.random(in: 0.15...0.85)
                            neuralEngineTokens += Int.random(in: 50...180)
                        }
                    }) {
                        Label("رندر آنی با متال ۳ (Execute Metal 3 Shader)", systemImage: "bolt.fill")
                            .fontWeight(.semibold)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                    }
                    .padding(.horizontal)

                    Spacer()
                }
                .padding(.top, 12)
            }
        }
    }
}`,
              },
              {
                name: 'DynamicIslandWidget.swift',
                path: 'AliAppleStudio/Sources/Widgets/DynamicIslandWidget.swift',
                language: 'swift',
                size: '2.9 KB',
                content: `import WidgetKit
import SwiftUI

struct StudioActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var status: String
        var progress: Double
    }
    var projectName: String
}

@main
struct StudioDynamicIslandWidget: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: StudioActivityAttributes.self) { context in
            // Lock Screen Banner
            VStack {
                Text(context.attributes.projectName)
                ProgressView(value: context.state.progress)
            }
            .activityBackgroundTint(Color.black.opacity(0.8))
        } dynamicIsland: { context in
            DynamicIsland {
                DynamicIslandExpandedRegion(.leading) {
                    Label("ALI OS", systemImage: "sparkles")
                        .font(.caption2)
                        .foregroundColor(.cyan)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    Text("\(Int(context.state.progress * 100))%")
                        .font(.caption)
                        .bold()
                }
                DynamicIslandExpandedRegion(.bottom) {
                    Text(context.state.status)
                        .font(.footnote)
                }
            } compactLeading: {
                Image(systemName: "cpu")
                    .foregroundColor(.cyan)
            } compactTrailing: {
                Text("\(Int(context.state.progress * 100))%")
            } minimal: {
                Image(systemName: "bolt.fill")
                    .foregroundColor(.yellow)
            }
        }
    }
}`,
              },
              {
                name: 'Package.swift',
                path: 'AliAppleStudio/Package.swift',
                language: 'swift',
                size: '1.4 KB',
                content: `// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "AliAppleStudio",
    platforms: [.iOS(.v18), .macOS(.v15), .visionOS(.v2)],
    products: [
        .library(name: "AliAppleStudio", targets: ["AliAppleStudio"])
    ],
    dependencies: [
        .package(url: "https://github.com/apple/swift-async-algorithms", from: "1.0.0")
    ],
    targets: [
        .target(
            name: "AliAppleStudio",
            dependencies: [
                .product(name: "AsyncAlgorithms", package: "swift-async-algorithms")
            ],
            swiftSettings: [.enableUpcomingFeature("StrictConcurrency")]
        )
    ]
)`,
              },
            ],
          },
          {
            id: 'apple_vision_spatial',
            title: 'Apple Vision Pro Spatial Computing & RealityKit',
            titleFa: 'برنامه واقعیت فضایی ویژن‌پرو با RealityKit',
            desc: 'Immersive 3D volumes, gaze & pinch gesture recognition, spatial audio renderer.',
            descFa: 'رندرینگ سه‌بعدی حجم‌های فضایی، ردیابی نگاه و ژست حرکتی انگشت در visionOS.',
            previewComponent: 'apple_vision',
            files: [
              {
                name: 'SpatialScene.swift',
                path: 'AliAppleStudio/Sources/Spatial/SpatialScene.swift',
                language: 'swift',
                size: '2.4 KB',
                content: `import SwiftUI
import RealityKit

struct SpatialSceneView: View {
    var body: some View {
        RealityView { content in
            let model = ModelEntity(
                mesh: .generateSphere(radius: 0.15),
                materials: [SimpleMaterial(color: .cyan, roughness: 0.1, isMetallic: true)]
            )
            content.add(model)
        }
    }
}`,
              },
            ],
          },
        ],
      },
      windows: {
        id: 'windows',
        name: 'Microsoft Windows 11 Fluent & .NET 9',
        nameFa: 'مایکروسافت ویندوز ۱۱ (WinUI 3 · دات‌نت ۹ · Mica)',
        vendor: 'Microsoft Developer Division / WinAppSDK',
        iconName: 'Monitor',
        badge: 'WinUI 3 / Windows 11 24H2',
        primaryColor: 'text-blue-400',
        accentBg: 'from-blue-950 via-slate-900 to-cyan-950',
        borderColor: 'border-blue-500/40',
        glowColor: 'shadow-blue-500/20',
        targetOs: 'Windows 11 Build 26100 (24H2) / Windows Server 2025',
        architectures: ['x64 (AVX-512)', 'ARM64 (Qualcomm Snapdragon X Elite)', 'DirectX 12 Ultimate'],
        toolchains: ['MSBuild 17.12', 'dotnet 9.0.100', 'WinAppSDK 1.6', 'C# 13', 'C++/WinRT', 'Native AOT'],
        packageFormat: '.msix / .exe (Signed with Authenticode & MSIX Packaging)',
        templates: [
          {
            id: 'win11_fluent_mica_dashboard',
            title: 'WinUI 3 Fluent Studio with Mica Material',
            titleFa: 'استودیو فلوئنت ویندوز ۱۱ با متریال شیشه‌ای Mica و WinAppSDK',
            desc: 'Windows App SDK 1.6, C# 13 Native AOT, Mica Alt backdrop, NavigationView, Acrylic controls.',
            descFa: 'طراحی مدرن ویندوز ۱۱ با پنجره نیمه‌شفاف میکا، پشتیبانی از معماری Native AOT در دات‌نت ۹.',
            previewComponent: 'windows_fluent',
            files: [
              {
                name: 'MainWindow.xaml',
                path: 'AliWindowsStudio/Views/MainWindow.xaml',
                language: 'xml',
                size: '3.4 KB',
                content: `<Window
    x:Class="AliWindowsStudio.MainWindow"
    xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
    xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
    xmlns:d="http://schemas.microsoft.com/expression/blend/2008"
    xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
    Title="ALI Windows 11 Engineering Suite"
    SystemBackdrop="MicaAltBackdrop">

    <Grid RowDefinitions="Auto,*">
        <!-- Windows 11 Custom TitleBar -->
        <Border Grid.Row="0" Height="40" Background="#1E1E1E" BorderBrush="#333333" BorderThickness="0,0,0,1">
            <Grid ColumnDefinitions="Auto,*,Auto" Margin="16,0,16,0">
                <StackPanel Orientation="Horizontal" Spacing="8" VerticalAlignment="Center">
                    <FontIcon Glyph="&#xE756;" Foreground="#0078D4"/>
                    <TextBlock Text="ALI Engineering Studio · WinUI 3" FontWeight="SemiBold" Foreground="White" FontSize="13"/>
                </StackPanel>
                <TextBlock Grid.Column="1" Text=".NET 9.0 · Native AOT win-x64" Foreground="#888888" HorizontalAlignment="Center" VerticalAlignment="Center" FontSize="11"/>
            </Grid>
        </Border>

        <!-- Main Content Area with NavigationView -->
        <NavigationView Grid.Row="1" PaneDisplayMode="Left" IsSettingsVisible="True" Header="داشبورد مهندسی ویندوز">
            <NavigationView.MenuItems>
                <NavigationViewItem Content="مدیریت سرویس‌ها" Icon="AllApps"/>
                <NavigationViewItem Content="پایش عملکرد GPU" Icon="SpeedHigh"/>
                <NavigationViewItem Content="پایپ‌لاین بیلد و استقرار" Icon="Sync"/>
            </NavigationView.MenuItems>
            <Frame x:Name="ContentFrame"/>
        </NavigationView>
    </Grid>
</Window>`,
              },
              {
                name: 'MainWindow.xaml.cs',
                path: 'AliWindowsStudio/Views/MainWindow.xaml.cs',
                language: 'csharp',
                size: '2.7 KB',
                content: `using System;
using Microsoft.UI.Xaml;
using Microsoft.UI.Composition.SystemBackdrops;
using System.Runtime.InteropServices;

namespace AliWindowsStudio;

public sealed partial class MainWindow : Window
{
    private WindowsSystemDispatcherQueueHelper? _wsdqHelper;
    private MicaController? _micaController;
    private SystemBackdropConfiguration? _configurationSource;

    public MainWindow()
    {
        this.InitializeComponent();
        TrySetMicaBackdrop();
        ExtendsContentIntoTitleBar = true;
    }

    private bool TrySetMicaBackdrop()
    {
        if (MicaController.IsSupported())
        {
            _wsdqHelper = new WindowsSystemDispatcherQueueHelper();
            _wsdqHelper.EnsureWindowsSystemDispatcherQueueController();

            _configurationSource = new SystemBackdropConfiguration();
            _configurationSource.Theme = SystemBackdropTheme.Dark;

            _micaController = new MicaController();
            _micaController.Kind = MicaKind.BaseAlt;
            _micaController.AddSystemBackdropTarget(this.As<Microsoft.UI.Composition.ICompositionSupportsSystemBackdrop>());
            _micaController.SetSystemBackdropConfiguration(_configurationSource);
            return true;
        }
        return false;
    }
}`,
              },
              {
                name: 'AliWindowsStudio.csproj',
                path: 'AliWindowsStudio/AliWindowsStudio.csproj',
                language: 'xml',
                size: '1.9 KB',
                content: `<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <OutputType>WinExe</OutputType>
    <TargetFramework>net9.0-windows10.0.22621.0</TargetFramework>
    <TargetPlatformMinVersion>10.0.19041.0</TargetPlatformMinVersion>
    <RootNamespace>AliWindowsStudio</RootNamespace>
    <ApplicationManifest>app.manifest</ApplicationManifest>
    <Platforms>x64;ARM64</Platforms>
    <RuntimeIdentifiers>win-x64;win-arm64</RuntimeIdentifiers>
    <PublishAot>true</PublishAot>
    <UseWinUI>true</UseWinUI>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Microsoft.WindowsAppSDK" Version="1.6.241114003" />
    <PackageReference Include="Microsoft.Windows.SDK.BuildTools" Version="10.0.26100.1742" />
    <PackageReference Include="CommunityToolkit.Mvvm" Version="8.3.2" />
  </ItemGroup>
</Project>`,
              },
            ],
          },
        ],
      },
      linux: {
        id: 'linux',
        name: 'Linux / Ubuntu 24.04, GNOME 46 & Qt6',
        nameFa: 'لینوکس (اوبونتو ۲۴ · GNOME 46 · Libadwaita · Qt6)',
        vendor: 'Linux Foundation / FreeDesktop / GNOME',
        iconName: 'Boxes',
        badge: 'Kernel 6.11 / Libadwaita 1.6',
        primaryColor: 'text-emerald-400',
        accentBg: 'from-emerald-950 via-slate-900 to-teal-950',
        borderColor: 'border-emerald-500/40',
        glowColor: 'shadow-emerald-500/20',
        targetOs: 'Ubuntu 24.04 LTS / Arch Linux / Fedora 41 (Wayland)',
        architectures: ['x86_64', 'aarch64 (Raspberry Pi 5)', 'riscv64', 'eBPF JIT'],
        toolchains: ['GCC 14.2', 'Clang 18', 'Rust 1.82', 'CMake 3.30', 'Ninja', 'Meson', 'Cargo'],
        packageFormat: '.AppImage / .deb / Flatpak (Flathub compliant)',
        templates: [
          {
            id: 'linux_libadwaita_rust',
            title: 'Modern GNOME 46 Libadwaita App in Rust',
            titleFa: 'برنامه مدرن لینوکس اوبونتو با Libadwaita و زبان Rust',
            desc: 'GTK4, Libadwaita 1.6, Wayland native rendering, Linux cgroups v2 process inspection.',
            descFa: 'رابط پیشرفته لینوکس گنوم با ویجت‌های کارت مدرن، رندرینگ ویلند و دسترسی به فایل‌سیستم هسته.',
            previewComponent: 'linux_adwaita',
            files: [
              {
                name: 'main.rs',
                path: 'src/main.rs',
                language: 'rust',
                size: '3.2 KB',
                content: `use adw::prelude::*;
use adw::{Application, ApplicationWindow, HeaderBar, ActionRow, PreferencesGroup, StatusPage};
use gtk4::{Box, Orientation, Button, Label};

const APP_ID: &str = "org.ali.engineering.studio";

fn main() {
    let app = Application::builder()
        .application_id(APP_ID)
        .build();

    app.connect_activate(build_ui);
    app.run();
}

fn build_ui(app: &Application) {
    let content = Box::new(Orientation::Vertical, 0);

    // GNOME 46 HeaderBar
    let header = HeaderBar::builder()
        .title_widget(&adw::WindowTitle::new("استودیوی مهندسی لینوکس", "Ubuntu 24.04 Noble"))
        .build();
    content.append(&header);

    // Libadwaita Preferences Group
    let group = PreferencesGroup::builder()
        .title("اطلاعات هسته لینوکس و پایپ‌لاین")
        .description("مانیتورینگ هسته Linux 6.11 با Rust و eBPF")
        .margin_top(20)
        .margin_bottom(20)
        .margin_start(24)
        .margin_end(24)
        .build();

    let row1 = ActionRow::builder()
        .title("سرویس شتاب‌دهنده Wayland")
        .subtitle("رندرینگ با بافر مستقیم بدون تأخیر (Zero Copy)")
        .build();
    
    let btn = Button::with_label("تست ارتباط");
    btn.add_css_class("suggested-action");
    row1.add_suffix(&btn);

    group.add(&row1);
    content.append(&group);

    let window = ApplicationWindow::builder()
        .application(app)
        .title("ALI Linux Studio")
        .default_width(680)
        .default_height(500)
        .content(&content)
        .build();

    window.present();
}`,
              },
              {
                name: 'Cargo.toml',
                path: 'Cargo.toml',
                language: 'toml',
                size: '940 B',
                content: `[package]
name = "ali-linux-studio"
version = "4.5.0"
edition = "2021"
authors = ["Ali Reza <developer@aliphone.io>"]
description = "High-performance Linux GTK4 and Libadwaita engineering suite"

[dependencies]
gtk4 = { version = "0.9", features = ["v4_14"] }
adw = { package = "libadwaita", version = "0.7", features = ["v1_6"] }
tokio = { version = "1.41", features = ["full"] }
sysinfo = "0.31"

[profile.release]
opt-level = 3
lto = "fat"
codegen-units = 1
panic = "abort"
strip = true`,
              },
              {
                name: 'CMakeLists.txt',
                path: 'CMakeLists.txt',
                language: 'cmake',
                size: '1.2 KB',
                content: `cmake_minimum_required(VERSION 3.25)
project(AliLinuxStudio LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

find_package(PkgConfig REQUIRED)
pkg_check_modules(GTK4 REQUIRED IMPORTED_TARGET gtk4)
pkg_check_modules(ADW REQUIRED IMPORTED_TARGET libadwaita-1)

add_executable(ali-linux-studio src/main.cpp)
target_link_libraries(ali-linux-studio PRIVATE PkgConfig::GTK4 PkgConfig::ADW)

install(TARGETS ali-linux-studio DESTINATION bin)`,
              },
            ],
          },
        ],
      },
    }),
    []
  );

  const activePlatformData = PLATFORMS[selectedPlatform];
  const activeTemplate = activePlatformData.templates[selectedTemplateIndex] || activePlatformData.templates[0];
  const activeFiles = activeTemplate.files;
  const currentFile = activeFiles[activeFileIndex] || activeFiles[0];

  // Sync editable code when file changes
  useEffect(() => {
    if (currentFile) {
      setEditableCode(currentFile.content);
    }
  }, [currentFile]);

  // Periodic sensor simulation for telemetry and live preview
  useEffect(() => {
    const interval = setInterval(() => {
      setSensorValues((prev) => ({
        cpu: Math.min(96, Math.max(12, Math.floor(prev.cpu + (Math.random() * 8 - 4)))),
        ram: Math.min(88, Math.max(30, Math.floor(prev.ram + (Math.random() * 4 - 2)))),
        fps: Math.random() > 0.85 ? 119 : 120,
        temp: +(33.5 + Math.random() * 2.5).toFixed(1),
        battery: Math.max(10, prev.battery),
        networkLatency: Math.floor(12 + Math.random() * 6),
      }));
    }, 2200);
    return () => clearInterval(interval);
  }, []);

  const handleCopyCode = () => {
    if (soundEnabled) soundEffects.click();
    navigator.clipboard.writeText(editableCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handlePlatformSwitch = (platformId: PlatformTarget) => {
    if (soundEnabled) soundEffects.click();
    setSelectedPlatform(platformId);
    setSelectedTemplateIndex(0);
    setActiveFileIndex(0);
    setBuildArtifact(null);
    setBuildLogs([]);
  };

  const handleRunBuildPipeline = () => {
    if (isBuilding) return;
    if (soundEnabled) soundEffects.cameraShutter();
    setIsBuilding(true);
    setBuildProgress(10);
    setBuildArtifact(null);

    const platformKey = selectedPlatform;
    const initialLogs: string[] = [];

    if (platformKey === 'samsung') {
      initialLogs.push('> ./gradlew assembleRelease --stacktrace --scan');
      initialLogs.push('⚙️ Configuring Samsung One UI 6.1 Gradle Build...');
      initialLogs.push('📦 Compiling Kotlin 2.0 with Compose Compiler 1.7.5...');
    } else if (platformKey === 'apple') {
      initialLogs.push('> xcodebuild -project AliAppleStudio.xcodeproj -scheme Release -destination "generic/platform=iOS" archive');
      initialLogs.push('🍏 Clang 18 resolving Swift 6 strict concurrency checks...');
      initialLogs.push('⚡ Metal 3 compiling shader compute pipeline for A18 Pro Bionic...');
    } else if (platformKey === 'windows') {
      initialLogs.push('> dotnet publish -c Release -r win-x64 --self-contained /p:PublishAot=true');
      initialLogs.push('🪟 Microsoft C# 13 compiler with WinAppSDK 1.6...');
      initialLogs.push('⚡ Native AOT generating zero-overhead Windows PE binary...');
    } else {
      initialLogs.push('> cargo build --release --target x86_64-unknown-linux-gnu');
      initialLogs.push('🐧 Compiling Libadwaita 1.6 & GTK4 binding with LTO=fat...');
      initialLogs.push('📦 Generating Ubuntu .AppImage & Flatpak bundle...');
    }

    setBuildLogs(initialLogs);

    // Timed pipeline simulation
    setTimeout(() => {
      setBuildProgress(45);
      setBuildLogs((prev) => [
        ...prev,
        '✓ Static analysis & security scan passed (0 CVEs, 0 vulnerabilities)',
        '✓ Memory layout optimization: SIMD / AVX / Neon vectorization enabled',
      ]);
    }, 600);

    setTimeout(() => {
      setBuildProgress(80);
      setBuildLogs((prev) => [
        ...prev,
        '✓ Code signing verified: Hardware Enclave cryptographic signature applied',
        '✓ Binary stripped and compressed with high-ratio ZSTD algorithm',
      ]);
    }, 1200);

    setTimeout(() => {
      setBuildProgress(100);
      setIsBuilding(false);

      let artifactName = '';
      let artifactSize = '';
      if (platformKey === 'samsung') {
        artifactName = 'GalaxyStudio-v4.5.0-release.apk';
        artifactSize = '18.4 MB';
      } else if (platformKey === 'apple') {
        artifactName = 'AppleStudio-iOS18-Universal.ipa';
        artifactSize = '24.1 MB';
      } else if (platformKey === 'windows') {
        artifactName = 'AliWindowsStudio-v4.5-Setup.msix';
        artifactSize = '32.6 MB';
      } else {
        artifactName = 'AliLinuxStudio-x86_64.AppImage';
        artifactSize = '14.8 MB';
      }

      setBuildLogs((prev) => [
        ...prev,
        `🎉 BUILD SUCCESSFUL in 1.84s!`,
        `📦 Output artifact generated: ${artifactName} (${artifactSize})`,
        `🚀 Ready for direct installation and target hardware deployment!`,
      ]);

      setBuildArtifact({
        name: artifactName,
        size: artifactSize,
        ready: true,
      });

      if (soundEnabled) soundEffects.notification();
    }, 1800);
  };

  const handleExportZip = async () => {
    if (soundEnabled) soundEffects.click();
    setIsExportingZip(true);
    try {
      const zip = new JSZip();

      // Add all active template files with their real paths
      activeFiles.forEach((file) => {
        zip.file(file.path, file.content);
      });

      // Add README.md
      const readme = `# ${activeTemplate.title} (${activeTemplate.titleFa})
Target Platform: ${activePlatformData.name} (${activePlatformData.nameFa})
OS: ${activePlatformData.targetOs}
Architectures: ${activePlatformData.architectures.join(', ')}
Toolchain: ${activePlatformData.toolchains.join(', ')}
Package Format: ${activePlatformData.packageFormat}

Exported from ALI Engineering Studio Pro v4.5 (4-OS Native Platform).

### Build Command:
${selectedPlatform === 'samsung' ? './gradlew assembleRelease' : selectedPlatform === 'apple' ? 'xcodebuild -scheme Release archive' : selectedPlatform === 'windows' ? 'dotnet publish -c Release' : 'cargo build --release'}
`;
      zip.file('README.md', readme);

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${activeTemplate.id}-${selectedPlatform}-project.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      if (soundEnabled) soundEffects.notification();
    } catch (err) {
      console.error('ZIP Export Error:', err);
    } finally {
      setIsExportingZip(false);
    }
  };

  const handleRunLiveCode = async () => {
    if (soundEnabled) soundEffects.click();
    setIsRunningCode(true);
    setShowLiveConsole(true);
    try {
      const res = await executeCodeInBrowser(editableCode, currentFile?.language || 'javascript');
      setLiveExecutionResult(res);
      if (soundEnabled) soundEffects.notification();
    } catch (err: any) {
      setLiveExecutionResult({
        output: [],
        error: err?.message || String(err),
        durationMs: 0,
        success: false,
      });
    } finally {
      setIsRunningCode(false);
    }
  };

  const handleTriggerScaffold = (promptPreset?: string) => {
    const prompt = promptPreset || customScaffoldPrompt;
    if (!prompt.trim()) return;

    if (soundEnabled) soundEffects.click();
    setScaffoldGenerating(true);
    setScaffoldSuccessMessage(null);

    setTimeout(() => {
      setScaffoldGenerating(false);
      setScaffoldSuccessMessage(
        isPersian
          ? `معماری مهندسی "${prompt}" با موفقیت برای ۴ پلتفرم (سامسونگ، اپل، ویندوز، لینوکس) کامپایل و در درخت پروژه ادغام شد!`
          : `Architecture "${prompt}" scaffolded across all 4 platforms with clean patterns (MVVM + Clean Architecture)!`
      );
      if (soundEnabled) soundEffects.notification();
    }, 1200);
  };

  return (
    <div className="flex flex-col h-full w-full bg-slate-950 text-slate-100 select-none overflow-hidden font-sans">
      {/* Top Professional Navigation Bar */}
      <div className="flex items-center justify-between px-3 py-2.5 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 z-20">
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              if (soundEnabled) soundEffects.click();
              onBack();
            }}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            title={isPersian ? 'بازگشت به صفحه اصلی' : 'Back to Home'}
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-cyan-500 via-indigo-600 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Cpu className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-xs tracking-wide text-white">ALI DevStudio Pro</span>
                <span className="px-1.5 py-0.5 text-[9px] font-mono font-bold bg-indigo-500/20 text-indigo-300 rounded border border-indigo-500/30">
                  4-OS NATIVE
                </span>
              </div>
              <p className="text-[10px] text-slate-400">
                {isPersian ? 'موتور مهندسی سامسونگ · اپل · ویندوز · لینوکس' : 'Samsung · Apple · Windows · Linux Engineering Suite'}
              </p>
            </div>
          </div>
        </div>

        {/* Global Action Controls */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleRunBuildPipeline}
            disabled={isBuilding}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold shadow-md transition-all ${
              isBuilding
                ? 'bg-amber-600 text-white animate-pulse'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/20'
            }`}
          >
            {isBuilding ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>{isPersian ? 'در حال کامپایل...' : 'Building...'}</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{isPersian ? 'بیلد و کامپایل' : 'Build & Compile'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Platform Switcher Header (Samsung, Apple, Windows, Linux) */}
      <div className="grid grid-cols-4 gap-1 p-2 bg-slate-900 border-b border-slate-800">
        {(['samsung', 'apple', 'windows', 'linux'] as PlatformTarget[]).map((pid) => {
          const p = PLATFORMS[pid];
          const isSelected = selectedPlatform === pid;
          return (
            <button
              key={pid}
              onClick={() => handlePlatformSwitch(pid)}
              className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl transition-all relative ${
                isSelected
                  ? `bg-slate-800/95 border ${p.borderColor} ${p.glowColor} shadow-md`
                  : 'bg-slate-950/40 hover:bg-slate-800/50 border border-transparent opacity-75 hover:opacity-100'
              }`}
            >
              <div className="flex items-center gap-1 mb-0.5">
                {pid === 'samsung' && <Smartphone className={`w-3.5 h-3.5 ${isSelected ? 'text-cyan-400' : 'text-slate-400'}`} />}
                {pid === 'apple' && <Laptop className={`w-3.5 h-3.5 ${isSelected ? 'text-sky-400' : 'text-slate-400'}`} />}
                {pid === 'windows' && <Monitor className={`w-3.5 h-3.5 ${isSelected ? 'text-blue-400' : 'text-slate-400'}`} />}
                {pid === 'linux' && <Boxes className={`w-3.5 h-3.5 ${isSelected ? 'text-emerald-400' : 'text-slate-400'}`} />}
                <span className={`text-[11px] font-bold ${isSelected ? 'text-white' : 'text-slate-300'}`}>
                  {pid === 'samsung' ? (isPersian ? 'سامسونگ' : 'Samsung') :
                   pid === 'apple' ? (isPersian ? 'اپل' : 'Apple') :
                   pid === 'windows' ? (isPersian ? 'ویندوز' : 'Windows') :
                   (isPersian ? 'لینوکس' : 'Linux')}
                </span>
              </div>
              <span className="text-[9px] font-mono text-slate-400 truncate max-w-full">
                {p.packageFormat.split(' ')[0]}
              </span>
              {isSelected && (
                <span className="absolute bottom-0 w-8 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent rounded-full" />
              )}
            </button>
          );
        })}
      </div>

      {/* Target Specs Summary Bar */}
      <div className="flex items-center justify-between px-3 py-1.5 bg-slate-950/90 border-b border-slate-800/80 text-[10px] text-slate-400 overflow-x-auto whitespace-nowrap">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1 font-mono text-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            {activePlatformData.targetOs}
          </span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400 font-mono">
            {activePlatformData.architectures[0]}
          </span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400 font-mono">
            {activePlatformData.toolchains[0]}
          </span>
        </div>
        <div className="flex items-center gap-2 font-mono text-[9px] text-cyan-400">
          <span>LLVM/JIT Ready</span>
          <ShieldCheck className="w-3 h-3 text-cyan-400" />
        </div>
      </div>

      {/* Workspace Tabs (IDE, Live Preview, Pipeline, Architecture Scaffolder, Profiler) */}
      <div className="flex items-center justify-between px-2 pt-2 bg-slate-900/60 border-b border-slate-800">
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
          <button
            onClick={() => {
              if (soundEnabled) soundEffects.click();
              setActiveTab('editor');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-t-lg transition-colors border-t border-x ${
              activeTab === 'editor'
                ? 'bg-slate-950 text-cyan-400 border-slate-800 border-b-slate-950'
                : 'text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>{isPersian ? 'محیط کدنویسی' : 'IDE & Editor'}</span>
          </button>

          <button
            onClick={() => {
              if (soundEnabled) soundEffects.click();
              setActiveTab('preview');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-t-lg transition-colors border-t border-x ${
              activeTab === 'preview'
                ? 'bg-slate-950 text-emerald-400 border-slate-800 border-b-slate-950'
                : 'text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>{isPersian ? 'شبیه‌ساز و خروجی زنده' : 'Live Emulator'}</span>
          </button>

          <button
            onClick={() => {
              if (soundEnabled) soundEffects.click();
              setActiveTab('pipeline');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-t-lg transition-colors border-t border-x relative ${
              activeTab === 'pipeline'
                ? 'bg-slate-950 text-amber-400 border-slate-800 border-b-slate-950'
                : 'text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>{isPersian ? 'پایپ‌لاین بیلد' : 'Build Pipeline'}</span>
            {buildArtifact && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            )}
          </button>

          <button
            onClick={() => {
              if (soundEnabled) soundEffects.click();
              setActiveTab('scaffold');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-t-lg transition-colors border-t border-x ${
              activeTab === 'scaffold'
                ? 'bg-slate-950 text-purple-400 border-slate-800 border-b-slate-950'
                : 'text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isPersian ? 'تولید معماری جامع' : 'Omni Scaffolder'}</span>
          </button>

          <button
            onClick={() => {
              if (soundEnabled) soundEffects.click();
              setActiveTab('telemetry');
            }}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-t-lg transition-colors border-t border-x ${
              activeTab === 'telemetry'
                ? 'bg-slate-950 text-rose-400 border-slate-800 border-b-slate-950'
                : 'text-slate-400 border-transparent hover:text-slate-200'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>{isPersian ? 'پروفایلر سخت‌افزار' : 'Profiler'}</span>
          </button>
        </div>
      </div>

      {/* Main Workspace Body */}
      <div className="flex-1 overflow-hidden relative bg-slate-950 flex flex-col">
        {/* ==================== TAB 1: CODE EDITOR ==================== */}
        {activeTab === 'editor' && (
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* File Selector Tabs */}
            <div className="flex items-center justify-between px-2 py-1.5 bg-slate-900/80 border-b border-slate-800 overflow-x-auto text-xs">
              <div className="flex items-center gap-1">
                {activeFiles.map((file, idx) => {
                  const isActive = activeFileIndex === idx;
                  return (
                    <button
                      key={file.path}
                      onClick={() => {
                        if (soundEnabled) soundEffects.click();
                        setActiveFileIndex(idx);
                      }}
                      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-mono transition-colors ${
                        isActive
                          ? 'bg-slate-800 text-white font-medium border border-slate-700'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
                      }`}
                    >
                      <FileCode className="w-3 h-3 text-cyan-400" />
                      <span>{file.name}</span>
                      <span className="text-[10px] text-slate-500 font-normal">({file.size})</span>
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center gap-1.5">
                {/* Run Code in Browser */}
                <button
                  onClick={handleRunLiveCode}
                  disabled={isRunningCode}
                  className="px-2.5 py-1 rounded bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-300 border border-emerald-500/40 text-[11px] font-semibold flex items-center gap-1 transition-all"
                  title="Run Code in Sandbox"
                >
                  <Play className="w-3 h-3 fill-current" />
                  <span>{isRunningCode ? (isPersian ? 'اجرا...' : 'Running...') : (isPersian ? 'اجرای زنده' : 'Run')}</span>
                </button>

                {/* Export Full Project ZIP */}
                <button
                  onClick={handleExportZip}
                  disabled={isExportingZip}
                  className="px-2.5 py-1 rounded bg-blue-600/30 hover:bg-blue-600/50 text-blue-300 border border-blue-500/40 text-[11px] font-semibold flex items-center gap-1 transition-all"
                  title="Download Project ZIP"
                >
                  <Download className="w-3 h-3" />
                  <span>{isExportingZip ? 'ZIP...' : (isPersian ? 'دانلود ZIP' : 'Export ZIP')}</span>
                </button>

                <button
                  onClick={handleCopyCode}
                  className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors flex items-center gap-1 text-[11px]"
                  title="Copy code"
                >
                  {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedCode ? (isPersian ? 'کپی شد' : 'Copied') : (isPersian ? 'کپی' : 'Copy')}</span>
                </button>
              </div>
            </div>

            {/* Path breadcrumb */}
            <div className="px-3 py-1 bg-slate-950 border-b border-slate-800/50 flex items-center justify-between text-[11px] font-mono text-slate-400">
              <span className="truncate">{currentFile?.path}</span>
              <span className="text-[10px] text-slate-500 uppercase">{currentFile?.language}</span>
            </div>

            {/* Code Content Area with Line Numbers */}
            <div className="flex-1 overflow-auto flex text-xs font-mono bg-slate-950 text-slate-200">
              {/* Line Numbers */}
              <div className="py-3 px-2 bg-slate-900/60 text-slate-600 select-none text-right border-r border-slate-800/60 font-mono text-[11px] leading-relaxed">
                {editableCode.split('\n').map((_, i) => (
                  <div key={i} className="px-1">{i + 1}</div>
                ))}
              </div>

              {/* Code TextArea */}
              <textarea
                value={editableCode}
                onChange={(e) => setEditableCode(e.target.value)}
                spellCheck={false}
                className="flex-1 p-3 bg-transparent text-slate-200 focus:outline-none resize-none font-mono text-[11px] leading-relaxed whitespace-pre font-light selection:bg-cyan-900/50 selection:text-white"
              />
            </div>

            {/* Live Console Output Drawer */}
            {showLiveConsole && (
              <div className="h-40 bg-slate-900 border-t border-slate-800 flex flex-col text-xs font-mono">
                <div className="px-3 py-1.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between text-slate-400">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                    <span className="font-bold text-white text-[11px]">{isPersian ? 'خروجی زنده کنسول (Live Sandbox)' : 'Live Console Output'}</span>
                    {liveExecutionResult && (
                      <span className="text-[10px] text-emerald-400 font-bold">({liveExecutionResult.durationMs}ms)</span>
                    )}
                  </div>
                  <button
                    onClick={() => setShowLiveConsole(false)}
                    className="p-1 rounded text-slate-400 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="flex-1 p-2.5 overflow-y-auto space-y-1 bg-black/60 text-slate-200">
                  {liveExecutionResult ? (
                    <>
                      {liveExecutionResult.output.map((out, idx) => (
                        <div key={idx} className="leading-relaxed text-cyan-300">{out}</div>
                      ))}
                      {liveExecutionResult.returnValue !== undefined && (
                        <div className="text-emerald-400">↳ Return: {liveExecutionResult.returnValue}</div>
                      )}
                      {liveExecutionResult.error && (
                        <div className="text-rose-400">❌ Error: {liveExecutionResult.error}</div>
                      )}
                    </>
                  ) : (
                    <div className="text-slate-500">{isPersian ? 'در حال اجرای کد...' : 'Executing code...'}</div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ==================== TAB 2: LIVE EMULATOR PREVIEW ==================== */}
        {activeTab === 'preview' && (
          <div className="flex-1 overflow-y-auto p-3 flex flex-col items-center bg-slate-950/80">
            {/* Viewport Control Bar */}
            <div className="w-full max-w-sm flex items-center justify-between mb-3 px-3 py-1.5 bg-slate-900 rounded-xl border border-slate-800 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span className="font-semibold text-slate-300">
                  {selectedPlatform === 'samsung' && 'Samsung Galaxy S24 Ultra (One UI 6.1)'}
                  {selectedPlatform === 'apple' && 'Apple iPhone 16 Pro Max / macOS Sequoia'}
                  {selectedPlatform === 'windows' && 'Windows 11 Fluent 24H2 Desktop'}
                  {selectedPlatform === 'linux' && 'Ubuntu 24.04 GNOME 46 Libadwaita'}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => {
                    if (soundEnabled) soundEffects.click();
                    setSimulatedInputState((s) => ({ ...s, counter: 0 }));
                  }}
                  className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white"
                  title="Reset state"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Target Hardware Realistic Emulator Frame */}
            <div className="w-full max-w-sm rounded-3xl p-3 bg-slate-900/90 border border-slate-800 shadow-2xl relative">
              {/* === SAMSUNG GALAXY EMULATOR === */}
              {selectedPlatform === 'samsung' && (
                <div className="w-full rounded-2xl bg-slate-950 border-2 border-slate-700/80 overflow-hidden shadow-inner flex flex-col">
                  {/* Punch Hole Camera & Status Bar */}
                  <div className="h-7 bg-slate-950 px-4 flex items-center justify-between text-[10px] text-slate-400">
                    <span className="font-mono">12:45</span>
                    <div className="w-3.5 h-3.5 rounded-full bg-black border border-slate-800 shadow-inner" />
                    <div className="flex items-center gap-1.5 font-mono">
                      <span>5G+</span>
                      <span>{sensorValues.battery}%</span>
                    </div>
                  </div>

                  {/* One UI App Content */}
                  <div className="p-4 flex flex-col gap-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-bold text-white">Galaxy Health Pro</h4>
                        <p className="text-[10px] text-cyan-400">Samsung Knox Verified Engine</p>
                      </div>
                      <span className="px-2 py-0.5 rounded-full text-[9px] bg-cyan-500/20 text-cyan-300 font-mono border border-cyan-500/30">
                        BioActive v4
                      </span>
                    </div>

                    {/* Sensor Cards */}
                    <div className="grid grid-cols-2 gap-2 mt-1">
                      <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col">
                        <span className="text-[10px] text-slate-400">{isPersian ? 'ضربان قلب' : 'Heart Rate'}</span>
                        <div className="flex items-baseline gap-1 mt-1">
                          <span className="text-lg font-bold text-rose-400">{72 + simulatedInputState.counter}</span>
                          <span className="text-[9px] text-slate-500">BPM</span>
                        </div>
                      </div>
                      <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col">
                        <span className="text-[10px] text-slate-400">{isPersian ? 'اکسیژن SpO2' : 'Blood Oxygen'}</span>
                        <div className="flex items-baseline gap-1 mt-1">
                          <span className="text-lg font-bold text-cyan-400">99.1</span>
                          <span className="text-[9px] text-slate-500">%</span>
                        </div>
                      </div>
                    </div>

                    {/* Interactive Input */}
                    <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col gap-2">
                      <span className="text-[11px] font-semibold text-slate-200">
                        {isPersian ? 'شبیه‌سازی ورودی زنده One UI' : 'Live One UI Action'}
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            if (soundEnabled) soundEffects.click();
                            setSimulatedInputState((s) => ({ ...s, counter: s.counter + 1 }));
                          }}
                          className="flex-1 py-1.5 px-3 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-md transition-all active:scale-95"
                        >
                          {isPersian ? 'افزایش پایش بیومتریک' : 'Scan BioActive (+1)'}
                        </button>
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                        <span>{isPersian ? 'حالت دکس (DeX Mode)' : 'Samsung DeX Status'}</span>
                        <button
                          onClick={() => {
                            if (soundEnabled) soundEffects.click();
                            setSimulatedInputState((s) => ({ ...s, toggle1: !s.toggle1 }));
                          }}
                          className={`w-9 h-5 rounded-full p-0.5 transition-colors ${
                            simulatedInputState.toggle1 ? 'bg-cyan-600' : 'bg-slate-700'
                          }`}
                        >
                          <div
                            className={`w-4 h-4 rounded-full bg-white transition-transform ${
                              simulatedInputState.toggle1 ? 'translate-x-4' : 'translate-x-0'
                            }`}
                          />
                        </button>
                      </div>
                    </div>

                    {/* One UI Bottom Navigation Bar */}
                    <div className="pt-2 flex items-center justify-around border-t border-slate-900 text-slate-500">
                      <div className="w-3.5 h-3.5 border-2 border-slate-500 rounded-sm" />
                      <div className="w-3.5 h-3.5 rounded-full border-2 border-slate-500" />
                      <div className="text-xs font-bold">&lt;</div>
                    </div>
                  </div>
                </div>
              )}

              {/* === APPLE EMULATOR === */}
              {selectedPlatform === 'apple' && (
                <div className="w-full rounded-2xl bg-black border-2 border-slate-700/80 overflow-hidden shadow-inner flex flex-col">
                  {/* Dynamic Island Header */}
                  <div className="pt-2 pb-1 bg-black flex flex-col items-center">
                    <div className="px-4 py-1.5 bg-neutral-900 rounded-full border border-neutral-800 flex items-center gap-3 shadow-lg">
                      <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
                      <span className="text-[10px] font-semibold text-white tracking-tight">Live Activity Active</span>
                      <span className="text-[9px] font-mono text-cyan-300">A18 Pro</span>
                    </div>
                  </div>

                  {/* iOS SwiftUI View */}
                  <div className="p-4 flex flex-col gap-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-bold text-white">Apple Studio iOS 18</h4>
                        <p className="text-[10px] text-sky-400">Metal 3 Accelerated</p>
                      </div>
                      <span className="px-2 py-0.5 rounded-full text-[9px] bg-sky-500/20 text-sky-300 font-mono border border-sky-500/30">
                        Swift 6.0
                      </span>
                    </div>

                    {/* Cupertino Glass Card */}
                    <div className="p-3 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md flex flex-col gap-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-300 font-medium">{isPersian ? 'تعداد پالس عصبی NPU' : 'Neural Engine Pulses'}</span>
                        <span className="font-mono text-emerald-400 font-bold">{1420 + simulatedInputState.counter * 12}</span>
                      </div>
                      <div className="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-sky-500 transition-all duration-300"
                          style={{ width: `${Math.min(100, 35 + simulatedInputState.counter * 5)}%` }}
                        />
                      </div>
                    </div>

                    {/* Interactive Button */}
                    <button
                      onClick={() => {
                        if (soundEnabled) soundEffects.click();
                        setSimulatedInputState((s) => ({ ...s, counter: s.counter + 1 }));
                      }}
                      className="w-full py-2 px-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold text-xs shadow-lg shadow-sky-500/20 active:scale-95 transition-all"
                    >
                      {isPersian ? 'اجرای رندرینگ متال ۳ (Render Metal 3)' : 'Trigger Metal 3 Compute'}
                    </button>

                    {/* iOS Home Indicator Bar */}
                    <div className="pt-3 flex justify-center">
                      <div className="w-28 h-1 rounded-full bg-white/60" />
                    </div>
                  </div>
                </div>
              )}

              {/* === WINDOWS 11 EMULATOR === */}
              {selectedPlatform === 'windows' && (
                <div className="w-full rounded-2xl bg-[#1e1e1e] border-2 border-slate-700/80 overflow-hidden shadow-inner flex flex-col">
                  {/* Windows 11 Title Bar with Controls */}
                  <div className="h-8 bg-[#252526] px-3 flex items-center justify-between border-b border-[#333]">
                    <div className="flex items-center gap-1.5">
                      <div className="grid grid-cols-2 gap-0.5 w-3 h-3">
                        <div className="bg-[#0078D4]" />
                        <div className="bg-[#0078D4]" />
                        <div className="bg-[#0078D4]" />
                        <div className="bg-[#0078D4]" />
                      </div>
                      <span className="text-[10px] font-medium text-slate-300">WinUI 3 Mica Studio</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] text-slate-400">―</span>
                      <span className="text-[9px] text-slate-400">□</span>
                      <span className="text-[9px] text-rose-400 font-bold">✕</span>
                    </div>
                  </div>

                  {/* Windows 11 Content */}
                  <div className="p-4 flex flex-col gap-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-white">.NET 9 Native AOT Dashboard</h4>
                      <span className="px-2 py-0.5 rounded text-[9px] bg-blue-500/20 text-blue-300 font-mono border border-blue-500/30">
                        x64 / ARM64
                      </span>
                    </div>

                    <div className="p-3 rounded-xl bg-[#2d2d2d] border border-[#3e3e3e] flex flex-col gap-2">
                      <span className="text-[11px] text-slate-300">Fluent Controls & Acrylic Sheet</span>
                      <div className="flex items-center justify-between text-xs text-slate-400">
                        <span>DirectX 12 Compute Threads</span>
                        <span className="text-white font-mono font-bold">{32 + simulatedInputState.counter * 4}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        if (soundEnabled) soundEffects.click();
                        setSimulatedInputState((s) => ({ ...s, counter: s.counter + 1 }));
                      }}
                      className="py-1.5 px-3 rounded-lg bg-[#0078D4] hover:bg-[#0086F0] text-white font-medium text-xs shadow-md transition-all active:scale-95"
                    >
                      {isPersian ? 'شبیه‌سازی رویداد WinUI 3 (+1)' : 'Fire WinUI Dispatcher Event'}
                    </button>
                  </div>
                </div>
              )}

              {/* === LINUX GNOME 46 EMULATOR === */}
              {selectedPlatform === 'linux' && (
                <div className="w-full rounded-2xl bg-[#242424] border-2 border-slate-700/80 overflow-hidden shadow-inner flex flex-col">
                  {/* GNOME 46 Libadwaita HeaderBar */}
                  <div className="h-8 bg-[#303030] px-3 flex items-center justify-between border-b border-[#3b3b3b]">
                    <div className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                      <span className="text-[10px] font-bold text-slate-200">Ubuntu 24.04 (Wayland)</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-3 h-3 rounded-full bg-[#454545] hover:bg-rose-600 flex items-center justify-center text-[8px] text-white">
                        ✕
                      </div>
                    </div>
                  </div>

                  {/* Libadwaita Cards */}
                  <div className="p-4 flex flex-col gap-3">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-white">GNOME 46 / Libadwaita 1.6</h4>
                      <span className="px-2 py-0.5 rounded text-[9px] bg-emerald-500/20 text-emerald-300 font-mono border border-emerald-500/30">
                        Rust + GTK4
                      </span>
                    </div>

                    <div className="p-3 rounded-xl bg-[#2e2e2e] border border-[#3e3e3e] flex flex-col gap-1.5">
                      <span className="text-[11px] font-semibold text-slate-200">Linux Kernel 6.11 Process Info</span>
                      <span className="text-[10px] text-slate-400">cgroups v2 active · zero memory leak</span>
                      <div className="flex items-center justify-between text-xs text-emerald-400 font-mono mt-1">
                        <span>eBPF Filtered Packets</span>
                        <span>{18420 + simulatedInputState.counter * 250}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        if (soundEnabled) soundEffects.click();
                        setSimulatedInputState((s) => ({ ...s, counter: s.counter + 1 }));
                      }}
                      className="py-1.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs shadow-md transition-all active:scale-95"
                    >
                      {isPersian ? 'ارسال سیگنال هسته (Send Syscall)' : 'Send POSIX Syscall'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ==================== TAB 3: BUILD PIPELINE & TERMINAL ==================== */}
        {activeTab === 'pipeline' && (
          <div className="flex-1 flex flex-col bg-slate-950 overflow-hidden">
            {/* Pipeline Header */}
            <div className="p-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-amber-400" />
                <span className="font-semibold text-white">
                  {isPersian ? 'پایپ‌لاین کامپایلر بومی' : 'Native Compilation Pipeline'}
                </span>
                <span className="font-mono text-[10px] px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded">
                  {activePlatformData.toolchains[0]}
                </span>
              </div>
              <button
                onClick={handleRunBuildPipeline}
                disabled={isBuilding}
                className="px-3 py-1 rounded-md bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs transition-colors flex items-center gap-1.5 shadow"
              >
                <Play className="w-3 h-3 fill-current" />
                <span>{isBuilding ? (isPersian ? 'کامپایل...' : 'Building...') : (isPersian ? 'شروع بیلد' : 'Run Build')}</span>
              </button>
            </div>

            {/* Build Progress Bar */}
            {isBuilding && (
              <div className="w-full bg-slate-900 h-1">
                <div
                  className="bg-gradient-to-r from-amber-500 via-emerald-500 to-cyan-500 h-full transition-all duration-300"
                  style={{ width: `${buildProgress}%` }}
                />
              </div>
            )}

            {/* Terminal Output */}
            <div className="flex-1 p-3 overflow-y-auto font-mono text-xs bg-slate-950 text-slate-300 flex flex-col gap-1">
              {buildLogs.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-600 gap-2">
                  <Terminal className="w-8 h-8 stroke-[1.5]" />
                  <p className="text-xs">
                    {isPersian
                      ? 'آماده اجرای پایپ‌لاین کامپایل برای ' + activePlatformData.nameFa
                      : 'Ready to compile for ' + activePlatformData.name}
                  </p>
                </div>
              ) : (
                buildLogs.map((log, index) => (
                  <div
                    key={index}
                    className={`leading-relaxed ${
                      log.startsWith('>')
                        ? 'text-cyan-400 font-bold'
                        : log.startsWith('✓')
                        ? 'text-emerald-400'
                        : log.startsWith('🎉')
                        ? 'text-amber-300 font-bold'
                        : log.startsWith('📦')
                        ? 'text-purple-400 font-bold'
                        : 'text-slate-400'
                    }`}
                  >
                    {log}
                  </div>
                ))
              )}
            </div>

            {/* Ready Artifact Download Box */}
            {buildArtifact && (
              <div className="p-3 bg-emerald-950/40 border-t border-emerald-500/30 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <div>
                    <div className="font-bold text-xs text-white">{buildArtifact.name}</div>
                    <div className="text-[10px] text-emerald-400">
                      {isPersian ? 'بسته نصبی آماده دانلود و اجرا' : 'Package ready for target device'} · {buildArtifact.size}
                    </div>
                  </div>
                </div>
                <button
                  onClick={handleExportZip}
                  disabled={isExportingZip}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-lg shadow-emerald-600/30 transition-all active:scale-95"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{isExportingZip ? 'در حال ساخت ZIP...' : (isPersian ? 'دانلود سورس و بسته کامل (.ZIP)' : 'Download Full ZIP (.zip)')}</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* ==================== TAB 4: OMNI ARCHITECTURE SCAFFOLDER ==================== */}
        {activeTab === 'scaffold' && (
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 bg-slate-950">
            <div className="p-3 rounded-2xl bg-gradient-to-r from-purple-950/40 via-indigo-950/30 to-slate-900 border border-purple-500/30">
              <div className="flex items-center gap-2 mb-1">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <h3 className="font-bold text-sm text-white">
                  {isPersian ? 'موتور ساخت معماری جامع چندسکویی' : 'Cross-Platform Omni Architecture Scaffolder'}
                </h3>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {isPersian
                  ? 'یک ایده نرم‌افزاری وارد کنید تا بستر مهندسی، معماری تمیز (Clean Architecture)، کدنویسی و فایل‌های پیکربندی را همزمان برای سامسونگ، اپل، ویندوز و لینوکس تولید کند.'
                  : 'Enter any software concept to generate clean cross-platform source files, manifests, and tooling configurations simultaneously for Samsung, Apple, Windows, and Linux.'}
              </p>
            </div>

            {/* Custom Input */}
            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold text-slate-300">
                {isPersian ? 'عنوان یا شرح ایده برنامه:' : 'Application Concept / Specifications:'}
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={customScaffoldPrompt}
                  onChange={(e) => setCustomScaffoldPrompt(e.target.value)}
                  placeholder={
                    isPersian
                      ? 'مثال: سیستم تحلیل بلادرنگ داده‌های مالی و کریپتو...'
                      : 'e.g., High-throughput crypto trading engine with local AI...'
                  }
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500 transition-colors"
                />
                <button
                  onClick={() => handleTriggerScaffold()}
                  disabled={scaffoldGenerating}
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs shadow-lg shadow-purple-600/30 transition-all flex items-center gap-1.5"
                >
                  {scaffoldGenerating ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Sparkles className="w-3.5 h-3.5" />
                  )}
                  <span>{isPersian ? 'تولید ساختار' : 'Scaffold'}</span>
                </button>
              </div>
            </div>

            {/* Presets */}
            <div className="flex flex-col gap-2">
              <span className="text-xs font-semibold text-slate-400">
                {isPersian ? 'الگوهای معماری آماده:' : 'Pre-architected Blueprints:'}
              </span>
              <div className="grid grid-cols-1 gap-2">
                {[
                  {
                    title: isPersian ? 'هاب اینترنت اشیاء و اتوماسیون صنعتی' : 'Industrial IoT & Sensor Matrix',
                    desc: isPersian ? 'سامسونگ دکس + سوئیفت‌یوآی اپل + WinUI 3 میکا + کلاینت GTK4 لینوکس' : 'Samsung DeX + Apple SwiftUI + Windows WinUI + Linux Libadwaita',
                  },
                  {
                    title: isPersian ? 'موتور پردازش صوت و هوش مصنوعی محلی' : 'Edge AI Voice & Vision Engine',
                    desc: isPersian ? 'استفاده مستقیم از Knox NPU، Apple Neural Engine، DirectML و Linux eBPF' : 'Hardware accelerated with Knox NPU, Apple ANE, DirectML & Linux eBPF',
                  },
                  {
                    title: isPersian ? 'کیف پول غیرمتمرکز سازمانی با رمزنگاری سخت‌افزاری' : 'Hardware-Enforced Multi-Platform Vault',
                    desc: isPersian ? 'ذخیره‌سازی کلید در Knox Vault، Apple Secure Enclave، Windows Hello و Linux TPM 2.0' : 'Key security on Knox Vault, Secure Enclave, Windows Hello, and Linux TPM',
                  },
                ].map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleTriggerScaffold(preset.title)}
                    className="p-3 rounded-xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800 hover:border-purple-500/40 text-left transition-all flex items-center justify-between group"
                  >
                    <div>
                      <div className="text-xs font-bold text-white group-hover:text-purple-300 transition-colors">
                        {preset.title}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{preset.desc}</div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-purple-400 transition-colors" />
                  </button>
                ))}
              </div>
            </div>

            {/* Scaffold Message */}
            {scaffoldSuccessMessage && (
              <div className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{scaffoldSuccessMessage}</span>
              </div>
            )}
          </div>
        )}

        {/* ==================== TAB 5: PROFILER & TELEMETRY ==================== */}
        {activeTab === 'telemetry' && (
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 bg-slate-950">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-white">
                  {isPersian ? 'پایش لحظه‌ای سخت‌افزار و فریم‌ریت' : 'Hardware Telemetry & Frame Profiler'}
                </h3>
                <p className="text-xs text-slate-400">
                  {isPersian ? 'تحلیل رندرینگ زنده روی پردازنده Apple A18 Pro Bionic' : 'Live hardware execution telemetry on Apple A18 Pro Bionic'}
                </p>
              </div>
              <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                {sensorValues.fps} FPS (120Hz ProMotion)
              </span>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-1">
                <span className="text-xs text-slate-400">{isPersian ? 'بار پردازش CPU' : 'CPU Utilization'}</span>
                <span className="text-2xl font-bold font-mono text-cyan-400">{sensorValues.cpu}%</span>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden mt-1">
                  <div
                    className="h-full bg-cyan-500 transition-all duration-300"
                    style={{ width: `${sensorValues.cpu}%` }}
                  />
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-1">
                <span className="text-xs text-slate-400">{isPersian ? 'مصرف حافظه RAM' : 'Memory Heap (Unified)'}</span>
                <span className="text-2xl font-bold font-mono text-purple-400">{sensorValues.ram}%</span>
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden mt-1">
                  <div
                    className="h-full bg-purple-500 transition-all duration-300"
                    style={{ width: `${sensorValues.ram}%` }}
                  />
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-1">
                <span className="text-xs text-slate-400">{isPersian ? 'دمای سیلیکون' : 'Core Thermal'}</span>
                <span className="text-2xl font-bold font-mono text-amber-400">{sensorValues.temp} °C</span>
                <span className="text-[10px] text-emerald-400">{isPersian ? 'وضعیت خنک‌کننده: مطلوب' : 'Thermal Throttle: None'}</span>
              </div>

              <div className="p-3 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-1">
                <span className="text-xs text-slate-400">{isPersian ? 'تأخیر شبکه / IPC' : 'IPC / Loopback Ping'}</span>
                <span className="text-2xl font-bold font-mono text-emerald-400">{sensorValues.networkLatency} ms</span>
                <span className="text-[10px] text-slate-500">Zero-copy shared memory</span>
              </div>
            </div>

            {/* Architecture Standards Compliance */}
            <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-col gap-2">
              <span className="text-xs font-semibold text-slate-300">
                {isPersian ? 'استانداردهای مهندسی ۴ پلتفرم فعال:' : 'Active Engineering Standards:'}
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  'Samsung Knox API 35',
                  'One UI Material You',
                  'Apple Metal 3 Shaders',
                  'Swift 6 Concurrency',
                  'WinUI 3 Mica Backdrop',
                  '.NET 9 Native AOT',
                  'GTK4 & Libadwaita 1.6',
                  'Wayland Zero-Copy',
                ].map((std) => (
                  <span
                    key={std}
                    className="px-2 py-1 rounded-md text-[10px] font-mono bg-slate-800 text-slate-300 border border-slate-700/60"
                  >
                    ✓ {std}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Status Footer */}
      <div className="px-3 py-1.5 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-400">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>{activePlatformData.vendor}</span>
        </div>
        <div className="font-mono text-slate-500">
          ALI Studio v4.5 · Multi-Platform OS Engine
        </div>
      </div>
    </div>
  );
};
