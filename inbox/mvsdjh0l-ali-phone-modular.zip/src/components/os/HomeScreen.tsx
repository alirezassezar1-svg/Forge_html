import React, { useState, useRef, useEffect } from 'react';
import {
  Phone,
  MessageCircle,
  Compass,
  Camera,
  Image,
  ShoppingBag,
  Package,
  FileText,
  Calculator,
  Music2,
  CloudSun,
  Clock,
  Settings,
  Sparkles,
  Search,
  Battery,
  TrendingUp,
  Receipt,
  Kanban,
  BarChart3,
  QrCode,
  Terminal,
  Globe,
  Layers,
  FileCode,
  Calendar,
  MapPin,
  Code2,
  Folder,
  Laptop,
  Smartphone,
  Play,
  X,
  FolderGit2,
  Github,
  Cpu,
  Zap,
  Activity,
  ChevronLeft,
  ChevronRight,
  Shield,
  Lock,
  Heart,
  Atom,
  Share2,
  Languages,
  ExternalLink,
  Wifi,
  Navigation,
  HardDrive,
  Eye,
  Sliders,
  Maximize2,
  Server,
  TrendingDown,
  Coins,
  Radio,
} from 'lucide-react';
import { CustomApp, ProductItem, AppLanguage } from '../../types/phone';
import { soundEffects } from '../../utils/soundEffects';
import { t, formatDigits } from '../../utils/i18n';
import { useWeatherSummary } from '../../utils/weather';
import { InstallPrompt } from './InstallPrompt';
import { InteractiveLiveWallpaper } from '../hardware/InteractiveLiveWallpaper';
import { useLiveMarketData } from '../../utils/liveMarketData';

interface HomeScreenProps {
  onOpenApp: (appId: string) => void;
  installedApps: CustomApp[];
  products: ProductItem[];
  wallpaperUrl: string;
  onOpenSiri: () => void;
  onOpenControlCenter: () => void;
  soundEnabled: boolean;
  currentTime: Date;
  language: AppLanguage;
}

export type IconStyleType = 'cyber_neon' | 'cyber_hexa' | 'ios_classic';

const ICON_MAP: Record<string, React.ElementType> = {
  Package,
  Receipt,
  TrendingUp,
  Kanban,
  BarChart3,
  QrCode,
  Terminal,
  FileText,
  Globe,
  Layers,
  ShoppingBag,
  FileCode,
  Folder,
  Laptop,
  Smartphone,
  Code2,
  FolderGit2,
  Github,
  Cpu,
};

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onOpenApp,
  installedApps,
  products,
  wallpaperUrl,
  onOpenSiri,
  onOpenControlCenter,
  soundEnabled,
  currentTime,
  language,
}) => {
  const isPersian = language === 'fa';
  const weather = useWeatherSummary();
  const totalStock = products.reduce((acc, p) => acc + p.stock, 0);

  // Horizontal Paging State (Page 0: Daily/Core, Page 1: Pro/Dev/Studio, Page 2: Google & Internet)
  const [currentPage, setCurrentPage] = useState(0);
  const totalPages = 3;

  // Touch and drag swipe tracking for horizontal scroll
  const touchStartXRef = useRef<number | null>(null);
  const touchEndXRef = useRef<number | null>(null);

  // Icon Aesthetic Style (Defaults to cyber_neon matching user's uploaded images IMG_0192 / IMG_0193)
  const [iconStyle, setIconStyle] = useState<IconStyleType>('cyber_neon');

  // 10x Turbo Processing Speed Mode
  const [is10xTurbo, setIs10xTurbo] = useState<boolean>(true);

  // Live Wallpaper state (Interactive Cyber Canvas)
  const [liveWallpaperEnabled, setLiveWallpaperEnabled] = useState<boolean>(true);

  // Live Market & DevOps server uptime data
  const { coins, servers, lastUpdated } = useLiveMarketData();

  // Folder modal state
  const [activeFolderModal, setActiveFolderModal] = useState<string | null>(null);

  // Google Quick Search state in Page 3
  const [googleQuickQuery, setGoogleQuickQuery] = useState('');

  // Apps Configuration with alternating Cyber Neon palette (Cyan / Pink)
  const ALL_BUILTIN_APPS = [
    // Page 1 apps
    { id: 'phone', nameKey: 'phone', icon: Phone, color: 'bg-emerald-500', neonType: 'cyan', page: 0 },
    { id: 'messages', nameKey: 'messages', icon: MessageCircle, color: 'bg-emerald-500', neonType: 'pink', page: 0 },
    { id: 'safari', nameKey: 'safari', icon: Compass, color: 'bg-gradient-to-tr from-sky-400 to-blue-600', neonType: 'cyan', page: 0 },
    { id: 'camera', nameKey: 'camera', icon: Camera, color: 'bg-neutral-800', neonType: 'pink', page: 0 },
    { id: 'photos', nameKey: 'photos', icon: Image, color: 'bg-gradient-to-tr from-amber-400 via-rose-500 to-blue-500', neonType: 'cyan', page: 0 },
    { id: 'files', nameKey: 'files', icon: Folder, color: 'bg-gradient-to-tr from-sky-400 to-blue-600', badgeText: 'LOCAL', neonType: 'pink', page: 0 },
    { id: 'appstore', nameKey: 'appstore', icon: ShoppingBag, color: 'bg-blue-600', neonType: 'cyan', page: 0 },
    { id: 'googleplay', nameKey: 'googleplay', icon: FileCode, color: 'bg-gradient-to-tr from-emerald-600 to-teal-700', badgeText: 'APK', neonType: 'pink', page: 0 },
    { id: 'cloud_android', nameKey: 'cloud_android', icon: Smartphone, color: 'bg-gradient-to-tr from-cyan-600 to-blue-700', badgeText: 'CLOUD', neonType: 'cyan', page: 0 },
    { id: 'google_hub', nameKey: 'google_hub', icon: Globe, color: 'bg-gradient-to-tr from-blue-600 via-emerald-600 to-amber-500', badgeText: 'GOOGLE', isSpecial: true, neonType: 'pink', page: 0 },
    { id: 'products', nameKey: 'products', icon: Package, color: 'bg-gradient-to-tr from-amber-500 to-orange-600', isSpecial: true, neonType: 'cyan', page: 0 },
    { id: 'calendar', nameKey: 'calendar', icon: Calendar, color: 'bg-gradient-to-tr from-rose-500 to-red-600', badgeText: 'TODAY', neonType: 'pink', page: 0 },

    // Page 2 Pro & Dev Apps
    { id: 'engineering_studio', nameKey: 'engineering_studio', icon: Cpu, color: 'bg-gradient-to-tr from-cyan-600 via-indigo-600 to-purple-800', badgeText: '4-OS', isSpecial: true, neonType: 'cyan', page: 1 },
    { id: 'my_repos', nameKey: 'my_repos', icon: FolderGit2, color: 'bg-gradient-to-tr from-slate-900 via-indigo-950 to-neutral-900', badgeText: '230', isSpecial: true, neonType: 'pink', page: 1 },
    { id: 'terminal', nameKey: 'terminal', icon: Code2, color: 'bg-gradient-to-tr from-purple-600 via-indigo-700 to-slate-900', badgeText: 'PY/JS', neonType: 'cyan', page: 1 },
    { id: 'maps', nameKey: 'maps', icon: MapPin, color: 'bg-gradient-to-tr from-emerald-500 via-teal-500 to-blue-600', badgeText: 'GPS', neonType: 'pink', page: 1 },
    { id: 'notes', nameKey: 'notes', icon: FileText, color: 'bg-amber-400', neonType: 'cyan', page: 1 },
    { id: 'calculator', nameKey: 'calculator', icon: Calculator, color: 'bg-neutral-900', neonType: 'pink', page: 1 },
    { id: 'music', nameKey: 'music', icon: Music2, color: 'bg-rose-500', neonType: 'cyan', page: 1 },
    { id: 'weather', nameKey: 'weather', icon: CloudSun, color: 'bg-sky-500', neonType: 'pink', page: 1 },
    { id: 'clock', nameKey: 'clock', icon: Clock, color: 'bg-black', neonType: 'cyan', page: 1 },
    { id: 'settings', nameKey: 'settings', icon: Settings, color: 'bg-neutral-600', neonType: 'pink', page: 1 },
  ];

  // Dev Projects Folder
  const DEV_PROJECTS_FOLDER = {
    id: 'folder_dev_projects',
    title: language === 'fa' ? 'پروژه‌ها و کد' : 'Dev Projects',
    apps: [
      { id: 'project_react', name: 'React Storefront', icon: Layers, color: 'bg-cyan-500', badge: 'REACT' },
      { id: 'project_laravel', name: 'Laravel API', icon: Globe, color: 'bg-rose-500', badge: 'LARAVEL' },
      { id: 'project_python', name: 'Python FastAPI', icon: Terminal, color: 'bg-emerald-500', badge: 'PY 3' },
      { id: 'project_node', name: 'Node.js API', icon: Code2, color: 'bg-green-600', badge: 'NODE' },
      { id: 'project_windows', name: 'Windows Tools', icon: Laptop, color: 'bg-blue-700', badge: 'WIN .EXE' },
      { id: 'project_samsung', name: 'Samsung APKs', icon: Smartphone, color: 'bg-indigo-600', badge: 'SAMSUNG' },
    ],
  };

  // Custom user apps
  const extraCustomApps = installedApps.filter(
    (app) => !ALL_BUILTIN_APPS.some((b) => b.id === app.id)
  );

  const handleAppClick = (appId: string) => {
    soundEffects.click(soundEnabled);
    setActiveFolderModal(null);
    onOpenApp(appId);
  };

  // Horizontal Swipe Handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartXRef.current = e.touches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndXRef.current = e.touches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (!touchStartXRef.current || !touchEndXRef.current) return;
    const diff = touchStartXRef.current - touchEndXRef.current;
    const threshold = 40;

    if (diff > threshold) {
      // Swiped Left -> Next page
      if (currentPage < totalPages - 1) {
        if (soundEnabled) soundEffects.click();
        setCurrentPage((p) => p + 1);
      }
    } else if (diff < -threshold) {
      // Swiped Right -> Previous page
      if (currentPage > 0) {
        if (soundEnabled) soundEffects.click();
        setCurrentPage((p) => p - 1);
      }
    }
    touchStartXRef.current = null;
    touchEndXRef.current = null;
  };

  // Helper for rendering an app icon based on selected style
  const renderIconBox = (app: {
    id: string;
    icon: React.ElementType;
    color: string;
    neonType?: string;
    badgeText?: string;
    isSpecial?: boolean;
  }) => {
    const IconComp = app.icon;
    const isPink = app.neonType === 'pink';

    if (iconStyle === 'cyber_neon') {
      // Exact match to user's uploaded images IMG_0192_de559c05.jpeg and IMG_0193_ec7ba323.jpeg
      const neonBorder = isPink ? 'border-[#FF2A85]' : 'border-[#00E5FF]';
      const neonShadow = isPink
        ? 'shadow-[0_0_15px_rgba(255,42,133,0.65),inset_0_0_8px_rgba(255,42,133,0.3)]'
        : 'shadow-[0_0_15px_rgba(0,229,255,0.65),inset_0_0_8px_rgba(0,229,255,0.3)]';
      const neonText = isPink ? 'text-[#FF2A85]' : 'text-[#00E5FF]';
      const innerRingBorder = isPink ? 'border-[#FF2A85]/40' : 'border-[#00E5FF]/40';

      return (
        <div
          className={`w-[58px] h-[58px] rounded-full bg-black/85 backdrop-blur-md border-2 ${neonBorder} ${neonShadow} flex items-center justify-center relative group-hover:scale-105 active:scale-90 transition-all ${
            is10xTurbo ? 'duration-75' : 'duration-200'
          }`}
        >
          {/* Subtle concentric inner neon ring */}
          <div className={`absolute inset-1 rounded-full border border-dashed ${innerRingBorder} pointer-events-none`} />

          {/* Glyph */}
          <IconComp className={`w-6 h-6 ${neonText} drop-shadow-[0_0_6px_currentColor]`} />

          {app.badgeText && (
            <span
              className={`absolute -top-1 -left-1 px-1.5 py-0.2 rounded-full text-[7px] font-black tracking-tight border ${
                isPink
                  ? 'bg-[#FF2A85] text-black border-white/80 shadow-[0_0_6px_#FF2A85]'
                  : 'bg-[#00E5FF] text-black border-white/80 shadow-[0_0_6px_#00E5FF]'
              }`}
            >
              {app.badgeText}
            </span>
          )}
        </div>
      );
    }

    if (iconStyle === 'cyber_hexa') {
      // Match to IMG_0191_c3946734.jpeg hexagonal hologram icons
      const hexaColor = isPink ? 'text-[#FF2A85] border-[#FF2A85]/70' : 'text-[#00E5FF] border-[#00E5FF]/70';
      return (
        <div
          className={`w-[58px] h-[58px] rounded-2xl rotate-45 bg-slate-950/90 border-2 ${hexaColor} shadow-[0_0_14px_rgba(0,229,255,0.4)] flex items-center justify-center relative group-hover:scale-105 active:scale-90 transition-all ${
            is10xTurbo ? 'duration-75' : 'duration-200'
          }`}
        >
          <div className="-rotate-45 flex items-center justify-center">
            <IconComp className={`w-6 h-6 ${isPink ? 'text-[#FF2A85]' : 'text-[#00E5FF]'} drop-shadow-[0_0_6px_currentColor]`} />
          </div>
          {app.badgeText && (
            <span className="-rotate-45 absolute -top-1.5 -left-1.5 px-1 py-0.2 rounded bg-cyan-400 text-black text-[7px] font-black border border-black shadow">
              {app.badgeText}
            </span>
          )}
        </div>
      );
    }

    // Classic Apple squircle
    return (
      <div
        className={`w-[58px] h-[58px] rounded-[22%] ${app.color} flex items-center justify-center text-white shadow-[0_4px_14px_rgba(0,0,0,0.35)] relative group-hover:scale-105 active:scale-90 transition-all ${
          is10xTurbo ? 'duration-75' : 'duration-200'
        } ${app.isSpecial ? 'ring-2 ring-amber-400/80 shadow-amber-500/25' : ''}`}
      >
        <IconComp className="w-7 h-7 text-white" />
        {app.badgeText && (
          <span className="absolute -top-1.5 -left-1.5 px-1.5 py-0.2 rounded-full bg-emerald-500 text-black text-[8px] font-black tracking-tight border border-black shadow">
            {app.badgeText}
          </span>
        )}
      </div>
    );
  };

  return (
    <div
      className="h-full flex flex-col justify-between p-3.5 pt-12 pb-2 select-none relative overflow-hidden text-white font-sans"
      style={{
        backgroundImage: wallpaperUrl ? `url(${wallpaperUrl})` : undefined,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Background Dim & OLED Darkening */}
      <div className="absolute inset-0 bg-black/45 backdrop-blur-[0.5px] pointer-events-none" />

      {/* Interactive Cyberpunk Live Particle Wallpaper (60fps Canvas) */}
      <InteractiveLiveWallpaper
        enabled={liveWallpaperEnabled}
        theme={iconStyle === 'cyber_neon' ? 'cyber_neon' : 'deep_blue'}
      />

      {/* Cyberpunk Sci-Fi Circuit Overlay (Matching IMG_0192_de559c05.jpeg and IMG_0193_ec7ba323.jpeg) */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none opacity-25" xmlns="http://www.w3.org/2000/svg">
        <path d="M 20 40 L 60 40 L 80 60 L 140 60" stroke="#00E5FF" strokeWidth="1" fill="none" />
        <circle cx="140" cy="60" r="2.5" fill="#00E5FF" />
        <path d="M 340 40 L 300 40 L 280 60 L 220 60" stroke="#FF2A85" strokeWidth="1" fill="none" />
        <circle cx="220" cy="60" r="2.5" fill="#FF2A85" />
        <path d="M 20 540 L 60 540 L 80 520 L 160 520" stroke="#00E5FF" strokeWidth="1" fill="none" />
        <circle cx="160" cy="520" r="2.5" fill="#00E5FF" />
        <path d="M 340 540 L 300 540 L 280 520 L 200 520" stroke="#FF2A85" strokeWidth="1" fill="none" />
        <circle cx="200" cy="520" r="2.5" fill="#FF2A85" />
      </svg>

      {/* Top Bar: Controls, Turbo, Live FX & Theme Switcher */}
      <div className="relative z-10 flex items-center justify-between px-1 mb-2 gap-1 flex-wrap sm:flex-nowrap">
        <div className="flex items-center gap-1.5">
          {/* 10x Turbo Speed Indicator & Toggle */}
          <button
            onClick={() => {
              if (soundEnabled) soundEffects.click();
              setIs10xTurbo(!is10xTurbo);
            }}
            className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-mono font-bold transition-all border ${
              is10xTurbo
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400/50 shadow-[0_0_10px_rgba(0,229,255,0.4)]'
                : 'bg-black/50 text-slate-400 border-white/10'
            }`}
            title="سرعت پردازش ۱۰ برابری"
          >
            <Zap className={`w-3 h-3 ${is10xTurbo ? 'text-amber-400 fill-amber-400 animate-pulse' : 'text-slate-400'}`} />
            <span>{is10xTurbo ? '10x' : '1x'}</span>
          </button>

          {/* Live Wallpaper Interactive Toggle */}
          <button
            onClick={() => {
              if (soundEnabled) soundEffects.click();
              setLiveWallpaperEnabled(!liveWallpaperEnabled);
            }}
            className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-mono font-bold transition-all border ${
              liveWallpaperEnabled
                ? 'bg-pink-500/20 text-pink-300 border-pink-400/50 shadow-[0_0_10px_rgba(255,42,133,0.4)]'
                : 'bg-black/50 text-slate-400 border-white/10'
            }`}
            title={isPersian ? 'والپیپر زنده متحرک تعاملی' : 'Interactive Neon Live Wallpaper'}
          >
            <Sparkles className={`w-3 h-3 ${liveWallpaperEnabled ? 'text-pink-400 animate-spin' : 'text-slate-400'}`} style={{ animationDuration: '4s' }} />
            <span>{liveWallpaperEnabled ? (isPersian ? 'زنده' : 'Live') : (isPersian ? 'ثابت' : 'Off')}</span>
          </button>
        </div>

        {/* PWA iPhone Install Button */}
        <InstallPrompt
          variant="button"
          iosManual={true}
          buttonLabel={isPersian ? 'نصب PWA' : 'Install PWA'}
        />

        {/* Icon Theme Switcher (Cyber Neon vs Hexa vs Classic) */}
        <div className="flex items-center bg-black/60 backdrop-blur-md rounded-full p-0.5 border border-white/15 text-[9px] font-medium">
          <button
            onClick={() => {
              if (soundEnabled) soundEffects.click();
              setIconStyle('cyber_neon');
            }}
            className={`px-2 py-0.5 rounded-full transition-all ${
              iconStyle === 'cyber_neon'
                ? 'bg-gradient-to-r from-cyan-500 to-pink-500 text-white font-bold shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {isPersian ? 'نئون' : 'Neon'}
          </button>
          <button
            onClick={() => {
              if (soundEnabled) soundEffects.click();
              setIconStyle('cyber_hexa');
            }}
            className={`px-2 py-0.5 rounded-full transition-all ${
              iconStyle === 'cyber_hexa'
                ? 'bg-cyan-600 text-white font-bold shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {isPersian ? 'هگزا' : 'Hexa'}
          </button>
          <button
            onClick={() => {
              if (soundEnabled) soundEffects.click();
              setIconStyle('ios_classic');
            }}
            className={`px-2 py-0.5 rounded-full transition-all ${
              iconStyle === 'ios_classic'
                ? 'bg-blue-600 text-white font-bold shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {isPersian ? 'کلاسیک' : 'iOS'}
          </button>
        </div>
      </div>

      {/* ===================== HORIZONTAL SWIPEABLE PAGES CONTAINER ===================== */}
      <div className="relative z-10 flex-1 overflow-hidden flex flex-col justify-center">
        <div
          className={`flex w-full h-full transition-transform ease-out ${
            is10xTurbo ? 'duration-100' : 'duration-300'
          }`}
          style={{
            transform: `translateX(-${currentPage * 100}%)`,
          }}
        >
          {/* ==================== PAGE 0: DAILY / CORE APPS ==================== */}
          <div className="w-full shrink-0 h-full flex flex-col justify-between px-1">
            {/* Top Widgets Cluster */}
            <div className="space-y-2.5 mb-2">
              <div className="grid grid-cols-2 gap-2.5">
                {/* Weather Widget */}
                <div
                  onClick={() => handleAppClick('weather')}
                  className="p-3 rounded-2xl bg-neutral-900/65 backdrop-blur-xl border border-cyan-500/25 cursor-pointer hover:bg-neutral-900/80 active:scale-98 transition-all shadow-lg flex flex-col justify-between h-24 relative overflow-hidden"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-neutral-200">
                      {weather?.city ?? (isPersian ? 'تهران' : 'Tehran')}
                    </span>
                    <CloudSun className="w-5 h-5 text-amber-300" />
                  </div>
                  <div>
                    <p className="text-xl font-light font-mono text-white">
                      {weather ? `${formatDigits(Math.round(weather.temp), language === 'fa' ? 'persian' : 'latin')}°` : '24°'}
                    </p>
                    <p className="text-[10px] text-cyan-300 mt-0.5">
                      {weather?.text ?? (isPersian ? 'آفتابی و مطلوب' : 'Clear')}
                    </p>
                  </div>
                </div>

                {/* Products & Inventory Widget */}
                <div
                  onClick={() => handleAppClick('products')}
                  className="p-3 rounded-2xl bg-neutral-900/65 backdrop-blur-xl border border-pink-500/25 cursor-pointer hover:bg-neutral-900/80 active:scale-98 transition-all shadow-lg flex flex-col justify-between h-24"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-semibold text-neutral-200">
                      {t('products', language)}
                    </span>
                    <Package className="w-5 h-5 text-pink-400" />
                  </div>
                  <div>
                    <p className="text-lg font-bold font-mono text-pink-400">
                      {formatDigits(products.length, language === 'fa' ? 'persian' : 'latin')}{' '}
                      {isPersian ? 'کالا' : 'Items'}
                    </p>
                    <p className="text-[10px] text-emerald-300 mt-0.5">
                      {formatDigits(totalStock, language === 'fa' ? 'persian' : 'latin')}{' '}
                      {isPersian ? 'موجودی انبار' : 'In Stock'}
                    </p>
                  </div>
                </div>
              </div>

              {/* ALI Intelligence Smart Bar Widget */}
              <div
                onClick={onOpenSiri}
                className="p-2.5 px-3.5 rounded-2xl bg-neutral-900/70 backdrop-blur-xl border border-white/20 flex items-center justify-between cursor-pointer hover:bg-neutral-900/90 active:scale-98 transition-all shadow-md"
              >
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-cyan-400 via-purple-500 to-pink-500 flex items-center justify-center animate-spin" style={{ animationDuration: '6s' }}>
                    <Sparkles className="w-3 h-3 text-white" />
                  </div>
                  <span className="text-xs font-semibold text-neutral-200">
                    {t('di_assistant', language)}
                  </span>
                </div>
                <span className="text-[10px] text-cyan-400 font-mono font-medium">
                  {isPersian ? 'فرمان صوتی و هوش مصنوعی ↵' : 'Ask AI ↵'}
                </span>
              </div>
            </div>

            {/* Page 0 Grid of Core Apps (4 Columns) */}
            <div className="grid grid-cols-4 gap-y-3 gap-x-2 text-center my-auto">
              {ALL_BUILTIN_APPS.filter((a) => a.page === 0).map((app) => {
                const appLabel = t(app.nameKey, language);
                return (
                  <div
                    key={app.id}
                    onClick={() => handleAppClick(app.id)}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    {renderIconBox(app)}
                    <span className="text-[10.5px] text-neutral-200 font-medium tracking-tight truncate max-w-[64px] drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]">
                      {appLabel}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ==================== PAGE 1: PRO / ENGINEERING & DEV TOOLS ==================== */}
          <div className="w-full shrink-0 h-full flex flex-col justify-between px-1 overflow-y-auto no-scrollbar">
            {/* Top Cluster: Hardware A18 Pro + Live Market Ticker */}
            <div className="space-y-2 mb-2">
              {/* 10x Turbo Engine Hardware Gauge Banner */}
              <div className="p-2.5 rounded-2xl bg-gradient-to-r from-cyan-950/60 via-slate-900/90 to-purple-950/60 border border-cyan-500/40 backdrop-blur-xl shadow-xl flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-xl bg-gradient-to-tr from-cyan-500 to-purple-600 flex items-center justify-center shadow-lg shadow-cyan-500/30">
                    <Cpu className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-[11px] font-bold text-white">Apple A18 Pro 10x Overclock</span>
                      <span className="px-1 py-0.2 rounded text-[7px] bg-emerald-500/20 text-emerald-400 font-mono">120Hz</span>
                    </div>
                    <p className="text-[9px] text-slate-400">
                      {isPersian ? 'موتور پردازش سخت‌افزاری فعال · تأخیر صفر' : 'Zero latency hardware acceleration active'}
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-mono font-bold text-cyan-400">10X PRO</span>
              </div>

              {/* Live Financial & Crypto Market Ticker Widget */}
              <div
                onClick={() => handleAppClick('products')}
                className="p-2.5 rounded-2xl bg-slate-950/80 backdrop-blur-xl border border-amber-500/30 shadow-lg cursor-pointer hover:border-amber-400/60 active:scale-98 transition-all"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5">
                    <Coins className="w-3.5 h-3.5 text-amber-400" />
                    <span className="text-[10px] font-bold text-white tracking-wide">
                      {isPersian ? 'نبض زنده بازارهای مالی و رمزارز' : 'Live Crypto & Market Ticker'}
                    </span>
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  </div>
                  <span className="text-[8px] font-mono text-slate-400">
                    {lastUpdated.toLocaleTimeString(language === 'fa' ? 'fa-IR' : 'en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                </div>

                {/* Coins Grid */}
                <div className="grid grid-cols-4 gap-1">
                  {coins.map((coin) => {
                    const isPositive = coin.change24h >= 0;
                    return (
                      <div
                        key={coin.symbol}
                        className="bg-black/50 rounded-xl p-1.5 border border-white/5 flex flex-col items-center justify-between"
                      >
                        <div className="flex items-center justify-between w-full">
                          <span className="text-[9px] font-black" style={{ color: coin.iconColor }}>
                            {coin.symbol}
                          </span>
                          <span
                            className={`text-[7px] font-mono font-bold px-1 rounded ${
                              isPositive ? 'text-emerald-400 bg-emerald-950/60' : 'text-rose-400 bg-rose-950/60'
                            }`}
                          >
                            {isPositive ? '+' : ''}{coin.change24h.toFixed(1)}%
                          </span>
                        </div>
                        <p className="text-[10px] font-mono font-bold text-white mt-1">
                          ${coin.priceUsd >= 1000 ? coin.priceUsd.toLocaleString() : coin.priceUsd.toFixed(2)}
                        </p>
                        <p className="text-[7px] text-slate-400 truncate max-w-full">
                          {isPersian ? `${(coin.priceToman / 1000000).toFixed(1)} م ت` : `${(coin.priceToman / 1000).toFixed(0)}k T`}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* DevOps Server Uptime & Latency Monitor Widget */}
              <div
                onClick={() => handleAppClick('engineering_studio')}
                className="p-2 rounded-2xl bg-neutral-900/70 backdrop-blur-xl border border-cyan-500/25 flex items-center justify-between cursor-pointer hover:border-cyan-400/50 active:scale-98 transition-all"
              >
                <div className="flex items-center gap-1.5">
                  <Server className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="text-[9.5px] font-bold text-slate-200">
                    {isPersian ? 'وضعیت سرورها:' : 'DevOps Ping:'}
                  </span>
                  <div className="flex items-center gap-2 font-mono text-[8px] text-cyan-300">
                    <span>G-Cloud: <b className="text-emerald-400">{servers[0]?.pingMs ?? 24}ms</b></span>
                    <span>Cloudflare: <b className="text-emerald-400">{servers[1]?.pingMs ?? 14}ms</b></span>
                    <span>Mesh: <b className="text-emerald-400">{servers[3]?.pingMs ?? 4}ms</b></span>
                  </div>
                </div>
                <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono font-bold">
                  99.99% UP
                </span>
              </div>
            </div>

            {/* Page 1 Apps Grid (4 Columns) */}
            <div className="grid grid-cols-4 gap-y-3 gap-x-2 text-center my-auto">
              {ALL_BUILTIN_APPS.filter((a) => a.page === 1).map((app) => {
                const appLabel = t(app.nameKey, language);
                return (
                  <div
                    key={app.id}
                    onClick={() => handleAppClick(app.id)}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    {renderIconBox(app)}
                    <span className="text-[10.5px] text-neutral-200 font-medium tracking-tight truncate max-w-[64px] drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]">
                      {appLabel}
                    </span>
                  </div>
                );
              })}

              {/* Dev Projects Folder */}
              <div
                onClick={() => {
                  soundEffects.click(soundEnabled);
                  setActiveFolderModal('dev_projects');
                }}
                className="flex flex-col items-center gap-1 cursor-pointer group"
              >
                <div className="w-[58px] h-[58px] rounded-full bg-slate-950/85 backdrop-blur-md border-2 border-indigo-400 shadow-[0_0_15px_rgba(99,102,241,0.6)] p-2 grid grid-cols-3 gap-1 items-center justify-items-center group-hover:scale-105 active:scale-90 transition-all">
                  {DEV_PROJECTS_FOLDER.apps.slice(0, 6).map((fApp) => {
                    const FIcon = fApp.icon;
                    return (
                      <div key={fApp.id} className="w-3 h-3 rounded-full bg-indigo-500/40 flex items-center justify-center">
                        <FIcon className="w-2 h-2 text-cyan-300" />
                      </div>
                    );
                  })}
                </div>
                <span className="text-[10.5px] text-neutral-200 font-medium tracking-tight truncate max-w-[64px]">
                  {DEV_PROJECTS_FOLDER.title}
                </span>
              </div>

              {/* Custom Installed Apps */}
              {extraCustomApps.map((app) => {
                const IconComponent = ICON_MAP[app.iconName] || Globe;
                const appTitle = isPersian ? app.nameFa || app.name : app.name;
                return (
                  <div
                    key={app.id}
                    onClick={() => handleAppClick(app.id)}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div className="w-[58px] h-[58px] rounded-full bg-slate-950/85 border-2 border-cyan-400 shadow-[0_0_12px_rgba(0,229,255,0.5)] flex items-center justify-center group-hover:scale-105 active:scale-90 transition-all">
                      <IconComponent className="w-6 h-6 text-cyan-400" />
                    </div>
                    <span className="text-[10.5px] text-neutral-200 font-medium truncate max-w-[64px]">
                      {appTitle}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ==================== PAGE 2: GOOGLE ONLINE & INTERNET ECOSYSTEM ==================== */}
          <div className="w-full shrink-0 h-full flex flex-col justify-between px-1">
            {/* Google Services Search Banner */}
            <div className="p-3 rounded-2xl bg-slate-900/80 backdrop-blur-xl border border-blue-500/30 flex flex-col gap-2 mb-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-white flex items-center justify-center text-xs font-bold shadow">
                    <span className="text-[#4285F4]">G</span>
                  </div>
                  <span className="text-xs font-bold text-white">
                    {isPersian ? 'جستجوی مستقیم گوگل' : 'Direct Google Search'}
                  </span>
                </div>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono">
                  Online API
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <input
                  type="text"
                  value={googleQuickQuery}
                  onChange={(e) => setGoogleQuickQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') handleAppClick('google_hub');
                  }}
                  placeholder={isPersian ? 'جستجو در گوگل، نقشه‌ها، ترنسلیت...' : 'Search Google, Maps, Translate...'}
                  className="flex-1 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
                />
                <button
                  onClick={() => handleAppClick('google_hub')}
                  className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-semibold text-white shadow"
                >
                  {isPersian ? 'اجرا' : 'Go'}
                </button>
              </div>
            </div>

            {/* Google Cloud Services Quick Launchers Grid */}
            <div className="grid grid-cols-4 gap-y-3 gap-x-2 text-center my-auto">
              {[
                { id: 'google_hub', title: isPersian ? 'هاب گوگل' : 'Google Hub', icon: Globe, neonType: 'cyan' },
                { id: 'maps', title: isPersian ? 'گوگل مپ' : 'Google Maps', icon: MapPin, neonType: 'pink' },
                { id: 'safari', title: isPersian ? 'وب اینترنت' : 'Web Browser', icon: Compass, neonType: 'cyan' },
                { id: 'googleplay', title: isPersian ? 'پلی‌استور' : 'Play Store', icon: FileCode, neonType: 'pink' },
                { id: 'cloud_android', title: isPersian ? 'اندروید ابری' : 'Cloud Android', icon: Smartphone, neonType: 'cyan' },
                { id: 'engineering_studio', title: isPersian ? 'استودیو ۴-OS' : 'DevStudio', icon: Cpu, neonType: 'pink' },
                { id: 'terminal', title: isPersian ? 'ترمینال کد' : 'Terminal', icon: Terminal, neonType: 'cyan' },
                { id: 'appstore', title: isPersian ? 'اپ استور' : 'App Store', icon: ShoppingBag, neonType: 'pink' },
              ].map((item) => (
                <div
                  key={item.id}
                  onClick={() => handleAppClick(item.id)}
                  className="flex flex-col items-center gap-1 cursor-pointer group"
                >
                  {renderIconBox({
                    id: item.id,
                    icon: item.icon,
                    color: 'bg-blue-600',
                    neonType: item.neonType,
                  })}
                  <span className="text-[10.5px] text-neutral-200 font-medium truncate max-w-[64px]">
                    {item.title}
                  </span>
                </div>
              ))}
            </div>

            {/* Internet Ping & Latency Status Card */}
            <div
              onClick={() => handleAppClick('google_hub')}
              className="p-2.5 px-3 rounded-2xl bg-neutral-900/60 backdrop-blur-xl border border-emerald-500/30 flex items-center justify-between cursor-pointer hover:bg-neutral-900/80 transition-all text-xs"
            >
              <div className="flex items-center gap-2">
                <Wifi className="w-4 h-4 text-emerald-400" />
                <span className="font-semibold text-white">Google Cloud Gateway: {servers[0]?.pingMs ?? 24}ms</span>
              </div>
              <span className="text-[10px] text-emerald-400 font-mono font-bold">100% UNRESTRICTED</span>
            </div>
          </div>
        </div>
      </div>

      {/* ===================== HORIZONTAL PAGINATION DOTS (iOS STYLE) ===================== */}
      <div className="relative z-10 flex items-center justify-center gap-1.5 py-1">
        {Array.from({ length: totalPages }).map((_, i) => (
          <button
            key={i}
            onClick={() => {
              if (soundEnabled) soundEffects.click();
              setCurrentPage(i);
            }}
            className={`transition-all rounded-full ${
              currentPage === i
                ? 'w-5 h-1.5 bg-gradient-to-r from-cyan-400 to-pink-500 shadow-[0_0_8px_rgba(0,229,255,0.8)]'
                : 'w-1.5 h-1.5 bg-white/35 hover:bg-white/60'
            }`}
            title={`Page ${i + 1}`}
          />
        ))}
      </div>

      {/* Spotlight Search Pill */}
      <div className="relative z-10 flex justify-center pb-1">
        <button
          onClick={onOpenSiri}
          className="px-3.5 py-1 rounded-full bg-black/50 backdrop-blur-md border border-white/15 text-neutral-300 text-[11px] flex items-center gap-1.5 hover:bg-neutral-900/80 active:scale-95 transition-all shadow-sm"
        >
          <Search className="w-3 h-3 text-cyan-400" />
          <span>{t('search', language)}</span>
        </button>
      </div>

      {/* iOS Dock (Bottom 4 pinned apps in blurred capsule) */}
      <div className="relative z-10 p-2 rounded-[30px] bg-black/40 backdrop-blur-3xl border border-white/20 shadow-[0_10px_30px_rgba(0,0,0,0.5)] flex items-center justify-around mx-1">
        {[
          { id: 'phone', icon: Phone, color: 'bg-emerald-500', neonType: 'cyan', labelKey: 'phone' },
          { id: 'safari', icon: Compass, color: 'bg-gradient-to-tr from-sky-400 to-blue-600', neonType: 'pink', labelKey: 'safari' },
          { id: 'messages', icon: MessageCircle, color: 'bg-emerald-500', neonType: 'cyan', labelKey: 'messages' },
          { id: 'camera', icon: Camera, color: 'bg-neutral-800', neonType: 'pink', labelKey: 'camera' },
        ].map((dockApp) => (
          <button
            key={dockApp.id}
            onClick={() => handleAppClick(dockApp.id)}
            className="flex items-center justify-center active:scale-90 transition-transform"
            title={t(dockApp.labelKey, language)}
          >
            {renderIconBox(dockApp)}
          </button>
        ))}
      </div>

      {/* Expanded iOS Folder Modal */}
      {activeFolderModal === 'dev_projects' && (
        <div className="absolute inset-0 bg-black/70 backdrop-blur-2xl z-50 flex flex-col items-center justify-center p-6 animate-in fade-in zoom-in-95 duration-150">
          <div className="w-full max-w-xs p-6 rounded-[36px] bg-neutral-900/85 border border-indigo-500/30 shadow-2xl backdrop-blur-xl">
            <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-5">
              <h3 className="text-lg font-bold text-white">{DEV_PROJECTS_FOLDER.title}</h3>
              <button
                onClick={() => setActiveFolderModal(null)}
                className="p-1 rounded-full bg-neutral-800 text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-y-4 gap-x-3 text-center">
              {DEV_PROJECTS_FOLDER.apps.map((app) => {
                const IconComp = app.icon;
                return (
                  <div
                    key={app.id}
                    onClick={() => handleAppClick(app.id)}
                    className="flex flex-col items-center gap-1 cursor-pointer group"
                  >
                    <div className="w-14 h-14 rounded-full bg-slate-950 border-2 border-indigo-400 shadow-[0_0_12px_rgba(99,102,241,0.5)] flex items-center justify-center text-white group-hover:scale-105 active:scale-90 transition-all relative">
                      <IconComp className="w-6 h-6 text-cyan-300" />
                      <span className="absolute -top-1 -left-1 px-1 rounded-full bg-indigo-600 text-[7px] font-bold text-white border border-black">
                        {app.badge}
                      </span>
                    </div>
                    <span className="text-[10px] text-neutral-200 font-medium truncate max-w-[60px]">
                      {app.name}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
