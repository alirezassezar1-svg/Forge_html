import React, { useState, useEffect } from 'react';
import {
  Download,
  Share,
  PlusSquare,
  X,
  Smartphone,
  Check,
  Copy,
  QrCode,
  Sparkles,
  Wifi,
  ExternalLink,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { soundEffects } from '../../utils/soundEffects';

interface Props {
  canInstall?: boolean;
  installed?: boolean;
  iosManual?: boolean;
  onInstall?: () => void;
  variant?: 'button' | 'banner' | 'card';
  buttonLabel?: string;
}

/** Install entry point: native prompt where supported, step-by-step interactive guide on iOS Safari with QR Code and copy link. */
export const InstallPrompt: React.FC<Props> = ({
  canInstall = false,
  installed = false,
  iosManual = true,
  onInstall,
  variant = 'button',
  buttonLabel,
}) => {
  const [guideOpen, setGuideOpen] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [dismissed, setDismissed] = useState(
    () => localStorage.getItem('aliphone_install_dismissed') === '1'
  );

  // Current page URL for QR code and iPhone sharing
  const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://ais-pre-mwysbr5yxp43ijyevhruvy-17774190120.europe-west3.run.app';
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(currentUrl)}`;

  const handleCopyLink = () => {
    soundEffects.click(true);
    if (typeof navigator !== 'undefined') {
      navigator.clipboard.writeText(currentUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleAction = () => {
    soundEffects.click(true);
    if (canInstall && onInstall) {
      onInstall();
    } else {
      setGuideOpen(true);
    }
  };

  const handleDismiss = () => {
    soundEffects.click(true);
    localStorage.setItem('aliphone_install_dismissed', '1');
    setDismissed(true);
  };

  return (
    <>
      {/* 1. BUTTON VARIANT */}
      {variant === 'button' && (
        <button
          onClick={handleAction}
          className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white border border-blue-400/40 text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-blue-600/20 active:scale-95 transition-all"
          title="نصب نسخه PWA روی آیفون"
        >
          <Smartphone className="w-3.5 h-3.5 text-cyan-300" />
          <span>{buttonLabel || 'نصب روی آیفون (PWA)'}</span>
        </button>
      )}

      {/* 2. CARD VARIANT (FOR SETTINGS OR HOMESCREEN) */}
      {variant === 'card' && (
        <div
          onClick={() => {
            soundEffects.click(true);
            setGuideOpen(true);
          }}
          className="p-3.5 rounded-2xl bg-gradient-to-r from-blue-950/60 via-slate-900 to-indigo-950/50 border border-blue-500/30 hover:border-blue-400/60 cursor-pointer shadow-lg flex items-center justify-between group transition-all"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/30">
              <Smartphone className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-xs text-white">نصب PWA روی آیفون و آیپد</span>
                <span className="px-1.5 py-0.2 rounded text-[8px] bg-blue-500/20 text-cyan-300 font-mono border border-blue-400/30">
                  STANDALONE
                </span>
              </div>
              <p className="text-[10px] text-slate-400 mt-0.5">
                اجرای تمام‌صفحه بدون مرورگر، آفلاین و سریع روی صفحه اصلی آیفون
              </p>
            </div>
          </div>
          <div className="px-3 py-1 rounded-lg bg-blue-600 group-hover:bg-blue-500 text-white font-bold text-xs shadow transition-all">
            راهنمای نصب
          </div>
        </div>
      )}

      {/* 3. BANNER VARIANT */}
      {variant === 'banner' && !installed && !dismissed && (
        <div
          className="fixed inset-x-3 z-[100] rounded-2xl bg-neutral-900/95 backdrop-blur-2xl border border-blue-500/30 p-3 flex items-center gap-3 shadow-2xl shadow-black/80"
          style={{ bottom: 'calc(env(safe-area-inset-bottom) + 12px)' }}
        >
          <img src="/icons/icon-192.png" alt="App Icon" className="w-11 h-11 rounded-xl border border-white/20 shadow-md" />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <p className="text-xs font-bold text-white">نصب ALI phone روی آیفون</p>
              <span className="px-1.5 py-0.2 rounded text-[8px] bg-emerald-500/20 text-emerald-400 font-mono">PWA</span>
            </div>
            <p className="text-[10px] text-neutral-400 truncate">تمام‌صفحه و آفلاین روی Home Screen</p>
          </div>
          <button
            onClick={handleAction}
            className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-600/30 active:scale-95 transition-all"
          >
            نصب
          </button>
          <button
            onClick={handleDismiss}
            aria-label="بستن"
            className="p-1 text-neutral-500 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 4. COMPREHENSIVE IPHONE INSTALLATION GUIDE MODAL */}
      {guideOpen && (
        <div
          className="fixed inset-0 z-[120] bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-3 select-none animate-in fade-in duration-200"
          onClick={() => setGuideOpen(false)}
        >
          <div
            className="w-full max-w-md rounded-3xl bg-neutral-950 border border-slate-800 shadow-2xl overflow-hidden flex flex-col text-white"
            onClick={(e) => e.stopPropagation()}
            dir="rtl"
          >
            {/* Modal Header */}
            <div className="p-4 bg-gradient-to-r from-blue-950/70 via-slate-900 to-indigo-950/70 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-500/30">
                  <Smartphone className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">راهنمای نصب نسخه PWA روی آیفون</h3>
                  <p className="text-[10px] text-cyan-300">نصب مستقیم در Safari بدون نیاز به App Store</p>
                </div>
              </div>
              <button
                onClick={() => setGuideOpen(false)}
                className="p-1.5 rounded-full bg-slate-800 text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 flex flex-col gap-4 overflow-y-auto max-h-[75vh]">
              {/* Advantages Badge */}
              <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 flex flex-col items-center gap-1">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span className="font-semibold text-white">تمام‌صفحه (Standalone)</span>
                  <span className="text-[9px] text-slate-400">بدون نوار مرورگر</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 flex flex-col items-center gap-1">
                  <Wifi className="w-4 h-4 text-emerald-400" />
                  <span className="font-semibold text-white">اجرای آفلاین</span>
                  <span className="text-[9px] text-slate-400">کش هوشمند SW</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 flex flex-col items-center gap-1">
                  <ShieldCheck className="w-4 h-4 text-cyan-400" />
                  <span className="font-semibold text-white">آیکون اختصاصی</span>
                  <span className="text-[9px] text-slate-400">روی صفحه اصلی</span>
                </div>
              </div>

              {/* Step-by-Step Instructions */}
              <div className="flex flex-col gap-2.5">
                <span className="text-xs font-bold text-slate-300">مراحل نصب در مرورگر Safari آیفون:</span>

                {/* Step 1 */}
                <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-blue-600/30 text-blue-400 border border-blue-500/40 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    ۱
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white">لینک برنامه را در مرورگر Safari باز کنید</div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      (توجه: قابلیت نصب PWA در سیستم‌عامل iOS فقط از طریق Safari اپل فعال است).
                    </p>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-blue-600/30 text-blue-400 border border-blue-500/40 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    ۲
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-white">
                      <span>دکمه اشتراک‌گذاری (Share)</span>
                      <Share className="w-3.5 h-3.5 text-blue-400" />
                      <span>را در نوار پایین لمس کنید</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      در نوار ابزار پایین مرورگر Safari، آیکون مربع با فلش رو به بالا را بزنید.
                    </p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-blue-600/30 text-blue-400 border border-blue-500/40 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    ۳
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-white">
                      <span>گزینه «Add to Home Screen»</span>
                      <PlusSquare className="w-3.5 h-3.5 text-cyan-400" />
                      <span>را انتخاب کنید</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      در منوی باز شده کمی به پایین اسکرول کنید و «افزودن به صفحه اصلی» را انتخاب کنید.
                    </p>
                  </div>
                </div>

                {/* Step 4 */}
                <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800/80 flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-blue-600/30 text-blue-400 border border-blue-500/40 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    ۴
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white">کلید «Add» (افزودن) در گوشه بالا را بزنید</div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      آیکون ALI Phone به صفحه اصلی آیفون اضافه می‌شود و می‌توانید مانند یک اپلیکیشن بومی آن را اجرا نمایید.
                    </p>
                  </div>
                </div>
              </div>

              {/* QR Code & Copy Link for Instant Transfer to Real iPhone */}
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col items-center gap-3">
                <span className="text-xs font-semibold text-slate-300">
                  اگر روی کامپیوتر هستید: با دوربین آیفون اسکن کنید
                </span>
                <div className="p-2 rounded-xl bg-white shadow-xl">
                  <img src={qrCodeUrl} alt="QR Code" className="w-32 h-32" />
                </div>
                <div className="flex items-center gap-2 w-full">
                  <input
                    type="text"
                    readOnly
                    value={currentUrl}
                    className="flex-1 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-[11px] text-slate-300 font-mono truncate focus:outline-none"
                  />
                  <button
                    onClick={handleCopyLink}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white flex items-center gap-1 border border-slate-700 shrink-0 transition-colors"
                  >
                    {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedLink ? 'کپی شد!' : 'کپی لینک'}</span>
                  </button>
                </div>
              </div>

              {/* Close Button */}
              <button
                onClick={() => setGuideOpen(false)}
                className="w-full py-2.5 rounded-xl bg-white text-black font-bold text-xs hover:bg-neutral-200 transition-colors shadow-lg"
              >
                متوجه شدم (بستن پنجره)
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
