import React from 'react';
import { usePhone } from '../../context/PhoneContext';
import { t } from '../../utils/i18n';

import { LockScreen } from './LockScreen';
import { HomeScreen } from './HomeScreen';

import { AppStoreApp } from '../apps/AppStoreApp';
import { GooglePlayApkApp } from '../apps/GooglePlayApkApp';
import { ProductManagerApp } from '../apps/ProductManagerApp';
import { CameraApp } from '../apps/CameraApp';
import { PhotosApp } from '../apps/PhotosApp';
import { PhoneApp } from '../apps/PhoneApp';
import { MessagesApp } from '../apps/MessagesApp';
import { SafariApp } from '../apps/SafariApp';
import { CalculatorApp } from '../apps/CalculatorApp';
import { NotesApp } from '../apps/NotesApp';
import { MusicApp } from '../apps/MusicApp';
import { WeatherApp } from '../apps/WeatherApp';
import { ClockApp } from '../apps/ClockApp';
import { SettingsApp } from '../apps/SettingsApp';
import { CustomAppViewer } from '../apps/CustomAppViewer';
import { TerminalApp } from '../apps/TerminalApp';
import { CalendarApp } from '../apps/CalendarApp';
import { MapsApp } from '../apps/MapsApp';
import { FilesApp } from '../apps/FilesApp';
import { ProjectRunnerApp } from '../apps/ProjectRunnerApp';
import { GitHubReposApp } from '../apps/GitHubReposApp';
import { EngineeringStudioApp } from '../apps/EngineeringStudioApp';
import { GoogleServicesApp } from '../apps/GoogleServicesApp';

/**
 * Central app router — keeps giant ternary out of App.tsx.
 * Terminal & ProjectRunner talk only to isolated /api/terminal/* endpoints.
 */
export function AppRenderer() {
  const phone = usePhone();
  const {
    isLocked,
    currentApp,
    openApp,
    closeApp,
    wallpaperUrl,
    flashlightOn,
    setFlashlightOn,
    soundEnabled,
    currentTime,
    language,
    numberSystem,
    calendarType,
    setCalendarType,
    installedApps,
    setInstalledApps,
    products,
    setProducts,
    notes,
    setNotes,
    photos,
    setPhotos,
    contacts,
    titaniumFinish,
    setTitaniumFinish,
    setWallpaperUrl,
    setLanguage,
    region,
    setRegion,
    setNumberSystem,
    handleResetData,
    handleCapturePhoto,
    handleStartCall,
    handleEndCall,
    handleStartTimer,
    activeCall,
    isMusicPlaying,
    currentTrackTitle,
    handleToggleMusic,
    setSiriOpen,
    setControlCenterOpen,
    handleExecuteAction,
    setCurrentTrackTitle,
  } = phone;

  const activeCustomApp = installedApps.find((a) => a.id === currentApp);

  if (isLocked) {
    return (
      <LockScreen
        onUnlock={() => phone.setIsLocked(false)}
        wallpaperUrl={wallpaperUrl}
        flashlightOn={flashlightOn}
        setFlashlightOn={setFlashlightOn}
        onOpenApp={openApp}
        soundEnabled={soundEnabled}
        currentTime={currentTime}
        language={language}
        numberSystem={numberSystem}
        calendarType={calendarType}
      />
    );
  }

  if (currentApp === null) {
    return (
      <HomeScreen
        onOpenApp={openApp}
        installedApps={installedApps}
        products={products}
        wallpaperUrl={wallpaperUrl}
        onOpenSiri={() => setSiriOpen(true)}
        onOpenControlCenter={() => setControlCenterOpen(true)}
        soundEnabled={soundEnabled}
        currentTime={currentTime}
        language={language}
      />
    );
  }

  switch (currentApp) {
    case 'googleplay':
    case 'cloud_android':
      return (
        <GooglePlayApkApp
          initialTab={currentApp === 'cloud_android' ? 'cloud' : 'store'}
          installedApps={installedApps}
          onInstallCustomApp={(newApp) => setInstalledApps((prev) => [...prev, newApp])}
          products={products}
          onRestoreProducts={setProducts}
          notes={notes}
          onRestoreNotes={setNotes}
          language={language}
          soundEnabled={soundEnabled}
          titaniumFinish={titaniumFinish}
          wallpaperUrl={wallpaperUrl}
        />
      );

    case 'appstore':
      return (
        <AppStoreApp
          installedApps={installedApps}
          onInstallApp={(newApp) => setInstalledApps((prev) => [...prev, newApp])}
          onUninstallApp={(appId) =>
            setInstalledApps((prev) => prev.filter((a) => a.id !== appId))
          }
          onLaunchApp={openApp}
          soundEnabled={soundEnabled}
        />
      );

    case 'products':
      return (
        <ProductManagerApp
          products={products}
          onAddProduct={(p) => setProducts((prev) => [p, ...prev])}
          onUpdateProduct={(p) =>
            setProducts((prev) => prev.map((item) => (item.id === p.id ? p : item)))
          }
          onDeleteProduct={(id) => setProducts((prev) => prev.filter((p) => p.id !== id))}
          soundEnabled={soundEnabled}
        />
      );

    case 'camera':
      return (
        <CameraApp
          onCapturePhoto={handleCapturePhoto}
          onOpenPhotos={() => openApp('photos')}
          soundEnabled={soundEnabled}
        />
      );

    case 'photos':
      return (
        <PhotosApp
          photos={photos}
          onDeletePhoto={(id) => setPhotos((prev) => prev.filter((p) => p.id !== id))}
          soundEnabled={soundEnabled}
        />
      );

    case 'phone':
      return (
        <PhoneApp
          contacts={contacts}
          onStartCall={handleStartCall}
          onEndCall={handleEndCall}
          activeCall={activeCall}
          soundEnabled={soundEnabled}
        />
      );

    case 'messages':
      return (
        <MessagesApp
          onExecuteAction={handleExecuteAction}
          soundEnabled={soundEnabled}
          phoneContext={{
            productsCount: products.length,
            installedAppsCount: installedApps.length,
            language,
          }}
        />
      );

    case 'safari':
      return <SafariApp soundEnabled={soundEnabled} />;

    case 'calculator':
      return <CalculatorApp soundEnabled={soundEnabled} />;

    case 'notes':
      return (
        <NotesApp
          notes={notes}
          onAddNote={(n) => setNotes((prev) => [n, ...prev])}
          onUpdateNote={(n) =>
            setNotes((prev) => prev.map((x) => (x.id === n.id ? n : x)))
          }
          onDeleteNote={(id) => setNotes((prev) => prev.filter((n) => n.id !== id))}
          soundEnabled={soundEnabled}
        />
      );

    case 'music':
      return (
        <MusicApp
          isPlaying={isMusicPlaying}
          onTogglePlay={handleToggleMusic}
          currentTrack={currentTrackTitle}
          onSelectTrack={setCurrentTrackTitle}
          soundEnabled={soundEnabled}
        />
      );

    case 'weather':
      return <WeatherApp soundEnabled={soundEnabled} />;

    case 'clock':
      return (
        <ClockApp
          onStartTimer={handleStartTimer}
          soundEnabled={soundEnabled}
        />
      );

    case 'terminal':
      return <TerminalApp soundEnabled={soundEnabled} />;

    case 'my_repos':
      return (
        <GitHubReposApp
          language={language}
          soundEnabled={soundEnabled}
          onBack={closeApp}
        />
      );

    case 'engineering_studio':
      return (
        <EngineeringStudioApp
          language={language}
          soundEnabled={soundEnabled}
          onBack={closeApp}
        />
      );

    case 'google_hub':
      return (
        <GoogleServicesApp
          language={language}
          soundEnabled={soundEnabled}
          onBack={closeApp}
        />
      );

    case 'calendar':
      return (
        <CalendarApp
          language={language}
          calendarType={calendarType}
          onSelectCalendarType={setCalendarType}
          numberSystem={numberSystem}
          soundEnabled={soundEnabled}
        />
      );

    case 'maps':
      return <MapsApp soundEnabled={soundEnabled} />;

    case 'files':
      return (
        <FilesApp
          language={language}
          soundEnabled={soundEnabled}
          onOpenProjectRunner={(projId) => openApp(`project_${projId}`)}
          onInstallAppToHomeScreen={(newApp) => {
            setInstalledApps((prev) => [newApp, ...prev.filter((a) => a.id !== newApp.id)]);
          }}
          onBackToHome={closeApp}
        />
      );

    case 'settings':
      return (
        <SettingsApp
          titaniumFinish={titaniumFinish}
          onSelectTitaniumFinish={setTitaniumFinish}
          currentWallpaperUrl={wallpaperUrl}
          onSelectWallpaper={setWallpaperUrl}
          soundEnabled={soundEnabled}
          onToggleSound={() => phone.setSoundEnabled(!soundEnabled)}
          language={language}
          onSelectLanguage={setLanguage}
          region={region}
          onSelectRegion={setRegion}
          calendarType={calendarType}
          onSelectCalendar={setCalendarType}
          numberSystem={numberSystem}
          onSelectNumberSystem={setNumberSystem}
          onResetData={handleResetData}
        />
      );

    default:
      if (currentApp.startsWith('project_')) {
        const projectId = currentApp.replace('project_', '');
        return (
          <ProjectRunnerApp
            projectId={projectId}
            language={language}
            soundEnabled={soundEnabled}
            onBack={() => openApp('files')}
            onInstallToHomeScreen={(newApp) => {
              setInstalledApps((prev) => [newApp, ...prev.filter((a) => a.id !== newApp.id)]);
            }}
          />
        );
      }

      if (activeCustomApp) {
        return (
          <CustomAppViewer
            app={activeCustomApp}
            products={products}
            onBack={closeApp}
            soundEnabled={soundEnabled}
          />
        );
      }

      return (
        <div className="h-full flex items-center justify-center p-6 text-center text-neutral-400">
          <div>
            <p className="text-sm font-semibold">
              {language === 'fa' ? 'برنامه در دسترس نیست' : 'App Not Found'}
            </p>
            <button
              onClick={closeApp}
              className="mt-3 px-4 py-1.5 rounded-full bg-neutral-800 text-xs text-white"
            >
              {t('back', language)}
            </button>
          </div>
        </div>
      );
  }
}
