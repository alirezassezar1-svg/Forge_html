import React, { useRef, useEffect } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
}

interface InteractiveLiveWallpaperProps {
  enabled?: boolean;
  theme?: 'cyber_neon' | 'deep_blue' | 'titanium_gold';
}

export const InteractiveLiveWallpaper: React.FC<InteractiveLiveWallpaperProps> = ({
  enabled = true,
  theme = 'cyber_neon',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mousePos = useRef<{ x: number; y: number; active: boolean }>({ x: 0, y: 0, active: false });

  useEffect(() => {
    if (!enabled) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || window.innerWidth);
    let height = (canvas.height = canvas.parentElement?.clientHeight || window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.parentElement?.clientWidth || window.innerWidth;
      height = canvas.height = canvas.parentElement?.clientHeight || window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    // Color palette based on theme
    const colors =
      theme === 'cyber_neon'
        ? ['#00E5FF', '#FF2A85', '#38BDF8', '#F43F5E']
        : theme === 'deep_blue'
        ? ['#3B82F6', '#8B5CF6', '#60A5FA', '#A78BFA']
        : ['#F59E0B', '#D97706', '#FBBF24', '#B45309'];

    // Spawn 40 particles for smooth 60fps performance without draining battery
    const particlesCount = 42;
    const particles: Particle[] = [];

    for (let i = 0; i < particlesCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.8,
        vy: (Math.random() - 0.5) * 0.8,
        size: Math.random() * 2 + 1.2,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: Math.random() * 0.6 + 0.3,
      });
    }

    // Touch and mouse ripple trackers
    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      const clientX = 'touches' in e ? e.touches[0]?.clientX : e.clientX;
      const clientY = 'touches' in e ? e.touches[0]?.clientY : e.clientY;
      if (clientX !== undefined && clientY !== undefined && canvas) {
        const rect = canvas.getBoundingClientRect();
        mousePos.current = {
          x: clientX - rect.left,
          y: clientY - rect.top,
          active: true,
        };
      }
    };

    const handlePointerLeave = () => {
      mousePos.current.active = false;
    };

    const container = canvas.parentElement;
    if (container) {
      container.addEventListener('mousemove', handlePointerMove);
      container.addEventListener('touchmove', handlePointerMove, { passive: true });
      container.addEventListener('mouseleave', handlePointerLeave);
      container.addEventListener('touchend', handlePointerLeave);
    }

    // Animation Loop
    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Deep dark background gradient
      const bgGrad = ctx.createLinearGradient(0, 0, width, height);
      bgGrad.addColorStop(0, '#020617'); // slate-950
      bgGrad.addColorStop(0.5, '#090d16');
      bgGrad.addColorStop(1, '#050508');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, width, height);

      // Connect near particles with glowing neon lines
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 85) {
            ctx.beginPath();
            ctx.strokeStyle = particles[i].color;
            ctx.globalAlpha = (1 - dist / 85) * 0.22;
            ctx.lineWidth = 0.8;
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      // Draw and update particles
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        // Move
        p.x += p.vx;
        p.y += p.vy;

        // Bounce on borders
        if (p.x < 0 || p.x > width) p.vx *= -1;
        if (p.y < 0 || p.y > height) p.vy *= -1;

        // Interaction with touch/mouse pointer: gentle repulsion
        if (mousePos.current.active) {
          const mdx = p.x - mousePos.current.x;
          const mdy = p.y - mousePos.current.y;
          const mdist = Math.sqrt(mdx * mdx + mdy * mdy);
          if (mdist < 90) {
            const force = (90 - mdist) / 90;
            p.x += (mdx / mdist) * force * 2.5;
            p.y += (mdy / mdist) * force * 2.5;
          }
        }

        // Draw particle with glow
        ctx.save();
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 8;
        ctx.fill();
        ctx.restore();
      }

      // If touch/mouse is active, draw a subtle glowing ring around it
      if (mousePos.current.active) {
        ctx.save();
        ctx.beginPath();
        ctx.arc(mousePos.current.x, mousePos.current.y, 22, 0, Math.PI * 2);
        ctx.strokeStyle = theme === 'cyber_neon' ? '#00E5FF' : '#3B82F6';
        ctx.globalAlpha = 0.35;
        ctx.lineWidth = 1.5;
        ctx.shadowColor = '#00E5FF';
        ctx.shadowBlur = 12;
        ctx.stroke();
        ctx.restore();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      if (container) {
        container.removeEventListener('mousemove', handlePointerMove);
        container.removeEventListener('touchmove', handlePointerMove);
        container.removeEventListener('mouseleave', handlePointerLeave);
        container.removeEventListener('touchend', handlePointerLeave);
      }
    };
  }, [enabled, theme]);

  if (!enabled) return null;

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none z-0"
    />
  );
};
