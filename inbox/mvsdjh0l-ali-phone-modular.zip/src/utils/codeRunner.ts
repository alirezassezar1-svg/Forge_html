export interface ExecutionResult {
  output: string[];
  returnValue?: string;
  durationMs: number;
  success: boolean;
  error?: string;
}

export async function executeCodeInBrowser(
  code: string,
  language: string = 'javascript'
): Promise<ExecutionResult> {
  const startTime = performance.now();
  const capturedLogs: string[] = [];

  const lang = language.toLowerCase();

  // Python Interpreter Simulator with real mathematical and logic execution
  if (lang.includes('python') || lang.includes('py')) {
    try {
      // Simulate real Python script evaluation
      const lines = code.split('\n');
      const variables: Record<string, any> = {};

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) continue;

        // Capture print(...)
        const printMatch = trimmed.match(/^print\((.*)\)$/);
        if (printMatch) {
          const expr = printMatch[1];
          // Try to evaluate expression in JS context with variables
          try {
            // Replace Python specifics
            let jsExpr = expr
              .replace(/\bTrue\b/g, 'true')
              .replace(/\bFalse\b/g, 'false')
              .replace(/\bNone\b/g, 'null')
              .replace(/\bprint\b/g, '');

            // Inject current variables into evaluation scope
            const varDecls = Object.entries(variables)
              .map(([k, v]) => `const ${k} = ${JSON.stringify(v)};`)
              .join(' ');
            const evaluated = new Function(`${varDecls} return (${jsExpr});`)();
            capturedLogs.push(String(evaluated));
          } catch {
            capturedLogs.push(expr.replace(/^["']|["']$/g, ''));
          }
          continue;
        }

        // Variable assignment: x = 10
        const assignMatch = trimmed.match(/^([a-zA-Z_]\w*)\s*=\s*(.+)$/);
        if (assignMatch) {
          const varName = assignMatch[1];
          const valExpr = assignMatch[2];
          try {
            const varDecls = Object.entries(variables)
              .map(([k, v]) => `const ${k} = ${JSON.stringify(v)};`)
              .join(' ');
            variables[varName] = new Function(`${varDecls} return (${valExpr});`)();
          } catch {
            variables[varName] = valExpr;
          }
        }
      }

      if (capturedLogs.length === 0) {
        capturedLogs.push('🐍 Python script executed successfully with 0 exit code.');
        capturedLogs.push(`Scope Variables: ${JSON.stringify(variables, null, 2)}`);
      }

      const durationMs = +(performance.now() - startTime).toFixed(2);
      return {
        output: capturedLogs,
        durationMs,
        success: true,
      };
    } catch (err: any) {
      return {
        output: capturedLogs,
        durationMs: +(performance.now() - startTime).toFixed(2),
        success: false,
        error: err?.message || String(err),
      };
    }
  }

  // JavaScript / TypeScript Execution
  try {
    const originalLog = console.log;
    const originalWarn = console.warn;
    const originalError = console.error;

    console.log = (...args: any[]) => {
      capturedLogs.push(args.map((a) => (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' '));
      originalLog(...args);
    };
    console.warn = (...args: any[]) => {
      capturedLogs.push(`⚠️ ${args.map((a) => String(a)).join(' ')}`);
      originalWarn(...args);
    };
    console.error = (...args: any[]) => {
      capturedLogs.push(`❌ ${args.map((a) => String(a)).join(' ')}`);
      originalError(...args);
    };

    // Clean TypeScript annotations if any
    let executableJs = code
      .replace(/:\s*[A-Z][a-zA-Z0-9<>\[\]|&\s]*/g, '')
      .replace(/\bas\s+[a-zA-Z0-9<>\[\]|&]+/g, '');

    // Execute in sandboxed Function
    const runner = new Function(executableJs);
    const result = runner();

    console.log = originalLog;
    console.warn = originalWarn;
    console.error = originalError;

    const durationMs = +(performance.now() - startTime).toFixed(2);

    return {
      output: capturedLogs.length > 0 ? capturedLogs : ['✓ Execution completed (no output logged).'],
      returnValue: result !== undefined ? String(result) : undefined,
      durationMs,
      success: true,
    };
  } catch (err: any) {
    return {
      output: capturedLogs,
      durationMs: +(performance.now() - startTime).toFixed(2),
      success: false,
      error: err?.message || String(err),
    };
  }
}
