# ALI phone — iPhone 16 Pro Max Simulator (Modular)

Ultra-realistic iPhone 16 Pro Max simulation with Dynamic Island, Control Center, multi-language (fa/en/ar/…), Persian calendar, product manager, and **isolated** developer tools (Terminal / Project Runner).

## Architecture (cleaned & modular)

```
src/
  App.tsx                 # Thin shell only
  context/
    PhoneContext.tsx      # All shared OS state + actions
  hooks/
    useLocalStorage.ts    # Typed persistence
  components/
    os/
      AppRenderer.tsx     # App switch (no giant ternary in App)
      HomeScreen, LockScreen, ControlCenter, DynamicIsland, …
    apps/                 # One folder per app (still large; further split recommended)
    hardware/
  types/phone.ts
  utils/
server.ts                 # Express + Gemini + terminal sandbox
terminal_sandbox/         # Isolated cwd for all exec/file ops (safeSandboxPath)
```

### Isolation guarantees
- Terminal & Project Runner only operate inside `terminal_sandbox/`.
- `safeSandboxPath()` blocks `../` escapes.
- `exec` always runs with `cwd: sandboxDir` and a 15–20s timeout.
- No shared mutable state between apps beyond PhoneContext.

## Run locally

```bash
npm install
cp .env.example .env.local   # set GEMINI_API_KEY
npm run dev
```

Open http://localhost:3000

## PWA

```bash
npm run build && NODE_ENV=production npm start
```

Serve over HTTPS (or localhost). On phone: install / Add to Home Screen → fullscreen native mode (no chassis).

## Notes for further cleanup
- `EngineeringStudioApp.tsx` (~2k lines) and `GooglePlayApkApp.tsx` (~1.6k) should be split into subcomponents when time allows.
- Large media assets were stripped from this clean package; only essential icons + titanium wallpapers remain.
