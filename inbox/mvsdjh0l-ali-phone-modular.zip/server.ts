import express from 'express';
import http from 'http';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import { exec } from 'child_process';
import fs from 'fs';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000;

// Increase request payload limits to 100MB for large code bundles, photos, scripts, and file data
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ limit: '100mb', extended: true, parameterLimit: 100000 }));
app.use(express.text({ limit: '100mb' }));
app.use(express.raw({ limit: '100mb' }));

// Gracefully handle any payload-too-large or body-parsing error
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  if (err) {
    if (
      err.type === 'entity.too.large' ||
      err.status === 413 ||
      err.statusCode === 413 ||
      err.name === 'PayloadTooLargeError' ||
      (typeof err.message === 'string' && err.message.toLowerCase().includes('too large'))
    ) {
      console.warn(`[413] Payload too large on ${req.method} ${req.path}`);
      return res.status(413).json({
        error: 'Payload Too Large',
        message: 'حجم داده یا فایل ارسالی فراتر از حد مجاز سرور است (حداکثر ۱۰۰ مگابایت).',
        limit: '100mb',
      });
    }
    return res.status(err.status || 400).json({
      error: 'Invalid Request',
      message: err.message || 'خطا در پردازش درخواست',
    });
  }
  next();
});

// Initialize Google Gemini AI client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// ALI Assistant Chat endpoint
app.post('/api/assistant/chat', async (req, res) => {
  try {
    const { prompt, history, language = 'fa', systemContext = {} } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const systemInstruction = `
You are "ALI Intelligence" (دستیار هوشمند علی), the ultra-advanced AI built into the iPhone 16 Pro Max ("ALI phone").
You respond in a polite, super-fast, intelligent, and helpful tone in the user's language (Persian by default, or English if asked).
You have deep integration with the ALI phone hardware & software:
- You know the device is an iPhone 16 Pro Max with A18 Pro chip, 1TB Titanium storage, iOS 18.2 / ALI OS.
- You can help users manage and install products, launch apps (Phone, Messages, Camera, Photos, Safari, Terminal, Calendar, Maps, Notes, Calculator, Music, Weather, Clock, Settings, Store, Product Manager), calculate finances, draft invoices, write notes, or answer general knowledge questions.
- Current active phone context: ${JSON.stringify(systemContext)}.
- If the user asks you to open an app or execute an action, you can include an action tag in your answer like [ACTION:open_app:camera], [ACTION:open_app:products], [ACTION:open_app:terminal], [ACTION:open_app:calendar], [ACTION:open_app:maps], [ACTION:open_app:notes], [ACTION:open_app:calculator], [ACTION:open_app:music], [ACTION:open_app:settings], [ACTION:open_app:store], [ACTION:open_app:phone], [ACTION:open_app:safari], [ACTION:flashlight:toggle], [ACTION:take_photo].
Keep responses crisp, high quality, and elegant.
`;

    // Construct contents
    const contents: any[] = [];
    if (history && Array.isArray(history)) {
      for (const msg of history.slice(-6)) {
        contents.push({
          role: msg.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: msg.text }],
        });
      }
    }
    contents.push({
      role: 'user',
      parts: [{ text: prompt }],
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const replyText = response.text || 'پاسخی دریافت نشد.';

    // Extract any action if present
    const actionMatch = replyText.match(/\[ACTION:([^\]]+)\]/);
    const action = actionMatch ? actionMatch[1] : null;
    const cleanReply = replyText.replace(/\[ACTION:[^\]]+\]/g, '').trim();

    return res.json({
      reply: cleanReply,
      action,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in /api/assistant/chat:', error);
    return res.status(500).json({
      error: 'Failed to communicate with ALI Intelligence',
      details: error.message || 'Unknown error',
    });
  }
});

// Check phone status
app.get('/api/status', (req, res) => {
  res.json({
    device: 'ALI phone - iPhone 16 Pro Max',
    chip: 'Apple A18 Pro',
    os: 'ALI OS 18.2',
    status: 'online',
    time: new Date().toISOString(),
  });
});

// Setup terminal sandbox directory
const sandboxDir = path.resolve(__dirname, 'terminal_sandbox');

/** Resolve a path strictly inside sandboxDir. Throws if escape attempted. */
function safeSandboxPath(userPath: string = ''): string {
  const normalized = path.normalize(userPath || '').replace(/^(\.\.[\/\\])+/, '');
  const resolved = path.resolve(sandboxDir, normalized);
  if (!resolved.startsWith(sandboxDir + path.sep) && resolved !== sandboxDir) {
    throw new Error('Path escapes terminal sandbox');
  }
  return resolved;
}


if (!fs.existsSync(sandboxDir)) {
  fs.mkdirSync(sandboxDir, { recursive: true });
}
if (!fs.existsSync(path.join(sandboxDir, 'package.json'))) {
  fs.writeFileSync(path.join(sandboxDir, 'package.json'), JSON.stringify({ type: 'commonjs' }, null, 2));
}
if (!fs.existsSync(path.join(sandboxDir, 'hello.py'))) {
  fs.writeFileSync(
    path.join(sandboxDir, 'hello.py'),
    `# Python 3 in ALI Phone Terminal
import sys
import platform
import math

print("🐍 Python 3 on ALI Phone (iPhone 16 Pro Max - A18 Pro)")
print(f"Version: {sys.version.split()[0]}")
print(f"Platform: {platform.system()} {platform.machine()}")
print(f"Calculated Pi: {math.pi:.6f}")

numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
squares = [x**2 for x in numbers]
print(f"Squares: {squares}")
`
  );

  fs.writeFileSync(
    path.join(sandboxDir, 'app.js'),
    `// Node.js script on ALI Phone
console.log("🟢 Node.js v" + process.version + " running on ALI Phone A18 Pro");
const os = require('os');
console.log("Arch: " + os.arch() + " | Free Mem: " + Math.round(os.freemem() / 1024 / 1024) + " MB");
const greetings = ["درود بر شما", "Hello World", "مرحبا", "Bonjour"];
console.log("Random greeting: " + greetings[Math.floor(Math.random() * greetings.length)]);
`
  );

  fs.writeFileSync(
    path.join(sandboxDir, 'system_info.sh'),
    `#!/bin/bash
echo "📱 ALI Phone Terminal Shell"
echo "Kernel: $(uname -s -r)"
echo "Date & Time: $(date)"
echo "Directory: $(pwd)"
echo "Available files:"
ls -lh
`
  );
}

// Initialize seed folders matching user's real iPhone screenshot
const seedFolders = [
  'QWEN2',
  'Google-ai',
  'vibe2',
  'deepseek3',
  'web crawler',
  'Prompt',
  'workflow',
  'Froshgahi',
  'Downloads 2',
  'Dev',
  'App',
  'api',
  'React-Storefront',
  'Laravel-Commerce',
  'Python-FastAPI',
  'Node-Realtime',
  'Windows-Tools',
  'Samsung-APKs'
];

seedFolders.forEach((folder) => {
  const fPath = path.join(sandboxDir, folder);
  if (!fs.existsSync(fPath)) {
    fs.mkdirSync(fPath, { recursive: true });
  }
});

// Seed sample html file from screenshot
if (!fs.existsSync(path.join(sandboxDir, '0001.html'))) {
  fs.writeFileSync(
    path.join(sandboxDir, '0001.html'),
    `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>0001 Preview</title><style>body{background:#0b0f19;color:#fff;font-family:system-ui;padding:24px;text-align:center;}h1{color:#38bdf8;}code{color:#f59e0b;}</style></head>
<body>
  <h1>📱 ALI Phone Web Sandbox</h1>
  <p>فایل محلی 0001.html آماده اجرا و ویرایش در محیط آیفون ۱۶ پرو مکس</p>
  <div style="background:#1e293b;padding:16px;border-radius:14px;margin-top:20px;">
    <code>Status: Active · Chip: Apple A18 Pro · Storage: 1TB NVMe</code>
  </div>
</body>
</html>`
  );
}

// -----------------------------------------------------------------------------
// Terminal & Execution Endpoints (Python 3, Node.js, Shell, Any File)
// -----------------------------------------------------------------------------
app.post('/api/terminal/exec', async (req, res) => {
  try {
    const { command, language, code, fileName } = req.body;
    const startTime = Date.now();

    let cmdToRun = command;

    if (code) {
      const ext = language === 'python' ? '.py' : language === 'node' ? '.js' : '.sh';
      const targetFile = fileName || `temp_run_${Date.now()}${ext}`;
      const filePath = path.join(sandboxDir, targetFile);
      fs.writeFileSync(filePath, code, 'utf8');

      if (language === 'python') {
        cmdToRun = `python3 "${targetFile}"`;
      } else if (language === 'node') {
        cmdToRun = `node "${targetFile}"`;
      } else {
        cmdToRun = `bash "${targetFile}"`;
      }
    }

    if (!cmdToRun) {
      return res.status(400).json({ error: 'Command or code is required' });
    }

    exec(
      cmdToRun,
      {
        cwd: sandboxDir,
        timeout: 20000,
        maxBuffer: 2 * 1024 * 1024,
        env: {
          ...process.env,
          PYTHONUNBUFFERED: '1',
          NODE_ENV: 'development',
        },
      },
      (error, stdout, stderr) => {
        const executionTimeMs = Date.now() - startTime;
        return res.json({
          command: cmdToRun,
          stdout: stdout || '',
          stderr: stderr || (error ? error.message : ''),
          exitCode: error ? error.code || 1 : 0,
          executionTimeMs,
        });
      }
    );
  } catch (err: any) {
    return res.status(500).json({
      error: 'Execution failed',
      details: err.message,
    });
  }
});

// List files in sandbox (supports nested subpaths for Files App)
app.get('/api/terminal/files', (req, res) => {
  try {
    const subpath = typeof req.query.path === 'string' ? req.query.path : '';
    const safeSubpath = path.normalize(subpath).replace(/^(\.\.[\/\\])+/, '');
    const currentDir = safeSandboxPath(safeSubpath);

    if (!fs.existsSync(currentDir)) {
      return res.json({ currentPath: safeSubpath, files: [] });
    }

    const fileNames = fs.readdirSync(currentDir);
    const files = fileNames.map((name) => {
      const fullPath = path.join(currentDir, name);
      const stat = fs.statSync(fullPath);
      return {
        name,
        path: safeSubpath ? `${safeSubpath}/${name}` : name,
        size: stat.size,
        updatedAt: stat.mtime.toISOString(),
        isDirectory: stat.isDirectory(),
      };
    });

    return res.json({ currentPath: safeSubpath, files });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Read file content
app.get('/api/terminal/file', (req, res) => {
  try {
    const queryPath = (req.query.path || req.query.name) as string;
    if (!queryPath || typeof queryPath !== 'string') {
      return res.status(400).json({ error: 'File path is required' });
    }
    const safePath = path.normalize(queryPath).replace(/^(\.\.[\/\\])+/, '');
    const filePath = safeSandboxPath(safePath);
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ error: 'File not found' });
    }
    const content = fs.readFileSync(filePath, 'utf8');
    return res.json({ name: path.basename(safePath), path: safePath, content });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Save or create file in sandbox
app.post('/api/terminal/file', (req, res) => {
  try {
    const { name, path: reqPath, content } = req.body;
    const target = reqPath || name;
    if (!target) {
      return res.status(400).json({ error: 'File path is required' });
    }
    const safePath = path.normalize(target).replace(/^(\.\.[\/\\])+/, '');
    const filePath = safeSandboxPath(safePath);
    const parentDir = path.dirname(filePath);
    if (!fs.existsSync(parentDir)) {
      fs.mkdirSync(parentDir, { recursive: true });
    }
    fs.writeFileSync(filePath, content || '', 'utf8');
    return res.json({ success: true, name: path.basename(safePath), path: safePath });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Multi-framework Project Execution (Python, Node, PHP/Laravel, React, Windows, Samsung)
app.post('/api/projects/execute', async (req, res) => {
  try {
    const { framework, code, command, projectPath, fileName } = req.body;
    const startTime = Date.now();

    // 1. Python execution
    if (framework === 'python') {
      const scriptCode = code || 'print("Python 3 script executed")';
      const tempFile = path.join(sandboxDir, fileName || `temp_py_${Date.now()}.py`);
      fs.writeFileSync(tempFile, scriptCode, 'utf8');

      exec(`python3 "${path.basename(tempFile)}"`, { cwd: sandboxDir, timeout: 15000 }, (error, stdout, stderr) => {
        return res.json({
          framework: 'python',
          stdout: stdout || '',
          stderr: stderr || (error ? error.message : ''),
          exitCode: error ? error.code || 1 : 0,
          durationMs: Date.now() - startTime,
        });
      });
      return;
    }

    // 2. Node.js execution
    if (framework === 'nodejs') {
      const scriptCode = code || 'console.log("Node.js script executed");';
      const tempFile = path.join(sandboxDir, fileName || `temp_node_${Date.now()}.js`);
      fs.writeFileSync(tempFile, scriptCode, 'utf8');

      exec(`node "${path.basename(tempFile)}"`, { cwd: sandboxDir, timeout: 15000 }, (error, stdout, stderr) => {
        return res.json({
          framework: 'nodejs',
          stdout: stdout || '',
          stderr: stderr || (error ? error.message : ''),
          exitCode: error ? error.code || 1 : 0,
          durationMs: Date.now() - startTime,
        });
      });
      return;
    }

    // 3. PHP / Laravel simulation or execution
    if (framework === 'laravel' || framework === 'php') {
      // If user provided custom command e.g. "php artisan route:list"
      const cmd = command || 'php artisan serve';
      let simulatedOutput = '';

      if (cmd.includes('artisan serve') || cmd.includes('serve')) {
        simulatedOutput = `   INFO  Server running on [http://127.0.0.1:8000].

   Press Ctrl+C to stop the server

  2026-10-24 14:02:10 ........................................ ~ 12ms
  GET /api/products .......................................... 200 OK
  GET /api/orders ............................................ 200 OK
  POST /api/checkout ......................................... 201 Created
`;
      } else if (cmd.includes('route:list')) {
        simulatedOutput = `+--------+----------+--------------------+-------------------+-------------------------------+
| Domain | Method   | URI                | Name              | Action                        |
+--------+----------+--------------------+-------------------+-------------------------------+
|        | GET|HEAD | /                  | home              | HomeController@index          |
|        | GET|HEAD | api/products       | products.index    | Api\\ProductController@index  |
|        | POST     | api/products       | products.store    | Api\\ProductController@store  |
|        | GET|HEAD | api/products/{id}  | products.show     | Api\\ProductController@show   |
|        | POST     | api/orders         | orders.create     | Api\\OrderController@create   |
|        | GET|HEAD | up                 |                   | Closure                       |
+--------+----------+--------------------+-------------------+-------------------------------+`;
      } else if (cmd.includes('migrate')) {
        simulatedOutput = `   INFO  Running migrations.

  2026_10_01_000000_create_users_table ........................... 14.22ms DONE
  2026_10_05_000000_create_products_table ........................ 18.05ms DONE
  2026_10_12_000000_create_orders_table .......................... 22.84ms DONE
  2026_10_18_000000_create_failed_jobs_table ..................... 11.19ms DONE
`;
      } else {
        simulatedOutput = `PHP 8.3.10 (cli) (built: ALI OS Engine)
Laravel Framework 11.28.0 (PHP v8.3)
Execution completed for: ${cmd}
Output: OK (200)`;
      }

      return res.json({
        framework: 'laravel',
        stdout: simulatedOutput,
        stderr: '',
        exitCode: 0,
        durationMs: Date.now() - startTime,
      });
    }

    // Default bash execution
    exec(command || 'ls -lh', { cwd: sandboxDir, timeout: 15000 }, (error, stdout, stderr) => {
      return res.json({
        framework: framework || 'bash',
        stdout: stdout || '',
        stderr: stderr || (error ? error.message : ''),
        exitCode: error ? error.code || 1 : 0,
        durationMs: Date.now() - startTime,
      });
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});


// Delete file
app.delete('/api/terminal/file', (req, res) => {
  try {
    const { name } = req.query;
    if (!name || typeof name !== 'string') {
      return res.status(400).json({ error: 'File name is required' });
    }
    const safeName = path.basename(name);
    const filePath = path.join(sandboxDir, safeName);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    return res.json({ success: true, name: safeName });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// -----------------------------------------------------------------------------
// Safari Web Proxy & Live Search Endpoint
// -----------------------------------------------------------------------------
app.get('/api/safari/proxy', async (req, res) => {
  try {
    const targetUrl = req.query.url as string;
    if (!targetUrl) {
      return res.status(400).json({ error: 'URL parameter is required' });
    }

    const parsed = new URL(targetUrl.startsWith('http') ? targetUrl : `https://${targetUrl}`);
    const response = await fetch(parsed.href, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.2 Mobile/15E148 Safari/604.1',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
      },
    });

    const contentType = response.headers.get('content-type') || 'text/html';
    let body = await response.text();

    // Inject base href so relative images/scripts load properly
    if (contentType.includes('text/html')) {
      const baseTag = `<base href="${parsed.origin}/">`;
      body = body.replace(/<head[^>]*>/i, `$&${baseTag}`);
    }

    res.setHeader('Content-Type', contentType);
    // Allow iframe embedding from our dev site
    res.removeHeader('X-Frame-Options');
    res.removeHeader('Content-Security-Policy');
    return res.send(body);
  } catch (error: any) {
    return res.status(500).send(`
      <!DOCTYPE html>
      <html lang="fa" dir="rtl">
      <head><meta charset="UTF-8"><style>body{background:#000;color:#fff;font-family:sans-serif;padding:24px;text-align:center;}a{color:#38bdf8;}</style></head>
      <body>
        <h3>خطا در بارگذاری صفحه از طریق پروکسی سافاری</h3>
        <p style="color:#aaa;font-size:12px;">${error.message}</p>
        <p><a href="${req.query.url}" target="_blank">باز کردن مستقیم در تب جدید</a></p>
      </body>
      </html>
    `);
  }
});

// Vite Middleware for dev or static serving for prod
async function startServer() {
  const httpServer = http.createServer(app);

  if (process.env.NODE_ENV === 'production') {
    app.use(
      express.static(path.resolve(__dirname, 'dist'), {
        setHeaders: (res, file) => {
          if (file.endsWith('sw.js') || file.endsWith('index.html')) res.setHeader('Cache-Control', 'no-cache');
          if (file.endsWith('.webmanifest')) res.setHeader('Content-Type', 'application/manifest+json');
          if (/\/assets\//.test(file)) res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
        },
      })
    );
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: {
          server: httpServer,
        },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  httpServer.listen(port, '0.0.0.0', () => {
    console.log(`ALI phone server running at http://0.0.0.0:${port}`);
  });
}

startServer();
