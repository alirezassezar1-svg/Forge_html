import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Zap,
  Check,
  X,
  Copy,
  RotateCcw,
  ArrowRight,
  Split,
  FileCode,
  ShieldCheck,
  ListTree,
  Sliders,
  Bug,
  AlertTriangle,
  Layers,
  ChevronRight,
  TrendingUp,
  Cpu,
  CheckCircle2,
} from 'lucide-react';

export type RefactorGoal =
  | 'optimize_loops'
  | 'simplify_logic'
  | 'best_practices'
  | 'extract_helpers'
  | 'error_handling'
  | 'custom';

export interface RefactorImprovement {
  type: 'performance' | 'readability' | 'best_practice' | 'security';
  title: string;
  description: string;
}

export interface RefactorMetrics {
  complexityBefore: string;
  complexityAfter: string;
  linesChange: string;
  readabilityScore: number;
}

export interface RefactorResult {
  title: string;
  summary: string;
  improvements: RefactorImprovement[];
  metrics: RefactorMetrics;
  refactoredCode: string;
  diffSummary: string;
}

interface AIRefactorModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedCode: string;
  fullFileContent: string;
  filePath: string;
  language?: string;
  startLine: number;
  endLine: number;
  onApproveRefactor: (newCodeSnippet: string, title: string, summary: string) => void;
}

export const AIRefactorModal: React.FC<AIRefactorModalProps> = ({
  isOpen,
  onClose,
  selectedCode,
  fullFileContent,
  filePath,
  language = 'javascript',
  startLine,
  endLine,
  onApproveRefactor,
}) => {
  const [goal, setGoal] = useState<RefactorGoal>('optimize_loops');
  const [customInstruction, setCustomInstruction] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<RefactorResult | null>(null);
  const [diffViewMode, setDiffViewMode] = useState<'split' | 'unified' | 'full'>('split');
  const [isCopied, setIsCopied] = useState(false);

  // Reset state when opening with new selection
  useEffect(() => {
    if (isOpen) {
      setResult(null);
      setError(null);
      setIsLoading(false);
    }
  }, [isOpen, selectedCode]);

  // Loading steps animation
  useEffect(() => {
    if (!isLoading) return;
    const steps = [
      'Scanning AST & symbol dependencies...',
      'Analyzing loop boundaries & algorithmic complexity...',
      'Synthesizing optimized patterns & guard clauses...',
      'Verifying semantic parity & building diff...',
    ];
    let idx = 0;
    const timer = setInterval(() => {
      idx = (idx + 1) % steps.length;
      setLoadingStep(idx);
    }, 900);
    return () => clearInterval(timer);
  }, [isLoading]);

  if (!isOpen) return null;

  const handleGenerate = async (overrideGoal?: RefactorGoal, overridePrompt?: string) => {
    const targetGoal = overrideGoal || goal;
    const targetPrompt = overridePrompt !== undefined ? overridePrompt : customInstruction;

    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/ai/refactor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: selectedCode,
          fullFileContent,
          filePath,
          goal: targetGoal,
          customInstruction: targetPrompt,
          language,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status}`);
      }

      const data: RefactorResult = await response.json();
      setResult(data);
    } catch (err: any) {
      console.error('Refactoring error:', err);
      setError(err.message || 'Failed to generate refactoring. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyCode = () => {
    if (!result?.refactoredCode) return;
    navigator.clipboard.writeText(result.refactoredCode);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleApprove = () => {
    if (!result?.refactoredCode) return;
    onApproveRefactor(result.refactoredCode, result.title, result.summary);
    onClose();
  };

  // Build Full File Preview with replacement
  const getFullFilePreview = () => {
    if (!result || !fullFileContent) return result?.refactoredCode || selectedCode;
    const idx = fullFileContent.indexOf(selectedCode);
    if (idx !== -1) {
      return (
        fullFileContent.substring(0, idx) +
        result.refactoredCode +
        fullFileContent.substring(idx + selectedCode.length)
      );
    }
    return fullFileContent;
  };

  // Helper for rendering Split Diff
  const renderSplitDiff = () => {
    const originalLines = selectedCode.split('\n');
    const refactoredLines = (result?.refactoredCode || '').split('\n');
    const maxLines = Math.max(originalLines.length, refactoredLines.length);

    return (
      <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-white/10 font-mono text-[11px] leading-5 h-full overflow-auto custom-scrollbar bg-[#06080d]">
        {/* Left: Original Code */}
        <div className="flex flex-col">
          <div className="px-3 py-2 bg-rose-500/10 border-b border-rose-500/20 text-rose-300 font-sans font-semibold text-[11px] flex items-center justify-between sticky top-0 z-10 backdrop-blur-md">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-rose-400"></span>
              ORIGINAL CODE (Lines {startLine} - {endLine})
            </span>
            <span className="font-mono text-[10px] text-rose-300/80">{originalLines.length} lines</span>
          </div>
          <div className="p-2 space-y-0.5 flex-1">
            {originalLines.map((line, i) => {
              const isDifferent = refactoredLines[i] !== line;
              return (
                <div
                  key={`orig_${i}`}
                  className={`flex items-start rounded-xs ${
                    isDifferent ? 'bg-rose-500/15 text-rose-200' : 'text-slate-400'
                  }`}
                >
                  <span className="w-9 select-none text-right pr-2 text-slate-600 font-mono text-[10px] shrink-0">
                    {startLine + i}
                  </span>
                  <span className="w-4 select-none text-center font-bold text-rose-400 shrink-0">
                    {isDifferent ? '-' : ' '}
                  </span>
                  <span className="whitespace-pre overflow-x-auto flex-1">{line || ' '}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Refactored Code */}
        <div className="flex flex-col bg-[#070b12]">
          <div className="px-3 py-2 bg-emerald-500/10 border-b border-emerald-500/20 text-emerald-300 font-sans font-semibold text-[11px] flex items-center justify-between sticky top-0 z-10 backdrop-blur-md">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              AI PROPOSED REFACTOR
            </span>
            <span className="font-mono text-[10px] text-emerald-300/80">{refactoredLines.length} lines</span>
          </div>
          <div className="p-2 space-y-0.5 flex-1">
            {refactoredLines.map((line, i) => {
              const isDifferent = originalLines[i] !== line;
              return (
                <div
                  key={`refac_${i}`}
                  className={`flex items-start rounded-xs ${
                    isDifferent ? 'bg-emerald-500/15 text-emerald-200 font-medium' : 'text-slate-300'
                  }`}
                >
                  <span className="w-9 select-none text-right pr-2 text-emerald-500/60 font-mono text-[10px] shrink-0">
                    {i + 1}
                  </span>
                  <span className="w-4 select-none text-center font-bold text-emerald-400 shrink-0">
                    {isDifferent ? '+' : ' '}
                  </span>
                  <span className="whitespace-pre overflow-x-auto flex-1">{line || ' '}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  // Helper for Unified Diff
  const renderUnifiedDiff = () => {
    const originalLines = selectedCode.split('\n');
    const refactoredLines = (result?.refactoredCode || '').split('\n');

    return (
      <div className="font-mono text-[11px] leading-5 p-3 overflow-auto custom-scrollbar h-full bg-[#06080d] space-y-0.5">
        <div className="text-[10px] text-slate-500 pb-2 border-b border-white/5 font-sans flex items-center justify-between">
          <span>Unified changes for {filePath}</span>
          <span className="text-emerald-400">Green = Addition, Red = Deletion</span>
        </div>
        {/* Render deleted lines */}
        {originalLines.map((line, i) => (
          <div key={`del_${i}`} className="flex items-start bg-rose-500/15 text-rose-200 rounded-xs">
            <span className="w-9 select-none text-right pr-2 text-rose-500/50 text-[10px] shrink-0">
              {startLine + i}
            </span>
            <span className="w-5 text-center text-rose-400 font-bold select-none shrink-0">-</span>
            <span className="whitespace-pre overflow-x-auto flex-1">{line || ' '}</span>
          </div>
        ))}
        {/* Render added lines */}
        {refactoredLines.map((line, i) => (
          <div key={`add_${i}`} className="flex items-start bg-emerald-500/15 text-emerald-200 rounded-xs">
            <span className="w-9 select-none text-right pr-2 text-emerald-500/60 text-[10px] shrink-0">
              {i + 1}
            </span>
            <span className="w-5 text-center text-emerald-400 font-bold select-none shrink-0">+</span>
            <span className="whitespace-pre overflow-x-auto flex-1">{line || ' '}</span>
          </div>
        ))}
      </div>
    );
  };

  const goalsList: Array<{
    id: RefactorGoal;
    label: string;
    icon: any;
    desc: string;
    tag: string;
  }> = [
    {
      id: 'optimize_loops',
      label: 'Optimize Loops & Performance',
      icon: Zap,
      desc: 'Eliminate O(n²) bottlenecks, use Sets/Maps, cache bounds & iterations',
      tag: 'Performance',
    },
    {
      id: 'simplify_logic',
      label: 'Simplify Logic & Conditionals',
      icon: ListTree,
      desc: 'Flatten nested ifs, apply guard clauses, early returns, clean booleans',
      tag: 'Readability',
    },
    {
      id: 'best_practices',
      label: 'Modern Best Practices',
      icon: ShieldCheck,
      desc: 'ES2022+ standards, const/let, optional chaining (?.) and nullish checks (??)',
      tag: 'Standards',
    },
    {
      id: 'extract_helpers',
      label: 'Extract Helper Functions',
      icon: Layers,
      desc: 'Decompose monolithic procedures into modular, testable pure functions',
      tag: 'Architecture',
    },
    {
      id: 'error_handling',
      label: 'Defensive Error Handling',
      icon: Bug,
      desc: 'Safe null/undefined checks, boundary guards, and structured try/catch',
      tag: 'Reliability',
    },
    {
      id: 'custom',
      label: 'Custom Instruction',
      icon: Sliders,
      desc: 'Specify your exact refactoring goals or prompt in your own words',
      tag: 'Custom',
    },
  ];

  const quickPromptChips = [
    'Convert to async/await and memoize results',
    'Replace nested loop with Map/Set lookup',
    'Use early return guard clauses to flatten',
    'Upgrade to optional chaining and nullish coalescing',
    'Add defensive error handling with try/catch',
    'Extract into reusable helper function',
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
      <div className="w-full max-w-5xl h-[90vh] flex flex-col rounded-2xl glass-dropdown border border-cyan-500/30 shadow-2xl overflow-hidden text-xs">
        {/* Top Header */}
        <div className="p-4 border-b border-white/10 bg-[#0a0d16] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/25">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-tight">AI Code Refactoring Studio</h2>
                <span className="px-2 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 font-mono text-[10px]">
                  {filePath}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-white/5 text-slate-400 font-mono text-[10px]">
                  Lines {startLine}–{endLine} ({selectedCode.split('\n').length} lines)
                </span>
              </div>
              <p className="text-slate-400 text-[11px] mt-0.5">
                Optimize algorithms, simplify branching logic, adhere to standards, and verify changes with precision diff.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl border border-white/10 hover:bg-white/10 text-slate-400 hover:text-white transition cursor-pointer"
            title="Close Refactor Studio (Esc)"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Main Body */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          {/* Left Column: Configuration & Goals (Collapsible on mobile or 360px on desktop) */}
          <div className="w-full md:w-84 border-r border-white/10 bg-[#07090f] p-4 flex flex-col overflow-y-auto space-y-4 shrink-0">
            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-2">
                1. Select Refactoring Goal
              </label>
              <div className="grid grid-cols-1 gap-1.5">
                {goalsList.map((g) => {
                  const Icon = g.icon;
                  const isSelected = goal === g.id;
                  return (
                    <button
                      key={g.id}
                      onClick={() => setGoal(g.id)}
                      className={`text-left p-2.5 rounded-xl border transition flex items-start gap-2.5 cursor-pointer ${
                        isSelected
                          ? 'border-cyan-400/80 bg-cyan-500/10 text-white shadow-md shadow-cyan-500/10'
                          : 'border-white/5 bg-white/[0.02] text-slate-300 hover:border-white/20 hover:bg-white/[0.04]'
                      }`}
                    >
                      <div
                        className={`p-1.5 rounded-lg shrink-0 mt-0.5 ${
                          isSelected ? 'bg-cyan-500/20 text-cyan-300' : 'bg-white/5 text-slate-400'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-xs truncate">{g.label}</span>
                          <span
                            className={`text-[9px] px-1.5 py-0.2 rounded font-mono ${
                              isSelected ? 'bg-cyan-500/30 text-cyan-200' : 'bg-white/5 text-slate-500'
                            }`}
                          >
                            {g.tag}
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-400 mt-0.5 line-clamp-2 leading-relaxed">{g.desc}</p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Custom Instruction Prompt Input */}
            <div>
              <label className="text-[11px] font-bold text-slate-300 uppercase tracking-wider block mb-1.5">
                2. Custom Prompt / Specifics (Optional)
              </label>
              <textarea
                value={customInstruction}
                onChange={(e) => setCustomInstruction(e.target.value)}
                placeholder="e.g. Optimize for memory, remove nested loops, rename variables descriptively..."
                rows={2}
                className="w-full bg-[#111420] border border-white/10 rounded-xl p-2 text-xs text-white placeholder-slate-500 focus:border-cyan-400 outline-none resize-none"
              />

              {/* Quick suggestion chips */}
              <div className="mt-2 space-y-1">
                <span className="text-[10px] text-slate-500 block">Quick presets:</span>
                <div className="flex flex-wrap gap-1">
                  {quickPromptChips.map((chip, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCustomInstruction(chip)}
                      className="px-2 py-0.5 rounded-full bg-white/5 hover:bg-cyan-500/10 text-[10px] text-slate-400 hover:text-cyan-300 border border-white/5 hover:border-cyan-500/30 transition text-left cursor-pointer truncate max-w-full"
                    >
                      {chip}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Generate Action Button */}
            <div className="pt-2">
              <button
                onClick={() => handleGenerate()}
                disabled={isLoading}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 cursor-pointer"
              >
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>Refactoring with AI...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-cyan-200" />
                    <span>{result ? 'Re-Generate Refactoring' : 'Generate Refactoring'}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Right Column: Code Review, Diff Viewer & Approval Gate */}
          <div className="flex-1 flex flex-col overflow-hidden bg-[#07090e]">
            {isLoading && (
              <div className="h-full flex flex-col items-center justify-center p-8 text-center space-y-4">
                <div className="relative">
                  <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 animate-pulse">
                    <Sparkles className="w-8 h-8" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-cyan-400 animate-ping"></div>
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Analyzing Code Architecture</h3>
                  <p className="text-xs text-cyan-400/90 font-mono mt-1">
                    {loadingStep === 0 && 'Parsing AST & inspecting dependencies...'}
                    {loadingStep === 1 && 'Detecting nested loops & big-O complexity...'}
                    {loadingStep === 2 && 'Synthesizing modern idioms & guard clauses...'}
                    {loadingStep === 3 && 'Validating semantic output & rendering diff...'}
                  </p>
                </div>
                <div className="w-64 h-1.5 rounded-full bg-white/10 overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full animate-[shimmer_2s_infinite] w-full"></div>
                </div>
              </div>
            )}

            {!isLoading && error && (
              <div className="h-full flex flex-col items-center justify-center p-8 text-center space-y-3">
                <AlertTriangle className="w-10 h-10 text-rose-400" />
                <h3 className="text-sm font-bold text-white">Refactoring Failed</h3>
                <p className="text-xs text-rose-300 max-w-md">{error}</p>
                <button
                  onClick={() => handleGenerate()}
                  className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-semibold cursor-pointer"
                >
                  Try Again
                </button>
              </div>
            )}

            {!isLoading && !error && !result && (
              <div className="h-full flex flex-col overflow-hidden">
                <div className="p-3 border-b border-white/5 bg-[#0a0d16] flex items-center justify-between">
                  <span className="text-slate-400 font-mono text-[11px] flex items-center gap-1.5">
                    <FileCode className="w-3.5 h-3.5 text-cyan-400" />
                    Selected Code Snippet (Target for Refactoring)
                  </span>
                  <span className="text-slate-500 text-[10px]">
                    Click &apos;Generate Refactoring&apos; on the left to start
                  </span>
                </div>
                <div className="flex-1 p-4 font-mono text-[11px] leading-relaxed text-slate-300 overflow-auto custom-scrollbar whitespace-pre bg-[#07090e]">
                  {selectedCode}
                </div>
              </div>
            )}

            {!isLoading && !error && result && (
              <div className="h-full flex flex-col overflow-hidden">
                {/* AI Review & Summary Card */}
                <div className="p-3 border-b border-white/10 bg-[#0a0d16] space-y-2 shrink-0">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-[10px] tracking-wide uppercase border border-emerald-500/30">
                          PROPOSAL READY
                        </span>
                        <h3 className="text-sm font-bold text-white">{result.title}</h3>
                      </div>
                      <p className="text-[11px] text-slate-300 mt-0.5 leading-snug">{result.summary}</p>
                    </div>

                    {/* Metrics Badges */}
                    <div className="flex items-center gap-1.5 font-mono text-[10px]">
                      <div className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-slate-300">
                        <span className="text-slate-500 block text-[9px] uppercase font-sans">Complexity</span>
                        <span className="text-cyan-400 font-bold">
                          {result.metrics.complexityBefore} → {result.metrics.complexityAfter}
                        </span>
                      </div>
                      <div className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-slate-300">
                        <span className="text-slate-500 block text-[9px] uppercase font-sans">Lines Delta</span>
                        <span className="text-emerald-400 font-bold">{result.metrics.linesChange}</span>
                      </div>
                      <div className="px-2.5 py-1 rounded-lg bg-white/5 border border-white/10 text-slate-300">
                        <span className="text-slate-500 block text-[9px] uppercase font-sans">Readability</span>
                        <span className="text-purple-400 font-bold">{result.metrics.readabilityScore}/100</span>
                      </div>
                    </div>
                  </div>

                  {/* Bullet points of improvements */}
                  {result.improvements && result.improvements.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pt-1 border-t border-white/5">
                      {result.improvements.map((imp, idx) => (
                        <div
                          key={idx}
                          className="px-2 py-1 rounded-lg bg-[#111422] border border-white/5 flex items-center gap-1.5 text-[10px]"
                        >
                          <span
                            className={`w-1.5 h-1.5 rounded-full ${
                              imp.type === 'performance'
                                ? 'bg-amber-400'
                                : imp.type === 'security'
                                ? 'bg-emerald-400'
                                : 'bg-cyan-400'
                            }`}
                          ></span>
                          <span className="font-semibold text-slate-200">{imp.title}:</span>
                          <span className="text-slate-400 truncate max-w-xs">{imp.description}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Diff Viewer Toolbar & Switcher */}
                <div className="h-9 px-3 border-b border-white/5 bg-[#080b12] flex items-center justify-between text-xs select-none shrink-0">
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] text-slate-500 mr-1 uppercase font-semibold">Diff View:</span>
                    <button
                      onClick={() => setDiffViewMode('split')}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition cursor-pointer ${
                        diffViewMode === 'split'
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                      }`}
                    >
                      Side-by-Side
                    </button>
                    <button
                      onClick={() => setDiffViewMode('unified')}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition cursor-pointer ${
                        diffViewMode === 'unified'
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                      }`}
                    >
                      Unified
                    </button>
                    <button
                      onClick={() => setDiffViewMode('full')}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-medium transition cursor-pointer ${
                        diffViewMode === 'full'
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                          : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                      }`}
                    >
                      Full File Preview
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleCopyCode}
                      className="flex items-center gap-1 px-2 py-1 rounded hover:bg-white/10 text-slate-400 hover:text-cyan-400 transition cursor-pointer text-[11px]"
                    >
                      {isCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{isCopied ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                </div>

                {/* Diff Viewer Area */}
                <div className="flex-1 overflow-hidden relative">
                  {diffViewMode === 'split' && renderSplitDiff()}
                  {diffViewMode === 'unified' && renderUnifiedDiff()}
                  {diffViewMode === 'full' && (
                    <div className="h-full flex flex-col font-mono text-[11px] leading-5 bg-[#06080d] p-3 overflow-auto custom-scrollbar">
                      <div className="text-[10px] text-slate-500 pb-2 border-b border-white/5 font-sans flex items-center justify-between">
                        <span>Full file preview with refactoring applied</span>
                        <span className="font-mono text-cyan-400">{filePath}</span>
                      </div>
                      <div className="whitespace-pre text-slate-300 flex-1 pt-2">{getFullFilePreview()}</div>
                    </div>
                  )}
                </div>

                {/* Explicit Approval & Rejection Gateway Footer */}
                <div className="p-3.5 border-t border-white/10 bg-[#0a0d16] flex items-center justify-between shrink-0">
                  <div className="flex items-center gap-2 text-slate-400 text-xs">
                    <CheckCircle2 className="w-4 h-4 text-cyan-400" />
                    <span>Explicit approval required. Original code remains unchanged until you approve.</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={onClose}
                      className="flex items-center gap-1.5 px-4 py-2 rounded-xl border border-rose-500/30 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 font-medium transition cursor-pointer text-xs"
                      title="Reject changes and keep original code"
                    >
                      <X className="w-4 h-4 text-rose-400" />
                      <span>Reject & Discard</span>
                    </button>

                    <button
                      onClick={handleApprove}
                      className="flex items-center gap-2 px-6 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs shadow-lg shadow-cyan-500/30 transition-all hover:scale-[1.01] active:scale-[0.99] cursor-pointer"
                      title="Approve changes and replace code in editor"
                    >
                      <Check className="w-4 h-4" />
                      <span>Approve & Apply Refactor</span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
