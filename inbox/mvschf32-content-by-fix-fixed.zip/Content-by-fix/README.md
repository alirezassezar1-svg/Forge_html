# AETHERIS / Nononick Content Studio (Flat structure)

ساختار کاملاً فلت — همه فایل‌ها در ریشه برای کار راحت با موبایل.

## اجرا

```bash
npm install
cp .env.example .env.local
# GEMINI_API_KEY را تنظیم کنید
npm run dev
```

## فایل‌های اصلی
- `main.tsx` / `App.tsx` — نقطه ورود
- `*View.tsx` — صفحات و ویوها
- `media.ts` / `types.ts` — تایپ‌ها
- `mediaData.ts` و سایر data — داده‌ها
- تصاویر jpg در ریشه
- `server.ts` — سرور Express + Vite

## Production / live deploy

```
npm install
npm run build
NODE_ENV=production PORT=3000 npm start
```

The app needs a Node.js server (Express serves dist/ and the /api/* routes), so static hosts like GitHub Pages will not work. Use a Node host (Render, Railway, Fly.io, VPS, or cPanel Setup Node.js App) with start command `npm start`.
