WebMirror Studio — PWA Export

This is an installable Progressive Web App.

Files:
- index.html — main page (links manifest + service worker)
- css/style.css — all styles
- js/script.js — interaction scripts (if any)
- manifest.json — PWA manifest
- sw.js — service worker for offline caching

To install: open index.html in a modern browser and use Add to Home Screen.
For full PWA features, serve from any static host (e.g. GitHub Pages, Netlify).