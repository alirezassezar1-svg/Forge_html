# NONONICK — iOS Home Screen Portfolio OS

A digital portfolio, interactive engineering workspace, and service hub for **NONONICK**, inspired by the iPhone Home Screen, iOS widgets, Dynamic Island, and Apple's refined interaction design.

---

## 🌟 Key Features

1. **iOS Home Screen Paradigm**:
   - Realistic **Status Bar** with live local clock, date, clearly labeled simulated 5G & battery indicators, and a center interactive **Dynamic Island**.
   - **Dynamic Island Hub**: Tap to expand into a live procedural Web Audio Lo-Fi ambient synthesizer, OS availability status, and 1-click email copy.
   - **Hero Identity Widget**: NONONICK wordmark, time-aware greeting, personal bio, and an interactive 3D mathematical generative orb with cursor deflection.
   - **Smart Widgets**:
     - *Featured Project*: Spotlight with direct launch.
     - *Services*: 4 core offerings (Website Development, Custom Web Tools, Live Editing, Site Management).
     - *Project Activity*: Verifiable live breakdown of catalog states (Live, In Development, Experimental).
     - *Quick Contact*: 1-click clipboard copy and direct mailto.
     - *About Me*: Concise engineering statement and story launcher.
     - *Digital Experiments*: Live interactive 2D canvas particle physics toy.
   - **App Grid & Virtual Pages**: Page 1 & Page 2 pagination with smooth transitions.
   - **iOS Jiggle Mode**: Tap "Toggle Edit Mode" in Dynamic Island or Settings to make icons wobble and move apps between pages with persistent `localStorage` saving.
   - **Floating Translucent Dock**: Home, Projects Library, Services, About, Contact, and Settings with micro-magnification and active indicators.
   - **Spotlight Search (`⌘K` / `Ctrl+K`)**: Instant search across projects, services, tags, and technologies.
   - **Bilingual English & Persian (فارسی)**: Instant RTL/LTR flip, custom typography pairing (`Plus Jakarta Sans` & `Vazirmatn`).
   - **Zero-Dependency Web Audio Haptics**: Procedural synthesized micro-clicks and airy chimes without external media files.

---

## 📁 Project Structure

```
├── index.html                   # HTML entry point with Plus Jakarta Sans & Vazirmatn fonts
├── metadata.json                # AI Studio application metadata
├── src/
│   ├── App.tsx                  # Root Home Screen OS shell, page coordinator & dock
│   ├── main.tsx                 # React DOM mount point
│   ├── index.css                # Tailwind CSS v4, iOS glassmorphism & jiggle keyframes
│   ├── types/
│   │   └── index.ts             # TypeScript interfaces for projects, services, and OS settings
│   ├── data/
│   │   ├── projectsData.ts      # Project catalog configuration (add/edit your projects here)
│   │   ├── servicesData.ts      # 4 core services with scopes, deliverables & turnarounds
│   │   └── translations.ts      # Bilingual English & Persian translations dictionary
│   ├── utils/
│   │   └── audio.ts             # Zero-dependency Web Audio synthesizer engine
│   └── components/
│       ├── StatusBar.tsx        # Live time, simulated network/battery, Dynamic Island mount
│       ├── DynamicIsland.tsx    # Expandable pill with procedural audio synth & controls
│       ├── AppIcon.tsx          # Authentic iOS squircle icon with sheen & jiggle wobble
│       ├── Dock.tsx             # Floating translucent dock with active tabs
│       ├── SpotlightSearch.tsx  # Global search & filter overlay with ⌘K support
│       ├── widgets/
│       │   ├── HeroWidget.tsx             # Large identity widget with time greeting
│       │   ├── InteractiveOrb.tsx         # 3D Fibonacci sphere canvas
│       │   ├── FeaturedProjectWidget.tsx  # Spotlight project card
│       │   ├── ServicesWidget.tsx         # Quick services preview card
│       │   ├── ProjectActivityWidget.tsx  # Verifiable project stats
│       │   ├── QuickContactWidget.tsx     # Fast copy & email trigger
│       │   ├── AboutMeWidget.tsx          # Bio preview
│       │   ├── DigitalExperimentsWidget.tsx # Interactive physics playground card
│       │   └── DigitalExperimentsCanvas.tsx # 60fps kinetic particle canvas
│       └── modals/
│           ├── ProjectDetailModal.tsx     # Sheet window with live interactive prototypes
│           ├── ProjectsLibraryModal.tsx   # Full App Store catalog with search & filters
│           ├── ServicesModal.tsx          # Comprehensive services guide with inquiry flow
│           ├── AboutModal.tsx             # Full story, core philosophy & vCard download
│           ├── ContactModal.tsx           # Contact form with validation & mailto dispatch
│           └── SettingsModal.tsx          # Wallpapers, language, haptics, iPhone frame toggle
```

---

## 🛠️ Adding Your Real Projects and URLs

To update or add your real projects, open `src/data/projectsData.ts`. Each project object follows this schema:

```typescript
{
  id: 'your-project-id',
  name: 'Project Name',
  nameFa: 'نام پروژه به فارسی',
  category: 'web', // 'web' | 'ai' | 'tools' | 'audio' | 'experiments' | 'system'
  categoryFa: 'وب و برند',
  status: 'Live', // 'Live' | 'In Development' | 'Experimental'
  statusFa: 'آنلاین',
  description: 'Short 1-line summary.',
  descriptionFa: 'توضیح کوتاه یک خطی.',
  longDescription: 'Detailed architectural overview.',
  longDescriptionFa: 'توضیحات کامل فارسی.',
  technologies: ['React', 'TypeScript', 'Tailwind'],
  accentColor: '#0A84FF',
  gradient: 'from-blue-600 via-indigo-600 to-cyan-500',
  iconName: 'Globe', // 'Globe' | 'Sparkles' | 'Server' | 'Headphones' | 'Shapes' | 'Wrench' | 'Smartphone' | 'FlaskConical'
  projectUrl: 'https://your-domain.com', // Verified URL (or null for internal showcase)
  repoUrl: 'https://github.com/your-username/repo', // Optional repo URL (or null)
  featured: true, // Highlights on Home Screen
  displayOrder: 1,
  page: 1, // 1 or 2
  highlights: ['Key point 1', 'Key point 2'],
  highlightsFa: ['نکته کلیدی ۱', 'نکته کلیدی ۲']
}
```

---

## 🚀 Deployment Instructions

### 1. Build for Production
Run the standard build command:
```bash
npm run build
```
This generates an optimized, minified static distribution inside the `dist/` directory.

### 2. Deploying to cPanel Hosting
1. Log into your **cPanel** dashboard.
2. Open **File Manager** and navigate to your web root (`public_html` or your designated subdomain directory).
3. Upload all files from the generated `dist/` folder directly into `public_html/`.
4. Ensure an `.htaccess` file is present in `public_html/` to support SPA routing:
```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```
5. Ensure HTTPS / SSL is active via cPanel's **AutoSSL** or **Let's Encrypt**.

### 3. Deploying to GitHub Pages
1. Push this repository to GitHub.
2. If using GitHub Actions, configure a static deployment workflow targeting the `dist/` folder generated by `npm run build`.
3. In your repository settings under **Pages**, set the source to **GitHub Actions**.
