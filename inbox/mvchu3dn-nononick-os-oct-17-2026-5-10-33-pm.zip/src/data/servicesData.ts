import { ServiceItem } from '../types';

export const servicesData: ServiceItem[] = [
  {
    id: 'website-development',
    title: 'Website Development',
    titleFa: 'توسعه وب‌سایت‌های مدرن',
    shortDesc: 'Bespoke, high-performance web applications and flagships with tactile iOS-level polish.',
    shortDescFa: 'طراحی و پیاده‌سازی وب‌سایت‌ها و وب‌اپلیکیشن‌های اختصاصی پرسرعت با استاندارد رابط کاربری اپل.',
    description: 'Engineering responsive, accessible, and cinematic web experiences tailored to your brand identity. Combining lightning-fast load times, robust TypeScript architectures, and custom animations that elevate your digital presence above standard templates.',
    descriptionFa: 'توسعه وب‌سایت‌های واکنش‌گرا و مدرن متناسب با هویت برند شما؛ با ترکیب سرعت بارگذاری فوق‌العاده، معماری قدرتمند تایپ‌اسکریپت و انیمیشن‌های روان.',
    deliverables: [
      'Custom React / Next.js / Vite SPA or SSR architecture',
      'Fluid responsiveness for mobile, tablet, and ultra-wide screens',
      'WCAG AA accessible markup & semantic HTML hierarchy',
      'SEO optimization, OpenGraph cards & Core Web Vitals scores > 95',
      'Interactive micro-animations & custom stateful components'
    ],
    deliverablesFa: [
      'معماری اختصاصی React، Next.js یا Vite',
      'پاسخ‌دهی دقیق در موبایل، تبلت و مانیتورهای عریض',
      'دسترسی‌پذیری طبق استاندارد WCAG AA و سئو ساختاریافته',
      'امتیاز سرعت بالای ۹۵ در Core Web Vitals گوگل',
      'ریزتعامل‌های جذاب و کامپوننت‌های سفارشی'
    ],
    techFocus: ['React 19', 'TypeScript', 'Tailwind CSS', 'Vite', 'Motion', 'Node.js'],
    turnaround: '2 - 4 weeks',
    turnaroundFa: '۲ الی ۴ هفته',
    iconName: 'Layout',
    accentColor: '#0A84FF'
  },
  {
    id: 'custom-web-tools',
    title: 'Custom Web Tools',
    titleFa: 'ابزارهای سفارشی وب',
    shortDesc: 'Internal developer utilities, interactive calculators, and specialized browser software.',
    shortDescFa: 'توسعه ابزارهای اختصاصی تحت وب، محاسبه‌گرهای پیشرفته و نرم‌افزارهای داخلی کسب‌وکار.',
    description: 'Transforming complex manual workflows, repetitive tasks, and technical requirements into intuitive, zero-friction browser software. Focused on local-first performance, offline resilience, and clean ergonomic design.',
    descriptionFa: 'تبدیل فرآیندهای پیچیده و کارهای زمان‌بر به ابزارهای هوشمند تحت وب با تمرکز بر عملکرد لحظه‌ای، پشتیبانی آفلاین و طراحی ارگونومیک.',
    deliverables: [
      'Tailored browser calculators, data transformers, & converters',
      'Local-first data persistence (IndexedDB / localStorage)',
      'Real-time data visualization charts and SVG graphs',
      'Export capabilities (CSV, JSON, PDF, clipboard formats)',
      'Zero-latency client-side processing without third-party leaks'
    ],
    deliverablesFa: [
      'ابزارهای تبدیل داده، پردازشگرهای متنی و فرمول‌های محاسباتی',
      'ذخیره‌سازی اطلاعات به صورت لوکال (IndexedDB / localStorage)',
      'نمایشگرهای تعاملی و نمودارهای لحظه‌ای',
      'خروجی با فرمت‌های مختلف (PDF, CSV, JSON)',
      'پردازش فوق‌سریع در مرورگر بدون کندی یا ارسال اطلاعات غیرضروری'
    ],
    techFocus: ['TypeScript', 'Canvas API', 'Web Workers', 'Tailwind', 'IndexedDB'],
    turnaround: '1 - 3 weeks',
    turnaroundFa: '۱ الی ۳ هفته',
    iconName: 'Wrench',
    accentColor: '#FF9F0A'
  },
  {
    id: 'live-editing',
    title: 'Live Editing & Interactive Systems',
    titleFa: 'سیستم‌های ویرایش زنده و تعاملی',
    shortDesc: 'Real-time preview canvases, drag-and-drop builders, and dynamic visual generators.',
    shortDescFa: 'محیط‌های پیش‌نمایش آنی، ابزارهای Drag-and-Drop و بوم‌های گرافیکی پویا.',
    description: 'Crafting responsive WYSIWYG interfaces, interactive code/prompt sandboxes, and generative canvases where user changes render with zero perceptual lag.',
    descriptionFa: 'ساخت ابزارهای تعاملی پیشرفته با قابلیت مشاهده بلادرنگ تغییرات، ویرایشگرهای بصری و بوم‌های متحرک با پاسخ‌دهی زیر ۱۰۰ میلی‌ثانیه.',
    deliverables: [
      'Interactive canvas workspaces and visual property editors',
      'Drag-and-drop layout arrangements with fluid physics',
      'Live code/text parsing and syntax-highlighted preview',
      'Undo/redo state management stacks with history timeline',
      'Touch and stylus gesture support for tablets and phones'
    ],
    deliverablesFa: [
      'بوم‌های گرافیکی تعاملی و پنل‌های تنظیمات بصری',
      'چیدمان عناصر با کشیدن و رها کردن و فیزیک طبیعی حرکات',
      'پیش‌نمایش آنی کد و متن با هایلایت سینتکس',
      'مدیریت تاریخچه تغییرات (Undo/Redo)',
      'پشتیبانی از ژست‌های لمسی و قلم در تبلت و موبایل'
    ],
    techFocus: ['Canvas API', 'WebGL', 'State Machines', 'Framer Motion', 'TypeScript'],
    turnaround: '2 - 5 weeks',
    turnaroundFa: '۲ الی ۵ هفته',
    iconName: 'Sparkles',
    accentColor: '#BF5AF2'
  },
  {
    id: 'site-management',
    title: 'Site Management & Modernization',
    titleFa: 'مدیریت و بهینه‌سازی وب‌سایت',
    shortDesc: 'Performance audits, technical updates, cPanel/VPS deployments, and ongoing engineering.',
    shortDescFa: 'بهینه‌سازی سرعت و امنیت، ارتقای کدهای فرسوده، استقرار روی سرور و پشتیبانی فنی مداوم.',
    description: 'Ensuring your production web presence remains secure, blazingly fast, and completely up to date. From resolving elusive CSS layout bugs to configuring CI/CD pipelines and fine-tuning server environments.',
    descriptionFa: 'اطمینان از کارکرد پایدار، امن و پرسرعت وب‌سایت شما؛ شامل رفع باگ‌های فنی، تنظیمات استقرار بر روی سرور یا هاست سی‌پنل و نظارت کیفی.',
    deliverables: [
      'Core Web Vitals and Lighthouse 100/100 performance audits',
      'Legacy codebase modernizations (migrating to TypeScript & modern bundlers)',
      'cPanel, VPS, Nginx, or Cloud Run deployment configurations',
      'Domain, SSL certificate, and security header hardening',
      'Scheduled maintenance, security patches, and continuous monitoring'
    ],
    deliverablesFa: [
      'بهینه‌سازی حداکثری سرعت در تست‌های گوگل لایت‌هاوس',
      'مدرن‌سازی کدهای قدیمی و ارتقا به تایپ‌اسکریپت',
      'تنظیمات استقرار روی هاست‌های cPanel، سرورهای لینوکس یا سرویس‌های ابری',
      'پیکربندی گواهینامه‌های امنیتی SSL و تنظیمات امنیتی وب',
      'پشتیبانی دوره‌ای، رفع اشکالات و بروزرسانی‌های ضروری'
    ],
    techFocus: ['Performance Auditing', 'Nginx', 'cPanel', 'Git', 'Vite', 'Docker'],
    turnaround: 'Ongoing / Sprint-based',
    turnaroundFa: 'پیوسته / بر مبنای پروژه',
    iconName: 'ShieldCheck',
    accentColor: '#30D158'
  }
];
