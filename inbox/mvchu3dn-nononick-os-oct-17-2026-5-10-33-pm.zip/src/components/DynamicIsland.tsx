import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Volume2, VolumeX, Play, Pause, Copy, Check, Globe, Sliders } from 'lucide-react';
import { audio } from '../utils/audio';
import { Language } from '../types';
import { translations } from '../data/translations';

interface DynamicIslandProps {
  lang: Language;
  onToggleLang: () => void;
  onToggleEditMode: () => void;
  isEditMode: boolean;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const DynamicIsland: React.FC<DynamicIslandProps> = ({
  lang,
  onToggleLang,
  onToggleEditMode,
  isEditMode,
  soundEnabled,
  onToggleSound
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isPlaying, setIsPlaying] = useState(audio.getIsAmbientPlaying());
  const [copiedEmail, setCopiedEmail] = useState(false);
  const t = translations[lang];

  const handleToggleAudio = (e: React.MouseEvent) => {
    e.stopPropagation();
    audio.playClick('tap');
    const newState = audio.toggleAmbientSynth();
    setIsPlaying(newState);
  };

  const handleCopyEmail = (e: React.MouseEvent) => {
    e.stopPropagation();
    audio.playClick('tap');
    navigator.clipboard.writeText('alirezassezar.1@gmail.com');
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2200);
  };

  return (
    <div className="relative z-50 flex items-center justify-center">
      {/* Collapsed Dynamic Island Pill */}
      <motion.button
        type="button"
        layoutId="dynamic-island"
        onClick={() => {
          audio.playClick('open');
          setIsExpanded(!isExpanded);
        }}
        className={`group relative flex items-center justify-between gap-3 px-3.5 py-1.5 bg-black/90 hover:bg-black text-white rounded-full border border-white/15 shadow-2xl transition-all cursor-pointer ${
          isExpanded ? 'opacity-0 pointer-events-none' : 'opacity-100'
        }`}
        style={{ minWidth: '150px', height: '34px' }}
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        aria-label="Dynamic Island Hub"
      >
        {/* Left: simulated sensor & indicator */}
        <div className="flex items-center gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-slate-800 border border-white/20 relative">
            <div className="absolute inset-0.5 rounded-full bg-cyan-400/80 animate-pulse" />
          </div>
          <span className="text-[11px] font-medium tracking-tight text-white/90">
            NONONICK
          </span>
        </div>

        {/* Right: mini animated visualizer or status */}
        <div className="flex items-center gap-1.5">
          {isPlaying ? (
            <div className="flex items-end gap-0.5 h-3">
              <span className="w-0.5 bg-cyan-400 h-2 animate-bounce" />
              <span className="w-0.5 bg-cyan-400 h-3 animate-pulse" />
              <span className="w-0.5 bg-cyan-400 h-1.5 animate-bounce" />
            </div>
          ) : (
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_8px_#30d158]" />
          )}
          <span className="text-[10px] text-white/60 font-mono">
            {isPlaying ? 'AUDIO' : 'ONLINE'}
          </span>
        </div>
      </motion.button>

      {/* Expanded Dynamic Island Flyout Overlay */}
      <AnimatePresence>
        {isExpanded && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                audio.playClick('close');
                setIsExpanded(false);
              }}
              className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              layoutId="dynamic-island"
              initial={{ opacity: 0, scale: 0.92, y: -10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.92, y: -10 }}
              transition={{ type: 'spring', damping: 28, stiffness: 350 }}
              className="absolute top-0 z-50 w-[92vw] max-w-sm sm:max-w-md bg-zinc-950/95 text-white rounded-[28px] border border-white/20 p-5 shadow-2xl backdrop-blur-2xl"
            >
              {/* Header row */}
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-emerald-500 shadow-[0_0_10px_#10b981]" />
                  <span className="text-xs font-semibold tracking-wider text-white">
                    NONONICK OS STATUS
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    audio.playClick('close');
                    setIsExpanded(false);
                  }}
                  className="px-2 py-0.5 rounded-full text-xs text-white/60 hover:text-white bg-white/10 hover:bg-white/20 transition-colors"
                >
                  {t.modal.close}
                </button>
              </div>

              {/* Status Message */}
              <div className="my-3.5 p-3 rounded-xl bg-white/[0.05] border border-white/10">
                <div className="text-xs text-white/90 leading-relaxed font-normal">
                  {t.dynamicIsland.availableStatus}
                </div>
                <div className="mt-1 text-[11px] text-cyan-400 font-mono">
                  Primary: TypeScript · React · Creative UI
                </div>
              </div>

              {/* Web Audio Ambient Player */}
              <div className="p-3.5 rounded-2xl bg-gradient-to-r from-blue-950/40 via-purple-950/30 to-zinc-900/40 border border-white/10 my-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <button
                      type="button"
                      onClick={handleToggleAudio}
                      className="w-9 h-9 rounded-full bg-cyan-500 hover:bg-cyan-400 text-black flex items-center justify-center transition-transform active:scale-95 shadow-lg shadow-cyan-500/20"
                    >
                      {isPlaying ? <Pause size={16} /> : <Play size={16} className="ml-0.5" />}
                    </button>
                    <div>
                      <div className="text-xs font-medium text-white flex items-center gap-1.5">
                        {t.dynamicIsland.nowPlaying}
                        {isPlaying && (
                          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                        )}
                      </div>
                      <div className="text-[10px] text-white/60">
                        {t.dynamicIsland.lofiTrack}
                      </div>
                    </div>
                  </div>

                  {/* Frequency Wave Animation */}
                  <div className="flex items-end gap-1 h-5 px-2">
                    {[6, 14, 18, 10, 16, 12, 8].map((h, i) => (
                      <span
                        key={i}
                        className={`w-1 rounded-full transition-all duration-300 ${
                          isPlaying ? 'bg-cyan-400' : 'bg-white/20'
                        }`}
                        style={{
                          height: isPlaying ? `${Math.max(4, (h * (i % 2 === 0 ? 1.2 : 0.8)))}px` : '4px'
                        }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Quick Actions Grid */}
              <div className="grid grid-cols-2 gap-2 mt-3">
                <button
                  type="button"
                  onClick={handleCopyEmail}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-xs text-white transition-colors"
                >
                  {copiedEmail ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
                  <span className="truncate">
                    {copiedEmail ? t.dynamicIsland.emailCopied : t.dynamicIsland.copyEmail}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    audio.playClick('switch');
                    onToggleLang();
                  }}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-xs text-white transition-colors"
                >
                  <Globe size={14} className="text-cyan-400" />
                  <span>{t.dynamicIsland.langToggle}</span>
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    audio.playClick('tap');
                    onToggleEditMode();
                  }}
                  className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs transition-colors ${
                    isEditMode
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : 'bg-white/10 hover:bg-white/15 text-white'
                  }`}
                >
                  <Sliders size={14} />
                  <span>{isEditMode ? 'Lock Apps' : t.dynamicIsland.editMode}</span>
                </button>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleSound();
                  }}
                  className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-xs text-white transition-colors"
                >
                  {soundEnabled ? <Volume2 size={14} className="text-emerald-400" /> : <VolumeX size={14} className="text-white/40" />}
                  <span>{soundEnabled ? 'Haptics ON' : 'Haptics OFF'}</span>
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};
