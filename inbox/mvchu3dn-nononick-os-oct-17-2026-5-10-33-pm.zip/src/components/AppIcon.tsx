import React from 'react';
import { motion } from 'motion/react';
import {
  Globe,
  Sparkles,
  Server,
  Headphones,
  Shapes,
  Wrench,
  Smartphone,
  FlaskConical,
  ArrowRightLeft,
  X
} from 'lucide-react';
import { Project, Language } from '../types';
import { audio } from '../utils/audio';

interface AppIconProps {
  project: Project;
  lang: Language;
  onOpen: (project: Project) => void;
  isEditMode: boolean;
  onMovePage?: (projectId: string) => void;
  index: number;
}

const iconMap: Record<string, React.ElementType> = {
  Globe,
  Sparkles,
  Server,
  Headphones,
  Shapes,
  Wrench,
  Smartphone,
  FlaskConical
};

export const AppIcon: React.FC<AppIconProps> = ({
  project,
  lang,
  onOpen,
  isEditMode,
  onMovePage,
  index
}) => {
  const IconComponent = iconMap[project.iconName] || Globe;
  const displayName = lang === 'fa' ? project.nameFa : project.name;

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isEditMode) return;
    audio.playClick('open');
    onOpen(project);
  };

  const getStatusColor = () => {
    switch (project.status) {
      case 'Live':
        return 'bg-emerald-400';
      case 'In Development':
        return 'bg-amber-400';
      case 'Experimental':
        return 'bg-cyan-400';
      default:
        return 'bg-blue-400';
    }
  };

  return (
    <div className="flex flex-col items-center group relative select-none w-20 sm:w-24">
      {/* Jiggle container in edit mode */}
      <motion.div
        className={`relative ${
          isEditMode
            ? index % 2 === 0
              ? 'animate-jiggle-1'
              : 'animate-jiggle-2'
            : ''
        }`}
        whileHover={isEditMode ? {} : { scale: 1.08, y: -2 }}
        whileTap={isEditMode ? {} : { scale: 0.94 }}
        transition={{ type: 'spring', damping: 20, stiffness: 400 }}
      >
        {/* App Squircle Button */}
        <button
          type="button"
          onClick={handleClick}
          aria-label={displayName}
          className={`relative w-16 h-16 sm:w-18 sm:h-18 ios-squircle p-0 flex items-center justify-center bg-gradient-to-br ${project.gradient} border border-white/25 ios-app-shadow transition-shadow group-hover:shadow-[0_12px_28px_rgba(0,0,0,0.7)] overflow-hidden cursor-pointer`}
        >
          {/* Subtle gloss highlight on top half of icon */}
          <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/30 to-transparent pointer-events-none" />

          {/* Icon center */}
          <IconComponent
            size={28}
            className="text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.4)] relative z-10"
          />

          {/* Bottom subtle edge shade */}
          <div className="absolute inset-x-0 bottom-0 h-1.5 bg-black/25 pointer-events-none" />
        </button>

        {/* Status indicator dot on top-right */}
        {!isEditMode && (
          <div
            className={`absolute -top-1 -right-1 w-3 h-3 rounded-full ${getStatusColor()} border-2 border-black shadow-md`}
            title={`Status: ${project.status}`}
          />
        )}

        {/* Edit mode move page badge */}
        {isEditMode && onMovePage && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              audio.playClick('switch');
              onMovePage(project.id);
            }}
            className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-zinc-800 text-white border border-white/30 flex items-center justify-center hover:bg-zinc-700 active:scale-90 shadow-md cursor-pointer"
            title="Move to other page"
          >
            <ArrowRightLeft size={11} />
          </button>
        )}
      </motion.div>

      {/* App label below */}
      <span className="mt-1.5 text-xs font-medium text-white/95 text-center leading-tight tracking-tight drop-shadow-[0_1px_2px_rgba(0,0,0,0.9)] line-clamp-2 px-1">
        {displayName}
      </span>
    </div>
  );
};
