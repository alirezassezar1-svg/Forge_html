import React, { useState, useEffect } from 'react';
import { Wifi } from 'lucide-react';
import { DynamicIsland } from './DynamicIsland';
import { Language } from '../types';
import { translations } from '../data/translations';

interface StatusBarProps {
  lang: Language;
  onToggleLang: () => void;
  onToggleEditMode: () => void;
  isEditMode: boolean;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const StatusBar: React.FC<StatusBarProps> = ({
  lang,
  onToggleLang,
  onToggleEditMode,
  isEditMode,
  soundEnabled,
  onToggleSound
}) => {
  const [time, setTime] = useState<Date>(new Date());
  const [showTooltip, setShowTooltip] = useState<string | null>(null);
  const t = translations[lang];

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formattedTime = new Intl.DateTimeFormat(lang === 'fa' ? 'fa-IR' : 'en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: false
  }).format(time);

  const formattedDate = new Intl.DateTimeFormat(lang === 'fa' ? 'fa-IR' : 'en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric'
  }).format(time);

  return (
    <header className="relative w-full z-40 px-4 md:px-8 py-2 select-none">
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-2">
        {/* Left: Time & Date */}
        <div className="flex items-center gap-2.5 text-white/90 shrink-0">
          <span className="text-sm font-semibold tracking-tight font-mono tabular-nums text-white">
            {formattedTime}
          </span>
          <span className="hidden sm:inline-block text-xs text-white/60 font-medium">
            {formattedDate}
          </span>
        </div>

        {/* Center: Dynamic Island */}
        <div className="flex-1 flex justify-center">
          <DynamicIsland
            lang={lang}
            onToggleLang={onToggleLang}
            onToggleEditMode={onToggleEditMode}
            isEditMode={isEditMode}
            soundEnabled={soundEnabled}
            onToggleSound={onToggleSound}
          />
        </div>

        {/* Right: Simulated Connectivity & Battery */}
        <div className="flex items-center gap-3 text-white/90 shrink-0 relative">
          {/* Simulated 5G cellular indicator */}
          <div
            className="flex items-end gap-0.5 h-3 cursor-help relative"
            onMouseEnter={() => setShowTooltip('network')}
            onMouseLeave={() => setShowTooltip(null)}
            title={t.statusNotice.networkSimulated}
          >
            <span className="w-0.5 h-1 bg-white/90 rounded-full" />
            <span className="w-0.5 h-1.5 bg-white/90 rounded-full" />
            <span className="w-0.5 h-2.5 bg-white/90 rounded-full" />
            <span className="w-0.5 h-3 bg-white/90 rounded-full" />
            <span className="text-[10px] font-semibold text-white/70 ml-1 hidden xs:inline">
              5G
            </span>
          </div>

          {/* Wi-Fi */}
          <div
            className="cursor-help"
            title="Wi-Fi (Web Client Connected)"
          >
            <Wifi size={14} className="text-white/90" />
          </div>

          {/* Battery-style decorative indicator */}
          <div
            className="flex items-center gap-1.5 cursor-help relative"
            onMouseEnter={() => setShowTooltip('battery')}
            onMouseLeave={() => setShowTooltip(null)}
            title={t.statusNotice.batterySimulated}
          >
            <span className="text-[11px] font-mono tabular-nums text-white/80 hidden sm:inline">
              98%
            </span>
            <div className="w-5 h-2.5 rounded-[4px] border border-white/60 p-[1px] flex items-center relative">
              <div className="w-[88%] h-full rounded-[2px] bg-emerald-400" />
              <div className="w-0.5 h-1 bg-white/60 absolute -right-1 rounded-r-sm top-[2px]" />
            </div>
          </div>

          {/* Explicit simulated disclaimer tooltip */}
          {showTooltip && (
            <div className="absolute right-0 top-7 z-50 bg-black/90 border border-white/20 px-2.5 py-1 rounded-md text-[11px] text-white/80 whitespace-nowrap shadow-xl">
              {showTooltip === 'battery' ? t.statusNotice.batterySimulated : t.statusNotice.networkSimulated}
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
