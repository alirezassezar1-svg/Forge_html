import React from 'react';
import { motion } from 'motion/react';
import { Home, FolderGit2, Layers, User, Mail, Settings } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../data/translations';
import { audio } from '../utils/audio';

export type ActiveDockTab = 'home' | 'projects' | 'services' | 'about' | 'contact' | 'settings';

interface DockProps {
  activeTab: ActiveDockTab;
  onSelectTab: (tab: ActiveDockTab) => void;
  lang: Language;
}

export const Dock: React.FC<DockProps> = ({ activeTab, onSelectTab, lang }) => {
  const t = translations[lang];

  const items = [
    {
      id: 'home' as ActiveDockTab,
      label: t.dock.home,
      icon: Home,
      gradient: 'from-blue-500 to-indigo-600'
    },
    {
      id: 'projects' as ActiveDockTab,
      label: t.dock.projects,
      icon: FolderGit2,
      gradient: 'from-cyan-500 to-blue-600'
    },
    {
      id: 'services' as ActiveDockTab,
      label: t.dock.services,
      icon: Layers,
      gradient: 'from-purple-500 to-pink-600'
    },
    {
      id: 'about' as ActiveDockTab,
      label: t.dock.about,
      icon: User,
      gradient: 'from-amber-500 to-orange-600'
    },
    {
      id: 'contact' as ActiveDockTab,
      label: t.dock.contact,
      icon: Mail,
      gradient: 'from-emerald-500 to-teal-600'
    },
    {
      id: 'settings' as ActiveDockTab,
      label: t.dock.settings,
      icon: Settings,
      gradient: 'from-zinc-600 to-zinc-800'
    }
  ];

  return (
    <div className="fixed bottom-3 sm:bottom-5 inset-x-0 z-40 flex justify-center px-4 pointer-events-none select-none">
      <nav
        aria-label="iOS Dock"
        className="pointer-events-auto ios-glass-dock rounded-[30px] p-2 sm:p-2.5 flex items-center gap-2 sm:gap-3.5 shadow-2xl border border-white/20"
      >
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <motion.button
              key={item.id}
              type="button"
              onClick={() => {
                audio.playClick('open');
                onSelectTab(item.id);
              }}
              whileHover={{ scale: 1.15, y: -4 }}
              whileTap={{ scale: 0.92 }}
              transition={{ type: 'spring', damping: 18, stiffness: 400 }}
              className="group relative flex flex-col items-center cursor-pointer p-0 focus:outline-none"
              title={item.label}
              aria-label={item.label}
            >
              {/* Tooltip on hover */}
              <span className="absolute -top-8 px-2 py-0.5 rounded-md bg-black/85 text-[11px] font-medium text-white border border-white/10 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap shadow-lg">
                {item.label}
              </span>

              {/* Icon Container */}
              <div
                className={`w-12 h-12 sm:w-14 sm:h-14 ios-squircle flex items-center justify-center bg-gradient-to-br ${item.gradient} border border-white/30 shadow-lg relative overflow-hidden transition-all ${
                  isActive ? 'ring-2 ring-white/60 shadow-[0_0_16px_rgba(255,255,255,0.35)]' : ''
                }`}
              >
                {/* Specular gloss */}
                <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/30 to-transparent pointer-events-none" />

                <Icon size={22} className="text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)] relative z-10" />
              </div>

              {/* iOS Active Indicator Dot */}
              <div className="h-1.5 flex items-center justify-center mt-1">
                {isActive && (
                  <div className="w-1.5 h-1.5 rounded-full bg-white shadow-[0_0_6px_#ffffff]" />
                )}
              </div>
            </motion.button>
          );
        })}
      </nav>
    </div>
  );
};
