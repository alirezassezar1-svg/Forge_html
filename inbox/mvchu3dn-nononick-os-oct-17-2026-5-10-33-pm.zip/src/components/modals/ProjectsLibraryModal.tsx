import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Search, Globe, Sparkles, Server, Headphones, Shapes, Wrench, Smartphone, FlaskConical, Filter, ArrowRight } from 'lucide-react';
import { Project, Language, ProjectCategory, ProjectStatus } from '../../types';
import { translations } from '../../data/translations';
import { audio } from '../../utils/audio';

interface ProjectsLibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  projects: Project[];
  lang: Language;
  onSelectProject: (p: Project) => void;
}

const iconMap: Record<string, React.ElementType> = {
  Globe,
  Sparkles,
  Server,
  Headphones,
  Shapes,
  Wrench,
  Smartphone,
  FlaskConical
};

export const ProjectsLibraryModal: React.FC<ProjectsLibraryModalProps> = ({
  isOpen,
  onClose,
  projects,
  lang,
  onSelectProject
}) => {
  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  const t = translations[lang];

  if (!isOpen) return null;

  const filtered = projects.filter((p) => {
    const matchesCat = selectedCat === 'all' || p.category === selectedCat;
    const matchesStatus = selectedStatus === 'all' || p.status === selectedStatus;
    if (!matchesCat || !matchesStatus) return false;

    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      p.nameFa.includes(q) ||
      p.description.toLowerCase().includes(q) ||
      p.technologies.some((tech) => tech.toLowerCase().includes(q))
    );
  });

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 select-none overflow-y-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => {
            audio.playClick('close');
            onClose();
          }}
          className="fixed inset-0 bg-black/80 backdrop-blur-md"
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 20 }}
          transition={{ type: 'spring', damping: 28, stiffness: 340 }}
          className="relative z-10 w-full max-w-4xl bg-zinc-950/95 border border-white/20 rounded-[32px] ios-widget-shadow overflow-hidden flex flex-col my-auto max-h-[90vh]"
        >
          {/* Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white">
                {t.dock.projects} Library
              </h2>
              <p className="text-xs text-white/60 mt-0.5">
                Complete engineering portfolio and digital product catalog
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                audio.playClick('close');
                onClose();
              }}
              className="p-2 rounded-full bg-white/10 hover:bg-white/15 text-white/80 hover:text-white transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>

          {/* Search & Filter Bar */}
          <div className="p-4 sm:p-5 border-b border-white/10 space-y-3 bg-white/[0.02]">
            <div className="relative">
              <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-white/40" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t.searchPlaceholder}
                className="w-full bg-white/[0.06] border border-white/15 rounded-xl pl-10 pr-4 py-2 text-xs sm:text-sm text-white placeholder-white/40 focus:outline-none focus:border-cyan-400/50"
              />
            </div>

            {/* Filter pills */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[11px] font-semibold text-white/40 uppercase tracking-wider mr-1">
                Category:
              </span>
              {(['all', 'web', 'ai', 'tools', 'audio', 'experiments'] as const).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => {
                    audio.playClick('tap');
                    setSelectedCat(cat);
                  }}
                  className={`px-3 py-1 rounded-full text-xs transition-colors cursor-pointer ${
                    selectedCat === cat
                      ? 'bg-cyan-500 text-black font-semibold'
                      : 'bg-white/10 text-white/70 hover:text-white'
                  }`}
                >
                  {t.categories[cat]}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[11px] font-semibold text-white/40 uppercase tracking-wider mr-1">
                Status:
              </span>
              {[
                { id: 'all', label: 'All' },
                { id: 'Live', label: 'Live' },
                { id: 'In Development', label: 'In Development' },
                { id: 'Experimental', label: 'Experimental' }
              ].map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => {
                    audio.playClick('tap');
                    setSelectedStatus(s.id);
                  }}
                  className={`px-2.5 py-0.5 rounded-md text-[11px] transition-colors cursor-pointer ${
                    selectedStatus === s.id
                      ? 'bg-white/30 text-white font-semibold'
                      : 'bg-white/[0.05] text-white/50 hover:text-white'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Grid of Projects */}
          <div className="overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
            {filtered.map((p) => {
              const Icon = iconMap[p.iconName] || Globe;
              const name = lang === 'fa' ? p.nameFa : p.name;
              const desc = lang === 'fa' ? p.descriptionFa : p.description;

              return (
                <div
                  key={p.id}
                  onClick={() => {
                    audio.playClick('open');
                    onSelectProject(p);
                  }}
                  className="p-4 rounded-2xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 hover:border-cyan-500/30 transition-all flex flex-col justify-between cursor-pointer group"
                >
                  <div className="flex items-start gap-3.5">
                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${p.gradient} flex items-center justify-center shrink-0 border border-white/20 shadow-md`}>
                      <Icon size={24} className="text-white" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span className="text-[10px] text-cyan-400 font-semibold uppercase tracking-wider">
                          {p.category}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 text-white/70 font-mono">
                          {p.status}
                        </span>
                      </div>
                      <h3 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                        {name}
                      </h3>
                      <p className="text-xs text-white/70 line-clamp-2 mt-1 leading-relaxed font-normal">
                        {desc}
                      </p>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
                    <div className="flex flex-wrap gap-1 text-[10px] text-white/40">
                      {p.technologies.slice(0, 3).join(' · ')}
                    </div>
                    <div className="flex items-center gap-1 text-xs font-semibold text-cyan-400 group-hover:translate-x-0.5 transition-transform">
                      <span>Details</span>
                      <ArrowRight size={13} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
