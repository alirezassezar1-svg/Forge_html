import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Layout, Wrench, Sparkles, ShieldCheck, CheckCircle2, Clock, Send } from 'lucide-react';
import { servicesData } from '../../data/servicesData';
import { ServiceItem, Language } from '../../types';
import { translations } from '../../data/translations';
import { audio } from '../../utils/audio';

interface ServicesModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onInquireService: (service: ServiceItem) => void;
}

const serviceIcons: Record<string, React.ElementType> = {
  Layout,
  Wrench,
  Sparkles,
  ShieldCheck
};

export const ServicesModal: React.FC<ServicesModalProps> = ({
  isOpen,
  onClose,
  lang,
  onInquireService
}) => {
  const t = translations[lang];

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 select-none overflow-y-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => {
            audio.playClick('close');
            onClose();
          }}
          className="fixed inset-0 bg-black/80 backdrop-blur-md"
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 20 }}
          transition={{ type: 'spring', damping: 28, stiffness: 340 }}
          className="relative z-10 w-full max-w-4xl bg-zinc-950/95 border border-white/20 rounded-[32px] ios-widget-shadow overflow-hidden flex flex-col my-auto max-h-[90vh]"
        >
          {/* Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white">
                {t.dock.services} & Capabilities
              </h2>
              <p className="text-xs text-white/60 mt-0.5">
                Bespoke frontend engineering, custom web applications & full-lifecycle management
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                audio.playClick('close');
                onClose();
              }}
              className="p-2 rounded-full bg-white/10 hover:bg-white/15 text-white/80 hover:text-white transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>

          {/* Services List */}
          <div className="overflow-y-auto p-6 space-y-6">
            {servicesData.map((s) => {
              const Icon = serviceIcons[s.iconName] || Layout;
              const title = lang === 'fa' ? s.titleFa : s.title;
              const desc = lang === 'fa' ? s.descriptionFa : s.description;
              const deliverables = lang === 'fa' ? s.deliverablesFa : s.deliverables;
              const turnaround = lang === 'fa' ? s.turnaroundFa : s.turnaround;

              return (
                <div
                  key={s.id}
                  className="p-6 rounded-3xl bg-white/[0.04] border border-white/10 hover:border-white/20 transition-all flex flex-col md:flex-row gap-6 items-start"
                >
                  <div
                    className="w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 border border-white/20 shadow-xl"
                    style={{ backgroundColor: `${s.accentColor}25`, color: s.accentColor }}
                  >
                    <Icon size={30} />
                  </div>

                  <div className="flex-1 space-y-4">
                    <div>
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                        <h3 className="text-xl font-bold text-white">
                          {title}
                        </h3>
                        <div className="flex items-center gap-1.5 text-xs text-white/60 font-mono">
                          <Clock size={13} className="text-cyan-400" />
                          <span>{turnaround}</span>
                        </div>
                      </div>
                      <p className="text-xs sm:text-sm text-white/70 leading-relaxed font-normal">
                        {desc}
                      </p>
                    </div>

                    {/* Deliverables */}
                    <div>
                      <div className="text-[11px] font-semibold text-white/40 uppercase tracking-wider mb-2">
                        Core Deliverables
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {deliverables.map((item, idx) => (
                          <div key={idx} className="flex items-start gap-2 text-xs text-white/80">
                            <CheckCircle2 size={14} className="text-emerald-400 shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Technologies & CTA */}
                    <div className="pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
                      <div className="flex flex-wrap gap-1.5">
                        {s.techFocus.map((tech) => (
                          <span
                            key={tech}
                            className="text-[11px] font-mono px-2 py-0.5 rounded-md bg-white/[0.06] text-cyan-300"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          audio.playClick('open');
                          onInquireService(s);
                          onClose();
                        }}
                        className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white text-black font-semibold text-xs hover:bg-white/90 active:scale-95 transition-all shadow-md cursor-pointer"
                      >
                        <Send size={12} />
                        <span>Inquire About This Service</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
