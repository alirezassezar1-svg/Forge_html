import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  Globe,
  Sliders,
  Volume2,
  VolumeX,
  Eye,
  Smartphone,
  RotateCcw,
  Check,
  Palette
} from 'lucide-react';
import { SystemSettings, ThemeWallpaper, Language } from '../../types';
import { translations } from '../../data/translations';
import { audio } from '../../utils/audio';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: SystemSettings;
  onUpdateSettings: (newSettings: Partial<SystemSettings>) => void;
  onResetLayout: () => void;
}

const wallpapers: { id: ThemeWallpaper; name: string; nameFa: string; gradient: string }[] = [
  {
    id: 'obsidian',
    name: 'Deep Obsidian',
    nameFa: 'ابسیدین عمیق',
    gradient: 'from-black via-zinc-950 to-neutral-900'
  },
  {
    id: 'aurora',
    name: 'Cosmic Aurora',
    nameFa: 'شفق کیهانی',
    gradient: 'from-slate-950 via-indigo-950 to-purple-950'
  },
  {
    id: 'midnight',
    name: 'Midnight Indigo',
    nameFa: 'نیلی نیمه‌شب',
    gradient: 'from-slate-950 via-blue-950 to-zinc-950'
  },
  {
    id: 'sunset',
    name: 'Sunset Prism',
    nameFa: 'منشور غروب',
    gradient: 'from-zinc-950 via-rose-950/60 to-purple-950'
  },
  {
    id: 'matte',
    name: 'Carbon Matte',
    nameFa: 'کربن مات',
    gradient: 'from-[#0d0f12] via-[#14171d] to-[#0a0b0d]'
  }
];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  onResetLayout
}) => {
  const [resetMessage, setResetMessage] = useState(false);
  const t = translations[settings.language];

  if (!isOpen) return null;

  const handleReset = () => {
    audio.playClick('switch');
    onResetLayout();
    setResetMessage(true);
    setTimeout(() => setResetMessage(false), 2500);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 select-none overflow-y-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => {
            audio.playClick('close');
            onClose();
          }}
          className="fixed inset-0 bg-black/80 backdrop-blur-md"
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 20 }}
          transition={{ type: 'spring', damping: 28, stiffness: 340 }}
          className="relative z-10 w-full max-w-xl bg-zinc-950/95 border border-white/20 rounded-[32px] ios-widget-shadow overflow-hidden flex flex-col my-auto max-h-[90vh]"
        >
          {/* Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-white">
              {t.settings.title}
            </h2>
            <button
              type="button"
              onClick={() => {
                audio.playClick('close');
                onClose();
              }}
              className="p-2 rounded-full bg-white/10 hover:bg-white/15 text-white/80 hover:text-white transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>

          {/* Settings Body */}
          <div className="overflow-y-auto p-6 space-y-6">
            {/* Wallpaper Selection */}
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">
                <Palette size={14} className="text-cyan-400" />
                <span>{t.settings.appearance}</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {wallpapers.map((wp) => {
                  const isSelected = settings.wallpaper === wp.id;
                  const name = settings.language === 'fa' ? wp.nameFa : wp.name;

                  return (
                    <button
                      key={wp.id}
                      type="button"
                      onClick={() => {
                        audio.playClick('switch');
                        onUpdateSettings({ wallpaper: wp.id });
                      }}
                      className={`p-3 rounded-2xl bg-gradient-to-br ${wp.gradient} border text-start flex flex-col justify-between h-20 transition-all cursor-pointer relative overflow-hidden ${
                        isSelected
                          ? 'border-cyan-400 ring-2 ring-cyan-400/40'
                          : 'border-white/15 hover:border-white/30'
                      }`}
                    >
                      <span className="text-xs font-semibold text-white z-10">
                        {name}
                      </span>
                      {isSelected && (
                        <div className="self-end w-5 h-5 rounded-full bg-cyan-400 text-black flex items-center justify-center z-10">
                          <Check size={12} />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Language Switcher */}
            <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
                  <Globe size={20} />
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">
                    {t.settings.language}
                  </div>
                  <div className="text-xs text-white/50">
                    English & فارسی (RTL / LTR)
                  </div>
                </div>
              </div>

              <div className="flex items-center p-1 bg-white/10 rounded-xl border border-white/10">
                <button
                  type="button"
                  onClick={() => {
                    audio.playClick('switch');
                    onUpdateSettings({ language: 'en' });
                  }}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                    settings.language === 'en'
                      ? 'bg-white text-black shadow-sm'
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  English
                </button>
                <button
                  type="button"
                  onClick={() => {
                    audio.playClick('switch');
                    onUpdateSettings({ language: 'fa' });
                  }}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                    settings.language === 'fa'
                      ? 'bg-white text-black shadow-sm'
                      : 'text-white/60 hover:text-white'
                  }`}
                >
                  فارسی
                </button>
              </div>
            </div>

            {/* Audio & Haptic Feedback */}
            <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                  {settings.soundEnabled ? <Volume2 size={20} /> : <VolumeX size={20} />}
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">
                    {t.settings.audio}
                  </div>
                  <div className="text-xs text-white/50">
                    {t.settings.soundDesc}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  const next = !settings.soundEnabled;
                  audio.setSoundEnabled(next);
                  if (next) audio.playClick('tap');
                  onUpdateSettings({ soundEnabled: next });
                }}
                className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                  settings.soundEnabled ? 'bg-cyan-500' : 'bg-white/20'
                }`}
              >
                <span
                  className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                    settings.soundEnabled ? 'left-6.5' : 'left-0.5'
                  }`}
                />
              </button>
            </div>

            {/* Reduced Motion */}
            <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Eye size={20} />
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">
                    {t.settings.reducedMotion}
                  </div>
                  <div className="text-xs text-white/50">
                    {t.settings.reducedMotionDesc}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  audio.playClick('switch');
                  onUpdateSettings({ reducedMotion: !settings.reducedMotion });
                }}
                className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                  settings.reducedMotion ? 'bg-emerald-500' : 'bg-white/20'
                }`}
              >
                <span
                  className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                    settings.reducedMotion ? 'left-6.5' : 'left-0.5'
                  }`}
                />
              </button>
            </div>

            {/* iPhone Frame Simulator Toggle */}
            <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
                  <Smartphone size={20} />
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">
                    {t.settings.deviceFrame}
                  </div>
                  <div className="text-xs text-white/50">
                    {t.settings.deviceFrameDesc}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  audio.playClick('switch');
                  onUpdateSettings({ deviceFrame: !settings.deviceFrame });
                }}
                className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                  settings.deviceFrame ? 'bg-rose-500' : 'bg-white/20'
                }`}
              >
                <span
                  className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                    settings.deviceFrame ? 'left-6.5' : 'left-0.5'
                  }`}
                />
              </button>
            </div>

            {/* Home Screen Jiggle Mode */}
            <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Sliders size={20} />
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">
                    {t.settings.editMode}
                  </div>
                  <div className="text-xs text-white/50">
                    {t.settings.editModeDesc}
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  audio.playClick('switch');
                  onUpdateSettings({ isEditMode: !settings.isEditMode });
                }}
                className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                  settings.isEditMode ? 'bg-amber-500' : 'bg-white/20'
                }`}
              >
                <span
                  className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${
                    settings.isEditMode ? 'left-6.5' : 'left-0.5'
                  }`}
                />
              </button>
            </div>

            {/* Reset Defaults */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 border-t border-white/10">
              <div className="text-xs text-white/40">
                {resetMessage ? (
                  <span className="text-emerald-400 flex items-center gap-1">
                    <Check size={14} />
                    {t.settings.resetSuccess}
                  </span>
                ) : (
                  'Restores default app order and page distribution.'
                )}
              </div>

              <button
                type="button"
                onClick={handleReset}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs border border-white/10 active:scale-95 transition-all cursor-pointer whitespace-nowrap"
              >
                <RotateCcw size={13} />
                <span>{t.settings.resetLayout}</span>
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
