import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Code2, Cpu, Sparkles, Shield, Compass, Download, Mail } from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../data/translations';
import { audio } from '../../utils/audio';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onOpenContact: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({
  isOpen,
  onClose,
  lang,
  onOpenContact
}) => {
  const t = translations[lang];

  if (!isOpen) return null;

  const handleDownloadVCard = () => {
    audio.playClick('tap');
    const vcard = `BEGIN:VCARD
VERSION:3.0
N:NONONICK;;;;
FN:NONONICK
TITLE:Creative Technologist & UI Engineer
EMAIL;TYPE=INTERNET,WORK:alirezassezar.1@gmail.com
NOTE:Portfolio: NONONICK iOS Home Screen Portfolio OS
END:VCARD`;

    const blob = new Blob([vcard], { type: 'text/vcard;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'NONONICK_Contact.vcf');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 select-none overflow-y-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => {
            audio.playClick('close');
            onClose();
          }}
          className="fixed inset-0 bg-black/80 backdrop-blur-md"
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 20 }}
          transition={{ type: 'spring', damping: 28, stiffness: 340 }}
          className="relative z-10 w-full max-w-3xl bg-zinc-950/95 border border-white/20 rounded-[32px] ios-widget-shadow overflow-hidden flex flex-col my-auto max-h-[90vh]"
        >
          {/* Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white">
                {t.about.title}
              </h2>
              <p className="text-xs text-cyan-400 mt-0.5">
                {t.about.subtitle}
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                audio.playClick('close');
                onClose();
              }}
              className="p-2 rounded-full bg-white/10 hover:bg-white/15 text-white/80 hover:text-white transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>

          {/* Content */}
          <div className="overflow-y-auto p-6 sm:p-8 space-y-7">
            {/* Biography */}
            <div className="space-y-3">
              <p className="text-sm sm:text-base text-white/90 leading-relaxed font-normal">
                {t.about.statement1}
              </p>
              <p className="text-sm sm:text-base text-white/70 leading-relaxed font-normal">
                {t.about.statement2}
              </p>
            </div>

            {/* Core Principles */}
            <div>
              <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">
                {t.about.corePhilosophy}
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-2">
                  <div className="w-8 h-8 rounded-xl bg-blue-500/20 text-blue-400 flex items-center justify-center">
                    <Sparkles size={16} />
                  </div>
                  <div className="text-xs font-bold text-white">Tactile Precision</div>
                  <p className="text-xs text-white/60 leading-relaxed">
                    Micro-interactions, spring curves, and surface reflection tuned for maximum delight.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-2">
                  <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                    <Shield size={16} />
                  </div>
                  <div className="text-xs font-bold text-white">Honest Engineering</div>
                  <p className="text-xs text-white/60 leading-relaxed">
                    Zero fake metrics or empty mockups. Every button and tool performs real computation.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 space-y-2">
                  <div className="w-8 h-8 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center">
                    <Compass size={16} />
                  </div>
                  <div className="text-xs font-bold text-white">Bilingual Parity</div>
                  <p className="text-xs text-white/60 leading-relaxed">
                    Full LTR & RTL typography alignment across Persian and English language systems.
                  </p>
                </div>
              </div>
            </div>

            {/* Technical Stack */}
            <div>
              <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">
                {t.about.skillsHeading}
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/10">
                  <div className="font-semibold text-white mb-1">Frontend Core</div>
                  <div className="text-white/60 space-y-0.5">
                    <div>TypeScript</div>
                    <div>React 19 & Next.js</div>
                    <div>Tailwind CSS v4</div>
                    <div>Framer Motion</div>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/10">
                  <div className="font-semibold text-white mb-1">Creative & Web Audio</div>
                  <div className="text-white/60 space-y-0.5">
                    <div>HTML5 Canvas 2D</div>
                    <div>Web Audio API</div>
                    <div>GLSL / Shaders</div>
                    <div>Procedural Math</div>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/10">
                  <div className="font-semibold text-white mb-1">Architecture & Data</div>
                  <div className="text-white/60 space-y-0.5">
                    <div>Node.js & Express</div>
                    <div>SQLite / Drizzle ORM</div>
                    <div>REST & WebSocket</div>
                    <div>Local-First Stores</div>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/10">
                  <div className="font-semibold text-white mb-1">Deployment & Ops</div>
                  <div className="text-white/60 space-y-0.5">
                    <div>cPanel / Apache</div>
                    <div>Cloud Run / Docker</div>
                    <div>Vite & Rollup</div>
                    <div>Lighthouse 100/100</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer CTAs */}
          <div className="p-5 border-t border-white/10 bg-white/[0.02] flex items-center justify-between">
            <button
              type="button"
              onClick={handleDownloadVCard}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs border border-white/15 transition-colors cursor-pointer"
            >
              <Download size={13} />
              <span>{t.about.downloadVCard}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                audio.playClick('open');
                onClose();
                onOpenContact();
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-white text-black font-semibold text-xs hover:bg-white/90 active:scale-95 transition-all shadow-md cursor-pointer"
            >
              <Mail size={13} />
              <span>{t.contactMe}</span>
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
