import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  X,
  ExternalLink,
  Github,
  CheckCircle2,
  Clock,
  FlaskConical,
  Share2,
  Check,
  Code2,
  Layers,
  Sparkles,
  Globe,
  Server,
  Headphones,
  Shapes,
  Wrench,
  Smartphone
} from 'lucide-react';
import { Project, Language } from '../../types';
import { translations } from '../../data/translations';
import { audio } from '../../utils/audio';

interface ProjectDetailModalProps {
  project: Project | null;
  onClose: () => void;
  lang: Language;
}

const iconMap: Record<string, React.ElementType> = {
  Globe,
  Sparkles,
  Server,
  Headphones,
  Shapes,
  Wrench,
  Smartphone,
  FlaskConical
};

export const ProjectDetailModal: React.FC<ProjectDetailModalProps> = ({
  project,
  onClose,
  lang
}) => {
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'interactive'>('overview');

  // Interactive mini playground state
  const [clampMin, setClampMin] = useState(16);
  const [clampMax, setClampMax] = useState(32);
  const [binauralFreq, setBinauralFreq] = useState(432);
  const [isTonePlaying, setIsTonePlaying] = useState(false);

  const t = translations[lang];

  if (!project) return null;

  const Icon = iconMap[project.iconName] || Globe;
  const name = lang === 'fa' ? project.nameFa : project.name;
  const desc = lang === 'fa' ? project.longDescriptionFa : project.longDescription;
  const highlights = lang === 'fa' ? project.highlightsFa : project.highlights;

  const handleShare = () => {
    audio.playClick('tap');
    const shareUrl = `${window.location.origin}/#project-${project.id}`;
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isSafeUrl = (url: string | null): boolean => {
    if (!url) return false;
    try {
      const parsed = new URL(url);
      return parsed.protocol === 'https:' || parsed.protocol === 'http:';
    } catch {
      return false;
    }
  };

  // Tone generation for NavaMind inside project preview
  const handleToggleNavaTone = () => {
    audio.playClick('tap');
    if (isTonePlaying) {
      audio.stopAmbientSynth();
      setIsTonePlaying(false);
    } else {
      audio.startAmbientSynth();
      setIsTonePlaying(true);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 select-none overflow-y-auto">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => {
            if (isTonePlaying) audio.stopAmbientSynth();
            audio.playClick('close');
            onClose();
          }}
          className="fixed inset-0 bg-black/80 backdrop-blur-md"
        />

        {/* Modal Window Container */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 20 }}
          transition={{ type: 'spring', damping: 28, stiffness: 340 }}
          className="relative z-10 w-full max-w-2xl bg-zinc-950/95 border border-white/20 rounded-[32px] ios-widget-shadow overflow-hidden flex flex-col my-auto max-h-[90vh]"
        >
          {/* Top Bar with Grab Handle & Close */}
          <div className="relative px-6 pt-5 pb-3 flex items-center justify-between border-b border-white/10">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-white/50 tracking-wider uppercase">
                {t.modal.status}:
              </span>
              <span className="text-xs font-semibold text-cyan-400">
                {lang === 'fa' ? project.statusFa : project.status}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleShare}
                className="p-2 rounded-full bg-white/10 hover:bg-white/15 text-white/80 hover:text-white transition-colors cursor-pointer"
                title={t.modal.share}
              >
                {copied ? <Check size={15} className="text-emerald-400" /> : <Share2 size={15} />}
              </button>

              <button
                type="button"
                onClick={() => {
                  if (isTonePlaying) audio.stopAmbientSynth();
                  audio.playClick('close');
                  onClose();
                }}
                className="p-2 rounded-full bg-white/10 hover:bg-white/15 text-white/80 hover:text-white transition-colors cursor-pointer"
                aria-label={t.modal.close}
              >
                <X size={16} />
              </button>
            </div>
          </div>

          {/* Scrollable Body */}
          <div className="overflow-y-auto p-6 sm:p-7 space-y-6">
            {/* Hero App Header */}
            <div className="flex items-start gap-4 sm:gap-5">
              <div
                className={`w-20 h-20 sm:w-24 sm:h-24 ios-squircle p-0 flex items-center justify-center bg-gradient-to-br ${project.gradient} border border-white/30 shadow-xl shrink-0 relative overflow-hidden`}
              >
                <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/35 to-transparent pointer-events-none" />
                <Icon size={38} className="text-white drop-shadow-[0_4px_8px_rgba(0,0,0,0.5)] relative z-10" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-1">
                  {lang === 'fa' ? project.categoryFa : project.category}
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white leading-tight">
                  {name}
                </h2>
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-white/10 text-white/80 font-mono">
                    {project.status}
                  </span>
                  {project.featured && (
                    <span className="text-xs px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-medium">
                      {t.featuredBadge}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Segmented Tab Selector (Overview vs Interactive Sandbox) */}
            <div className="flex items-center gap-1 p-1 bg-white/[0.06] rounded-xl border border-white/10">
              <button
                type="button"
                onClick={() => {
                  audio.playClick('tap');
                  setActiveTab('overview');
                }}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
                  activeTab === 'overview'
                    ? 'bg-white text-black shadow-md'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                Architecture & Overview
              </button>
              <button
                type="button"
                onClick={() => {
                  audio.playClick('tap');
                  setActiveTab('interactive');
                }}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
                  activeTab === 'interactive'
                    ? 'bg-white text-black shadow-md'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                <Sparkles size={12} className={activeTab === 'interactive' ? 'text-black' : 'text-cyan-400'} />
                Interactive Sandbox
              </button>
            </div>

            {/* Tab 1: Overview */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-2">
                    Executive Summary
                  </h3>
                  <p className="text-sm text-white/85 leading-relaxed font-normal">
                    {desc}
                  </p>
                </div>

                {/* Highlights */}
                <div>
                  <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-2.5">
                    {t.modal.highlights}
                  </h3>
                  <ul className="space-y-2">
                    {highlights.map((h, i) => (
                      <li key={i} className="flex items-start gap-2.5 text-xs text-white/80">
                        <CheckCircle2 size={15} className="text-emerald-400 shrink-0 mt-0.5" />
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Technologies */}
                <div>
                  <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-2.5">
                    {t.modal.technologies}
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="px-3 py-1.5 rounded-xl bg-white/[0.06] border border-white/10 text-xs font-mono text-cyan-300"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Tab 2: Interactive Sandbox */}
            {activeTab === 'interactive' && (
              <div className="space-y-4 p-4 rounded-2xl bg-white/[0.03] border border-white/10">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-white">Live Prototype Sandbox</span>
                  <span className="text-[10px] text-cyan-400 font-mono">Running in browser</span>
                </div>

                {project.id === 'navamind' && (
                  <div className="space-y-3">
                    <p className="text-xs text-white/70">
                      Test the NavaMind procedural binaural synthesis engine right now:
                    </p>
                    <div className="flex items-center gap-3">
                      <button
                        type="button"
                        onClick={handleToggleNavaTone}
                        className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs transition-transform active:scale-95"
                      >
                        {isTonePlaying ? 'Stop Harmonic Tone' : 'Generate 432Hz Drone'}
                      </button>
                      <span className="text-xs font-mono text-white/60">
                        {isTonePlaying ? 'Synthesizing...' : 'Idle'}
                      </span>
                    </div>
                  </div>
                )}

                {project.id === 'web-development-tools' && (
                  <div className="space-y-3">
                    <p className="text-xs text-white/70">
                      CSS Fluid clamp() calculator generator:
                    </p>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] text-white/60 block mb-1">Min Font (px)</label>
                        <input
                          type="range"
                          min={12}
                          max={24}
                          value={clampMin}
                          onChange={(e) => setClampMin(Number(e.target.value))}
                          className="w-full"
                        />
                        <span className="text-xs font-mono text-cyan-400">{clampMin}px</span>
                      </div>
                      <div>
                        <label className="text-[11px] text-white/60 block mb-1">Max Font (px)</label>
                        <input
                          type="range"
                          min={24}
                          max={56}
                          value={clampMax}
                          onChange={(e) => setClampMax(Number(e.target.value))}
                          className="w-full"
                        />
                        <span className="text-xs font-mono text-cyan-400">{clampMax}px</span>
                      </div>
                    </div>
                    <div className="p-2.5 rounded-lg bg-black/60 font-mono text-xs text-emerald-400 select-all border border-white/10">
                      clamp({(clampMin / 16).toFixed(2)}rem, 2vw + 1rem, {(clampMax / 16).toFixed(2)}rem)
                    </div>
                  </div>
                )}

                {project.id === 'local-backend-forge' && (
                  <div className="space-y-2">
                    <p className="text-xs text-white/70">
                      Simulated SQLite Schema Generator output:
                    </p>
                    <pre className="p-3 rounded-xl bg-black/80 font-mono text-[11px] text-amber-300 overflow-x-auto border border-white/10">
{`CREATE TABLE IF NOT EXISTS "${project.id}_records" (
  "id" TEXT PRIMARY KEY,
  "created_at" INTEGER NOT NULL,
  "sync_state" TEXT DEFAULT 'local',
  "payload" BLOB
);`}
                    </pre>
                  </div>
                )}

                {project.id !== 'navamind' &&
                  project.id !== 'web-development-tools' &&
                  project.id !== 'local-backend-forge' && (
                    <div className="p-4 rounded-xl bg-black/50 border border-white/10 space-y-2">
                      <div className="text-xs font-mono text-cyan-300">
                        {`// System verification for ${project.name}`}
                      </div>
                      <p className="text-xs text-white/70 leading-relaxed">
                        This project is maintained directly within the NONONICK engineering ecosystem. All interface specifications and interaction logic are verified and actively maintained.
                      </p>
                    </div>
                  )}
              </div>
            )}
          </div>

          {/* Bottom Action Footer */}
          <div className="p-5 border-t border-white/10 bg-white/[0.02] flex items-center justify-between gap-3">
            <div className="text-xs text-white/50">
              {isSafeUrl(project.projectUrl) ? (
                <span>Verified Public Deployment</span>
              ) : (
                <span className="text-cyan-400/90">{t.modal.noExternalUrl}</span>
              )}
            </div>

            <div className="flex items-center gap-2">
              {isSafeUrl(project.projectUrl) && (
                <a
                  href={project.projectUrl!}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs transition-colors"
                >
                  <span>{t.modal.openExternal}</span>
                  <ExternalLink size={13} />
                </a>
              )}

              {isSafeUrl(project.repoUrl) && (
                <a
                  href={project.repoUrl!}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs border border-white/15 transition-colors"
                >
                  <Github size={13} />
                  <span>{t.modal.repoLink}</span>
                </a>
              )}

              <button
                type="button"
                onClick={() => {
                  if (isTonePlaying) audio.stopAmbientSynth();
                  audio.playClick('close');
                  onClose();
                }}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-white font-medium text-xs transition-colors cursor-pointer"
              >
                {t.modal.close}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
