import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Send, Copy, Check, Mail, AlertCircle, Clock, ExternalLink } from 'lucide-react';
import { Language, ContactMessage, ServiceItem } from '../../types';
import { translations } from '../../data/translations';
import { audio } from '../../utils/audio';

interface ContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  prefillService?: ServiceItem | null;
}

export const ContactModal: React.FC<ContactModalProps> = ({
  isOpen,
  onClose,
  lang,
  prefillService
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [outboxHistory, setOutboxHistory] = useState<ContactMessage[]>([]);

  const t = translations[lang];
  const directEmail = 'alirezassezar.1@gmail.com';

  // Load local outbox history
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('nononick_outbox_messages');
        if (saved) {
          setOutboxHistory(JSON.parse(saved));
        }
      } catch {}
    }
  }, []);

  // Set prefill subject if triggered from a service inquiry
  useEffect(() => {
    if (prefillService) {
      setSubject(`Service Inquiry: ${lang === 'fa' ? prefillService.titleFa : prefillService.title}`);
      setMessage(`Hello NONONICK,\n\nI am interested in your ${prefillService.title} service. Could you share more information about your availability and estimated project timeline?\n\nBest regards,`);
    }
  }, [prefillService, lang]);

  if (!isOpen) return null;

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = 'Please provide your name';
    if (!email.trim()) {
      errs.email = 'Email address is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      errs.email = 'Please provide a valid email address';
    }
    if (!message.trim()) {
      errs.message = 'Please write your message';
    } else if (message.trim().length < 10) {
      errs.message = 'Message should be at least 10 characters';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleCopyEmail = () => {
    audio.playClick('tap');
    navigator.clipboard.writeText(directEmail);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2200);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      audio.playClick('tap');
      return;
    }

    setIsSubmitting(true);
    audio.playClick('tap');

    const newMessage: ContactMessage = {
      id: `msg_${Date.now()}`,
      name: name.trim(),
      email: email.trim(),
      subject: subject.trim() || 'General Inquiry',
      message: message.trim(),
      timestamp: new Date().toISOString()
    };

    setTimeout(() => {
      // Save locally to outbox history
      try {
        const updated = [newMessage, ...outboxHistory].slice(0, 10);
        setOutboxHistory(updated);
        localStorage.setItem('nononick_outbox_messages', JSON.stringify(updated));
      } catch {}

      // Trigger mailto client with prefilled information
      const mailtoUrl = `mailto:${directEmail}?subject=${encodeURIComponent(
        newMessage.subject
      )}&body=${encodeURIComponent(
        `From: ${newMessage.name} (${newMessage.email})\n\nMessage:\n${newMessage.message}`
      )}`;

      window.location.href = mailtoUrl;

      setIsSubmitting(false);
      setIsSuccess(true);
    }, 600);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 select-none overflow-y-auto">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => {
            audio.playClick('close');
            onClose();
          }}
          className="fixed inset-0 bg-black/80 backdrop-blur-md"
        />

        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: 20 }}
          transition={{ type: 'spring', damping: 28, stiffness: 340 }}
          className="relative z-10 w-full max-w-2xl bg-zinc-950/95 border border-white/20 rounded-[32px] ios-widget-shadow overflow-hidden flex flex-col my-auto max-h-[90vh]"
        >
          {/* Header */}
          <div className="p-6 border-b border-white/10 flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white">
                {t.contact.title}
              </h2>
              <p className="text-xs text-white/60 mt-0.5">
                {t.contact.subtitle}
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                audio.playClick('close');
                onClose();
              }}
              className="p-2 rounded-full bg-white/10 hover:bg-white/15 text-white/80 hover:text-white transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>

          {/* Body */}
          <div className="overflow-y-auto p-6 sm:p-7 space-y-6">
            {/* Quick Email Direct Card */}
            <div className="p-4 rounded-2xl bg-white/[0.04] border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0">
                  <Mail size={20} />
                </div>
                <div>
                  <div className="text-[11px] font-semibold text-white/40 uppercase tracking-wider">
                    {t.contact.directEmail}
                  </div>
                  <div className="text-sm font-mono font-medium text-white select-all">
                    {directEmail}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyEmail}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs transition-colors cursor-pointer"
                >
                  {copiedEmail ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                  <span>{copiedEmail ? 'Copied' : 'Copy'}</span>
                </button>
                <a
                  href={`mailto:${directEmail}?subject=Inquiry`}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500 text-black font-semibold text-xs hover:bg-cyan-400 transition-colors"
                >
                  <span>{t.contact.openMailClient}</span>
                  <ExternalLink size={12} />
                </a>
              </div>
            </div>

            {/* Success Banner */}
            {isSuccess && (
              <div className="p-4 rounded-2xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-200 text-xs space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-emerald-400">
                  <Check size={16} />
                  <span>{t.contact.successTitle}</span>
                </div>
                <p className="text-white/80 leading-relaxed">
                  {t.contact.successDesc}
                </p>
              </div>
            )}

            {/* Contact Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-white/70 block mb-1.5">
                    {t.contact.nameLabel} <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (errors.name) setErrors({ ...errors, name: '' });
                    }}
                    placeholder="Your Name"
                    className="w-full bg-white/[0.05] border border-white/15 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-white/30 focus:outline-none focus:border-cyan-400"
                  />
                  {errors.name && (
                    <div className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                      <AlertCircle size={11} />
                      <span>{errors.name}</span>
                    </div>
                  )}
                </div>

                <div>
                  <label className="text-xs font-semibold text-white/70 block mb-1.5">
                    {t.contact.emailLabel} <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      if (errors.email) setErrors({ ...errors, email: '' });
                    }}
                    placeholder="name@example.com"
                    className="w-full bg-white/[0.05] border border-white/15 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-white/30 focus:outline-none focus:border-cyan-400"
                  />
                  {errors.email && (
                    <div className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                      <AlertCircle size={11} />
                      <span>{errors.email}</span>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-white/70 block mb-1.5">
                  {t.contact.subjectLabel}
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Website inquiry, tool build, or architectural consult"
                  className="w-full bg-white/[0.05] border border-white/15 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-white/30 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-white/70 block mb-1.5">
                  {t.contact.messageLabel} <span className="text-rose-400">*</span>
                </label>
                <textarea
                  rows={4}
                  value={message}
                  onChange={(e) => {
                    setMessage(e.target.value);
                    if (errors.message) setErrors({ ...errors, message: '' });
                  }}
                  placeholder="Tell me about your project goals, scope, and target timeframe..."
                  className="w-full bg-white/[0.05] border border-white/15 rounded-xl p-3.5 text-sm text-white placeholder-white/30 focus:outline-none focus:border-cyan-400 resize-none"
                />
                {errors.message && (
                  <div className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                    <AlertCircle size={11} />
                    <span>{errors.message}</span>
                  </div>
                )}
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 rounded-xl bg-white text-black font-semibold text-sm hover:bg-white/90 active:scale-[0.99] transition-all flex items-center justify-center gap-2 shadow-xl cursor-pointer disabled:opacity-50"
              >
                <Send size={15} />
                <span>{isSubmitting ? t.contact.sending : t.contact.sendButton}</span>
              </button>
            </form>

            {/* Outbox Local History */}
            {outboxHistory.length > 0 && (
              <div className="pt-4 border-t border-white/10">
                <div className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Clock size={12} />
                  <span>{t.contact.recentMessages}</span>
                </div>
                <div className="space-y-2">
                  {outboxHistory.map((m) => (
                    <div key={m.id} className="p-3 rounded-xl bg-white/[0.02] border border-white/10 text-xs">
                      <div className="flex items-center justify-between text-white/90 font-medium">
                        <span>{m.subject}</span>
                        <span className="text-[10px] text-white/40 font-mono">
                          {new Date(m.timestamp).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-white/60 line-clamp-1 mt-0.5">{m.message}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
