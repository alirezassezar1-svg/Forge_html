import React, { useEffect, useRef } from 'react';

interface InteractiveOrbProps {
  reducedMotion?: boolean;
}

export const InteractiveOrb: React.FC<InteractiveOrbProps> = ({ reducedMotion = false }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let angleX = 0;
    let angleY = 0;
    let targetAngleX = 0;
    let targetAngleY = 0;

    // Generate points on sphere using Fibonacci distribution
    const numPoints = 84;
    const points: { x: number; y: number; z: number; origX: number; origY: number; origZ: number }[] = [];
    const radius = 64;

    const phi = Math.PI * (3 - Math.sqrt(5)); // Golden angle

    for (let i = 0; i < numPoints; i++) {
      const y = 1 - (i / (numPoints - 1)) * 2; // y goes from 1 to -1
      const radiusAtY = Math.sqrt(1 - y * y);
      const theta = phi * i;

      const x = Math.cos(theta) * radiusAtY;
      const z = Math.sin(theta) * radiusAtY;

      points.push({
        x: x * radius,
        y: y * radius,
        z: z * radius,
        origX: x * radius,
        origY: y * radius,
        origZ: z * radius
      });
    }

    const handlePointerMove = (e: MouseEvent | TouchEvent) => {
      if (reducedMotion) return;
      const rect = canvas.getBoundingClientRect();
      const clientX = 'touches' in e ? e.touches[0].clientX : (e as MouseEvent).clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : (e as MouseEvent).clientY;
      const mouseX = (clientX - rect.left) / rect.width - 0.5;
      const mouseY = (clientY - rect.top) / rect.height - 0.5;

      targetAngleY = mouseX * 2.5;
      targetAngleX = -mouseY * 2.5;
    };

    window.addEventListener('mousemove', handlePointerMove);
    canvas.addEventListener('touchmove', handlePointerMove, { passive: true });

    let t = 0;

    const render = () => {
      t += 0.016;

      if (!reducedMotion) {
        angleX += (targetAngleX - angleX) * 0.08 + 0.003;
        angleY += (targetAngleY - angleY) * 0.08 + 0.006;
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;

      // Glow backdrop
      const radialGradient = ctx.createRadialGradient(
        centerX, centerY, 10,
        centerX, centerY, radius * 1.5
      );
      radialGradient.addColorStop(0, 'rgba(10, 132, 255, 0.22)');
      radialGradient.addColorStop(0.5, 'rgba(191, 90, 242, 0.12)');
      radialGradient.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = radialGradient;
      ctx.beginPath();
      ctx.arc(centerX, centerY, radius * 1.4, 0, Math.PI * 2);
      ctx.fill();

      // Project & sort points by Z depth
      const projected = points.map((p, idx) => {
        // Rotate around Y
        const cosY = Math.cos(angleY);
        const sinY = Math.sin(angleY);
        const x1 = p.origX * cosY - p.origZ * sinY;
        const z1 = p.origZ * cosY + p.origX * sinY;

        // Rotate around X
        const cosX = Math.cos(angleX);
        const sinX = Math.sin(angleX);
        const y2 = p.origY * cosX - z1 * sinX;
        const z2 = z1 * cosX + p.origY * sinX;

        // Perspective projection
        const fov = 200;
        const scale = fov / (fov + z2);
        const px = centerX + x1 * scale;
        const py = centerY + y2 * scale;

        return { px, py, z: z2, scale, idx };
      });

      projected.sort((a, b) => a.z - b.z);

      // Connect near neighbors with faint energy filaments
      ctx.lineWidth = 0.6;
      for (let i = 0; i < projected.length; i++) {
        for (let j = i + 1; j < projected.length; j++) {
          const p1 = projected[i];
          const p2 = projected[j];
          const dx = p1.px - p2.px;
          const dy = p1.py - p2.py;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 32) {
            const alpha = (1 - dist / 32) * (p1.z > 0 ? 0.35 : 0.12);
            ctx.strokeStyle = `rgba(100, 210, 255, ${alpha})`;
            ctx.beginPath();
            ctx.moveTo(p1.px, p1.py);
            ctx.lineTo(p2.px, p2.py);
            ctx.stroke();
          }
        }
      }

      // Draw points with optical depth
      projected.forEach((p) => {
        const normalizedZ = (p.z + radius) / (radius * 2); // 0 to 1
        const ptRadius = Math.max(0.8, (0.8 + normalizedZ * 1.8) * p.scale);

        ctx.beginPath();
        ctx.arc(p.px, p.py, ptRadius, 0, Math.PI * 2);

        if (normalizedZ > 0.6) {
          ctx.fillStyle = '#64D2FF';
          ctx.shadowColor = '#0A84FF';
          ctx.shadowBlur = 6;
        } else {
          ctx.fillStyle = `rgba(191, 90, 242, ${0.3 + normalizedZ * 0.5})`;
          ctx.shadowBlur = 0;
        }
        ctx.fill();
      });

      // Subtle equatorial orbital ring
      ctx.shadowBlur = 0;
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(angleY * 0.4);
      ctx.beginPath();
      ctx.ellipse(0, 0, radius * 1.25, radius * 0.35, angleX * 0.2, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
      ctx.lineWidth = 1;
      ctx.stroke();
      ctx.restore();

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('mousemove', handlePointerMove);
      canvas.removeEventListener('touchmove', handlePointerMove);
    };
  }, [reducedMotion]);

  return (
    <div className="relative flex items-center justify-center w-36 h-36 md:w-44 md:h-44 shrink-0 pointer-events-none">
      <canvas
        ref={canvasRef}
        width={180}
        height={180}
        className="w-full h-full object-contain filter drop-shadow-[0_0_24px_rgba(10,132,255,0.35)]"
        aria-hidden="true"
      />
    </div>
  );
};
