import React, { useState } from 'react';
import { Mail, Copy, Check, Send, ExternalLink } from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../data/translations';
import { audio } from '../../utils/audio';

interface QuickContactWidgetProps {
  lang: Language;
  onOpenContact: () => void;
}

export const QuickContactWidget: React.FC<QuickContactWidgetProps> = ({
  lang,
  onOpenContact
}) => {
  const [copied, setCopied] = useState(false);
  const t = translations[lang];
  const email = 'alirezassezar.1@gmail.com';

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    audio.playClick('tap');
    navigator.clipboard.writeText(email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  return (
    <div className="relative w-full h-full rounded-[24px] ios-glass-dark p-5 ios-widget-shadow border border-white/15 flex flex-col justify-between overflow-hidden">
      {/* Top Header */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-rose-400 uppercase tracking-wider">
            <Mail size={13} />
            <span>{t.widgets.quickContactTitle}</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono">
            Direct & Responsive
          </span>
        </div>

        <div className="text-xs text-white/80 font-normal leading-relaxed">
          Open for engineering opportunities, UI architectural consultations & bespoke tools.
        </div>
      </div>

      {/* Email Display & 1-Click Copy */}
      <div className="my-2 p-2.5 rounded-xl bg-white/[0.04] border border-white/10 flex items-center justify-between gap-2">
        <span className="text-[11px] font-mono text-cyan-300 truncate">
          {email}
        </span>
        <button
          type="button"
          onClick={handleCopy}
          className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-all shrink-0 cursor-pointer"
          title="Copy Email"
        >
          {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
        </button>
      </div>

      {/* Buttons */}
      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/10">
        <button
          type="button"
          onClick={() => {
            audio.playClick('open');
            onOpenContact();
          }}
          className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-white text-black font-semibold text-xs hover:bg-white/90 active:scale-95 transition-all shadow-md cursor-pointer"
        >
          <Send size={12} />
          <span>Write Note</span>
        </button>

        <a
          href={`mailto:${email}?subject=Project%20Inquiry%20via%20NONONICK%20OS`}
          onClick={() => audio.playClick('tap')}
          className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-white/10 hover:bg-white/15 text-white font-medium text-xs border border-white/10 active:scale-95 transition-all"
        >
          <span>Mailto</span>
          <ExternalLink size={11} />
        </a>
      </div>
    </div>
  );
};
