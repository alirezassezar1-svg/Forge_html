import React from 'react';
import { Layers, ArrowRight, Layout, Wrench, Sparkles, ShieldCheck } from 'lucide-react';
import { servicesData } from '../../data/servicesData';
import { Language } from '../../types';
import { translations } from '../../data/translations';
import { audio } from '../../utils/audio';

interface ServicesWidgetProps {
  lang: Language;
  onOpenServices: () => void;
}

const serviceIcons: Record<string, React.ElementType> = {
  Layout,
  Wrench,
  Sparkles,
  ShieldCheck
};

export const ServicesWidget: React.FC<ServicesWidgetProps> = ({
  lang,
  onOpenServices
}) => {
  const t = translations[lang];

  return (
    <div
      onClick={() => {
        audio.playClick('open');
        onOpenServices();
      }}
      className="group relative w-full h-full rounded-[24px] ios-glass-dark p-5 ios-widget-shadow border border-white/15 hover:border-purple-500/40 transition-all flex flex-col justify-between cursor-pointer overflow-hidden"
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold text-purple-400 uppercase tracking-wider">
          <Layers size={13} />
          <span>{t.widgets.servicesTitle}</span>
        </div>
        <ArrowRight size={13} className="text-white/40 group-hover:text-purple-300 group-hover:translate-x-0.5 transition-all" />
      </div>

      <div className="grid grid-cols-2 gap-2 my-1">
        {servicesData.map((s) => {
          const Icon = serviceIcons[s.iconName] || Layers;
          const title = lang === 'fa' ? s.titleFa : s.title;

          return (
            <div
              key={s.id}
              className="p-2.5 rounded-xl bg-white/[0.04] border border-white/10 group-hover:bg-white/[0.07] transition-colors flex items-center gap-2"
            >
              <div
                className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                style={{ backgroundColor: `${s.accentColor}25`, color: s.accentColor }}
              >
                <Icon size={14} />
              </div>
              <span className="text-[11px] font-medium text-white/90 truncate leading-snug">
                {title}
              </span>
            </div>
          );
        })}
      </div>

      <div className="text-[11px] text-white/50 pt-2 border-t border-white/10 flex items-center justify-between">
        <span>Tailored Architecture · Fast Delivery</span>
        <span className="text-purple-400 font-semibold">{t.myServices}</span>
      </div>
    </div>
  );
};
