import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
}

export const DigitalExperimentsCanvas: React.FC<{ reducedMotion?: boolean }> = ({ reducedMotion = false }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    const particles: Particle[] = [];
    const colors = ['#0A84FF', '#64D2FF', '#BF5AF2', '#FF375F', '#30D158'];

    const spawnParticle = (x: number, y: number) => {
      const angle = Math.random() * Math.PI * 2;
      const speed = Math.random() * 2 + 0.5;
      particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: Math.random() * 3 + 1.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        alpha: 1,
        life: 1
      });
      if (particles.length > 60) {
        particles.shift();
      }
    };

    const handlePointer = (e: MouseEvent | TouchEvent) => {
      const rect = canvas.getBoundingClientRect();
      const clientX = 'touches' in e ? e.touches[0].clientX : (e as MouseEvent).clientX;
      const clientY = 'touches' in e ? e.touches[0].clientY : (e as MouseEvent).clientY;
      const x = ((clientX - rect.left) / rect.width) * canvas.width;
      const y = ((clientY - rect.top) / rect.height) * canvas.height;

      for (let i = 0; i < 3; i++) {
        spawnParticle(x + (Math.random() - 0.5) * 10, y + (Math.random() - 0.5) * 10);
      }
    };

    canvas.addEventListener('mousemove', handlePointer);
    canvas.addEventListener('touchmove', handlePointer, { passive: true });

    // Seed initial gentle floating nodes
    for (let i = 0; i < 18; i++) {
      spawnParticle(Math.random() * canvas.width, Math.random() * canvas.height);
    }

    let t = 0;

    const render = () => {
      t += 0.02;
      ctx.fillStyle = 'rgba(10, 11, 14, 0.35)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      if (!reducedMotion && Math.random() < 0.08) {
        spawnParticle(Math.random() * canvas.width, Math.random() * canvas.height);
      }

      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 0.012;
        p.alpha = Math.max(0, p.life);

        // bounce walls
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.fill();

        // Connect nearby particles
        for (let j = i - 1; j >= 0; j--) {
          const p2 = particles[j];
          const dist = Math.hypot(p.x - p2.x, p.y - p2.y);
          if (dist < 45) {
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.strokeStyle = p.color;
            ctx.globalAlpha = (1 - dist / 45) * 0.25 * p.alpha;
            ctx.lineWidth = 0.8;
            ctx.stroke();
          }
        }

        ctx.globalAlpha = 1;

        if (p.life <= 0) {
          particles.splice(i, 1);
        }
      }

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
      canvas.removeEventListener('mousemove', handlePointer);
      canvas.removeEventListener('touchmove', handlePointer);
    };
  }, [reducedMotion]);

  return (
    <div className="relative w-full h-28 rounded-xl overflow-hidden bg-black/60 border border-white/10 group cursor-crosshair">
      <canvas
        ref={canvasRef}
        width={320}
        height={112}
        className="w-full h-full block"
      />
      <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/70 backdrop-blur-md text-[10px] text-white/60 pointer-events-none border border-white/10">
        Canvas 2D Particle Lab
      </div>
    </div>
  );
};
