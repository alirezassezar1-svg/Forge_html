import React from 'react';
import { motion } from 'motion/react';
import { ArrowUpRight, Sparkles, Mail, Layers } from 'lucide-react';
import { InteractiveOrb } from './InteractiveOrb';
import { Language } from '../../types';
import { translations } from '../../data/translations';
import { audio } from '../../utils/audio';

interface HeroWidgetProps {
  lang: Language;
  onExploreProjects: () => void;
  onOpenServices: () => void;
  onOpenContact: () => void;
  reducedMotion?: boolean;
}

export const HeroWidget: React.FC<HeroWidgetProps> = ({
  lang,
  onExploreProjects,
  onOpenServices,
  onOpenContact,
  reducedMotion = false
}) => {
  const t = translations[lang];

  // Time-based greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return t.greetingMorning;
    if (hour < 18) return t.greetingAfternoon;
    return t.greetingEvening;
  };

  return (
    <div className="relative w-full rounded-[28px] ios-glass-dark p-6 sm:p-7 ios-widget-shadow overflow-hidden border border-white/15">
      {/* Background ambient lighting */}
      <div className="absolute -top-24 -left-24 w-64 h-64 rounded-full bg-blue-600/15 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-64 h-64 rounded-full bg-purple-600/15 blur-3xl pointer-events-none" />

      <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Left: Identity & Prose */}
        <div className="flex-1 text-center md:text-start flex flex-col items-center md:items-start">
          {/* Subtle kicker */}
          <div className="flex items-center gap-2 mb-1.5 text-xs font-semibold tracking-wider uppercase text-cyan-400">
            <Sparkles size={13} className="shrink-0" />
            <span>{getGreeting()} · {t.portfolioTitle}</span>
          </div>

          {/* Wordmark */}
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white mb-2">
            NONO<span className="text-cyan-400">NICK</span>
          </h1>

          <div className="text-sm font-semibold text-white/90 mb-2">
            {t.heroRole}
          </div>

          <p className="text-xs sm:text-sm text-white/70 max-w-xl leading-relaxed mb-6 font-normal">
            {t.heroIntro}
          </p>

          {/* Primary Action Buttons */}
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-2.5 w-full">
            <button
              type="button"
              onClick={() => {
                audio.playClick('open');
                onExploreProjects();
              }}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white text-black font-semibold text-xs hover:bg-white/90 active:scale-95 transition-all shadow-lg shadow-white/10 cursor-pointer"
            >
              <span>{t.exploreProjects}</span>
              <ArrowUpRight size={14} />
            </button>

            <button
              type="button"
              onClick={() => {
                audio.playClick('open');
                onOpenServices();
              }}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-medium text-xs active:scale-95 border border-white/15 transition-all cursor-pointer"
            >
              <Layers size={14} className="text-cyan-400" />
              <span>{t.myServices}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                audio.playClick('open');
                onOpenContact();
              }}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 text-white font-medium text-xs active:scale-95 border border-white/15 transition-all cursor-pointer"
            >
              <Mail size={14} className="text-purple-400" />
              <span>{t.contactMe}</span>
            </button>
          </div>
        </div>

        {/* Right: Interactive 3D Generative Orb */}
        <div className="shrink-0 flex items-center justify-center">
          <InteractiveOrb reducedMotion={reducedMotion} />
        </div>
      </div>
    </div>
  );
};
