import React from 'react';
import { User, ArrowRight, Code2 } from 'lucide-react';
import { Language } from '../../types';
import { translations } from '../../data/translations';
import { audio } from '../../utils/audio';

interface AboutMeWidgetProps {
  lang: Language;
  onOpenAbout: () => void;
}

export const AboutMeWidget: React.FC<AboutMeWidgetProps> = ({
  lang,
  onOpenAbout
}) => {
  const t = translations[lang];

  return (
    <div
      onClick={() => {
        audio.playClick('open');
        onOpenAbout();
      }}
      className="group relative w-full h-full rounded-[24px] ios-glass-dark p-5 ios-widget-shadow border border-white/15 hover:border-cyan-500/40 transition-all flex flex-col justify-between cursor-pointer overflow-hidden"
    >
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-cyan-400 uppercase tracking-wider">
            <User size={13} />
            <span>{t.widgets.aboutTitle}</span>
          </div>
          <ArrowRight size={13} className="text-white/40 group-hover:text-cyan-300 group-hover:translate-x-0.5 transition-all" />
        </div>

        <div className="text-sm font-bold text-white mb-1">
          NONONICK · Creative Engineer
        </div>

        <p className="text-xs text-white/70 line-clamp-3 font-normal leading-relaxed">
          {lang === 'fa' ? t.about.statement1 : t.about.statement1}
        </p>
      </div>

      <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-white/50">
        <div className="flex items-center gap-1">
          <Code2 size={12} className="text-cyan-400" />
          <span>TypeScript · React · Apple UI</span>
        </div>
        <span className="text-cyan-400 font-semibold group-hover:underline">
          Read Story
        </span>
      </div>
    </div>
  );
};
