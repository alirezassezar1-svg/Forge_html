import React from 'react';
import { Sparkles, ArrowRight, CheckCircle2 } from 'lucide-react';
import { Project, Language } from '../../types';
import { translations } from '../../data/translations';
import { audio } from '../../utils/audio';

interface FeaturedProjectWidgetProps {
  project: Project;
  lang: Language;
  onOpen: (project: Project) => void;
}

export const FeaturedProjectWidget: React.FC<FeaturedProjectWidgetProps> = ({
  project,
  lang,
  onOpen
}) => {
  const t = translations[lang];
  const name = lang === 'fa' ? project.nameFa : project.name;
  const desc = lang === 'fa' ? project.descriptionFa : project.description;

  return (
    <div
      onClick={() => {
        audio.playClick('open');
        onOpen(project);
      }}
      className="group relative w-full h-full rounded-[24px] ios-glass-dark p-5 ios-widget-shadow border border-white/15 hover:border-cyan-500/40 transition-all flex flex-col justify-between cursor-pointer overflow-hidden"
    >
      {/* Top ambient sheen */}
      <div className="absolute -top-12 -right-12 w-32 h-32 rounded-full bg-cyan-500/15 blur-2xl pointer-events-none group-hover:bg-cyan-500/25 transition-all" />

      {/* Header */}
      <div>
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-cyan-400 uppercase tracking-wider">
            <Sparkles size={12} />
            <span>{t.widgets.featuredTitle}</span>
          </div>

          <div className="flex items-center gap-1 text-[10px] font-medium text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2 py-0.5 rounded-full">
            <CheckCircle2 size={10} />
            <span>{lang === 'fa' ? project.statusFa : project.status}</span>
          </div>
        </div>

        <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-cyan-300 transition-colors">
          {name}
        </h3>

        <p className="text-xs text-white/70 line-clamp-2 mt-1 font-normal leading-relaxed">
          {desc}
        </p>
      </div>

      {/* Technologies & CTA row */}
      <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
        <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-white/50">
          {project.technologies.slice(0, 3).map((tech, idx) => (
            <React.Fragment key={tech}>
              <span>{tech}</span>
              {idx < 2 && idx < project.technologies.slice(0, 3).length - 1 && (
                <span className="text-white/20">·</span>
              )}
            </React.Fragment>
          ))}
        </div>

        <div className="flex items-center gap-1 text-xs font-semibold text-white group-hover:text-cyan-400 transition-colors">
          <span>{t.viewProject}</span>
          <ArrowRight size={13} className="group-hover:translate-x-0.5 transition-transform" />
        </div>
      </div>
    </div>
  );
};
