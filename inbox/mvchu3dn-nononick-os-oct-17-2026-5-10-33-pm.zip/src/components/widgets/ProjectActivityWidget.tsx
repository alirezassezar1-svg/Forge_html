import React from 'react';
import { Activity, CheckCircle, Clock, FlaskConical } from 'lucide-react';
import { Project, Language } from '../../types';
import { translations } from '../../data/translations';

interface ProjectActivityWidgetProps {
  projects: Project[];
  lang: Language;
}

export const ProjectActivityWidget: React.FC<ProjectActivityWidgetProps> = ({
  projects,
  lang
}) => {
  const t = translations[lang];

  const liveCount = projects.filter((p) => p.status === 'Live').length;
  const devCount = projects.filter((p) => p.status === 'In Development').length;
  const expCount = projects.filter((p) => p.status === 'Experimental').length;

  return (
    <div className="relative w-full h-full rounded-[24px] ios-glass-dark p-5 ios-widget-shadow border border-white/15 flex flex-col justify-between overflow-hidden">
      {/* Header */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-400 uppercase tracking-wider">
            <Activity size={13} />
            <span>{t.widgets.activityTitle}</span>
          </div>
          <span className="text-[10px] text-white/40 font-mono">
            VERIFIED CATALOG
          </span>
        </div>

        <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono tabular-nums tracking-tight">
          {projects.length}
          <span className="text-xs font-normal text-white/50 ml-1.5 font-sans">
            {t.widgets.projectsCount}
          </span>
        </div>
      </div>

      {/* Real Breakdown Stats */}
      <div className="space-y-2 my-2">
        {/* Live */}
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-white/80">
            <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_6px_#30d158]" />
            <span>{t.widgets.liveCount}</span>
          </div>
          <span className="font-mono tabular-nums font-semibold text-emerald-300">
            {liveCount}
          </span>
        </div>

        {/* Development */}
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-white/80">
            <div className="w-2 h-2 rounded-full bg-amber-400 shadow-[0_0_6px_#ff9f0a]" />
            <span>{t.widgets.devCount}</span>
          </div>
          <span className="font-mono tabular-nums font-semibold text-amber-300">
            {devCount}
          </span>
        </div>

        {/* Experimental */}
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-white/80">
            <div className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_6px_#64d2ff]" />
            <span>{t.widgets.experimentalCount}</span>
          </div>
          <span className="font-mono tabular-nums font-semibold text-cyan-300">
            {expCount}
          </span>
        </div>
      </div>

      {/* Footer honesty disclaimer */}
      <div className="pt-2 border-t border-white/10 text-[10px] text-white/40 flex items-center justify-between">
        <span>{t.widgets.verifiedDataNotice}</span>
        <span className="text-emerald-400">100% Honest</span>
      </div>
    </div>
  );
};
