import React from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';
import { DigitalExperimentsCanvas } from './DigitalExperimentsCanvas';
import { Language, Project } from '../../types';
import { translations } from '../../data/translations';
import { audio } from '../../utils/audio';

interface DigitalExperimentsWidgetProps {
  lang: Language;
  onOpenProject: (p: Project) => void;
  project: Project;
  reducedMotion?: boolean;
}

export const DigitalExperimentsWidget: React.FC<DigitalExperimentsWidgetProps> = ({
  lang,
  onOpenProject,
  project,
  reducedMotion = false
}) => {
  const t = translations[lang];

  return (
    <div className="relative w-full h-full rounded-[24px] ios-glass-dark p-5 ios-widget-shadow border border-white/15 flex flex-col justify-between overflow-hidden">
      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-[11px] font-semibold text-cyan-400 uppercase tracking-wider">
            <Sparkles size={13} />
            <span>{t.widgets.digitalExperimentsTitle}</span>
          </div>
          <span className="text-[10px] text-white/50 font-mono">
            Interactive
          </span>
        </div>

        <p className="text-[11px] text-white/60 mb-2">
          {t.widgets.interactiveToyNotice}
        </p>
      </div>

      {/* Interactive canvas mini-sandbox */}
      <div className="my-1">
        <DigitalExperimentsCanvas reducedMotion={reducedMotion} />
      </div>

      <div className="pt-2 border-t border-white/10 flex items-center justify-between">
        <span className="text-[11px] text-white/50">Generative Physics & Shaders</span>
        <button
          type="button"
          onClick={() => {
            audio.playClick('open');
            onOpenProject(project);
          }}
          className="flex items-center gap-1 text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition-colors cursor-pointer"
        >
          <span>Lab Details</span>
          <ArrowRight size={12} />
        </button>
      </div>
    </div>
  );
};
