import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, X, Layers, Globe, Sparkles, Server, Headphones, Shapes, Wrench, Smartphone, FlaskConical, ArrowRight } from 'lucide-react';
import { Project, ServiceItem, Language } from '../types';
import { translations } from '../data/translations';
import { audio } from '../utils/audio';

interface SpotlightSearchProps {
  isOpen: boolean;
  onClose: () => void;
  projects: Project[];
  services: ServiceItem[];
  lang: Language;
  onSelectProject: (p: Project) => void;
  onSelectService: (s: ServiceItem) => void;
}

const iconMap: Record<string, React.ElementType> = {
  Globe,
  Sparkles,
  Server,
  Headphones,
  Shapes,
  Wrench,
  Smartphone,
  FlaskConical
};

export const SpotlightSearch: React.FC<SpotlightSearchProps> = ({
  isOpen,
  onClose,
  projects,
  services,
  lang,
  onSelectProject,
  onSelectService
}) => {
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const inputRef = useRef<HTMLInputElement | null>(null);
  const t = translations[lang];

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 80);
    } else {
      setQuery('');
      setSelectedCategory('all');
    }
  }, [isOpen]);

  // Global Cmd+K / Ctrl+K listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else {
          audio.playClick('open');
          // Can be toggled externally
        }
      } else if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const normalizedQuery = query.toLowerCase().trim();

  // Filter projects
  const filteredProjects = projects.filter((p) => {
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    if (!matchesCategory) return false;

    if (!normalizedQuery) return true;

    return (
      p.name.toLowerCase().includes(normalizedQuery) ||
      p.nameFa.includes(normalizedQuery) ||
      p.description.toLowerCase().includes(normalizedQuery) ||
      p.descriptionFa.includes(normalizedQuery) ||
      p.technologies.some((tech) => tech.toLowerCase().includes(normalizedQuery)) ||
      p.status.toLowerCase().includes(normalizedQuery)
    );
  });

  // Filter services
  const filteredServices = services.filter((s) => {
    if (selectedCategory !== 'all') return false;
    if (!normalizedQuery) return true;
    return (
      s.title.toLowerCase().includes(normalizedQuery) ||
      s.titleFa.includes(normalizedQuery) ||
      s.shortDesc.toLowerCase().includes(normalizedQuery) ||
      s.techFocus.some((tech) => tech.toLowerCase().includes(normalizedQuery))
    );
  });

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 select-none">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => {
            audio.playClick('close');
            onClose();
          }}
          className="fixed inset-0 bg-black/75 backdrop-blur-md"
        />

        {/* Modal Window */}
        <motion.div
          initial={{ opacity: 0, scale: 0.94, y: -20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.94, y: -20 }}
          transition={{ type: 'spring', damping: 26, stiffness: 320 }}
          className="relative z-10 w-full max-w-2xl bg-zinc-950/95 border border-white/20 rounded-3xl ios-widget-shadow overflow-hidden flex flex-col max-h-[80vh]"
        >
          {/* Search Header */}
          <div className="p-4 sm:p-5 border-b border-white/10 flex items-center gap-3">
            <Search size={20} className="text-cyan-400 shrink-0" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full bg-transparent text-white placeholder-white/40 text-base sm:text-lg focus:outline-none"
            />
            {query ? (
              <button
                type="button"
                onClick={() => setQuery('')}
                className="p-1 rounded-full text-white/50 hover:text-white bg-white/10"
              >
                <X size={16} />
              </button>
            ) : (
              <kbd className="hidden sm:inline-block px-2 py-0.5 rounded bg-white/10 border border-white/15 text-[11px] font-mono text-white/50">
                ESC
              </kbd>
            )}
          </div>

          {/* Quick Filter Categories */}
          <div className="px-4 py-2.5 border-b border-white/10 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            {(['all', 'web', 'ai', 'tools', 'audio', 'experiments'] as const).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => {
                  audio.playClick('tap');
                  setSelectedCategory(cat);
                }}
                className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-cyan-500 text-black font-semibold'
                    : 'bg-white/[0.06] hover:bg-white/[0.12] text-white/70 hover:text-white'
                }`}
              >
                {t.categories[cat]}
              </button>
            ))}
          </div>

          {/* Results List */}
          <div className="overflow-y-auto p-4 space-y-4">
            {/* Projects Group */}
            {filteredProjects.length > 0 && (
              <div>
                <div className="text-[11px] font-semibold text-white/40 uppercase tracking-wider mb-2 px-2">
                  {t.allProjects} ({filteredProjects.length})
                </div>
                <div className="space-y-1.5">
                  {filteredProjects.map((p) => {
                    const Icon = iconMap[p.iconName] || Globe;
                    const name = lang === 'fa' ? p.nameFa : p.name;
                    const desc = lang === 'fa' ? p.descriptionFa : p.description;

                    return (
                      <div
                        key={p.id}
                        onClick={() => {
                          audio.playClick('open');
                          onSelectProject(p);
                          onClose();
                        }}
                        className="flex items-center justify-between p-3 rounded-2xl hover:bg-white/[0.08] active:bg-white/[0.12] transition-colors cursor-pointer border border-transparent hover:border-white/10 group"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${p.gradient} flex items-center justify-center shrink-0 border border-white/20 shadow-md`}>
                            <Icon size={18} className="text-white" />
                          </div>
                          <div className="min-w-0">
                            <div className="text-sm font-semibold text-white group-hover:text-cyan-300 transition-colors flex items-center gap-2">
                              <span className="truncate">{name}</span>
                              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-white/10 text-white/60 font-mono">
                                {p.status}
                              </span>
                            </div>
                            <div className="text-xs text-white/60 truncate mt-0.5 font-normal">
                              {desc}
                            </div>
                          </div>
                        </div>

                        <ArrowRight size={16} className="text-white/30 group-hover:text-cyan-400 group-hover:translate-x-1 transition-all shrink-0 ml-3" />
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Services Group */}
            {filteredServices.length > 0 && (
              <div className="pt-2">
                <div className="text-[11px] font-semibold text-white/40 uppercase tracking-wider mb-2 px-2">
                  {t.widgets.servicesTitle} ({filteredServices.length})
                </div>
                <div className="space-y-1.5">
                  {filteredServices.map((s) => {
                    const title = lang === 'fa' ? s.titleFa : s.title;
                    const desc = lang === 'fa' ? s.shortDescFa : s.shortDesc;

                    return (
                      <div
                        key={s.id}
                        onClick={() => {
                          audio.playClick('open');
                          onSelectService(s);
                          onClose();
                        }}
                        className="flex items-center justify-between p-3 rounded-2xl hover:bg-white/[0.08] active:bg-white/[0.12] transition-colors cursor-pointer border border-transparent hover:border-white/10 group"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          <div
                            className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border border-white/20 shadow-md"
                            style={{ backgroundColor: `${s.accentColor}30`, color: s.accentColor }}
                          >
                            <Layers size={18} />
                          </div>
                          <div className="min-w-0">
                            <div className="text-sm font-semibold text-white group-hover:text-purple-300 transition-colors">
                              {title}
                            </div>
                            <div className="text-xs text-white/60 truncate mt-0.5 font-normal">
                              {desc}
                            </div>
                          </div>
                        </div>

                        <ArrowRight size={16} className="text-white/30 group-hover:text-purple-400 group-hover:translate-x-1 transition-all shrink-0 ml-3" />
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {filteredProjects.length === 0 && filteredServices.length === 0 && (
              <div className="py-12 text-center text-white/50 text-sm">
                No matching projects, tools, or services found for &quot;{query}&quot;.
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
