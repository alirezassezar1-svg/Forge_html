/**
 * Zero-dependency Procedural Web Audio Engine for NONONICK OS
 * Provides subtle tactile interaction feedback and an ambient procedural lofi synthesizer
 * for the Dynamic Island player.
 */

class AudioEngine {
  private ctx: AudioContext | null = null;
  private isAmbientPlaying = false;
  private ambientOscillators: OscillatorNode[] = [];
  private ambientGainNode: GainNode | null = null;
  private filterNode: BiquadFilterNode | null = null;
  private lfo: OscillatorNode | null = null;
  private isSoundEnabled = true;

  private initContext() {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public setSoundEnabled(enabled: boolean) {
    this.isSoundEnabled = enabled;
    if (!enabled && this.isAmbientPlaying) {
      this.stopAmbientSynth();
    }
  }

  /**
   * Tactile click cue inspired by iOS haptic feedback
   */
  public playClick(type: 'tap' | 'open' | 'close' | 'switch' = 'tap') {
    if (!this.isSoundEnabled) return;
    try {
      this.initContext();
      if (!this.ctx) return;

      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      const filter = this.ctx.createBiquadFilter();

      filter.type = 'lowpass';

      if (type === 'tap') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(320, now);
        osc.frequency.exponentialRampToValueAtTime(140, now + 0.025);

        filter.frequency.setValueAtTime(900, now);

        gain.gain.setValueAtTime(0.045, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.025);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now);
        osc.stop(now + 0.025);
      } else if (type === 'open') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(660, now + 0.08);

        filter.frequency.setValueAtTime(1200, now);

        gain.gain.setValueAtTime(0.05, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now);
        osc.stop(now + 0.09);
      } else if (type === 'close') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(540, now);
        osc.frequency.exponentialRampToValueAtTime(280, now + 0.06);

        filter.frequency.setValueAtTime(800, now);

        gain.gain.setValueAtTime(0.035, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now);
        osc.stop(now + 0.06);
      } else if (type === 'switch') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(400, now);
        osc.frequency.setValueAtTime(480, now + 0.015);

        gain.gain.setValueAtTime(0.04, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now);
        osc.stop(now + 0.04);
      }
    } catch {
      // AudioContext policy suppression gracefully handled
    }
  }

  /**
   * Procedural Ambient Lo-Fi Synthesizer (Dynamic Island Player)
   * Cycles gentle chords (Fmaj9 / Cmaj7) with organic filter modulation
   */
  public startAmbientSynth() {
    try {
      this.initContext();
      if (!this.ctx) return;
      if (this.isAmbientPlaying) return;

      const now = this.ctx.currentTime;

      // Master gain for ambient
      const masterGain = this.ctx.createGain();
      masterGain.gain.setValueAtTime(0.001, now);
      masterGain.gain.linearRampToValueAtTime(0.09, now + 1.2);
      masterGain.connect(this.ctx.destination);
      this.ambientGainNode = masterGain;

      // Warm lowpass filter
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(480, now);
      filter.Q.setValueAtTime(2.2, now);
      filter.connect(masterGain);
      this.filterNode = filter;

      // LFO for slow atmospheric breathing filter movement
      const lfo = this.ctx.createOscillator();
      const lfoGain = this.ctx.createGain();
      lfo.frequency.setValueAtTime(0.2, now); // 5 second cycle
      lfoGain.gain.setValueAtTime(140, now);
      lfo.connect(lfoGain);
      lfoGain.connect(filter.frequency);
      lfo.start(now);
      this.lfo = lfo;

      // Chord frequencies: C3 (130.81), G3 (196.00), B3 (246.94), E4 (329.63)
      const freqs = [130.81, 196.00, 246.94, 329.63];
      this.ambientOscillators = freqs.map((freq, idx) => {
        const osc = this.ctx!.createOscillator();
        osc.type = idx % 2 === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, now);
        // Subtle detune for analog warmth
        osc.detune.setValueAtTime((idx - 1.5) * 4, now);

        const noteGain = this.ctx!.createGain();
        noteGain.gain.setValueAtTime(0.35, now);
        osc.connect(noteGain);
        noteGain.connect(filter);

        osc.start(now);
        return osc;
      });

      this.isAmbientPlaying = true;
    } catch {
      this.isAmbientPlaying = false;
    }
  }

  public stopAmbientSynth() {
    if (!this.isAmbientPlaying || !this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      if (this.ambientGainNode) {
        this.ambientGainNode.gain.linearRampToValueAtTime(0.001, now + 0.6);
      }

      setTimeout(() => {
        this.ambientOscillators.forEach(osc => {
          try {
            osc.stop();
            osc.disconnect();
          } catch {}
        });
        this.ambientOscillators = [];

        if (this.lfo) {
          try {
            this.lfo.stop();
            this.lfo.disconnect();
          } catch {}
          this.lfo = null;
        }

        if (this.filterNode) {
          this.filterNode.disconnect();
          this.filterNode = null;
        }

        if (this.ambientGainNode) {
          this.ambientGainNode.disconnect();
          this.ambientGainNode = null;
        }

        this.isAmbientPlaying = false;
      }, 650);
    } catch {
      this.isAmbientPlaying = false;
    }
  }

  public toggleAmbientSynth(): boolean {
    if (this.isAmbientPlaying) {
      this.stopAmbientSynth();
      return false;
    } else {
      this.startAmbientSynth();
      return true;
    }
  }

  public getIsAmbientPlaying(): boolean {
    return this.isAmbientPlaying;
  }
}

export const audio = new AudioEngine();
