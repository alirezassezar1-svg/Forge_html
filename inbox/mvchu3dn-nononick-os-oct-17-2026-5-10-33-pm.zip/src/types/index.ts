export type ProjectCategory = 'web' | 'ai' | 'tools' | 'audio' | 'experiments' | 'system';
export type ProjectStatus = 'Live' | 'In Development' | 'Experimental';

export interface Project {
  id: string;
  name: string;
  nameFa: string;
  category: ProjectCategory;
  categoryFa: string;
  status: ProjectStatus;
  statusFa: string;
  description: string;
  descriptionFa: string;
  longDescription: string;
  longDescriptionFa: string;
  technologies: string[];
  accentColor: string;
  gradient: string;
  iconName: string;
  projectUrl: string | null;
  repoUrl: string | null;
  featured: boolean;
  displayOrder: number;
  page: number; // 1 or 2
  highlights: string[];
  highlightsFa: string[];
}

export interface ServiceItem {
  id: string;
  title: string;
  titleFa: string;
  shortDesc: string;
  shortDescFa: string;
  description: string;
  descriptionFa: string;
  deliverables: string[];
  deliverablesFa: string[];
  techFocus: string[];
  turnaround: string;
  turnaroundFa: string;
  iconName: string;
  accentColor: string;
}

export type Language = 'en' | 'fa';

export type ThemeWallpaper = 'obsidian' | 'aurora' | 'midnight' | 'sunset' | 'matte';

export interface SystemSettings {
  language: Language;
  wallpaper: ThemeWallpaper;
  soundEnabled: boolean;
  reducedMotion: boolean;
  deviceFrame: boolean;
  isEditMode: boolean;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  timestamp: string;
}
