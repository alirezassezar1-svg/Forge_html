import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, ChevronLeft, ChevronRight, Check } from 'lucide-react';
import { StatusBar } from './components/StatusBar';
import { Dock, ActiveDockTab } from './components/Dock';
import { AppIcon } from './components/AppIcon';
import { HeroWidget } from './components/widgets/HeroWidget';
import { FeaturedProjectWidget } from './components/widgets/FeaturedProjectWidget';
import { ServicesWidget } from './components/widgets/ServicesWidget';
import { ProjectActivityWidget } from './components/widgets/ProjectActivityWidget';
import { QuickContactWidget } from './components/widgets/QuickContactWidget';
import { AboutMeWidget } from './components/widgets/AboutMeWidget';
import { DigitalExperimentsWidget } from './components/widgets/DigitalExperimentsWidget';
import { SpotlightSearch } from './components/SpotlightSearch';
import { ProjectDetailModal } from './components/modals/ProjectDetailModal';
import { ProjectsLibraryModal } from './components/modals/ProjectsLibraryModal';
import { ServicesModal } from './components/modals/ServicesModal';
import { AboutModal } from './components/modals/AboutModal';
import { ContactModal } from './components/modals/ContactModal';
import { SettingsModal } from './components/modals/SettingsModal';

import { initialProjects } from './data/projectsData';
import { servicesData } from './data/servicesData';
import { translations } from './data/translations';
import { Project, ServiceItem, SystemSettings } from './types';
import { audio } from './utils/audio';

const STORAGE_KEY_PROJECTS = 'nononick_os_projects_v1';
const STORAGE_KEY_SETTINGS = 'nononick_os_settings_v1';

export default function App() {
  // Load persistent projects
  const [projects, setProjects] = useState<Project[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEY_PROJECTS);
        if (saved) return JSON.parse(saved);
      } catch {}
    }
    return initialProjects;
  });

  // Load persistent settings
  const [settings, setSettings] = useState<SystemSettings>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem(STORAGE_KEY_SETTINGS);
        if (saved) return JSON.parse(saved);
      } catch {}
    }
    return {
      language: 'en',
      wallpaper: 'obsidian',
      soundEnabled: true,
      reducedMotion: false,
      deviceFrame: false,
      isEditMode: false
    };
  });

  const [currentPage, setCurrentPage] = useState<number>(1);
  const [activeDockTab, setActiveDockTab] = useState<ActiveDockTab>('home');

  // Modals state
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isProjectsLibraryOpen, setIsProjectsLibraryOpen] = useState(false);
  const [isServicesOpen, setIsServicesOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSpotlightOpen, setIsSpotlightOpen] = useState(false);
  const [prefillService, setPrefillService] = useState<ServiceItem | null>(null);

  // Sync settings changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
    } catch {}
    audio.setSoundEnabled(settings.soundEnabled);
  }, [settings]);

  // Sync projects changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PROJECTS, JSON.stringify(projects));
    } catch {}
  }, [projects]);

  // Sync root dir attribute for RTL support
  useEffect(() => {
    document.documentElement.setAttribute('dir', settings.language === 'fa' ? 'rtl' : 'ltr');
    document.documentElement.setAttribute('lang', settings.language);
  }, [settings.language]);

  const t = translations[settings.language];

  const updateSettings = (updates: Partial<SystemSettings>) => {
    setSettings((prev) => ({ ...prev, ...updates }));
  };

  const handleResetLayout = () => {
    setProjects(initialProjects);
    try {
      localStorage.removeItem(STORAGE_KEY_PROJECTS);
    } catch {}
  };

  // Move project between Page 1 and Page 2 in Edit Mode
  const handleMoveProjectPage = (projectId: string) => {
    setProjects((prev) =>
      prev.map((p) => {
        if (p.id === projectId) {
          const newPage = p.page === 1 ? 2 : 1;
          return { ...p, page: newPage };
        }
        return p;
      })
    );
  };

  // Dock navigation handler
  const handleSelectDockTab = (tab: ActiveDockTab) => {
    setActiveDockTab(tab);
    if (tab === 'home') {
      // scroll to top or close any full modal
      setIsProjectsLibraryOpen(false);
      setIsServicesOpen(false);
      setIsAboutOpen(false);
      setIsContactOpen(false);
      setIsSettingsOpen(false);
    } else if (tab === 'projects') {
      setIsProjectsLibraryOpen(true);
    } else if (tab === 'services') {
      setIsServicesOpen(true);
    } else if (tab === 'about') {
      setIsAboutOpen(true);
    } else if (tab === 'contact') {
      setIsContactOpen(true);
    } else if (tab === 'settings') {
      setIsSettingsOpen(true);
    }
  };

  // Wallpaper backgrounds
  const getWallpaperBackground = () => {
    switch (settings.wallpaper) {
      case 'aurora':
        return 'bg-gradient-to-b from-[#030712] via-[#0f172a] to-[#1e1b4b]';
      case 'midnight':
        return 'bg-gradient-to-b from-[#020617] via-[#091e3a] to-[#020617]';
      case 'sunset':
        return 'bg-gradient-to-b from-[#09090b] via-[#2a081d] to-[#180828]';
      case 'matte':
        return 'bg-[#0f1115]';
      case 'obsidian':
      default:
        return 'bg-gradient-to-b from-black via-[#08090c] to-[#040405]';
    }
  };

  const page1Projects = projects.filter((p) => p.page === 1);
  const page2Projects = projects.filter((p) => p.page === 2);
  const featuredProject = projects.find((p) => p.featured) || projects[0];
  const experimentalProject = projects.find((p) => p.id === 'interactive-visual-experiments') || projects[4];

  // Shell content
  const homeScreenContent = (
    <div className="min-h-screen flex flex-col justify-between pb-28 pt-2 select-none relative overflow-x-hidden">
      {/* Top Status Bar with Dynamic Island */}
      <StatusBar
        lang={settings.language}
        onToggleLang={() =>
          updateSettings({ language: settings.language === 'en' ? 'fa' : 'en' })
        }
        onToggleEditMode={() =>
          updateSettings({ isEditMode: !settings.isEditMode })
        }
        isEditMode={settings.isEditMode}
        soundEnabled={settings.soundEnabled}
        onToggleSound={() =>
          updateSettings({ soundEnabled: !settings.soundEnabled })
        }
      />

      {/* Jiggle / Edit Mode Notice Banner */}
      <AnimatePresence>
        {settings.isEditMode && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="sticky top-12 z-30 mx-auto max-w-sm px-4 py-2 rounded-2xl bg-amber-500/90 text-black shadow-xl flex items-center justify-between gap-3 text-xs font-semibold backdrop-blur-md"
          >
            <span>{t.editModeHeader.instruction}</span>
            <button
              type="button"
              onClick={() => {
                audio.playClick('switch');
                updateSettings({ isEditMode: false });
              }}
              className="px-3 py-1 rounded-xl bg-black text-white hover:bg-black/80 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <Check size={13} />
              <span>{t.editModeHeader.done}</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Home Screen Virtual Pages */}
      <main className="flex-1 max-w-5xl mx-auto w-full px-4 sm:px-6 py-4 flex flex-col justify-center">
        {currentPage === 1 ? (
          /* PAGE 1: Hero Identity + Smart Widgets + Page 1 App Grid */
          <motion.div
            key="page-1"
            initial={{ opacity: 0, x: settings.language === 'fa' ? 40 : -40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: settings.language === 'fa' ? -40 : 40 }}
            transition={{ type: 'spring', damping: 25, stiffness: 280 }}
            className="space-y-6"
          >
            {/* Hero Identity Widget */}
            <HeroWidget
              lang={settings.language}
              onExploreProjects={() => setIsProjectsLibraryOpen(true)}
              onOpenServices={() => setIsServicesOpen(true)}
              onOpenContact={() => setIsContactOpen(true)}
              reducedMotion={settings.reducedMotion}
            />

            {/* Smart Widgets Grid: Featured Project & Services Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FeaturedProjectWidget
                project={featuredProject}
                lang={settings.language}
                onOpen={(p) => setSelectedProject(p)}
              />

              <ServicesWidget
                lang={settings.language}
                onOpenServices={() => setIsServicesOpen(true)}
              />
            </div>

            {/* Spotlight Search Pill */}
            <div className="flex justify-center pt-2">
              <button
                type="button"
                onClick={() => {
                  audio.playClick('open');
                  setIsSpotlightOpen(true);
                }}
                className="flex items-center justify-center gap-2 px-5 py-2 rounded-full ios-glass text-xs text-white/80 hover:text-white hover:bg-white/15 transition-all shadow-md group cursor-pointer max-w-xs w-full"
              >
                <Search size={14} className="text-cyan-400 group-hover:scale-110 transition-transform" />
                <span className="font-medium">{t.searchPlaceholder}</span>
                <kbd className="hidden sm:inline-block px-1.5 py-0.2 rounded bg-white/10 text-[10px] font-mono text-white/40">
                  ⌘K
                </kbd>
              </button>
            </div>

            {/* App Grid Row for Page 1 */}
            <div className="pt-2">
              <div className="flex flex-wrap items-start justify-center gap-4 sm:gap-8">
                {page1Projects.map((project, index) => (
                  <AppIcon
                    key={project.id}
                    project={project}
                    lang={settings.language}
                    onOpen={(p) => setSelectedProject(p)}
                    isEditMode={settings.isEditMode}
                    onMovePage={handleMoveProjectPage}
                    index={index}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        ) : (
          /* PAGE 2: Activity + Contact + About + Experiments + Page 2 App Grid */
          <motion.div
            key="page-2"
            initial={{ opacity: 0, x: settings.language === 'fa' ? -40 : 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: settings.language === 'fa' ? 40 : -40 }}
            transition={{ type: 'spring', damping: 25, stiffness: 280 }}
            className="space-y-6"
          >
            {/* Top 2 Widgets: Activity & Quick Contact */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <ProjectActivityWidget
                projects={projects}
                lang={settings.language}
              />

              <QuickContactWidget
                lang={settings.language}
                onOpenContact={() => setIsContactOpen(true)}
              />
            </div>

            {/* Middle 2 Widgets: About Me & Interactive Canvas Experiment */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <AboutMeWidget
                lang={settings.language}
                onOpenAbout={() => setIsAboutOpen(true)}
              />

              <DigitalExperimentsWidget
                project={experimentalProject}
                lang={settings.language}
                onOpenProject={(p) => setSelectedProject(p)}
                reducedMotion={settings.reducedMotion}
              />
            </div>

            {/* App Grid Row for Page 2 */}
            <div className="pt-4">
              <div className="flex flex-wrap items-start justify-center gap-4 sm:gap-8">
                {page2Projects.map((project, index) => (
                  <AppIcon
                    key={project.id}
                    project={project}
                    lang={settings.language}
                    onOpen={(p) => setSelectedProject(p)}
                    isEditMode={settings.isEditMode}
                    onMovePage={handleMoveProjectPage}
                    index={index}
                  />
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* iOS Home Screen Pagination Dots & Controls */}
        <div className="flex items-center justify-center gap-3 mt-8 select-none">
          <button
            type="button"
            onClick={() => {
              audio.playClick('switch');
              setCurrentPage(1);
            }}
            className="p-1 rounded-full text-white/40 hover:text-white transition-colors cursor-pointer"
            aria-label="Previous Page"
          >
            <ChevronLeft size={16} />
          </button>

          <div className="flex items-center gap-2 p-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/10">
            <button
              type="button"
              onClick={() => {
                audio.playClick('switch');
                setCurrentPage(1);
              }}
              className={`w-2.5 h-2.5 rounded-full transition-all cursor-pointer ${
                currentPage === 1 ? 'w-6 bg-white' : 'bg-white/40 hover:bg-white/70'
              }`}
              aria-label="Page 1"
            />
            <button
              type="button"
              onClick={() => {
                audio.playClick('switch');
                setCurrentPage(2);
              }}
              className={`w-2.5 h-2.5 rounded-full transition-all cursor-pointer ${
                currentPage === 2 ? 'w-6 bg-white' : 'bg-white/40 hover:bg-white/70'
              }`}
              aria-label="Page 2"
            />
          </div>

          <button
            type="button"
            onClick={() => {
              audio.playClick('switch');
              setCurrentPage(2);
            }}
            className="p-1 rounded-full text-white/40 hover:text-white transition-colors cursor-pointer"
            aria-label="Next Page"
          >
            <ChevronRight size={16} />
          </button>
        </div>
      </main>

      {/* Floating Translucent iOS Dock */}
      <Dock
        activeTab={activeDockTab}
        onSelectTab={handleSelectDockTab}
        lang={settings.language}
      />

      {/* Global Spotlight Search */}
      <SpotlightSearch
        isOpen={isSpotlightOpen}
        onClose={() => setIsSpotlightOpen(false)}
        projects={projects}
        services={servicesData}
        lang={settings.language}
        onSelectProject={(p) => setSelectedProject(p)}
        onSelectService={(s) => {
          setPrefillService(s);
          setIsContactOpen(true);
        }}
      />

      {/* Project Detail Window */}
      <ProjectDetailModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
        lang={settings.language}
      />

      {/* Projects Library (App Store) Modal */}
      <ProjectsLibraryModal
        isOpen={isProjectsLibraryOpen}
        onClose={() => {
          setIsProjectsLibraryOpen(false);
          setActiveDockTab('home');
        }}
        projects={projects}
        lang={settings.language}
        onSelectProject={(p) => {
          setIsProjectsLibraryOpen(false);
          setSelectedProject(p);
        }}
      />

      {/* Services Full Modal */}
      <ServicesModal
        isOpen={isServicesOpen}
        onClose={() => {
          setIsServicesOpen(false);
          setActiveDockTab('home');
        }}
        lang={settings.language}
        onInquireService={(s) => {
          setPrefillService(s);
          setIsServicesOpen(false);
          setIsContactOpen(true);
        }}
      />

      {/* About Me Full Modal */}
      <AboutModal
        isOpen={isAboutOpen}
        onClose={() => {
          setIsAboutOpen(false);
          setActiveDockTab('home');
        }}
        lang={settings.language}
        onOpenContact={() => {
          setIsAboutOpen(false);
          setIsContactOpen(true);
        }}
      />

      {/* Contact & Messages Modal */}
      <ContactModal
        isOpen={isContactOpen}
        onClose={() => {
          setIsContactOpen(false);
          setPrefillService(null);
          setActiveDockTab('home');
        }}
        lang={settings.language}
        prefillService={prefillService}
      />

      {/* System Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => {
          setIsSettingsOpen(false);
          setActiveDockTab('home');
        }}
        settings={settings}
        onUpdateSettings={updateSettings}
        onResetLayout={handleResetLayout}
      />
    </div>
  );

  return (
    <div className={`min-h-screen text-white ${getWallpaperBackground()} transition-colors duration-500`}>
      {/* If iPhone Mockup Frame is enabled on desktop viewports */}
      {settings.deviceFrame ? (
        <div className="min-h-screen py-6 px-4 flex items-center justify-center bg-black/95">
          <div className="relative w-full max-w-[430px] h-[912px] bg-black rounded-[54px] p-3 shadow-[0_0_80px_rgba(10,132,255,0.25)] border-[5px] border-zinc-700/80 ring-1 ring-white/20 overflow-hidden flex flex-col">
            {/* Speaker hole */}
            <div className="absolute top-3 left-1/2 -translate-x-1/2 w-18 h-1 bg-zinc-800 rounded-full z-50 pointer-events-none" />
            <div className="relative flex-1 rounded-[42px] overflow-y-auto no-scrollbar overflow-x-hidden">
              {homeScreenContent}
            </div>
          </div>
        </div>
      ) : (
        homeScreenContent
      )}
    </div>
  );
}
