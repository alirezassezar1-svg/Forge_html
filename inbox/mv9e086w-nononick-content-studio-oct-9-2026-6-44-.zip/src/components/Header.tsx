import React, { useState } from 'react';
import { NavigationTab } from '../types';
import { Sparkles, Layers, Search, Repeat, Calendar, History, Wrench, Menu, X, ArrowUpRight } from 'lucide-react';

interface HeaderProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  onQuickCreate: () => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, onQuickCreate }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks: { id: NavigationTab; label: string; icon: React.ReactNode }[] = [
    { id: 'workspace', label: 'استودیو', icon: <Layers className="w-4 h-4" /> },
    { id: 'seo', label: 'سئو محتوا', icon: <Search className="w-4 h-4" /> },
    { id: 'repurpose', label: 'بازآفرینی', icon: <Repeat className="w-4 h-4" /> },
    { id: 'calendar', label: 'تقویم', icon: <Calendar className="w-4 h-4" /> },
    { id: 'free_tools', label: 'ابزارها', icon: <Wrench className="w-4 h-4" /> },
    { id: 'history', label: 'تاریخچه', icon: <History className="w-4 h-4" /> },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-slate-800 bg-[#080c14]/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Zone */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setActiveTab('workspace')}
            className="flex items-center gap-2.5 text-right focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-500 rounded-md"
          >
            <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-cyan-600 via-indigo-600 to-violet-600 flex items-center justify-center text-white shadow-md shadow-cyan-950/40">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <span className="text-base sm:text-lg font-extrabold tracking-tight text-white block leading-tight">
                Nononick <span className="text-cyan-400 font-semibold text-sm sm:text-base">Content Studio</span>
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links (single-line, clean text hover underline) */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
          {navLinks.map((link) => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => setActiveTab(link.id)}
                className={`flex items-center gap-1.5 whitespace-nowrap transition-colors py-1 ${
                  isActive
                    ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400'
                    : 'text-slate-400 hover:text-slate-100'
                }`}
              >
                {link.icon}
                <span>{link.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Action & External Site Link */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href="https://nononick.com/services.php"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden lg:flex items-center gap-1 text-xs text-slate-400 hover:text-cyan-300 transition-colors whitespace-nowrap"
            title="خدمات طراحی سایت و توسعه Nononick"
          >
            <span>ساخت سایت با Nononick</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </a>

          <button
            onClick={onQuickCreate}
            className="inline-flex items-center justify-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-gradient-to-r from-cyan-600 to-indigo-600 rounded-lg hover:from-cyan-500 hover:to-indigo-500 active:scale-[0.98] transition-all shadow-md shadow-cyan-900/30 whitespace-nowrap shrink-0"
          >
            <Sparkles className="w-4 h-4" />
            <span>تولید محتوا</span>
          </button>

          {/* Mobile menu trigger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-slate-400 hover:text-white rounded-lg focus:outline-none"
            aria-label="منو"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-slate-800 bg-[#0b0f17] px-4 pt-2 pb-4 space-y-1">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => {
                setActiveTab(link.id);
                setMobileMenuOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-right ${
                activeTab === link.id
                  ? 'bg-slate-800 text-cyan-400 font-medium'
                  : 'text-slate-300 hover:bg-slate-900'
              }`}
            >
              {link.icon}
              <span>{link.label}</span>
            </button>
          ))}
          <div className="pt-2 border-t border-slate-800">
            <a
              href="https://nononick.com/services.php"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between px-3 py-2 text-xs text-slate-400 hover:text-cyan-300"
            >
              <span>سفارش طراحی سایت در Nononick</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
