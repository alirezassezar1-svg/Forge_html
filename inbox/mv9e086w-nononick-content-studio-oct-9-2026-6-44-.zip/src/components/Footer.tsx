import React from 'react';
import { Sparkles, ArrowUpRight, ShieldCheck, Heart } from 'lucide-react';
import { NavigationTab } from '../types';

interface FooterProps {
  setActiveTab: (tab: NavigationTab) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab }) => {
  return (
    <footer className="mt-24 border-t border-slate-800/80 bg-[#070a10] text-slate-400">
      {/* Top CTA Banner */}
      <div className="border-b border-slate-800/60 bg-gradient-to-r from-cyan-950/20 via-indigo-950/20 to-purple-950/20 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-semibold uppercase tracking-wider mb-2">
              <Sparkles className="w-4 h-4" />
              <span>رشد دیجیتال با زیرساخت استاندارد</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-white">
              به یک وب‌سایت اختصاصی، سریع و سئو شده نیاز دارید؟
            </h3>
            <p className="text-sm text-slate-300 mt-1 max-w-2xl">
              تیم توسعه و سئو Nononick از صفر تا صد ایده، طراحی رابط کاربری و فتح رتبه‌های نخست گوگل را در کنار شماست.
            </p>
          </div>
          <div className="flex items-center gap-4 shrink-0">
            <a
              href="https://nononick.com/services.php"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-cyan-600 hover:bg-cyan-500 rounded-lg shadow-lg shadow-cyan-950/50 transition-all"
            >
              <span>مشاهده خدمات طراحی سایت</span>
              <ArrowUpRight className="w-4 h-4" />
            </a>
            <a
              href="https://nononick.com/contact.php"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-800 border border-slate-700 rounded-lg transition-all"
            >
              <span>مشاوره و تماس</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center text-white">
                <Sparkles className="w-4 h-4" />
              </div>
              <span className="text-lg font-bold text-white tracking-tight">Nononick Content Studio</span>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed max-w-sm">
              Nononick مجموعه‌ای از ابزارهای دیجیتال برای ساخت، مدیریت و رشد حضور آنلاین کسب‌وکارهاست.
              با استودیوی محتوا، هر فرد و بیزینس می‌تواند بدون نیاز به ابزارهای پیچیده، محتوایی اثربخش و بهینه برای سئو تولید کند.
            </p>
            <div className="flex items-center gap-4 text-xs text-slate-500 pt-2">
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-cyan-500" />
                رایگان و بدون نیاز به ثبت‌نام
              </span>
              <span>·</span>
              <span>توسعه پایدار ۲۰۲۶</span>
            </div>
          </div>

          {/* Column 1: Studio Features */}
          <div className="space-y-3">
            <p className="text-xs font-semibold text-slate-200 tracking-wider">بخش‌های استودیو</p>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => setActiveTab('workspace')} className="hover:text-cyan-400 transition-colors">
                  تولید انواع محتوا
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('seo')} className="hover:text-cyan-400 transition-colors">
                  پکیج سئو محتوا (SEO Mode)
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('repurpose')} className="hover:text-cyan-400 transition-colors">
                  یک محتوا، چندین محتوا
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('calendar')} className="hover:text-cyan-400 transition-colors">
                  تقویم محتوایی ۳۰ روزه
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('workflow')} className="hover:text-cyan-400 transition-colors">
                  ورک‌فلو ۷ مرحله‌ای محتوا
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('prompt_builder')} className="hover:text-cyan-400 transition-colors">
                  پرامپت‌ساز حرفه‌ای
                </button>
              </li>
            </ul>
          </div>

          {/* Column 2: Free Tools */}
          <div className="space-y-3">
            <p className="text-xs font-semibold text-slate-200 tracking-wider">ابزارهای رایگان سئو</p>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => setActiveTab('free_tools')} className="hover:text-cyan-400 transition-colors">
                  شمارنده کلمات و حروف
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('free_tools')} className="hover:text-cyan-400 transition-colors">
                  سازنده عنوان و تیتر
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('free_tools')} className="hover:text-cyan-400 transition-colors">
                  تولید توضیحات متا
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('free_tools')} className="hover:text-cyan-400 transition-colors">
                  سازنده اسلاگ URL
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('free_tools')} className="hover:text-cyan-400 transition-colors">
                  بازنویسی و خلاصه‌ساز متن
                </button>
              </li>
              <li>
                <button onClick={() => setActiveTab('free_tools')} className="hover:text-cyan-400 transition-colors">
                  سازنده سوالات متداول FAQ
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Nononick Ecosystem */}
          <div className="space-y-3">
            <p className="text-xs font-semibold text-slate-200 tracking-wider">اکوسیستم Nononick</p>
            <ul className="space-y-2 text-sm">
              <li>
                <a
                  href="https://nononick.com/services.php"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-cyan-400 transition-colors flex items-center justify-between"
                >
                  <span>خدمات طراحی وب‌سایت</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-slate-500" />
                </a>
              </li>
              <li>
                <a
                  href="https://nononick.com/portfolio.php"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-cyan-400 transition-colors flex items-center justify-between"
                >
                  <span>نمونه کارها و پروژه‌ها</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-slate-500" />
                </a>
              </li>
              <li>
                <a
                  href="https://nononick.com/blog.php"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-cyan-400 transition-colors flex items-center justify-between"
                >
                  <span>وبلاگ تخصصی و مقالات</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-slate-500" />
                </a>
              </li>
              <li>
                <a
                  href="https://nononick.com/contact.php"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-cyan-400 transition-colors flex items-center justify-between"
                >
                  <span>ارتباط با کارشناسان</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-slate-500" />
                </a>
              </li>
              <li>
                <button onClick={() => setActiveTab('resources')} className="hover:text-cyan-400 transition-colors">
                  راهنمای سئو و تولید محتوا
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-slate-800/60 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} Nononick Content Studio. تمامی حقوق محفوظ است.</p>
          <div className="flex items-center gap-1 text-slate-400">
            <span>طراحی شده با دقت و افتخار برای برند</span>
            <span className="text-cyan-400 font-semibold">Nononick</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
