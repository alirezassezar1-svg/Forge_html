import React, { useState, useEffect } from 'react';
import { NavigationTab, GeneratedHistoryItem } from './types';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { WorkspaceView } from './components/WorkspaceView';
import { SeoModeView } from './components/SeoModeView';
import { RepurposeView } from './components/RepurposeView';
import { CalendarView } from './components/CalendarView';
import { WorkflowView } from './components/WorkflowView';
import { PromptBuilderView } from './components/PromptBuilderView';
import { FreeToolsView } from './components/FreeToolsView';
import { HistoryView } from './components/HistoryView';
import { ResourcesView } from './components/ResourcesView';
import { ShareModal } from './components/ShareModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('workspace');
  const [history, setHistory] = useState<GeneratedHistoryItem[]>([]);
  const [shareModalData, setShareModalData] = useState<{
    isOpen: boolean;
    title: string;
    content: string;
  }>({
    isOpen: false,
    title: '',
    content: '',
  });

  // Load history on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem('nononick_content_history');
      if (stored) {
        setHistory(JSON.parse(stored));
      }
    } catch (e) {
      console.error('Failed to load history from localStorage', e);
    }
  }, []);

  // Save history helper
  const handleSaveToHistory = (item: GeneratedHistoryItem) => {
    setHistory((prev) => {
      const updated = [item, ...prev].slice(0, 50); // limit to last 50 items
      try {
        localStorage.setItem('nononick_content_history', JSON.stringify(updated));
      } catch (e) {
        console.error('Failed to save to localStorage', e);
      }
      return updated;
    });
  };

  const handleDeleteHistoryItem = (id: string) => {
    setHistory((prev) => {
      const updated = prev.filter((i) => i.id !== id);
      try {
        localStorage.setItem('nononick_content_history', JSON.stringify(updated));
      } catch (e) {
        console.error(e);
      }
      return updated;
    });
  };

  const handleClearHistory = () => {
    setHistory([]);
    try {
      localStorage.removeItem('nononick_content_history');
    } catch (e) {
      console.error(e);
    }
  };

  const handleLoadItemIntoEditor = (item: GeneratedHistoryItem) => {
    setActiveTab('workspace');
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleExecutePromptInStudio = (promptText: string) => {
    setActiveTab('workspace');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleQuickCreate = () => {
    setActiveTab('workspace');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#070b13] text-slate-100 antialiased font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onQuickCreate={handleQuickCreate}
      />

      {/* Main Container Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        {activeTab === 'workspace' && (
          <WorkspaceView
            onSaveToHistory={handleSaveToHistory}
            onOpenSeoMode={() => setActiveTab('seo')}
            onOpenCalendar={() => setActiveTab('calendar')}
            onOpenRepurpose={() => setActiveTab('repurpose')}
          />
        )}

        {activeTab === 'seo' && (
          <SeoModeView onSaveToHistory={handleSaveToHistory} />
        )}

        {activeTab === 'repurpose' && (
          <RepurposeView onSaveToHistory={handleSaveToHistory} />
        )}

        {activeTab === 'calendar' && (
          <CalendarView onSaveToHistory={handleSaveToHistory} />
        )}

        {activeTab === 'workflow' && <WorkflowView />}

        {activeTab === 'prompt_builder' && (
          <PromptBuilderView
            onExecutePromptInStudio={handleExecutePromptInStudio}
          />
        )}

        {activeTab === 'free_tools' && (
          <FreeToolsView
            onExecuteToolOutputInEditor={(text) => {
              setActiveTab('workspace');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeTab === 'history' && (
          <HistoryView
            history={history}
            onLoadItemIntoEditor={handleLoadItemIntoEditor}
            onDeleteItem={handleDeleteHistoryItem}
            onClearAll={handleClearHistory}
          />
        )}

        {activeTab === 'resources' && <ResourcesView />}
      </main>

      {/* Share Modal Dialog */}
      <ShareModal
        isOpen={shareModalData.isOpen}
        onClose={() => setShareModalData({ ...shareModalData, isOpen: false })}
        title={shareModalData.title}
        content={shareModalData.content}
      />

      {/* Site Footer */}
      <Footer setActiveTab={setActiveTab} />
    </div>
  );
}
