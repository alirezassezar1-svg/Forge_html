'use client';

import { useState, useEffect } from 'react';
import { isOpenCvReady } from '@/lib/perspective-warp';

/**
 * Polls until OpenCV.js is available on window.
 * Keeps UI components free of OpenCV loading logic.
 */
export function useOpenCv(pollIntervalMs = 1000) {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    if (isOpenCvReady()) {
      setIsLoaded(true);
      return;
    }

    const id = setInterval(() => {
      if (isOpenCvReady()) {
        setIsLoaded(true);
        clearInterval(id);
      }
    }, pollIntervalMs);

    return () => clearInterval(id);
  }, [pollIntervalMs]);

  return { isOpenCvLoaded: isLoaded };
}
