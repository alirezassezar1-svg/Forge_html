'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { DocumentItem } from '@/lib/image-types';
import { processDocument, documentProcessHash } from '@/lib/processing/image-processor';

type UpdateFn = (id: string, patch: Partial<DocumentItem>) => void;

/**
 * Isolated processing orchestration:
 * - Debounced trigger on adjustments change
 * - Hash-based skip of unchanged work
 * - Writes results back via updateDocument callback
 */
export function useImageProcessing(
  activeDocument: DocumentItem | null,
  updateDocument: UpdateFn
) {
  const [isProcessing, setIsProcessing] = useState(false);
  const processTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastHashRef = useRef('');
  const activeDocRef = useRef(activeDocument);

  useEffect(() => {
    activeDocRef.current = activeDocument;
  }, [activeDocument]);

  const runProcessing = useCallback(
    async (doc: DocumentItem) => {
      if (!doc?.originalDataUrl) return;

      const hash = documentProcessHash(doc);
      if (lastHashRef.current === hash) return;
      lastHashRef.current = hash;

      setIsProcessing(true);
      try {
        const result = await processDocument(doc);
        updateDocument(doc.id, {
          processedBlob: result.processedBlob,
          processedDataUrl: result.processedDataUrl,
          processedBytes: result.processedBytes,
          processedWidth: result.processedWidth,
          processedHeight: result.processedHeight,
        });
      } catch (err) {
        console.error('Error during image processing:', err);
      } finally {
        setIsProcessing(false);
      }
    },
    [updateDocument]
  );

  const adjustmentsKey = activeDocument
    ? `${activeDocument.id}-${JSON.stringify(activeDocument.adjustments)}`
    : '';

  useEffect(() => {
    if (!adjustmentsKey) return;

    if (processTimerRef.current) {
      clearTimeout(processTimerRef.current);
    }

    processTimerRef.current = setTimeout(() => {
      if (activeDocRef.current) {
        runProcessing(activeDocRef.current);
      }
    }, 180);

    return () => {
      if (processTimerRef.current) clearTimeout(processTimerRef.current);
    };
  }, [adjustmentsKey, runProcessing]);

  return { isProcessing, runProcessing };
}
