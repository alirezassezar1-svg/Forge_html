'use client';

import { useState, useEffect, useCallback } from 'react';

const STORAGE_KEY = 'docscan_theme';

/**
 * Isolated theme (dark / light) management with localStorage persistence.
 */
export function useTheme() {
  const [darkMode, setDarkMode] = useState(false);

  const applyTheme = useCallback((isDark: boolean) => {
    setDarkMode(isDark);
    if (typeof document === 'undefined') return;

    if (isDark) {
      document.documentElement.classList.add('dark');
      document.documentElement.setAttribute('data-theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.setAttribute('data-theme', 'light');
    }
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    const isDark = saved === 'dark';
    queueMicrotask(() => applyTheme(isDark));
  }, [applyTheme]);

  const toggleDarkMode = useCallback(() => {
    setDarkMode((prev) => {
      const next = !prev;
      applyTheme(next);
      localStorage.setItem(STORAGE_KEY, next ? 'dark' : 'light');
      return next;
    });
  }, [applyTheme]);

  return { darkMode, toggleDarkMode, applyTheme };
}
