'use client';

import { useState, useCallback, useEffect } from 'react';
import {
  DocumentItem,
  DocumentAdjustment,
  FourCorners,
  UniversityPreset,
} from '@/lib/image-types';
import { classifyDocumentType } from '@/lib/image-math';
import { detectDocumentCorners } from '@/lib/perspective-warp';
import { createSampleDegreeCertificate } from '@/lib/sample-docs';

function createDocId() {
  return 'doc_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
}

function buildDefaultAdjustments(
  detectedType: DocumentItem['detectedType'],
  corners: FourCorners
): DocumentAdjustment {
  const isPhoto = detectedType === 'photo_3x4';
  return {
    rotation: 0,
    flipHorizontal: false,
    filterMode: isPhoto ? 'photo_3x4' : 'official_doc',
    brightness: 0,
    contrast: 10,
    shadowRemoval: true,
    sharpen: true,
    targetMaxKb: isPhoto ? 35 : 512,
    cropCorners: corners,
  };
}

/**
 * Isolated document queue: add / select / delete / update adjustments.
 * No processing logic — that lives in useImageProcessing.
 */
export function useDocumentQueue() {
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [activeDocId, setActiveDocId] = useState<string | null>(null);

  const activeDocument =
    documents.find((d) => d.id === activeDocId) || documents[0] || null;

  // Seed with sample certificate on first visit
  useEffect(() => {
    if (documents.length > 0) return;

    const sampleUrl = createSampleDegreeCertificate();
    const img = new Image();
    img.src = sampleUrl;
    img.onload = () => {
      const id = createDocId();
      const initialCorners: FourCorners = [
        { x: 120, y: 140 },
        { x: 1080, y: 80 },
        { x: 1120, y: 1460 },
        { x: 160, y: 1520 },
      ];

      const initialDoc: DocumentItem = {
        id,
        name: 'گواهی موقت دانشگاهی (نمونه)',
        originalDataUrl: sampleUrl,
        processedDataUrl: sampleUrl,
        sourceWidth: img.width,
        sourceHeight: img.height,
        detectedType: 'a4_document',
        adjustments: {
          rotation: 0,
          flipHorizontal: false,
          filterMode: 'official_doc',
          brightness: 0,
          contrast: 10,
          shadowRemoval: true,
          sharpen: true,
          targetMaxKb: 512,
          cropCorners: initialCorners,
        },
        createdAt: Date.now(),
      };

      setDocuments([initialDoc]);
      setActiveDocId(id);
    };
  }, [documents.length]);

  const updateDocument = useCallback((id: string, patch: Partial<DocumentItem>) => {
    setDocuments((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...patch } : item))
    );
  }, []);

  const handleUpdateAdjustments = useCallback(
    (updated: Partial<DocumentAdjustment>) => {
      if (!activeDocId) return;
      setDocuments((prev) =>
        prev.map((item) =>
          item.id === activeDocId
            ? { ...item, adjustments: { ...item.adjustments, ...updated } }
            : item
        )
      );
    },
    [activeDocId]
  );

  const handleUpdateCorners = useCallback(
    (corners: FourCorners) => {
      handleUpdateAdjustments({ cropCorners: corners });
    },
    [handleUpdateAdjustments]
  );

  const handleRotate = useCallback(
    (dir: 'cw' | 'ccw') => {
      if (!activeDocument) return;
      const current = activeDocument.adjustments.rotation || 0;
      const delta = dir === 'cw' ? 90 : -90;
      handleUpdateAdjustments({ rotation: (current + delta + 360) % 360 });
    },
    [activeDocument, handleUpdateAdjustments]
  );

  const handleFlip = useCallback(() => {
    if (!activeDocument) return;
    handleUpdateAdjustments({
      flipHorizontal: !activeDocument.adjustments.flipHorizontal,
    });
  }, [activeDocument, handleUpdateAdjustments]);

  const handleApplyEnhance = useCallback(() => {
    handleUpdateAdjustments({
      filterMode: 'clean_readable',
      shadowRemoval: true,
      sharpen: true,
      contrast: 12,
    });
  }, [handleUpdateAdjustments]);

  const handleApplyPreset = useCallback(
    (preset: UniversityPreset) => {
      handleUpdateAdjustments({
        targetMaxKb: preset.maxKb,
        filterMode: preset.targetFilter,
      });
    },
    [handleUpdateAdjustments]
  );

  const handleAddDocument = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      const img = new Image();
      img.src = dataUrl;
      img.onload = () => {
        const id = createDocId();
        const detectedType = classifyDocumentType(img.width, img.height);
        const corners = detectDocumentCorners(img);

        const newDoc: DocumentItem = {
          id,
          name: file.name.replace(/\.[^/.]+$/, '') || 'مدرک جدید',
          originalDataUrl: dataUrl,
          sourceWidth: img.width,
          sourceHeight: img.height,
          detectedType,
          adjustments: buildDefaultAdjustments(detectedType, corners),
          createdAt: Date.now(),
        };

        setDocuments((prev) => [...prev, newDoc]);
        setActiveDocId(id);
      };
    };
    reader.readAsDataURL(file);
  }, []);

  const handleAddDataUrl = useCallback((dataUrl: string, name: string) => {
    const img = new Image();
    img.src = dataUrl;
    img.onload = () => {
      const id = createDocId();
      const detectedType = classifyDocumentType(img.width, img.height);
      const corners = detectDocumentCorners(img);

      const newDoc: DocumentItem = {
        id,
        name,
        originalDataUrl: dataUrl,
        sourceWidth: img.width,
        sourceHeight: img.height,
        detectedType,
        adjustments: buildDefaultAdjustments(detectedType, corners),
        createdAt: Date.now(),
      };

      setDocuments((prev) => [...prev, newDoc]);
      setActiveDocId(id);
    };
  }, []);

  const handleDeleteDoc = useCallback(
    (id: string) => {
      setDocuments((prev) => {
        const filtered = prev.filter((d) => d.id !== id);
        if (activeDocId === id && filtered.length > 0) {
          setActiveDocId(filtered[0].id);
        } else if (filtered.length === 0) {
          setActiveDocId(null);
        }
        return filtered;
      });
    },
    [activeDocId]
  );

  const selectDoc = useCallback((id: string) => {
    setActiveDocId(id);
  }, []);

  return {
    documents,
    activeDocId,
    activeDocument,
    selectDoc,
    updateDocument,
    handleUpdateAdjustments,
    handleUpdateCorners,
    handleRotate,
    handleFlip,
    handleApplyEnhance,
    handleApplyPreset,
    handleAddDocument,
    handleAddDataUrl,
    handleDeleteDoc,
  };
}
