/**
 * Isolated image processing pipeline.
 * Pure functions — no React state. Used by useImageProcessing hook.
 */

import { DocumentItem, FourCorners } from '@/lib/image-types';
import { warpPerspectiveCanvas } from '@/lib/perspective-warp';
import { applyDocumentFilters } from '@/lib/image-filters';
import { compressCanvasToTargetKb, CompressionResult } from '@/lib/compressor';

export interface ProcessResult {
  processedBlob: Blob;
  processedDataUrl: string;
  processedBytes: number;
  processedWidth: number;
  processedHeight: number;
}

/**
 * Full pipeline: orientation → perspective warp → filters → compress
 */
export async function processDocument(doc: DocumentItem): Promise<ProcessResult> {
  if (!doc?.originalDataUrl) {
    throw new Error('Document has no source image');
  }

  const img = await loadImage(doc.originalDataUrl);
  const oriented = applyOrientation(img, doc.adjustments.rotation || 0, !!doc.adjustments.flipHorizontal);
  const corners = resolveCorners(doc.adjustments.cropCorners, oriented.width, oriented.height);
  const warped = warpPerspectiveCanvas(oriented, corners);

  const ctx = warped.getContext('2d');
  if (ctx) {
    applyDocumentFilters(ctx, warped.width, warped.height, doc.adjustments.filterMode, {
      brightness: doc.adjustments.brightness,
      contrast: doc.adjustments.contrast,
      shadowRemoval: doc.adjustments.shadowRemoval,
      sharpen: doc.adjustments.sharpen,
    });
  }

  const targetKb = doc.adjustments.targetMaxKb || 512;
  const compressed: CompressionResult = await compressCanvasToTargetKb(warped, targetKb);

  return {
    processedBlob: compressed.blob,
    processedDataUrl: compressed.dataUrl,
    processedBytes: compressed.bytes,
    processedWidth: compressed.width,
    processedHeight: compressed.height,
  };
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to load image'));
    img.src = src;
  });
}

function applyOrientation(
  img: HTMLImageElement,
  rotation: number,
  flipHorizontal: boolean
): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  if (rotation % 180 !== 0) {
    canvas.width = img.height;
    canvas.height = img.width;
  } else {
    canvas.width = img.width;
    canvas.height = img.height;
  }

  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;

  ctx.save();
  ctx.translate(canvas.width / 2, canvas.height / 2);
  ctx.rotate((rotation * Math.PI) / 180);
  if (flipHorizontal) ctx.scale(-1, 1);
  ctx.drawImage(img, -img.width / 2, -img.height / 2);
  ctx.restore();

  return canvas;
}

function resolveCorners(
  corners: FourCorners | undefined,
  width: number,
  height: number
): FourCorners {
  if (corners) return corners;
  return [
    { x: 0, y: 0 },
    { x: width, y: 0 },
    { x: width, y: height },
    { x: 0, y: height },
  ];
}

/**
 * Stable hash of document + adjustments for change detection / cache skip
 */
export function documentProcessHash(doc: DocumentItem): string {
  return `${doc.id}_${doc.originalDataUrl.length}_${JSON.stringify(doc.adjustments)}`;
}
