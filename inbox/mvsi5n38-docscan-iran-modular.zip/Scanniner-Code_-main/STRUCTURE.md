# ساختار ماژولار DocScan Iran

پروژه به صورت **ایزوله، ماژولار و لایه‌بندی‌شده** بازطراحی شده است.

## لایه‌ها

```
app/                    → فقط Composition Root (صفحه نازک)
hooks/                  → منطق وضعیت و side-effect (ایزوله از UI)
lib/
  processing/           → پایپ‌لاین خالص پردازش تصویر (بدون React)
  *.ts                  → الگوریتم‌ها، فیلتر، warp، فشرده‌سازی
components/
  layout/               → Navbar, PWA
  queue/                → صف مدارک
  scanner/              → Viewport اسکن و crop
  controls/             → فیلتر و فشرده‌سازی
  modals/               → مودال‌ها
```

## اصل ایزوله‌سازی

| ماژول | مسئولیت | وابستگی |
|--------|---------|---------|
| `lib/processing/image-processor` | orientation → warp → filter → compress | فقط lib/* |
| `hooks/useTheme` | تم روشن/تاریک + localStorage | هیچ |
| `hooks/useOpenCv` | آماده بودن OpenCV | perspective-warp |
| `hooks/useDocumentQueue` | صف مدارک، add/delete/adjust | types + sample + detect |
| `hooks/useImageProcessing` | debounce + hash + فراخوانی processor | image-processor |
| `app/page.tsx` | فقط اتصال hooks به components | hooks + components |

## جریان داده

```
User action
  → DocumentQueue / FilterControls / ScannerViewport
  → useDocumentQueue (state)
  → useImageProcessing (debounced)
  → processDocument()  [pure]
  → updateDocument()
  → UI re-render
```

## قوانین نگهداری

1. **هیچ منطق پردازشی داخل `page.tsx` نباشد.**
2. **کامپوننت‌های UI فقط props بگیرند و event emit کنند.**
3. **الگوریتم‌های تصویر فقط در `lib/` بمانند** تا قابل تست واحد باشند.
4. **هر hook یک مسئولیت واحد** داشته باشد.
5. برای گسترش (مثلاً PDF export یا batch) فقط hook/processor جدید اضافه کنید؛ صفحه را سنگین نکنید.

## فایل‌های کلیدی جدید

- `lib/processing/image-processor.ts` — پایپ‌لاین ایزوله
- `hooks/useTheme.ts`
- `hooks/useOpenCv.ts`
- `hooks/useDocumentQueue.ts`
- `hooks/useImageProcessing.ts`
- `hooks/index.ts` — barrel export
