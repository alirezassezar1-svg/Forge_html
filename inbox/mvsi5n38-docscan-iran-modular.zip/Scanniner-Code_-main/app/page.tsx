'use client';

import React, { useState } from 'react';
import Navbar from '@/components/layout/Navbar';
import DocumentQueue from '@/components/queue/DocumentQueue';
import ScannerViewport from '@/components/scanner/ScannerViewport';
import FilterControls from '@/components/controls/FilterControls';
import CompressionPanel from '@/components/controls/CompressionPanel';
import UniversityGuideModal from '@/components/modals/UniversityGuideModal';
import SaveModal from '@/components/modals/SaveModal';
import GitHubModal from '@/components/modals/GitHubModal';
import { useTheme } from '@/hooks/useTheme';
import { useOpenCv } from '@/hooks/useOpenCv';
import { useDocumentQueue } from '@/hooks/useDocumentQueue';
import { useImageProcessing } from '@/hooks/useImageProcessing';

/**
 * Thin composition root — all domain logic lives in isolated hooks & lib/processing.
 */
export default function DocumentScannerPage() {
  const { darkMode, toggleDarkMode } = useTheme();
  const { isOpenCvLoaded } = useOpenCv();

  const {
    documents,
    activeDocId,
    activeDocument,
    selectDoc,
    updateDocument,
    handleUpdateAdjustments,
    handleUpdateCorners,
    handleRotate,
    handleFlip,
    handleApplyEnhance,
    handleApplyPreset,
    handleAddDocument,
    handleAddDataUrl,
    handleDeleteDoc,
  } = useDocumentQueue();

  const { isProcessing } = useImageProcessing(activeDocument, updateDocument);

  const [guideModalOpen, setGuideModalOpen] = useState(false);
  const [saveModalOpen, setSaveModalOpen] = useState(false);
  const [githubModalOpen, setGithubModalOpen] = useState(false);
  const [viewTab, setViewTab] = useState<'crop' | 'preview'>('crop');

  return (
    <div className="flex min-h-screen flex-col bg-slate-100/70 text-slate-900 dark:bg-slate-950 dark:text-slate-100 transition-colors">
      <Navbar
        darkMode={darkMode}
        onToggleDarkMode={toggleDarkMode}
        onOpenGuide={() => setGuideModalOpen(true)}
        onOpenGitHub={() => setGithubModalOpen(true)}
        isOpenCvLoaded={isOpenCvLoaded}
      />

      <main className="mx-auto flex w-full max-w-7xl flex-1 flex-col gap-4 p-3 sm:p-5">
        <DocumentQueue
          documents={documents}
          activeDocId={activeDocId}
          onSelectDoc={selectDoc}
          onAddDocument={handleAddDocument}
          onAddDataUrl={handleAddDataUrl}
          onDeleteDoc={handleDeleteDoc}
        />

        {activeDocument && (
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-12">
            <div className="lg:col-span-7 xl:col-span-8 min-h-[420px]">
              <ScannerViewport
                documentItem={activeDocument}
                viewTab={viewTab}
                onChangeViewTab={setViewTab}
                onUpdateCorners={handleUpdateCorners}
                onRotate={handleRotate}
                onFlip={handleFlip}
                isOpenCvReady={isOpenCvLoaded}
                onApplyEnhance={handleApplyEnhance}
              />
            </div>

            <div className="lg:col-span-5 xl:col-span-4 flex flex-col gap-4">
              <FilterControls
                adjustments={activeDocument.adjustments}
                onChangeAdjustments={handleUpdateAdjustments}
              />

              <CompressionPanel
                documentItem={activeDocument}
                targetMaxKb={activeDocument.adjustments.targetMaxKb}
                onChangeTargetKb={(kb) => handleUpdateAdjustments({ targetMaxKb: kb })}
                onApplyPreset={handleApplyPreset}
                onPrepareForSave={() => setSaveModalOpen(true)}
                isProcessing={isProcessing}
              />
            </div>
          </div>
        )}
      </main>

      <footer className="mt-auto border-t border-slate-200 bg-white/60 py-3 text-center text-xs text-slate-500 dark:border-slate-800 dark:bg-slate-900/60 dark:text-slate-400">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-2 px-4">
          <div>اسکنر هوشمند مدارک دانشگاهی ایران • پردازش ۱۰۰٪ محلی درون مرورگر</div>
          <button
            type="button"
            onClick={() => setGithubModalOpen(true)}
            className="flex items-center gap-1.5 font-semibold text-slate-700 hover:text-emerald-600 dark:text-slate-300 dark:hover:text-emerald-400 transition"
          >
            <span>سورس‌کد پروژه در GitHub</span>
          </button>
        </div>
      </footer>

      <UniversityGuideModal
        isOpen={guideModalOpen}
        onClose={() => setGuideModalOpen(false)}
      />

      <GitHubModal
        isOpen={githubModalOpen}
        onClose={() => setGithubModalOpen(false)}
      />

      {activeDocument && (
        <SaveModal
          isOpen={saveModalOpen}
          onClose={() => setSaveModalOpen(false)}
          documentItem={activeDocument}
        />
      )}
    </div>
  );
}
