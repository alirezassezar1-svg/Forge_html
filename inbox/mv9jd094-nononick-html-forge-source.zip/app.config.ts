export default { logoUrl: "https://dummyimage.com/512x512/07111f/70f0dc.png&text=%3C%3E" };
