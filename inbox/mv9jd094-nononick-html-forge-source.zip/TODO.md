
- [x] **Runtime Lab** — Detect package manifests and frameworks; support explicit Vite/React-style builds and detected Node `.js`/`.mjs`/`.cjs` entries with temporary workspaces, npm lifecycle scripts disabled, timeouts, blocked sensitive paths and honest unsupported states. Verified with a minimal Node fixture and a Vite/React package detection request.
