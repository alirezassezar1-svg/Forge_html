

## Runtime Lab extension

The approved browser-only core now has a server-backed execution adapter because React, Vite and Node.js projects require a package/runtime environment. The adapter keeps execution explicit, writes only safe text files into temporary workspaces, blocks common sensitive/cache paths, disables npm lifecycle scripts during install, applies timeouts, runs build/run phases in a network-isolated process, never passes project secrets, and serves build output only through expiring Preview routes. Long-running servers, arbitrary commands, TypeScript-only entries and missing build scripts remain visibly unsupported rather than being faked.
