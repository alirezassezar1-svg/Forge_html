

## Runtime Lab

The server-backed Runtime Lab detects and executes supported project types after an explicit user action. It supports Vite/React-style projects with a declared `scripts.build`, installs dependencies with npm lifecycle scripts disabled, runs builds in a network-isolated process, and previews `dist`, `build`, `out` or `public` output. It can also run a detected `.js`, `.mjs` or `.cjs` Node entry with a short timeout and no public port. Long-running servers, arbitrary shell commands, TypeScript-only entries and projects without a declared build script are honestly marked `NOT SUPPORTED`.

Start the managed server with `node server.mjs`. The static browser-only workflow remains useful without runtime execution, while Runtime Lab requires the managed server capability.
