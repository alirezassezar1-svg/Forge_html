const encoder = new TextEncoder();
const decoder = new TextDecoder();

function crc32(bytes) {
  let crc = 0xffffffff;
  for (const byte of bytes) { crc ^= byte; for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ (0xedb88320 & -(crc & 1)); }
  return (crc ^ 0xffffffff) >>> 0;
}
const u16 = (n) => new Uint8Array([n & 255, (n >>> 8) & 255]);
const u32 = (n) => new Uint8Array([n & 255, (n >>> 8) & 255, (n >>> 16) & 255, (n >>> 24) & 255]);
function concat(...arrays) { const out = new Uint8Array(arrays.reduce((sum, a) => sum + a.length, 0)); let offset = 0; arrays.forEach(a => { out.set(a, offset); offset += a.length; }); return out; }
function read16(bytes, offset) { return bytes[offset] | bytes[offset + 1] << 8; }
function read32(bytes, offset) { return (bytes[offset] | bytes[offset + 1] << 8 | bytes[offset + 2] << 16 | bytes[offset + 3] << 24) >>> 0; }

export function zipStore(files) {
  const locals = [], centrals = []; let offset = 0;
  for (const file of files) {
    const name = encoder.encode(file.path); const body = typeof file.content === 'string' ? encoder.encode(file.content) : new Uint8Array(file.content || []); const crc = crc32(body);
    const local = concat(u32(0x04034b50), u16(20), u16(0), u16(0), u16(0), u16(0), u32(crc), u32(body.length), u32(body.length), u16(name.length), u16(0), name, body);
    const central = concat(u32(0x02014b50), u16(20), u16(20), u16(0), u16(0), u16(0), u16(0), u32(crc), u32(body.length), u32(body.length), u16(name.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(offset), name);
    locals.push(local); centrals.push(central); offset += local.length;
  }
  const centralBytes = concat(...centrals); const localBytes = concat(...locals); const end = concat(u32(0x06054b50), u16(0), u16(0), u16(files.length), u16(files.length), u32(centralBytes.length), u32(localBytes.length), u16(0));
  return new Blob([localBytes, centralBytes, end], { type: 'application/zip' });
}

async function inflateRaw(bytes, expectedSize) {
  if (!('DecompressionStream' in window)) throw new Error('Deflate ZIP entries are not supported by this browser.');
  const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  const buffer = new Uint8Array(await new Response(stream).arrayBuffer());
  if (expectedSize && buffer.length !== expectedSize) throw new Error('ZIP entry size verification failed.');
  return buffer;
}

export async function unzip(buffer) {
  const bytes = new Uint8Array(buffer); const files = []; let offset = 0; let safety = 0;
  while (offset + 30 < bytes.length && safety++ < 10000) {
    const signature = read32(bytes, offset); if (signature === 0x06054b50 || signature === 0x02014b50) break;
    if (signature !== 0x04034b50) throw new Error('Malformed ZIP: local file header not found.');
    const flags = read16(bytes, offset + 6); const method = read16(bytes, offset + 8); const compressed = read32(bytes, offset + 18); const original = read32(bytes, offset + 22); const nameLength = read16(bytes, offset + 26); const extraLength = read16(bytes, offset + 28);
    if (flags & 0x08) throw new Error('ZIP data descriptors are not supported for safe browser inspection.');
    const name = decoder.decode(bytes.slice(offset + 30, offset + 30 + nameLength)); const start = offset + 30 + nameLength + extraLength; const payload = bytes.slice(start, start + compressed); const cleanName = name.replaceAll('\\', '/').split('/').filter(part => part && part !== '..' && part !== '.').join('/');
    if (cleanName && !cleanName.endsWith('/')) { const data = method === 0 ? payload : method === 8 ? await inflateRaw(payload, original) : (() => { throw new Error(`Unsupported ZIP compression method ${method}.`); })(); files.push({ path: cleanName, content: decoder.decode(data), size: data.length, binary: false, source: 'zip' }); }
    offset = start + compressed;
  }
  if (!files.length) throw new Error('The ZIP contains no readable files.');
  return files;
}
