import { fileType } from './state.js';

export function recommend(files) {
  if (!files.length) return { mode: 'standalone', title: 'Standalone HTML', confidence: 'Awaiting input', reason: 'Start with a brief or import files to produce an evidence-backed recommendation.' };
  const types = files.map(file => fileType(file.path)); const hasHtml = types.some(type => type.html); const hasCss = types.some(type => type.css); const hasJs = types.some(type => type.js); const hasConfig = files.some(file => /(^|\/)(package\.json|vite\.config|next\.config|tsconfig)/i.test(file.path));
  if (hasConfig || (hasHtml && hasCss && hasJs)) return { mode: 'refactor', title: 'Existing-project refactor', confidence: 'High confidence', reason: 'Multiple connected source files or project configuration were detected. Preserve the structure and improve it in place.' };
  if (hasHtml || hasCss || hasJs) return { mode: 'modular', title: 'Modular static project', confidence: 'Good confidence', reason: 'The input already contains browser assets. A small modular project keeps references inspectable without forcing a framework conversion.' };
  return { mode: 'standalone', title: 'Standalone HTML', confidence: 'Best fit', reason: 'The input is brief or documentation-led, so a portable HTML output is the least surprising architecture.' };
}

const esc = value => String(value).replace(/[&<>"']/g, char => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[char]));
export function buildPlan(project, recommendation) {
  const hasFiles = project.files.length > 0;
  return [
    `Inspect ${hasFiles ? `${project.files.length} imported file${project.files.length === 1 ? '' : 's'}` : 'the natural-language brief'} without executing uploaded code.`,
    `Use ${recommendation.title.toLowerCase()} as the output contract and keep working files recoverable.`,
    'Generate semantic, responsive markup with accessible labels, metadata and a clear primary action.',
    'Run local structural, reference and security heuristics; keep unsupported runtime checks visibly NOT SUPPORTED.',
    'Export only the files the user selects, with a manifest and README describing evidence and limits.'
  ];
}

export function generateFromBrief(brief, direction = 'ltr') {
  const clean = brief.trim() || 'A focused product launch page'; const title = clean.split(/[.!?]/)[0].slice(0, 72); const rtl = direction === 'rtl' || /[\u0590-\u08ff]/.test(clean);
  const words = clean.replace(/[^\p{L}\p{N}\s]/gu, '').split(/\s+/).filter(Boolean); const subject = words.slice(0, 4).join(' ') || 'your next project';
  const html = `<!doctype html>\n<html lang="${rtl ? 'fa' : 'en'}" dir="${rtl ? 'rtl' : 'ltr'}">\n<head>\n  <meta charset="utf-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1">\n  <meta name="description" content="${esc(clean)}">\n  <title>${esc(title)}</title>\n  <style>\n    :root{font-family:Inter,system-ui,sans-serif;color:#eaf4ff;background:#07111f}*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(circle at 80% 0,#1b3a5b,transparent 42%),#07111f}main{max-width:1040px;margin:auto;padding:8vw 7vw}nav{display:flex;justify-content:space-between;align-items:center;color:#8da4bd;font-size:.9rem}nav strong{color:#70f0dc}section{padding:12vh 0 9vh;max-width:760px}h1{font-size:clamp(2.8rem,8vw,6rem);line-height:.95;letter-spacing:-.06em;margin:0 0 1.5rem}h1 span{color:#70f0dc}p{color:#a9bdd1;line-height:1.7;font-size:1.1rem;max-width:600px}.actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:2rem}a{padding:.8rem 1rem;border:1px solid #31506f;color:#eaf4ff;text-decoration:none;border-radius:4px}a.primary{background:#70f0dc;color:#052024;border-color:#70f0dc}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem}.card{border:1px solid #1d3048;padding:1.2rem;background:#0b1728}.card b{color:#70f0dc}.card p{font-size:.9rem}@media(max-width:650px){.grid{grid-template-columns:1fr}main{padding:10vw 6vw}}</style>\n</head>\n<body><main><nav><strong>&lt;&gt; FORGE OUTPUT</strong><span>Generated locally</span></nav><section><p>${esc(subject)}</p><h1>${esc(title)} <span>with intent.</span></h1><p>${esc(clean)}. This page is a clean starting point: semantic structure, responsive behavior, visible hierarchy and a primary action that can be edited in the Forge studio.</p><div class="actions"><a class="primary" href="#benefits">Explore the approach</a><a href="mailto:hello@example.com">Start a conversation</a></div></section><div id="benefits" class="grid"><article class="card"><b>01 / Clear</b><p>A focused message that gives visitors the next useful step.</p></article><article class="card"><b>02 / Modular</b><p>Simple markup and styles that remain readable when the project grows.</p></article><article class="card"><b>03 / Honest</b><p>No hidden services, no fake success states, no unverified claims.</p></article></div></main></body></html>`;
  return { path: 'index.html', content: html, size: html.length, binary: false, source: 'local-generator' };
}

export function assembleStandalone(files) {
  const html = files.find(file => fileType(file.path).html)?.content;
  if (!html) return null;
  const styles = files.filter(file => fileType(file.path).css).map(file => file.content).join('\n');
  if (!styles) return html;
  if (html.includes('</head>')) return html.replace('</head>', `<style>\n${styles}\n</style>\n</head>`);
  return `<!doctype html><html><head><style>${styles}</style></head><body>${html}</body></html>`;
}
