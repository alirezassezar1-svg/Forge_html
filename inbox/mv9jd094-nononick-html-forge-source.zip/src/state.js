const DB_NAME = 'htmlforge-local';
const DB_VERSION = 1;
let memoryProject = null;

export const emptyProject = () => ({
  id: crypto.randomUUID(), name: 'Untitled project', createdAt: Date.now(), updatedAt: Date.now(),
  files: [], history: [], selectedPath: '', architecture: 'standalone', direction: 'auto',
  plan: [], inventory: null, validation: null, lastTransform: null
});

const clone = value => JSON.parse(JSON.stringify(value));
const normalize = value => ({ ...emptyProject(), ...value, files: Array.isArray(value?.files) ? value.files : [], history: Array.isArray(value?.history) ? value.history : [] });

function openDb() {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) return reject(new Error('IndexedDB is not supported in this browser.'));
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => request.result.createObjectStore('projects', { keyPath: 'id' });
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Unable to open IndexedDB.'));
  });
}

export async function loadProject() {
  try {
    const db = await openDb();
    const value = await new Promise((resolve, reject) => {
      const request = db.transaction('projects', 'readonly').objectStore('projects').get('active');
      request.onsuccess = () => resolve(request.result?.value || null);
      request.onerror = () => reject(request.error);
    });
    db.close();
    if (value) { memoryProject = normalize(value); return clone(memoryProject); }
  } catch (error) { console.warn(error); }
  return clone(memoryProject || emptyProject());
}

export async function saveProject(project) {
  const normalized = normalize({ ...project, id: 'active', updatedAt: Date.now() });
  memoryProject = clone(normalized);
  try {
    const db = await openDb();
    await new Promise((resolve, reject) => {
      const request = db.transaction('projects', 'readwrite').objectStore('projects').put({ id: 'active', value: normalized });
      request.onsuccess = resolve; request.onerror = () => reject(request.error);
    });
    db.close();
    return { persisted: true, project: clone(normalized) };
  } catch (error) { console.warn(error); return { persisted: false, project: clone(normalized), error }; }
}

export function snapshot(project, reason) {
  const snap = { id: crypto.randomUUID(), createdAt: Date.now(), reason, files: clone(project.files), selectedPath: project.selectedPath };
  return { ...project, history: [snap, ...project.history].slice(0, 12) };
}

export function fileType(path = '') {
  const ext = path.split('.').pop()?.toLowerCase() || '';
  return { html: ['html','htm'].includes(ext), css: ext === 'css', js: ['js','mjs','cjs','ts','tsx','jsx'].includes(ext), json: ext === 'json', markdown: ['md','txt'].includes(ext), image: ['png','jpg','jpeg','webp','gif','svg'].includes(ext), extension: ext || 'file' };
}

export function safePath(path) {
  return path.replaceAll('\\', '/').split('/').filter(part => part && part !== '.' && part !== '..').join('/').slice(0, 220) || 'untitled.txt';
}

export function projectNameFromFiles(files) {
  const first = files.find(file => file.path && file.path !== 'index.html');
  return first ? first.path.split('/')[0] || 'Imported project' : 'Imported project';
}
