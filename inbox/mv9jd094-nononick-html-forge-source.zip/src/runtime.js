const blockedPath = /(^|\/)(node_modules|\.git|\.env(?:\.|$)|dist|build|coverage)(\/|$)/i;
const safeFiles = files => files.filter(file => !blockedPath.test(file.path) && !file.binary && typeof file.content === 'string').map(file => ({ path: file.path, content: file.content }));
async function call(endpoint, project) {
  const response = await fetch(endpoint, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ files: safeFiles(project.files) }) });
  const data = await response.json().catch(() => ({ ok: false, error: 'Runtime service returned an invalid response.' }));
  if (!response.ok || !data.ok) throw new Error(data.error || `Runtime request failed (${response.status}).`);
  return data;
}
export function analyzeRuntime(project) { return call('/api/runtime/analyze', project); }
export function buildRuntime(project) { return call('/api/runtime/build', project); }
export function runNodeRuntime(project) { return call('/api/runtime/run', project); }
export function runtimeFileCount(project) { return safeFiles(project.files).length; }
