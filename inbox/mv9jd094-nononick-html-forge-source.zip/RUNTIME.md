# Runtime Lab

Forge now includes an optional server-backed Runtime Lab for projects that cannot run in a browser-only page.

## Supported execution paths

- **Static/browser:** use the existing isolated iframe preview.
- **Vite/React/Next-style builds:** detect `package.json`, install dependencies with `npm install --ignore-scripts --no-audit --no-fund`, run an explicit `scripts.build` command in a network-isolated process, and serve `dist`, `build`, `out` or `public` output when an `index.html` exists.
- **Node.js entry:** detect `package.json.main`, `bin`, `src/index.js`, `src/main.js`, `index.js` or `main.js`; install with lifecycle scripts disabled, then run only a detected `.js`, `.mjs` or `.cjs` entry with a short timeout and no public port.

## Honest limits

- TypeScript-only entries, long-running servers, arbitrary commands, private repository access and projects without a declared build script are `NOT SUPPORTED`.
- This is a controlled build/run adapter, not a full container service. Imported projects are written to temporary workspaces, secrets are not passed through, network is disabled for build/run phases, timeouts are enforced, and common sensitive/cache paths are blocked. Do not use it as a security boundary for hostile code.
- `npm install` needs network access for dependency download and is run with package lifecycle scripts disabled. The application does not claim that third-party packages are trusted.
- Generated Preview directories expire after 30 minutes.
