# Vite + React + TS

Reconstructed website from https://webmirror-studio-dcy7.bolt.host/

## Capture Details
- **Source URL**: https://webmirror-studio-dcy7.bolt.host/
- **Capture Date**: 2026-10-19T14:20:59.679Z
- **Similarity Score**: 100.00%
- **Technologies**: None detected

## Structure
- `index.html` - Main page
- `assets/css/` - Stylesheets
- `assets/js/` - JavaScript files
- `assets/fonts/` - Font files
- `project.json` - Editable project data
- `manifest.json` - Project manifest

## Usage
Open `index.html` in a browser to view the reconstructed website.
