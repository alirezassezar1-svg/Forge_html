/*
# Create WebMirror Studio projects table

1. New Tables
- `webmirror_projects`
  - `id` (uuid, primary key)
  - `name` (text, project name)
  - `source_url` (text, the analyzed website URL)
  - `status` (text, current status: analyzing, ready, error)
  - `mode` (text, reference or reconstruction)
  - `pages` (jsonb, array of captured pages with their data)
  - `components` (jsonb, detected visual component tree)
  - `assets` (jsonb, detected assets list)
  - `content_map` (jsonb, content replacement mappings)
  - `generated_html` (text, the generated single HTML file)
  - `reconstruction_score` (jsonb, visual similarity scores)
  - `last_modified` (timestamp)
  - `created_at` (timestamp)

2. Security
- Enable RLS on `webmirror_projects`.
- Single-tenant app (no sign-in): allow anon + authenticated full CRUD.
*/

CREATE TABLE IF NOT EXISTS webmirror_projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT 'Untitled Project',
  source_url text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'analyzing',
  mode text NOT NULL DEFAULT 'reference',
  pages jsonb DEFAULT '[]'::jsonb,
  components jsonb DEFAULT '[]'::jsonb,
  assets jsonb DEFAULT '[]'::jsonb,
  content_map jsonb DEFAULT '[]'::jsonb,
  generated_html text DEFAULT '',
  reconstruction_score jsonb DEFAULT '{}'::jsonb,
  last_modified timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE webmirror_projects ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_projects" ON webmirror_projects;
CREATE POLICY "anon_select_projects" ON webmirror_projects FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_projects" ON webmirror_projects;
CREATE POLICY "anon_insert_projects" ON webmirror_projects FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_projects" ON webmirror_projects;
CREATE POLICY "anon_update_projects" ON webmirror_projects FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_projects" ON webmirror_projects;
CREATE POLICY "anon_delete_projects" ON webmirror_projects FOR DELETE
  TO anon, authenticated USING (true);
