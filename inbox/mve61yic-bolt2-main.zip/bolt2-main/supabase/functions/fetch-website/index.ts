import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { url } = await req.json();
    if (!url || typeof url !== "string") {
      return new Response(
        JSON.stringify({ error: "URL is required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let parsedUrl: URL;
    try {
      parsedUrl = new URL(url);
    } catch {
      return new Response(
        JSON.stringify({ error: "Invalid URL format" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000);

    const response = await fetch(parsedUrl.toString(), {
      headers: {
        "User-Agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Accept-Encoding": "gzip, deflate, br",
      },
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    const rawHtml = await response.text();
    const contentType = response.headers.get("content-type") || "";

    const titleMatch = rawHtml.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    const title = titleMatch ? titleMatch[1].trim() : parsedUrl.hostname;

    const metaDescMatch = rawHtml.match(
      /<meta\s+name=["']description["']\s+content=["']([^"']*)["']/i
    );
    const description = metaDescMatch ? metaDescMatch[1] : "";

    // Extract all stylesheet URLs and fetch their contents for inlining
    const stylesheetUrls: string[] = [];
    const linkRegex2 = /<link\s+[^>]*href=["']([^"']+)["']/gi;
    let match;
    while ((match = linkRegex2.exec(rawHtml)) !== null) {
      const href = match[1];
      const fullMatch = match[0];
      if (
        href.endsWith(".css") ||
        fullMatch.includes('rel="stylesheet"') ||
        fullMatch.includes("rel='stylesheet'") ||
        fullMatch.includes('rel=stylesheet')
      ) {
        try {
          const absolute = new URL(href, parsedUrl.origin).toString();
          stylesheetUrls.push(absolute);
        } catch {
          // skip
        }
      }
    }

    // Fetch CSS contents (parallel, with timeout)
    const cssContents: string[] = [];
    const cssPromises = stylesheetUrls.slice(0, 15).map(async (cssUrl) => {
      try {
        const cssController = new AbortController();
        const cssTimeout = setTimeout(() => cssController.abort(), 10000);
        const cssResp = await fetch(cssUrl, {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          },
          signal: cssController.signal,
        });
        clearTimeout(cssTimeout);
        const cssText = await cssResp.text();
        // Rewrite relative URLs in CSS to absolute
        const baseUrl = new URL(".", cssUrl).toString();
        const rewritten = cssText.replace(
          /url\(["']?([^"')]+)["']?\)/g,
          (_m: string, p1: string) => {
            try {
              if (p1.startsWith("data:") || p1.startsWith("http")) return `url(${p1})`;
              const absolute = new URL(p1, baseUrl).toString();
              return `url(${absolute})`;
            } catch {
              return `url(${p1})`;
            }
          }
        );
        return rewritten;
      } catch {
        return "";
      }
    });

    const cssResults = await Promise.all(cssPromises);
    cssContents.push(...cssResults.filter((c) => c.length > 0));

    // Extract inline <style> blocks
    const inlineStyles: string[] = [];
    const styleRegex = /<style[^>]*>([\s\S]*?)<\/style>/gi;
    while ((match = styleRegex.exec(rawHtml)) !== null) {
      inlineStyles.push(match[1]);
    }

    // Combine all CSS
    const allCss = [...inlineStyles, ...cssContents].join("\n");

    // Extract links
    const links: string[] = [];
    const linkRegex = /<a\s+[^>]*href=["']([^"']+)["']/gi;
    while ((match = linkRegex.exec(rawHtml)) !== null) {
      const href = match[1];
      if (
        !href.startsWith("#") &&
        !href.startsWith("mailto:") &&
        !href.startsWith("tel:") &&
        !href.startsWith("javascript:")
      ) {
        try {
          const absolute = new URL(href, parsedUrl.origin).toString();
          if (absolute.startsWith(parsedUrl.origin)) {
            links.push(absolute);
          }
        } catch {
          // skip
        }
      }
    }
    const uniqueLinks = [...new Set(links)].slice(0, 50);

    // Extract images
    const images: string[] = [];
    const imgRegex = /<img\s+[^>]*src=["']([^"']+)["']/gi;
    while ((match = imgRegex.exec(rawHtml)) !== null) {
      try {
        const absolute = new URL(match[1], parsedUrl.origin).toString();
        images.push(absolute);
      } catch {
        // skip
      }
    }

    // Extract srcset images
    const srcsetRegex = /srcset=["']([^"']+)["']/gi;
    while ((match = srcsetRegex.exec(rawHtml)) !== null) {
      const srcset = match[1];
      const urls = srcset.split(",").map((s) => s.trim().split(" ")[0]);
      for (const u of urls) {
        try {
          const absolute = new URL(u, parsedUrl.origin).toString();
          images.push(absolute);
        } catch {
          // skip
        }
      }
    }

    // Extract scripts
    const scripts: string[] = [];
    const scriptRegex = /<script\s+[^>]*src=["']([^"']+)["']/gi;
    while ((match = scriptRegex.exec(rawHtml)) !== null) {
      try {
        const absolute = new URL(match[1], parsedUrl.origin).toString();
        scripts.push(absolute);
      } catch {
        // skip
      }
    }

    // Extract fonts from CSS
    const fonts: string[] = [];
    const fontRegex = /@font-face\s*{[^}]*src:\s*url\(["']?([^"')]+)["']?\)/gi;
    while ((match = fontRegex.exec(allCss)) !== null) {
      try {
        const absolute = new URL(match[1], parsedUrl.origin).toString();
        fonts.push(absolute);
      } catch {
        // skip
      }
    }

    // Detect technologies
    const hasThreeJS = scripts.some((s) => s.includes("three"));
    const hasGSAP = scripts.some((s) => s.includes("gsap"));
    const hasWebGL = /WebGL|webgl|gl\.createBuffer/i.test(rawHtml);
    const hasLottie = scripts.some((s) => s.includes("lottie"));
    const hasReact = /react|__NEXT_DATA__|_reactRoot/i.test(rawHtml);
    const hasVue = /vue|__vue|nuxt/i.test(rawHtml);
    const hasTailwind = /tailwind|tw-/i.test(allCss);
    const hasBootstrap = /bootstrap|btn-primary|container-fluid/i.test(allCss);

    const technologies: string[] = [];
    if (hasReact) technologies.push("React");
    if (hasVue) technologies.push("Vue");
    if (hasThreeJS) technologies.push("Three.js");
    if (hasGSAP) technologies.push("GSAP");
    if (hasWebGL) technologies.push("WebGL");
    if (hasLottie) technologies.push("Lottie");
    if (hasTailwind) technologies.push("Tailwind CSS");
    if (hasBootstrap) technologies.push("Bootstrap");

    // Build cleaned HTML: remove scripts/tracking but keep structure
    let cleanedHtml = rawHtml;

    // Remove script tags
    cleanedHtml = cleanedHtml.replace(/<script[\s\S]*?<\/script>/gi, "");
    // Remove noscript
    cleanedHtml = cleanedHtml.replace(/<noscript[\s\S]*?<\/noscript>/gi, "");
    // Remove iframe tags (but keep their content visible)
    cleanedHtml = cleanedHtml.replace(/<iframe[^>]*>/gi, '<div class="wm-iframe-placeholder" style="min-height:200px;display:flex;align-items:center;justify-content:center;background:#f0f0f0;color:#999;font-size:14px;border-radius:8px;">IFRAME CONTENT</div>');
    // Remove tracking pixels and beacons
    cleanedHtml = cleanedHtml.replace(/<img[^>]*height=["']1["'][^>]*width=["']1["'][^>]*>/gi, "");
    cleanedHtml = cleanedHtml.replace(/<img[^>]*width=["']1["'][^>]*height=["']1["'][^>]*>/gi, "");
    // Remove inline event handlers
    cleanedHtml = cleanedHtml.replace(/\son\w+="[^"]*"/gi, "");
    cleanedHtml = cleanedHtml.replace(/\son\w+='[^']*'/gi, "");
    // Remove data attributes that are tracking-related
    cleanedHtml = cleanedHtml.replace(/data-(?:gtm|analytics|tracking|fb|pixel)[^=]*="[^"]*"/gi, "");

    // Rewrite all relative URLs to absolute
    cleanedHtml = cleanedHtml.replace(
      /(<img\s+[^>]*src=["'])([^"']+)(["'])/gi,
      (_m, p1, p2, p3) => {
        try {
          return `${p1}${new URL(p2, parsedUrl.origin).toString()}${p3}`;
        } catch {
          return `${p1}${p2}${p3}`;
        }
      }
    );

    // Rewrite href attributes
    cleanedHtml = cleanedHtml.replace(
      /(<a\s+[^>]*href=["'])([^"']+)(["'])/gi,
      (_m, p1, p2, p3) => {
        try {
          if (p2.startsWith("#") || p2.startsWith("mailto:") || p2.startsWith("tel:")) {
            return `${p1}${p2}${p3}`;
          }
          return `${p1}${new URL(p2, parsedUrl.origin).toString()}${p3}`;
        } catch {
          return `${p1}${p2}${p3}`;
        }
      }
    );

    // Build the final HTML: original cleaned body + all CSS inlined into head
    // Extract body content
    const bodyMatch = cleanedHtml.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    const bodyContent = bodyMatch ? bodyMatch[1] : cleanedHtml;

    // Extract head meta (excluding scripts/styles which we've already handled)
    const headMatch = cleanedHtml.match(/<head[^>]*>([\s\S]*?)<\/head>/i);
    let headContent = headMatch ? headMatch[1] : "";
    // Remove existing style/link from head (we'll inline everything)
    headContent = headContent.replace(/<link[^>]*rel=["']stylesheet["'][^>]*>/gi, "");
    headContent = headContent.replace(/<style[\s\S]*?<\/style>/gi, "");
    headContent = headContent.replace(/<script[\s\S]*?<\/script>/gi, "");

    // Build the self-contained HTML
    const selfContainedHtml = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
${headContent}
<style>
${allCss}

/* WebMirror Studio injected styles */
[data-wm-id] { cursor: pointer; }
.wm-iframe-placeholder { min-height: 200px; display: flex; align-items: center; justify-content: center; background: #f0f0f0; color: #999; font-size: 14px; border-radius: 8px; }
</style>
</head>
<body>
${bodyContent}
</body>
</html>`;

    return new Response(
      JSON.stringify({
        url: parsedUrl.toString(),
        title,
        description,
        html: rawHtml,
        cleanedHtml: selfContainedHtml,
        inlinedCss: allCss,
        contentType,
        links: uniqueLinks,
        images: [...new Set(images)].slice(0, 200),
        scripts: [...new Set(scripts)].slice(0, 50),
        stylesheets: stylesheetUrls,
        fonts: [...new Set(fonts)].slice(0, 30),
        technologies,
        status: response.status,
        htmlSize: rawHtml.length,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message || "Failed to fetch website" }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
