import { useState, useEffect, useRef } from "react";
import type { ComponentType } from "react";
import { Check, Loader2, AlertCircle, Globe, Cpu, Scan, Palette, Boxes, FileCode, Sparkles, Zap } from "lucide-react";
import type { AnalysisStep } from "@/types";
import { ANALYSIS_STEPS } from "@/types";
import { fetchWebsite, analyzeHtml, extractAssets, createPageData } from "@/lib/analyzer";
import { generateReconstructionScore, generateSingleHtml } from "@/lib/reconstructor";
import { saveProject } from "@/lib/storage";
import type { Project } from "@/types";

interface AnalyzingViewProps {
  url: string;
  onComplete: (project: Project) => void;
  onCancel: () => void;
}

const STEP_ICONS: Record<string, ComponentType<{ className?: string }>> = {
  launch: Cpu,
  render: Globe,
  dom: Scan,
  styles: Palette,
  components: Boxes,
  assets: Boxes,
  interactions: Zap,
  generate: FileCode,
  optimize: Sparkles,
  ready: Check,
};

export function AnalyzingView({ url, onComplete, onCancel }: AnalyzingViewProps) {
  const [steps, setSteps] = useState<AnalysisStep[]>(
    ANALYSIS_STEPS.map((s) => ({ ...s, status: "pending" as const }))
  );
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const completedRef = useRef(false);

  useEffect(() => {
    if (completedRef.current) return;
    completedRef.current = true;

    const run = async () => {
      try {
        // Steps 0-1: Launch + Render (simulated)
        for (let i = 0; i < 2; i++) {
          setSteps((prev) => prev.map((s, idx) => (idx === i ? { ...s, status: "active" } : s)));
          await new Promise((r) => setTimeout(r, 400));
          setSteps((prev) => prev.map((s, idx) => (idx === i ? { ...s, status: "done" } : s)));
          setProgress(((i + 1) / ANALYSIS_STEPS.length) * 100);
        }

        // Step 2: Fetch the website (this is the real work)
        setSteps((prev) => prev.map((s, idx) => (idx === 2 ? { ...s, status: "active" } : s)));

        const data = await fetchWebsite(url);

        setSteps((prev) => prev.map((s, idx) => (idx === 2 ? { ...s, status: "done" } : s)));
        setProgress((3 / ANALYSIS_STEPS.length) * 100);

        // Steps 3-4: Analyze DOM + Styles
        setSteps((prev) => prev.map((s, idx) => (idx === 3 ? { ...s, status: "active" } : s)));
        await new Promise((r) => setTimeout(r, 300));
        setSteps((prev) => prev.map((s, idx) => (idx === 3 ? { ...s, status: "done" } : s)));
        setProgress((4 / ANALYSIS_STEPS.length) * 100);

        setSteps((prev) => prev.map((s, idx) => (idx === 4 ? { ...s, status: "active" } : s)));
        const { components, contentMap } = analyzeHtml(data.html, url);
        setSteps((prev) => prev.map((s, idx) => (idx === 4 ? { ...s, status: "done" } : s)));
        setProgress((5 / ANALYSIS_STEPS.length) * 100);

        // Step 5: Detect components
        setSteps((prev) => prev.map((s, idx) => (idx === 5 ? { ...s, status: "active" } : s)));
        await new Promise((r) => setTimeout(r, 300));
        setSteps((prev) => prev.map((s, idx) => (idx === 5 ? { ...s, status: "done" } : s)));
        setProgress((6 / ANALYSIS_STEPS.length) * 100);

        // Step 6: Process assets
        setSteps((prev) => prev.map((s, idx) => (idx === 6 ? { ...s, status: "active" } : s)));
        const assets = extractAssets(data, components);
        const page = createPageData(data, components, assets);
        setSteps((prev) => prev.map((s, idx) => (idx === 6 ? { ...s, status: "done" } : s)));
        setProgress((7 / ANALYSIS_STEPS.length) * 100);

        // Step 7: Reconstruct interactions
        setSteps((prev) => prev.map((s, idx) => (idx === 7 ? { ...s, status: "active" } : s)));
        await new Promise((r) => setTimeout(r, 300));
        setSteps((prev) => prev.map((s, idx) => (idx === 7 ? { ...s, status: "done" } : s)));
        setProgress((8 / ANALYSIS_STEPS.length) * 100);

        // Step 8: Generate HTML
        setSteps((prev) => prev.map((s, idx) => (idx === 8 ? { ...s, status: "active" } : s)));
        const score = generateReconstructionScore(components);
        const html = generateSingleHtml([page], components, contentMap, "reference", data.title);
        setSteps((prev) => prev.map((s, idx) => (idx === 8 ? { ...s, status: "done" } : s)));
        setProgress((9 / ANALYSIS_STEPS.length) * 100);

        // Step 9: Optimize
        setSteps((prev) => prev.map((s, idx) => (idx === 9 ? { ...s, status: "active" } : s)));
        await new Promise((r) => setTimeout(r, 200));

        const project = await saveProject({
          name: data.title || url,
          source_url: url,
          status: "ready",
          mode: "reference",
          pages: [page],
          components,
          assets,
          content_map: contentMap,
          generated_html: html,
          reconstruction_score: score,
        });

        setSteps((prev) => prev.map((s, idx) => (idx === 9 ? { ...s, status: "done" } : s)));
        setProgress(100);

        setTimeout(() => onComplete(project), 600);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Analysis failed");
        setSteps((prev) =>
          prev.map((s) => (s.status === "active" ? { ...s, status: "error" } : s))
        );
      }
    };

    run();
  }, []);

  const activeStep = steps.find((s) => s.status === "active");

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white flex items-center justify-center px-6">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-blue-600/5 rounded-full blur-[120px]" />

      <div className="relative w-full max-w-md">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white/5 border border-white/10 mb-6 backdrop-blur-sm">
            {error ? (
              <AlertCircle className="w-7 h-7 text-red-400" />
            ) : (
              <div className="relative">
                <Globe className="w-7 h-7 text-cyan-400" />
                <div className="absolute inset-0 animate-ping">
                  <Globe className="w-7 h-7 text-cyan-400/30" />
                </div>
              </div>
            )}
          </div>
          <h2 className="text-xl font-semibold mb-2">
            {error ? "Analysis Failed" : "Analyzing Website"}
          </h2>
          <p className="text-sm text-white/40 truncate max-w-xs mx-auto">{url}</p>
        </div>

        {!error && (
          <div className="mb-8">
            <div className="flex items-center justify-between text-xs text-white/40 mb-2">
              <span>{activeStep?.label || "Processing..."}</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="h-1 bg-white/5 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        <div className="space-y-1">
          {steps.map((step) => {
            const Icon = STEP_ICONS[step.id] || Check;
            return (
              <div
                key={step.id}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all ${
                  step.status === "active"
                    ? "bg-white/5 border border-white/10"
                    : step.status === "done"
                    ? "opacity-50"
                    : step.status === "error"
                    ? "bg-red-500/10 border border-red-500/20"
                    : "opacity-30"
                }`}
              >
                <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0">
                  {step.status === "done" ? (
                    <Check className="w-4 h-4 text-emerald-400" />
                  ) : step.status === "active" ? (
                    <Loader2 className="w-4 h-4 text-cyan-400 animate-spin" />
                  ) : step.status === "error" ? (
                    <AlertCircle className="w-4 h-4 text-red-400" />
                  ) : (
                    <Icon className="w-4 h-4 text-white/40" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className={`text-sm font-medium ${
                    step.status === "active" ? "text-white" : "text-white/60"
                  }`}>
                    {step.label}
                  </p>
                  {step.status === "active" && step.detail && (
                    <p className="text-xs text-white/30">{step.detail}</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {error && (
          <div className="mt-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl">
            <p className="text-sm text-red-300 mb-4">{error}</p>
            <button
              onClick={onCancel}
              className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-xl text-sm font-medium text-white/70 hover:bg-white/10 transition-colors"
            >
              Back to Dashboard
            </button>
          </div>
        )}

        {!error && (
          <button
            onClick={onCancel}
            className="mt-6 w-full text-center text-xs text-white/30 hover:text-white/50 transition-colors"
          >
            Cancel analysis
          </button>
        )}
      </div>
    </div>
  );
}
