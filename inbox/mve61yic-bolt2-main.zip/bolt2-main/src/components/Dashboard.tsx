import { useState, useEffect } from "react";
import { Globe, Zap, Sparkles, Clock, Trash2, ArrowRight, Layers, Image as ImageIcon, FileCode } from "lucide-react";
import type { Project } from "@/types";
import { loadProjects, deleteProject } from "@/lib/storage";

interface DashboardProps {
  onAnalyze: (url: string) => void;
  onOpenProject: (project: Project) => void;
}

export function Dashboard({ onAnalyze, onOpenProject }: DashboardProps) {
  const [url, setUrl] = useState("");
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProjects()
      .then(setProjects)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url.trim()) {
      let normalized = url.trim();
      if (!normalized.startsWith("http://") && !normalized.startsWith("https://")) {
        normalized = `https://${normalized}`;
      }
      onAnalyze(normalized);
    }
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    await deleteProject(id);
    setProjects((prev) => prev.filter((p) => p.id !== id));
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-950/20 via-transparent to-transparent" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[120px]" />
        <div className="absolute top-40 right-20 w-[300px] h-[300px] bg-cyan-500/10 rounded-full blur-[100px]" />

        <div className="relative max-w-5xl mx-auto px-6 pt-24 pb-16">
          <div className="text-center">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm mb-8">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-xs font-medium text-white/70 tracking-wide">AI-POWERED VISUAL WEB RECONSTRUCTION</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-3">
              <span className="bg-gradient-to-r from-white via-white to-white/60 bg-clip-text text-transparent">WEBMIRROR</span>
              <span className="block text-2xl md:text-3xl font-light text-white/50 tracking-[0.2em] mt-2">STUDIO</span>
            </h1>

            <p className="text-lg text-white/50 max-w-xl mx-auto mb-12">
              Turn web inspiration into editable design systems.
            </p>

            <form onSubmit={handleSubmit} className="max-w-2xl mx-auto">
              <div className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600/30 via-cyan-500/30 to-blue-600/30 rounded-2xl blur opacity-40 group-focus-within:opacity-60 transition duration-500" />
                <div className="relative flex items-center gap-3 bg-[#111118] border border-white/10 rounded-2xl p-2 backdrop-blur-xl">
                  <Globe className="w-5 h-5 text-white/30 ml-3 flex-shrink-0" />
                  <input
                    type="text"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    placeholder="Paste website URL..."
                    className="flex-1 bg-transparent text-white placeholder-white/30 text-base outline-none py-2"
                    autoFocus
                  />
                  <button
                    type="submit"
                    disabled={!url.trim()}
                    className="flex items-center gap-2 px-6 py-2.5 bg-white text-black font-semibold rounded-xl text-sm hover:bg-white/90 transition-all disabled:opacity-30 disabled:cursor-not-allowed"
                  >
                    <Zap className="w-4 h-4" />
                    Analyze
                  </button>
                </div>
              </div>
            </form>

            <div className="flex items-center justify-center gap-6 mt-8 text-xs text-white/30">
              <span className="flex items-center gap-1.5"><Layers className="w-3.5 h-3.5" /> Component Detection</span>
              <span className="flex items-center gap-1.5"><ImageIcon className="w-3.5 h-3.5" /> Asset Processing</span>
              <span className="flex items-center gap-1.5"><FileCode className="w-3.5 h-3.5" /> Single HTML Export</span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 pb-24">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-sm font-semibold text-white/40 tracking-wider uppercase">Recent Projects</h2>
          {projects.length > 0 && (
            <span className="text-xs text-white/30">{projects.length} project{projects.length !== 1 ? "s" : ""}</span>
          )}
        </div>

        {loading ? (
          <div className="grid gap-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-20 bg-white/5 border border-white/10 rounded-2xl animate-pulse" />
            ))}
          </div>
        ) : projects.length === 0 ? (
          <div className="text-center py-16 border border-dashed border-white/10 rounded-2xl">
            <p className="text-white/30 text-sm">No projects yet. Enter a URL above to begin.</p>
          </div>
        ) : (
          <div className="grid gap-3">
            {projects.map((project) => (
              <button
                key={project.id}
                onClick={() => onOpenProject(project)}
                className="group flex items-center gap-4 p-5 bg-white/[0.03] border border-white/10 rounded-2xl hover:bg-white/[0.06] hover:border-white/20 transition-all text-left"
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-600/20 to-cyan-500/20 border border-white/10 flex items-center justify-center flex-shrink-0">
                  <Globe className="w-5 h-5 text-cyan-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-white truncate">{project.name}</h3>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                      project.status === "ready"
                        ? "bg-emerald-500/15 text-emerald-400"
                        : project.status === "analyzing"
                        ? "bg-amber-500/15 text-amber-400"
                        : "bg-white/10 text-white/40"
                    }`}>
                      {project.status.toUpperCase()}
                    </span>
                  </div>
                  <p className="text-xs text-white/40 truncate">{project.source_url}</p>
                  <div className="flex items-center gap-4 mt-2 text-[11px] text-white/30">
                    <span className="flex items-center gap-1"><Layers className="w-3 h-3" /> {project.components?.length || 0} components</span>
                    <span className="flex items-center gap-1"><ImageIcon className="w-3 h-3" /> {project.assets?.length || 0} assets</span>
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {new Date(project.last_modified).toLocaleDateString()}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <button
                    onClick={(e) => handleDelete(project.id, e)}
                    className="p-2 rounded-lg hover:bg-red-500/10 text-white/20 hover:text-red-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <div className="p-2 rounded-lg group-hover:bg-white/5 text-white/30 group-hover:text-white transition-colors">
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
