import type { ComponentType } from "react";
import { FolderPlus, Camera, Edit3, Image as ImageIcon, Download } from "lucide-react";
import type { MobileTab } from "@/types";

interface MobileNavProps {
  active: MobileTab;
  onChange: (tab: MobileTab) => void;
}

const TABS: { id: MobileTab; label: string; icon: ComponentType<{ className?: string }> }[] = [
  { id: "projects", label: "Projects", icon: FolderPlus },
  { id: "capture", label: "Capture", icon: Camera },
  { id: "editor", label: "Editor", icon: Edit3 },
  { id: "assets", label: "Assets", icon: ImageIcon },
  { id: "export", label: "Export", icon: Download },
];

export function MobileNav({ active, onChange }: MobileNavProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 md:hidden">
      <div className="mx-3 mb-3 flex items-center justify-around px-2 py-2.5 bg-[#111118]/90 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = active === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onChange(tab.id)}
              className="flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-all"
            >
              <div
                className={`p-2 rounded-xl transition-all ${
                  isActive
                    ? "bg-blue-500/20 text-blue-400 scale-110"
                    : "text-white/40"
                }`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <span
                className={`text-[10px] font-medium transition-colors ${
                  isActive ? "text-white" : "text-white/30"
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
