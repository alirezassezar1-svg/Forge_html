import { useState, useRef, useEffect } from "react";
import type { ComponentType as ReactComponentType } from "react";
import {
  ArrowLeft,
  Monitor,
  Smartphone,
  Tablet,
  Layers,
  Image as ImageIcon,
  FileCode,
  GitCompare,
  Download,
  Eye,
  Sparkles,
  Boxes,
  Trash2,
  Copy,
  Wand2,
  Check,
  X,
  ExternalLink,
  Code2,
} from "lucide-react";
import type { Project, ViewportSize, VisualComponent, ComponentType } from "@/types";
import { VIEWPORT_SIZES, COMPONENT_COLORS } from "@/types";
import { generateSingleHtml } from "@/lib/reconstructor";
import { saveProject } from "@/lib/storage";

interface WorkspaceProps {
  project: Project;
  onBack: () => void;
  onUpdate: (project: Project) => void;
}

type Panel = "components" | "assets" | "pages" | "export" | "difference";

export function Workspace({ project, onBack, onUpdate }: WorkspaceProps) {
  const [viewport, setViewport] = useState<ViewportSize>(VIEWPORT_SIZES[1]);
  const [panel, setPanel] = useState<Panel>("components");
  const [mode, setMode] = useState<"reference" | "reconstruction">(project.mode);
  const [selectedComponent, setSelectedComponent] = useState<VisualComponent | null>(null);
  const [showPreview, setShowPreview] = useState(true);
  const [generatedHtml, setGeneratedHtml] = useState(project.generated_html);
  const [contentMap, setContentMap] = useState(project.content_map);
  const [showMobilePanel, setShowMobilePanel] = useState(false);

  useEffect(() => {
    const html = generateSingleHtml(project.pages, project.components, contentMap, mode, project.name);
    setGeneratedHtml(html);
  }, [mode, contentMap, project]);

  const handleModeChange = async (newMode: "reference" | "reconstruction") => {
    setMode(newMode);
    const updated = { ...project, mode: newMode };
    onUpdate(updated);
    await saveProject({ ...updated, id: project.id });
  };

  const handleExportHtml = () => {
    const blob = new Blob([generatedHtml], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${project.name.replace(/[^a-z0-9]/gi, "-").toLowerCase()}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleExportJson = () => {
    const data = {
      name: project.name,
      source_url: project.source_url,
      mode,
      pages: project.pages.map((p) => ({ url: p.url, title: p.title, components: p.components.length, assets: p.assets.length })),
      components: project.components,
      content_map: contentMap,
      reconstruction_score: project.reconstruction_score,
      exported_at: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${project.name.replace(/[^a-z0-9]/gi, "-").toLowerCase()}-project.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleUpdateContent = (componentId: string, newReplacement: string) => {
    setContentMap((prev) => {
      const existing = prev.find((m) => m.componentId === componentId);
      if (existing) {
        return prev.map((m) => (m.componentId === componentId ? { ...m, replacement: newReplacement } : m));
      }
      return [...prev, { id: `map-${prev.length}`, componentId, original: "", replacement: newReplacement, type: "text" as const }];
    });
  };

  const viewportIcons: Record<string, ReactComponentType<{ className?: string }>> = {
    smartphone: Smartphone,
    tablet: Tablet,
    laptop: Monitor,
    monitor: Monitor,
  };

  const panelIcons: Record<Panel, ReactComponentType<{ className?: string }>> = {
    components: Layers,
    assets: ImageIcon,
    pages: FileCode,
    difference: GitCompare,
    export: Download,
  };

  return (
    <div className="h-screen bg-[#0a0a0f] text-white flex flex-col overflow-hidden">
      {/* Top Bar */}
      <div className="flex items-center justify-between px-3 py-2.5 border-b border-white/10 bg-[#0d0d14] backdrop-blur-xl flex-shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <button onClick={onBack} className="p-2 rounded-lg hover:bg-white/5 text-white/60 hover:text-white transition-colors flex-shrink-0">
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div className="h-5 w-px bg-white/10 flex-shrink-0" />
          <div className="min-w-0">
            <h1 className="text-sm font-semibold text-white truncate">{project.name}</h1>
            <p className="text-[10px] text-white/30 truncate hidden sm:block">{project.source_url}</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <div className="flex items-center bg-white/5 border border-white/10 rounded-lg p-0.5">
            <button
              onClick={() => handleModeChange("reference")}
              className={`px-2.5 sm:px-3 py-1.5 rounded-md text-xs font-medium transition-all ${mode === "reference" ? "bg-white text-black" : "text-white/50 hover:text-white"}`}
            >
              <Eye className="w-3 h-3 inline sm:mr-1.5" />
              <span className="hidden sm:inline">Reference</span>
            </button>
            <button
              onClick={() => handleModeChange("reconstruction")}
              className={`px-2.5 sm:px-3 py-1.5 rounded-md text-xs font-medium transition-all ${mode === "reconstruction" ? "bg-white text-black" : "text-white/50 hover:text-white"}`}
            >
              <Wand2 className="w-3 h-3 inline sm:mr-1.5" />
              <span className="hidden sm:inline">Reconstruction</span>
            </button>
          </div>

          <button
            onClick={() => setShowPreview(!showPreview)}
            className={`p-2 rounded-lg border transition-colors ${showPreview ? "bg-blue-500/15 border-blue-500/30 text-blue-400" : "bg-white/5 border-white/10 text-white/50"}`}
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Viewport + Panel Selector */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-white/10 bg-[#0b0b12] flex-shrink-0 gap-2">
        <div className="flex items-center gap-1 overflow-x-auto scrollbar-none flex-1">
          {VIEWPORT_SIZES.map((vp) => {
            const Icon = viewportIcons[vp.icon] || Monitor;
            return (
              <button
                key={vp.label}
                onClick={() => setViewport(vp)}
                className={`flex items-center gap-1 px-2 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${viewport.label === vp.label ? "bg-white/10 text-white border border-white/20" : "text-white/40 hover:text-white/60 hover:bg-white/5 border border-transparent"}`}
              >
                <Icon className="w-3 h-3" />
                <span className="hidden md:inline">{vp.width}px</span>
                <span className="md:hidden">{vp.width}</span>
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-1 flex-shrink-0">
          {(["components", "assets", "pages", "difference", "export"] as Panel[]).map((p) => {
            const Icon = panelIcons[p];
            return (
              <button
                key={p}
                onClick={() => { setPanel(p); setShowMobilePanel(true); }}
                className={`p-2 rounded-lg transition-colors ${panel === p ? "bg-white/10 text-white" : "text-white/40 hover:text-white/60 hover:bg-white/5"}`}
                title={p}
              >
                <Icon className="w-4 h-4" />
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Canvas Area */}
        <div className="flex-1 flex flex-col items-center justify-start overflow-auto bg-[#080810] p-2 sm:p-6">
          <div className="text-xs text-white/20 mb-2">
            {viewport.label} - {viewport.width} x {viewport.height}
          </div>
          <div
            className="relative bg-white rounded-lg overflow-hidden shadow-2xl transition-all duration-300"
            style={{
              width: `${viewport.width}px`,
              maxWidth: "100%",
              height: showPreview ? `${viewport.height}px` : "auto",
              maxHeight: showPreview ? "calc(100vh - 160px)" : "none",
            }}
          >
            <iframe
              srcDoc={generatedHtml}
              className="w-full h-full border-0"
              title="Preview"
              sandbox="allow-scripts allow-same-origin"
            />
          </div>
        </div>

        {/* Side Panel - Desktop */}
        <div className="hidden md:block w-80 border-l border-white/10 bg-[#0d0d14] overflow-y-auto flex-shrink-0">
          {renderPanel(panel, project, generatedHtml, contentMap, selectedComponent, setSelectedComponent, handleUpdateContent, handleExportHtml, handleExportJson)}
        </div>
      </div>

      {/* Side Panel - Mobile (slide-up) */}
      {showMobilePanel && (
        <div className="md:hidden fixed inset-0 z-40 flex flex-col justify-end" onClick={() => setShowMobilePanel(false)}>
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
          <div
            className="relative max-h-[70vh] bg-[#0d0d14] border-t border-white/15 rounded-t-2xl overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 flex items-center justify-between px-4 py-3 bg-[#0d0d14] border-b border-white/10 z-10">
              <span className="text-sm font-semibold capitalize">{panel}</span>
              <button onClick={() => setShowMobilePanel(false)} className="p-1.5 rounded-lg hover:bg-white/5 text-white/40">
                <X className="w-4 h-4" />
              </button>
            </div>
            {renderPanel(panel, project, generatedHtml, contentMap, selectedComponent, setSelectedComponent, handleUpdateContent, handleExportHtml, handleExportJson)}
          </div>
        </div>
      )}

      {/* Floating Inspector */}
      {selectedComponent && panel === "components" && (
        <FloatingInspector
          component={selectedComponent}
          contentMap={contentMap}
          onUpdateContent={handleUpdateContent}
          onClose={() => setSelectedComponent(null)}
        />
      )}
    </div>
  );
}

function renderPanel(
  panel: Panel,
  project: Project,
  generatedHtml: string,
  contentMap: any[],
  selectedComponent: VisualComponent | null,
  setSelectedComponent: (c: VisualComponent) => void,
  onUpdateContent: (id: string, text: string) => void,
  onExportHtml: () => void,
  onExportJson: () => void
) {
  switch (panel) {
    case "components":
      return <ComponentsPanel components={project.components} selectedComponent={selectedComponent} onSelect={setSelectedComponent} contentMap={contentMap} onUpdateContent={onUpdateContent} />;
    case "assets":
      return <AssetsPanel assets={project.assets} />;
    case "pages":
      return <PagesPanel project={project} />;
    case "difference":
      return <DifferencePanel project={project} />;
    case "export":
      return <ExportPanel project={project} generatedHtml={generatedHtml} onExport={onExportHtml} onExportJson={onExportJson} />;
  }
}

function ComponentsPanel({
  components,
  selectedComponent,
  onSelect,
  contentMap,
}: {
  components: VisualComponent[];
  selectedComponent: VisualComponent | null;
  onSelect: (c: VisualComponent) => void;
  contentMap: any[];
  onUpdateContent: (id: string, text: string) => void;
}) {
  const [filter, setFilter] = useState<ComponentType | "all">("all");
  const types = ["all", ...Array.from(new Set(components.map((c) => c.type)))];
  const filtered = filter === "all" ? components : components.filter((c) => c.type === filter);

  return (
    <div className="p-4">
      <div className="flex items-center gap-2 mb-4">
        <Boxes className="w-4 h-4 text-cyan-400" />
        <h3 className="text-sm font-semibold">Components</h3>
        <span className="text-xs text-white/30 ml-auto">{components.length}</span>
      </div>

      <div className="flex flex-wrap gap-1 mb-4">
        {types.slice(0, 10).map((t) => (
          <button
            key={t}
            onClick={() => setFilter(t as any)}
            className={`px-2 py-1 rounded-md text-[10px] font-medium transition-all ${filter === t ? "bg-white/10 text-white border border-white/20" : "bg-white/5 text-white/40 hover:text-white/60"}`}
          >
            {t === "all" ? "ALL" : t}
          </button>
        ))}
      </div>

      <div className="space-y-1">
        {filtered.slice(0, 80).map((comp) => {
          const color = COMPONENT_COLORS[comp.type];
          const mapping = contentMap.find((m: any) => m.componentId === comp.id);
          return (
            <button
              key={comp.id}
              onClick={() => onSelect(comp)}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-left transition-all ${selectedComponent?.id === comp.id ? "bg-white/10 border border-white/20" : "hover:bg-white/5 border border-transparent"}`}
            >
              <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: color }} />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-white/80 truncate">{comp.type}</p>
                <p className="text-[10px] text-white/30 truncate">{mapping?.replacement || comp.textContent || comp.tag}</p>
              </div>
              <span className="text-[10px] text-white/20">{comp.tag}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function AssetsPanel({ assets }: { assets: any[] }) {
  const statusColors: Record<string, string> = {
    keep: "text-emerald-400 bg-emerald-500/10",
    replace: "text-amber-400 bg-amber-500/10",
    remove: "text-red-400 bg-red-500/10",
    placeholder: "text-cyan-400 bg-cyan-500/10",
    embed: "text-purple-400 bg-purple-500/10",
  };

  return (
    <div className="p-4">
      <div className="flex items-center gap-2 mb-4">
        <ImageIcon className="w-4 h-4 text-cyan-400" />
        <h3 className="text-sm font-semibold">Assets</h3>
        <span className="text-xs text-white/30 ml-auto">{assets.length}</span>
      </div>

      <div className="space-y-2">
        {assets.slice(0, 80).map((asset) => (
          <div key={asset.id} className="p-3 bg-white/[0.03] border border-white/10 rounded-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium text-white/80 uppercase">{asset.type}</span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${statusColors[asset.status] || ""}`}>{asset.status}</span>
            </div>
            <p className="text-[10px] text-white/30 truncate">{asset.url}</p>
            <div className="flex items-center gap-3 mt-2 text-[10px] text-white/20">
              <span>{asset.format}</span>
              <span>{asset.size}</span>
            </div>
          </div>
        ))}
        {assets.length === 0 && <p className="text-xs text-white/30 text-center py-8">No assets detected</p>}
      </div>
    </div>
  );
}

function PagesPanel({ project }: { project: Project }) {
  return (
    <div className="p-4">
      <div className="flex items-center gap-2 mb-4">
        <FileCode className="w-4 h-4 text-cyan-400" />
        <h3 className="text-sm font-semibold">Pages</h3>
        <span className="text-xs text-white/30 ml-auto">{project.pages.length}</span>
      </div>

      <div className="space-y-2">
        {project.pages.map((page) => (
          <div key={page.id} className="p-3 bg-white/[0.03] border border-white/10 rounded-xl">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-medium text-white/80 truncate">{page.title}</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 flex-shrink-0">{page.status}</span>
            </div>
            <p className="text-[10px] text-white/30 truncate">{page.url}</p>
            <div className="flex items-center gap-3 mt-2 text-[10px] text-white/20">
              <span>{page.components.length} components</span>
              <span>{page.assets.length} assets</span>
            </div>
          </div>
        ))}
        {project.pages.length === 0 && <p className="text-xs text-white/30 text-center py-8">No pages captured</p>}
      </div>
    </div>
  );
}

function DifferencePanel({ project }: { project: Project }) {
  const score = project.reconstruction_score;
  const scores = [
    { label: "Visual", value: score.visual, color: "#3b82f6" },
    { label: "Layout", value: score.layout, color: "#06b6d4" },
    { label: "Typography", value: score.typography, color: "#8b5cf6" },
    { label: "Animation", value: score.animation, color: "#f59e0b" },
    { label: "Responsive", value: score.responsive, color: "#10b981" },
  ];

  return (
    <div className="p-4">
      <div className="flex items-center gap-2 mb-4">
        <GitCompare className="w-4 h-4 text-cyan-400" />
        <h3 className="text-sm font-semibold">Visual Reconstruction Score</h3>
      </div>

      <div className="text-center mb-6">
        <div className="relative inline-flex items-center justify-center">
          <svg className="w-32 h-32 -rotate-90">
            <circle cx="64" cy="64" r="56" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="8" />
            <circle cx="64" cy="64" r="56" fill="none" stroke="#3b82f6" strokeWidth="8" strokeDasharray={`${2 * Math.PI * 56 * (score.overall / 100)} ${2 * Math.PI * 56}`} strokeLinecap="round" />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-3xl font-bold">{score.overall}</span>
            <span className="text-[10px] text-white/40">OVERALL</span>
          </div>
        </div>
      </div>

      <div className="space-y-3">
        {scores.map((s) => (
          <div key={s.label}>
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-white/60">{s.label}</span>
              <span className="text-xs font-medium" style={{ color: s.color }}>{s.value}%</span>
            </div>
            <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
              <div className="h-full rounded-full transition-all duration-500" style={{ width: `${s.value}%`, background: s.color }} />
            </div>
          </div>
        ))}
      </div>

      {project.source_url && (
        <a
          href={project.source_url}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-4 flex items-center justify-center gap-2 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-white/60 hover:bg-white/10 transition-colors"
        >
          <ExternalLink className="w-3.5 h-3.5" />
          View Original Site
        </a>
      )}

      <div className="mt-4 p-3 bg-white/[0.03] border border-white/10 rounded-xl">
        <p className="text-[10px] text-white/40 leading-relaxed">
          This score reflects structural and visual similarity for design reference purposes. It does not measure content accuracy.
        </p>
      </div>
    </div>
  );
}

function ExportPanel({
  project,
  generatedHtml,
  onExport,
  onExportJson,
}: {
  project: Project;
  generatedHtml: string;
  onExport: () => void;
  onExportJson: () => void;
}) {
  const [exporting, setExporting] = useState(false);

  const stats = {
    pages: project.pages.length,
    components: project.components.length,
    assets: project.assets.length,
    animations: project.components.filter((c) => c.animation && c.animation !== "none").length,
    dependencies: project.assets.filter((a) => a.type === "script" || a.type === "stylesheet").length,
  };

  const handleExport = () => {
    setExporting(true);
    setTimeout(() => { onExport(); setExporting(false); }, 600);
  };

  return (
    <div className="p-4">
      <div className="flex items-center gap-2 mb-4">
        <Download className="w-4 h-4 text-cyan-400" />
        <h3 className="text-sm font-semibold">Export</h3>
      </div>

      <div className="space-y-2 mb-6">
        {[
          { label: "Pages", value: stats.pages, icon: FileCode },
          { label: "Components", value: stats.components, icon: Boxes },
          { label: "Assets", value: stats.assets, icon: ImageIcon },
          { label: "Animations", value: stats.animations, icon: Sparkles },
          { label: "External Dependencies", value: stats.dependencies, icon: Layers },
        ].map((s) => (
          <div key={s.label} className="flex items-center justify-between p-2.5 bg-white/[0.03] border border-white/10 rounded-lg">
            <div className="flex items-center gap-2">
              <s.icon className="w-3.5 h-3.5 text-white/40" />
              <span className="text-xs text-white/60">{s.label}</span>
            </div>
            <span className="text-xs font-semibold text-white">{s.value}</span>
          </div>
        ))}
      </div>

      <div className="text-xs text-white/40 mb-3">File size: ~{(new Blob([generatedHtml]).size / 1024).toFixed(1)} KB</div>

      <button
        onClick={handleExport}
        disabled={exporting}
        className="w-full flex items-center justify-center gap-2 py-3 bg-gradient-to-r from-blue-600 to-cyan-500 rounded-xl text-sm font-semibold text-white hover:opacity-90 transition-opacity disabled:opacity-50"
      >
        {exporting ? (
          <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Generating...</>
        ) : (
          <><FileCode className="w-4 h-4" /> Generate Single HTML</>
        )}
      </button>

      <button
        onClick={onExportJson}
        className="w-full mt-2 flex items-center justify-center gap-2 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs font-medium text-white/60 hover:bg-white/10 transition-colors"
      >
        <Code2 className="w-3.5 h-3.5" /> Export Project JSON
      </button>
    </div>
  );
}

function FloatingInspector({
  component,
  contentMap,
  onUpdateContent,
  onClose,
}: {
  component: VisualComponent;
  contentMap: any[];
  onUpdateContent: (id: string, text: string) => void;
  onClose: () => void;
}) {
  const mapping = contentMap.find((m: any) => m.componentId === component.id);
  const [editText, setEditText] = useState(mapping?.replacement || component.placeholder);
  const [tab, setTab] = useState<"edit" | "style" | "animation">("edit");

  const color = COMPONENT_COLORS[component.type];

  return (
    <div className="fixed bottom-4 right-4 left-4 md:left-auto md:w-72 bg-[#111118] border border-white/15 rounded-2xl shadow-2xl backdrop-blur-xl z-50 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full" style={{ background: color }} />
          <span className="text-xs font-semibold">{component.type}</span>
          <span className="text-[10px] text-white/30">{component.tag}</span>
        </div>
        <button onClick={onClose} className="p-1 rounded-lg hover:bg-white/5 text-white/40">
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="flex border-b border-white/10">
        {(["edit", "style", "animation"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 py-2 text-xs font-medium capitalize transition-colors ${tab === t ? "text-white border-b-2 border-blue-500" : "text-white/40 hover:text-white/60"}`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="p-4 max-h-60 md:max-h-80 overflow-y-auto">
        {tab === "edit" && (
          <div className="space-y-3">
            <div>
              <label className="text-[10px] text-white/40 uppercase tracking-wider">Content</label>
              <textarea
                value={editText}
                onChange={(e) => setEditText(e.target.value)}
                onBlur={() => onUpdateContent(component.id, editText)}
                rows={3}
                className="w-full mt-1 px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-xs text-white outline-none focus:border-blue-500/50 resize-none"
              />
            </div>
            <div className="flex gap-2">
              <button className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-white/5 border border-white/10 rounded-lg text-xs text-white/60 hover:bg-white/10 transition-colors">
                <Copy className="w-3 h-3" /> Duplicate
              </button>
              <button className="flex-1 flex items-center justify-center gap-1.5 py-2 bg-red-500/10 border border-red-500/20 rounded-lg text-xs text-red-400 hover:bg-red-500/20 transition-colors">
                <Trash2 className="w-3 h-3" /> Delete
              </button>
            </div>
          </div>
        )}

        {tab === "style" && (
          <div className="space-y-2.5">
            <StyleRow label="Tag" value={component.tag} />
            <StyleRow label="Selector" value={component.selector} />
            <StyleRow label="Display" value={component.display} />
            <StyleRow label="Background" value={component.background.substring(0, 40)} />
            <StyleRow label="Border Radius" value={component.borderRadius} />
            <StyleRow label="Shadow" value={component.boxShadow.substring(0, 30)} />
            <StyleRow label="Opacity" value={String(component.opacity)} />
            <StyleRow label="Z-Index" value={String(component.zIndex)} />
          </div>
        )}

        {tab === "animation" && (
          <div className="space-y-2.5">
            <StyleRow label="Transform" value={component.transform} />
            <StyleRow label="Animation" value={component.animation} />
            <div className="pt-2">
              <p className="text-[10px] text-white/40 uppercase tracking-wider mb-2">Responsive</p>
              <div className="grid grid-cols-3 gap-2">
                <div className="text-center p-2 bg-white/5 rounded-lg">
                  <p className="text-[10px] text-white/30">Mobile</p>
                  <p className="text-xs text-white/60">{component.responsive.mobile}</p>
                </div>
                <div className="text-center p-2 bg-white/5 rounded-lg">
                  <p className="text-[10px] text-white/30">Tablet</p>
                  <p className="text-xs text-white/60">{component.responsive.tablet}</p>
                </div>
                <div className="text-center p-2 bg-white/5 rounded-lg">
                  <p className="text-[10px] text-white/30">Desktop</p>
                  <p className="text-xs text-white/60">{component.responsive.desktop}</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function StyleRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-[10px] text-white/40 uppercase tracking-wider">{label}</span>
      <span className="text-xs text-white/70 font-mono truncate max-w-[140px]">{value}</span>
    </div>
  );
}
