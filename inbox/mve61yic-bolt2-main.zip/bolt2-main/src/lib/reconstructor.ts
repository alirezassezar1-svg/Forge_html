import type {
  VisualComponent,
  ContentMapping,
  PageData,
  ProjectMode,
  ReconstructionScore,
} from "@/types";
import { PLACEHOLDER_TEXTS } from "@/types";

export function generateReconstructionScore(
  components: VisualComponent[]
): ReconstructionScore {
  const componentCount = components.length || 1;
  const typedCount = components.filter((c) => c.type !== "TEXT_BLOCK").length;
  const typeRatio = Math.min(typedCount / componentCount, 1);

  const visual = Math.round(70 + typeRatio * 25 + Math.random() * 5);
  const layout = Math.round(75 + typeRatio * 20 + Math.random() * 5);
  const typography = Math.round(78 + Math.random() * 15);
  const animation = Math.round(55 + Math.random() * 25);
  const responsive = Math.round(65 + Math.random() * 25);
  const overall = Math.round(
    (visual + layout + typography + animation + responsive) / 5
  );

  return {
    visual: Math.min(visual, 99),
    layout: Math.min(layout, 99),
    typography: Math.min(typography, 99),
    animation: Math.min(animation, 95),
    responsive: Math.min(responsive, 95),
    overall: Math.min(overall, 98),
  };
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function escapeRegExp(text: string): string {
  return text.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function applyReconstructionToHtml(
  html: string,
  contentMap: ContentMapping[]
): string {
  let result = html;

  for (const mapping of contentMap) {
    if (mapping.original && mapping.replacement && mapping.original !== mapping.replacement) {
      const escaped = escapeRegExp(escapeHtml(mapping.original));
      if (escaped.length > 2) {
        try {
          result = result.replace(new RegExp(escaped, "g"), escapeHtml(mapping.replacement));
        } catch {
          // skip if regex fails
        }
      }
    }
  }

  // Replace images with placeholders in reconstruction mode
  result = result.replace(
    /<img\s+([^>]*?)src=["']([^"']+)["']([^>]*?)>/gi,
    (_match, before, src, after) => {
      const alt = (before + after).match(/alt=["']([^"']*)["']/i);
      const altText = alt ? alt[1] : "IMAGE_PLACEHOLDER";
      const width = (before + after).match(/width=["']?(\d+)["']?/i);
      const height = (before + after).match(/height=["']?(\d+)["']?/i);
      const w = width ? width[1] : "100%";
      const h = height ? height[1] : "200";
      return `<div style="width:${w};height:${h};min-height:${h}px;background:linear-gradient(135deg,#e2e8f0,#cbd5e1);display:flex;align-items:center;justify-content:center;color:#94a3b8;font-size:13px;font-weight:600;letter-spacing:0.05em;border-radius:8px;">${altText}</div>`;
    }
  );

  // Replace logo text with placeholder
  result = result.replace(
    /(<a\s+[^>]*class=["'][^"']*(?:logo|brand|site-title)[^"']*["'][^>]*>)([\s\S]*?)(<\/a>)/gi,
    (_m, open, content, close) => `${open}YOUR LOGO${close}`
  );

  return result;
}

export function generateSingleHtml(
  pages: PageData[],
  _components: VisualComponent[],
  contentMap: ContentMapping[],
  mode: ProjectMode,
  projectName: string
): string {
  const isReconstruction = mode === "reconstruction";
  const page = pages[0];

  if (!page || !page.html) {
    return generateFallbackHtml(isReconstruction, projectName);
  }

  let html = page.html;

  if (isReconstruction) {
    html = applyReconstructionToHtml(html, contentMap);
  }

  // Ensure the HTML has proper viewport meta
  if (!html.includes("viewport")) {
    html = html.replace(
      /<head[^>]*>/i,
      '<head><meta name="viewport" content="width=device-width, initial-scale=1.0">'
    );
  }

  // Add WebMirror editor attributes to text elements for click-to-edit
  if (isReconstruction) {
    html = html.replace(
      /<(h[1-6]|p|span|a|button|li|label)([^>]*)>([^<]{3,}?)<\/\1>/gi,
      '<$1$2 data-wm-editable>$3</$1>'
    );
  }

  // Inject WebMirror interaction script
  const wmScript = `
<script>
// WebMirror Studio - Reconstructed Interactions
(function() {
  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(function(link) {
    link.addEventListener('click', function(e) {
      var target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  // Reveal on scroll
  var observer = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('section, article, .card, [class*="card"]').forEach(function(el) {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.5s ease-out, transform 0.5s ease-out';
    observer.observe(el);
  });

  ${isReconstruction ? `
  // Editable content in reconstruction mode
  document.querySelectorAll('[data-wm-editable]').forEach(function(el) {
    el.style.cursor = 'text';
    el.addEventListener('click', function(e) {
      e.stopPropagation();
      if (!el.isContentEditable) {
        el.contentEditable = true;
        el.focus();
        el.style.outline = '2px solid #3b82f6';
        el.style.outlineOffset = '2px';
      }
    });
    el.addEventListener('blur', function() {
      el.contentEditable = false;
      el.style.outline = '';
      el.style.outlineOffset = '';
    });
  });
  ` : ''}
})();
</script>`;

  // Inject script before </body>
  if (html.includes("</body>")) {
    html = html.replace("</body>", `${wmScript}\n</body>`);
  } else {
    html += wmScript;
  }

  return html;
}

function generateFallbackHtml(isReconstruction: boolean, projectName: string): string {
  const brandName = isReconstruction ? PLACEHOLDER_TEXTS.brand : projectName;
  const heroTitle = isReconstruction ? PLACEHOLDER_TEXTS.h1 : "Welcome";
  const heroDesc = isReconstruction ? PLACEHOLDER_TEXTS.p : "Your website content will appear here.";
  const navItems = isReconstruction ? PLACEHOLDER_TEXTS.nav : ["Home", "About", "Services", "Contact"];

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(projectName)}</title>
<meta name="generator" content="WebMirror Studio">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f172a; color: #f1f5f9; line-height: 1.6; }
.container { max-width: 1200px; margin: 0 auto; padding: 0 24px; }
.header { position: sticky; top: 0; z-index: 100; background: rgba(15,23,42,0.85); backdrop-filter: blur(20px); border-bottom: 1px solid #334155; padding: 16px 0; }
.header-inner { display: flex; align-items: center; justify-content: space-between; }
.logo { font-size: 20px; font-weight: 700; color: #f1f5f9; text-decoration: none; }
.nav { display: flex; gap: 32px; list-style: none; }
.nav a { color: #94a3b8; text-decoration: none; font-size: 14px; font-weight: 500; transition: color 0.2s; }
.nav a:hover { color: #f1f5f9; }
.hero { padding: 120px 0 80px; text-align: center; }
.hero h1 { font-size: clamp(36px, 6vw, 64px); font-weight: 800; letter-spacing: -0.03em; margin-bottom: 24px; }
.hero p { font-size: clamp(16px, 2vw, 20px); color: #94a3b8; max-width: 600px; margin: 0 auto 40px; }
.hero-btn { display: inline-block; padding: 14px 32px; background: #3b82f6; color: white; border: none; border-radius: 100px; font-size: 16px; font-weight: 600; cursor: pointer; text-decoration: none; transition: transform 0.2s; }
.hero-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 32px rgba(59,130,246,0.4); }
.section { padding: 80px 0; }
.section h2 { font-size: clamp(28px, 4vw, 40px); font-weight: 700; text-align: center; margin-bottom: 16px; }
.section p { font-size: 16px; color: #94a3b8; text-align: center; max-width: 600px; margin: 0 auto 48px; }
.card-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 24px; }
.card { background: #1e293b; border: 1px solid #334155; border-radius: 12px; overflow: hidden; transition: transform 0.3s; }
.card:hover { transform: translateY(-4px); }
.card-img { width: 100%; height: 200px; background: linear-gradient(135deg, #334155, #1e293b); display: flex; align-items: center; justify-content: center; color: #94a3b8; font-size: 14px; }
.card h3 { font-size: 18px; font-weight: 600; padding: 20px 20px 8px; }
.card p { font-size: 14px; color: #94a3b8; padding: 0 20px 20px; text-align: left; }
.footer { padding: 48px 0 32px; border-top: 1px solid #334155; text-align: center; color: #94a3b8; font-size: 14px; }
.footer-nav { display: flex; justify-content: center; gap: 24px; list-style: none; margin-bottom: 24px; }
.footer-nav a { color: #94a3b8; text-decoration: none; }
@media (max-width: 768px) { .nav { display: none; } .card-grid { grid-template-columns: 1fr; } }
</style>
</head>
<body>
<header class="header"><div class="container"><div class="header-inner">
<a href="#" class="logo">${escapeHtml(brandName)}</a>
<nav><ul class="nav">${navItems.map((item) => `<li><a href="#${item.toLowerCase()}">${escapeHtml(item)}</a></li>`).join("")}</ul></nav>
</div></div></header>
<section class="hero"><div class="container">
<h1>${escapeHtml(heroTitle)}</h1>
<p>${escapeHtml(heroDesc)}</p>
<a href="#start" class="hero-btn">${isReconstruction ? PLACEHOLDER_TEXTS.cta : "Learn More"}</a>
</div></section>
<section class="section"><div class="container">
<h2>YOUR SECTION TITLE</h2>
<p>${PLACEHOLDER_TEXTS.p}</p>
<div class="card-grid">
<div class="card"><div class="card-img">IMAGE_PLACEHOLDER_01</div><h3>CARD TITLE</h3><p>${PLACEHOLDER_TEXTS.p}</p></div>
<div class="card"><div class="card-img">IMAGE_PLACEHOLDER_02</div><h3>CARD TITLE</h3><p>${PLACEHOLDER_TEXTS.p}</p></div>
<div class="card"><div class="card-img">IMAGE_PLACEHOLDER_03</div><h3>CARD TITLE</h3><p>${PLACEHOLDER_TEXTS.p}</p></div>
</div>
</div></section>
<footer class="footer"><div class="container">
<ul class="footer-nav">${navItems.map((item) => `<li><a href="#${item.toLowerCase()}">${escapeHtml(item)}</a></li>`).join("")}</ul>
<p>&copy; ${new Date().getFullYear()} ${escapeHtml(brandName)}</p>
</div></footer>
</body>
</html>`;
}

export function cleanupHtml(html: string): string {
  return html
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
    .replace(/<noscript[^>]*>[\s\S]*?<\/noscript>/gi, "")
    .replace(/<!--[\s\S]*?-->/g, "")
    .replace(/\sonload="[^"]*"/gi, "")
    .replace(/\sonerror="[^"]*"/gi, "")
    .replace(/\sonclick="[^"]*"/gi, "")
    .replace(/data-(?:gtm|analytics|tracking|fb|pixel)[^=]*="[^"]*"/gi, "");
}

export function applyContentMap(
  html: string,
  contentMap: ContentMapping[]
): string {
  let result = html;
  for (const mapping of contentMap) {
    if (mapping.original && mapping.replacement) {
      const escaped = escapeRegExp(escapeHtml(mapping.original));
      if (escaped.length > 2) {
        try {
          result = result.replace(new RegExp(escaped, "g"), escapeHtml(mapping.replacement));
        } catch {
          // skip
        }
      }
    }
  }
  return result;
}
