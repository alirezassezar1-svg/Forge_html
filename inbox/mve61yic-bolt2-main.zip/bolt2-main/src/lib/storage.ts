import { supabase } from "./supabase";
import type { Project } from "@/types";

export async function saveProject(project: Omit<Project, "id" | "created_at" | "last_modified"> & { id?: string }): Promise<Project> {
  const payload = {
    name: project.name,
    source_url: project.source_url,
    status: project.status,
    mode: project.mode,
    pages: project.pages,
    components: project.components,
    assets: project.assets,
    content_map: project.content_map,
    generated_html: project.generated_html,
    reconstruction_score: project.reconstruction_score,
    last_modified: new Date().toISOString(),
  };

  if (project.id) {
    const { data, error } = await supabase
      .from("webmirror_projects")
      .update(payload)
      .eq("id", project.id)
      .select("*")
      .maybeSingle();

    if (error) throw new Error(error.message);
    return mapDbRow(data);
  } else {
    const { data, error } = await supabase
      .from("webmirror_projects")
      .insert(payload)
      .select("*")
      .maybeSingle();

    if (error) throw new Error(error.message);
    return mapDbRow(data);
  }
}

export async function loadProjects(): Promise<Project[]> {
  const { data, error } = await supabase
    .from("webmirror_projects")
    .select("*")
    .order("last_modified", { ascending: false });

  if (error) throw new Error(error.message);
  return (data || []).map(mapDbRow);
}

export async function deleteProject(id: string): Promise<void> {
  const { error } = await supabase
    .from("webmirror_projects")
    .delete()
    .eq("id", id);

  if (error) throw new Error(error.message);
}

function mapDbRow(row: any): Project {
  if (!row) throw new Error("Project not found");
  return {
    id: row.id,
    name: row.name,
    source_url: row.source_url,
    status: row.status,
    mode: row.mode,
    pages: row.pages || [],
    components: row.components || [],
    assets: row.assets || [],
    content_map: row.content_map || [],
    generated_html: row.generated_html || "",
    reconstruction_score: row.reconstruction_score || {
      visual: 0,
      layout: 0,
      typography: 0,
      animation: 0,
      responsive: 0,
      overall: 0,
    },
    last_modified: row.last_modified,
    created_at: row.created_at,
  };
}
