import type { VisualComponent, ComponentType, AssetItem, PageData, ContentMapping } from "@/types";
import { PLACEHOLDER_TEXTS } from "@/types";

export interface FetchedData {
  url: string;
  title: string;
  description: string;
  html: string;
  cleanedHtml: string;
  inlinedCss: string;
  contentType: string;
  links: string[];
  images: string[];
  scripts: string[];
  stylesheets: string[];
  fonts: string[];
  technologies: string[];
  status: number;
  htmlSize: number;
}

export async function fetchWebsite(url: string): Promise<FetchedData> {
  const response = await fetch(
    `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/fetch-website`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({ url }),
    }
  );

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: "Unknown error" }));
    throw new Error(error.error || `Request failed (${response.status})`);
  }

  const data = await response.json();
  if (data.error) throw new Error(data.error);
  return data as FetchedData;
}

function detectComponentType(
  tag: string,
  className: string,
  id: string,
  textContent: string,
  parentTag: string,
  hasChildren: boolean,
  childCount: number
): ComponentType {
  const lowerClass = (className || "").toLowerCase();
  const lowerId = (id || "").toLowerCase();
  const combined = `${lowerClass} ${lowerId}`;

  if (tag === "header") return "HEADER";
  if (tag === "nav") return "NAVIGATION";
  if (tag === "footer") return "FOOTER";
  if (tag === "canvas") return "CANVAS";
  if (tag === "svg") return "IMAGE";
  if (tag === "video") return "VIDEO";
  if (tag === "form") return "FORM";
  if (tag === "button" || (tag === "a" && lowerClass.includes("btn"))) return "BUTTON";
  if (tag === "a" && (lowerClass.includes("cta") || lowerId.includes("cta"))) return "CTA";

  if (combined.includes("hero") || combined.includes("banner") || combined.includes("splash"))
    return "HERO";
  if (combined.includes("modal") || combined.includes("dialog")) return "MODAL";
  if (combined.includes("overlay") || combined.includes("popup")) return "OVERLAY";
  if (combined.includes("card")) return "CARD";
  if (combined.includes("grid") || combined.includes("gallery")) return "GRID";
  if (combined.includes("cta") || combined.includes("call-to-action")) return "CTA";
  if (combined.includes("nav") || combined.includes("menu")) return "NAVIGATION";

  if (tag === "img") return "IMAGE";
  if (["h1", "h2", "h3", "h4", "h5", "h6"].includes(tag)) return "TEXT_BLOCK";
  if (["p", "span", "label", "li"].includes(tag)) return "TEXT_BLOCK";

  if (hasChildren && childCount > 2) {
    if (["body", "main", "div"].includes(parentTag)) return "SECTION";
    return "GRID";
  }

  if (["section", "article", "main", "aside"].includes(tag)) return "SECTION";
  if (["ul", "ol"].includes(tag)) return "LIST";
  if (tag === "div" && !textContent) return "SECTION";

  return "TEXT_BLOCK";
}

function getPlaceholder(tag: string, type: ComponentType): string {
  if (type === "HERO") return PLACEHOLDER_TEXTS.h1;
  if (type === "HEADER") return PLACEHOLDER_TEXTS.brand;
  if (type === "FOOTER") return "FOOTER CONTENT";
  if (type === "NAVIGATION") return "NAVIGATION";
  if (type === "BUTTON" || type === "CTA") return PLACEHOLDER_TEXTS.cta;
  if (type === "IMAGE") return "IMAGE_PLACEHOLDER";
  if (type === "VIDEO") return "VIDEO_PLACEHOLDER";
  if (type === "CARD") return "CARD TITLE";
  if (type === "FORM") return "FORM";
  if (tag === "h1") return PLACEHOLDER_TEXTS.h1;
  if (tag === "h2") return PLACEHOLDER_TEXTS.h2;
  if (tag === "h3") return PLACEHOLDER_TEXTS.h3;
  if (tag === "p") return PLACEHOLDER_TEXTS.p;
  if (tag === "a") return PLACEHOLDER_TEXTS.a;
  if (tag === "button") return PLACEHOLDER_TEXTS.button;
  if (tag === "span") return PLACEHOLDER_TEXTS.span;
  return "YOUR CONTENT";
}

export function analyzeHtml(
  html: string,
  _url: string
): { components: VisualComponent[]; contentMap: ContentMapping[] } {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");

  const components: VisualComponent[] = [];
  const contentMap: ContentMapping[] = [];
  let componentIndex = 0;

  const body = doc.body;
  if (!body) return { components, contentMap };

  const walk = (node: Element, parentTag: string, depth: number) => {
    if (depth > 5) return;
    if (node.nodeType !== 1) return;

    const tag = node.tagName.toLowerCase();
    if (["script", "style", "noscript", "link", "meta"].includes(tag)) return;

    const className = node.className?.toString() || "";
    const id = node.id || "";
    const textContent = node.textContent?.trim().substring(0, 200) || "";
    const childElements = Array.from(node.children).filter(
      (c) => !["script", "style", "noscript"].includes(c.tagName.toLowerCase())
    );
    const hasChildren = childElements.length > 0;
    const childCount = childElements.length;

    const type = detectComponentType(tag, className, id, textContent, parentTag, hasChildren, childCount);

    if (
      type !== "TEXT_BLOCK" ||
      textContent.length > 0 ||
      hasChildren ||
      ["img", "video", "section", "header", "footer", "nav"].includes(tag)
    ) {
      const componentId = `comp-${componentIndex++}`;
      const placeholder = getPlaceholder(tag, type);

      const component: VisualComponent = {
        id: componentId,
        type,
        tag,
        selector: id ? `#${id}` : className ? `.${className.split(" ")[0]}` : tag,
        position: { x: 0, y: 0 },
        width: 0,
        height: 0,
        margin: { top: 0, right: 0, bottom: 0, left: 0 },
        padding: { top: 0, right: 0, bottom: 0, left: 0 },
        typography: {
          fontFamily: "inherit",
          fontSize: "16px",
          fontWeight: "400",
          lineHeight: "1.5",
          letterSpacing: "normal",
          color: "inherit",
          textAlign: "left",
        },
        background: "transparent",
        borderRadius: "0",
        border: "none",
        boxShadow: "none",
        opacity: 1,
        transform: "none",
        animation: "none",
        zIndex: 0,
        display: "block",
        flexDirection: "row",
        alignItems: "stretch",
        justifyContent: "flex-start",
        gap: "0",
        children: childElements.map((c) => c.tagName.toLowerCase()),
        textContent: textContent.substring(0, 100),
        placeholder,
        responsive: { mobile: "stack", tablet: "2-col", desktop: "auto" },
      };

      components.push(component);

      if (textContent && textContent.length > 2) {
        contentMap.push({
          id: `map-${contentMap.length}`,
          componentId,
          original: textContent.substring(0, 100),
          replacement: placeholder,
          type: "text",
        });
      }
    }

    for (const child of childElements) {
      walk(child, tag, depth + 1);
    }
  };

  walk(body, "html", 0);

  return { components: components.slice(0, 300), contentMap: contentMap.slice(0, 150) };
}

export function extractAssets(
  data: FetchedData,
  components: VisualComponent[]
): AssetItem[] {
  const assets: AssetItem[] = [];
  let idx = 0;

  for (const img of data.images) {
    const ext = img.split(".").pop()?.split("?")[0]?.toLowerCase() || "jpg";
    const isSvg = ext === "svg" || img.includes("svg");
    assets.push({
      id: `asset-${idx++}`,
      url: img,
      type: isSvg ? "svg" : "image",
      format: ext,
      size: "—",
      source: data.url,
      usedBy: components.filter((c) => c.type === "IMAGE").slice(0, 3).map((c) => c.id),
      status: "keep",
      embedded: false,
    });
  }

  for (const font of data.fonts) {
    const ext = font.split(".").pop()?.split("?")[0]?.toLowerCase() || "woff2";
    assets.push({
      id: `asset-${idx++}`,
      url: font,
      type: "font",
      format: ext,
      size: "—",
      source: data.url,
      usedBy: [],
      status: "embed",
      embedded: false,
    });
  }

  for (const script of data.scripts) {
    const ext = script.split(".").pop()?.split("?")[0]?.toLowerCase() || "js";
    assets.push({
      id: `asset-${idx++}`,
      url: script,
      type: "script",
      format: ext,
      size: "—",
      source: data.url,
      usedBy: [],
      status: "remove",
      embedded: false,
    });
  }

  for (const css of data.stylesheets) {
    assets.push({
      id: `asset-${idx++}`,
      url: css,
      type: "stylesheet",
      format: "css",
      size: "—",
      source: data.url,
      usedBy: [],
      status: "keep",
      embedded: false,
    });
  }

  return assets.slice(0, 150);
}

export function createPageData(
  data: FetchedData,
  components: VisualComponent[],
  assets: AssetItem[]
): PageData {
  return {
    id: `page-${Date.now()}`,
    url: data.url,
    title: data.title,
    html: data.cleanedHtml || data.html,
    components,
    assets,
    status: "ready",
  };
}
