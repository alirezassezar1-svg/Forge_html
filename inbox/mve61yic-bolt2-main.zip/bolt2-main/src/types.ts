export type ViewportSize = {
  label: string;
  width: number;
  height: number;
  icon: string;
};

export type ComponentType =
  | "HEADER"
  | "NAVIGATION"
  | "HERO"
  | "TEXT_BLOCK"
  | "IMAGE"
  | "VIDEO"
  | "CARD"
  | "GRID"
  | "BUTTON"
  | "CTA"
  | "SECTION"
  | "FOOTER"
  | "MODAL"
  | "OVERLAY"
  | "BACKGROUND"
  | "DECORATIVE"
  | "CANVAS"
  | "WEBGL"
  | "FORM"
  | "LIST";

export interface VisualComponent {
  id: string;
  type: ComponentType;
  tag: string;
  selector: string;
  position: { x: number; y: number };
  width: number;
  height: number;
  margin: { top: number; right: number; bottom: number; left: number };
  padding: { top: number; right: number; bottom: number; left: number };
  typography: {
    fontFamily: string;
    fontSize: string;
    fontWeight: string;
    lineHeight: string;
    letterSpacing: string;
    color: string;
    textAlign: string;
  };
  background: string;
  borderRadius: string;
  border: string;
  boxShadow: string;
  opacity: number;
  transform: string;
  animation: string;
  zIndex: number;
  display: string;
  flexDirection: string;
  alignItems: string;
  justifyContent: string;
  gap: string;
  children: string[];
  textContent: string;
  placeholder: string;
  responsive: {
    mobile: string;
    tablet: string;
    desktop: string;
  };
}

export interface AssetItem {
  id: string;
  url: string;
  type: "image" | "video" | "font" | "script" | "stylesheet" | "svg";
  format: string;
  size: string;
  source: string;
  usedBy: string[];
  status: "keep" | "replace" | "remove" | "placeholder" | "embed";
  embedded: boolean;
}

export interface ContentMapping {
  id: string;
  componentId: string;
  original: string;
  replacement: string;
  type: "text" | "image" | "logo" | "link" | "color" | "font";
}

export interface PageData {
  id: string;
  url: string;
  title: string;
  html: string;
  components: VisualComponent[];
  assets: AssetItem[];
  status: "pending" | "analyzing" | "ready" | "error";
  screenshot?: string;
}

export interface ReconstructionScore {
  visual: number;
  layout: number;
  typography: number;
  animation: number;
  responsive: number;
  overall: number;
}

export type ProjectMode = "reference" | "reconstruction";

export type ProjectStatus = "analyzing" | "ready" | "error" | "draft";

export interface Project {
  id: string;
  name: string;
  source_url: string;
  status: ProjectStatus;
  mode: ProjectMode;
  pages: PageData[];
  components: VisualComponent[];
  assets: AssetItem[];
  content_map: ContentMapping[];
  generated_html: string;
  reconstruction_score: ReconstructionScore;
  last_modified: string;
  created_at: string;
}

export type AppView =
  | "dashboard"
  | "analyzing"
  | "workspace"
  | "editor"
  | "assets"
  | "pages"
  | "export"
  | "difference";

export type MobileTab = "projects" | "capture" | "editor" | "assets" | "export";

export interface AnalysisStep {
  id: string;
  label: string;
  status: "pending" | "active" | "done" | "error";
  detail?: string;
}

export const VIEWPORT_SIZES: ViewportSize[] = [
  { label: "Mobile S", width: 375, height: 812, icon: "smartphone" },
  { label: "Mobile M", width: 390, height: 844, icon: "smartphone" },
  { label: "Mobile L", width: 430, height: 932, icon: "smartphone" },
  { label: "Tablet", width: 768, height: 1024, icon: "tablet" },
  { label: "Laptop", width: 1024, height: 768, icon: "laptop" },
  { label: "Desktop", width: 1280, height: 800, icon: "monitor" },
  { label: "Desktop L", width: 1440, height: 900, icon: "monitor" },
  { label: "Desktop XL", width: 1920, height: 1080, icon: "monitor" },
];

export const ANALYSIS_STEPS: Omit<AnalysisStep, "status">[] = [
  { id: "launch", label: "Launching Browser", detail: "Spinning up Chromium engine" },
  { id: "render", label: "Rendering Page", detail: "Loading DOM and executing scripts" },
  { id: "dom", label: "Analyzing DOM", detail: "Traversing element tree" },
  { id: "styles", label: "Analyzing Styles", detail: "Extracting computed CSS" },
  { id: "components", label: "Detecting Components", detail: "Identifying visual patterns" },
  { id: "assets", label: "Processing Assets", detail: "Cataloging images, fonts, media" },
  { id: "interactions", label: "Reconstructing Interactions", detail: "Detecting hover, scroll, animation" },
  { id: "generate", label: "Generating HTML", detail: "Building reconstruction" },
  { id: "optimize", label: "Optimizing", detail: "Cleaning and compressing" },
  { id: "ready", label: "Ready", detail: "Project complete" },
];

export const COMPONENT_COLORS: Record<ComponentType, string> = {
  HEADER: "#3b82f6",
  NAVIGATION: "#06b6d4",
  HERO: "#8b5cf6",
  TEXT_BLOCK: "#64748b",
  IMAGE: "#10b981",
  VIDEO: "#f59e0b",
  CARD: "#ec4899",
  GRID: "#14b8a6",
  BUTTON: "#ef4444",
  CTA: "#f97316",
  SECTION: "#6366f1",
  FOOTER: "#475569",
  MODAL: "#a855f7",
  OVERLAY: "#d946ef",
  BACKGROUND: "#1e293b",
  DECORATIVE: "#f43f5e",
  CANVAS: "#84cc16",
  WEBGL: "#eab308",
  FORM: "#0ea5e9",
  LIST: "#22d3ee",
};

export const PLACEHOLDER_TEXTS = {
  h1: "YOUR MAIN HEADLINE",
  h2: "YOUR SECTION TITLE",
  h3: "YOUR SUBTITLE",
  p: "YOUR DESCRIPTION GOES HERE. REPLACE THIS TEXT WITH YOUR OWN CONTENT TO TELL YOUR BRAND STORY.",
  span: "YOUR TEXT",
  a: "YOUR LINK",
  button: "YOUR BUTTON",
  logo: "YOUR LOGO",
  brand: "YOUR BRAND",
  cta: "GET STARTED",
  tagline: "DIGITAL EXPERIENCE",
  description: "YOUR DESCRIPTION",
  nav: ["HOME", "ABOUT", "SERVICES", "WORK", "BLOG", "CONTACT"],
};
