import { useState, useEffect } from "react";
import { Dashboard } from "@/components/Dashboard";
import { AnalyzingView } from "@/components/AnalyzingView";
import { Workspace } from "@/components/Workspace";
import { MobileNav } from "@/components/MobileNav";
import type { Project, AppView, MobileTab } from "@/types";

function App() {
  const [view, setView] = useState<AppView>("dashboard");
  const [currentUrl, setCurrentUrl] = useState("");
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [mobileTab, setMobileTab] = useState<MobileTab>("projects");

  const handleAnalyze = (url: string) => {
    setCurrentUrl(url);
    setView("analyzing");
  };

  const handleAnalysisComplete = (project: Project) => {
    setCurrentProject(project);
    setView("workspace");
  };

  const handleOpenProject = (project: Project) => {
    setCurrentProject(project);
    setView("workspace");
  };

  const handleBack = () => {
    setView("dashboard");
    setCurrentProject(null);
  };

  const handleProjectUpdate = (project: Project) => {
    setCurrentProject(project);
  };

  if (view === "dashboard") {
    return (
      <>
        <Dashboard onAnalyze={handleAnalyze} onOpenProject={handleOpenProject} />
        <MobileNav active={mobileTab} onChange={setMobileTab} />
      </>
    );
  }

  if (view === "analyzing") {
    return (
      <AnalyzingView
        url={currentUrl}
        onComplete={handleAnalysisComplete}
        onCancel={handleBack}
      />
    );
  }

  if (view === "workspace" && currentProject) {
    return (
      <>
        <Workspace
          project={currentProject}
          onBack={handleBack}
          onUpdate={handleProjectUpdate}
        />
      </>
    );
  }

  return <Dashboard onAnalyze={handleAnalyze} onOpenProject={handleOpenProject} />;
}

export default App;
