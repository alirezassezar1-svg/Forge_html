const glow = document.querySelector('.cursor-glow');
window.addEventListener('pointermove', (event) => {
  glow.style.left = `${event.clientX}px`;
  glow.style.top = `${event.clientY}px`;
});

const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => { if (entry.isIntersecting) entry.target.classList.add('visible'); });
}, { threshold: 0.14 });
document.querySelectorAll('.reveal').forEach((el) => revealObserver.observe(el));

const parallax = document.querySelectorAll('[data-speed]');
window.addEventListener('scroll', () => {
  const offset = window.scrollY;
  parallax.forEach((el) => { el.style.translate = `0 ${offset * Number(el.dataset.speed)}px`; });
}, { passive: true });
