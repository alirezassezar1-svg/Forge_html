"""Command line interface: `ali <command>` (or `python -m ali <command>`)."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from ali import __version__
from ali.backup import BackupError, create_backup, export_jsonl, restore_backup, verify_backup
from ali.citations import verify_citation
from ali.config import Settings
from ali.db import open_db
from ali.health import run_health
from ali.ingest import delete_document, gc_originals, ingest_path, ingest_url, recover_interrupted_jobs, reindex
from ali.library import get_document, list_documents, list_jobs, stats
from ali.search import MODES, search


def _p(obj: Any) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))


def _build() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="ali", description="ALI knowledge engine")
    ap.add_argument("--home", help="data directory (default: $ALI_HOME or ./ali_data)")
    ap.add_argument("--version", action="version", version=f"ali {__version__}")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init", help="create data directory and apply migrations")
    s = sub.add_parser("ingest", help="ingest files or directories"); s.add_argument("paths", nargs="+")
    s.add_argument("--key", help="explicit source key (single file only)")
    s = sub.add_parser("ingest-url", help="ingest public URLs"); s.add_argument("urls", nargs="+")
    s = sub.add_parser("search", help="search the knowledge base")
    s.add_argument("query"); s.add_argument("-n", "--limit", type=int, default=5)
    s.add_argument("--mode", choices=MODES, default="auto"); s.add_argument("--language")
    s.add_argument("--history", action="store_true", help="include superseded versions")
    s.add_argument("--json", action="store_true")
    sub.add_parser("list", help="list documents")
    s = sub.add_parser("show", help="show document details"); s.add_argument("document_id", type=int)
    s = sub.add_parser("verify", help="verify a citation JSON (file or '-' for stdin)")
    s.add_argument("citation"); s.add_argument("--deep", action="store_true")
    s = sub.add_parser("delete", help="delete a document and all derived data"); s.add_argument("document_id", type=int)
    sub.add_parser("jobs", help="show recent ingestion jobs")
    sub.add_parser("reindex", help="rebuild chunks and the FTS index from stored text")
    sub.add_parser("gc", help="remove unreferenced original files")
    sub.add_parser("stats", help="counts")
    s = sub.add_parser("health", help="health check (exit code 1 on error)"); s.add_argument("--deep", action="store_true")
    s = sub.add_parser("backup", help="create a backup archive"); s.add_argument("--out"); s.add_argument("--no-originals", action="store_true")
    s = sub.add_parser("verify-backup", help="verify a backup archive"); s.add_argument("archive")
    s = sub.add_parser("restore", help="restore a backup (stop the app first)"); s.add_argument("archive")
    s = sub.add_parser("export", help="export current knowledge as JSONL"); s.add_argument("out"); s.add_argument("--history", action="store_true")
    s = sub.add_parser("serve", help="run the web app")
    s.add_argument("--host", default="127.0.0.1"); s.add_argument("--port", type=int, default=8765)
    return ap


def _files(paths: list[str]) -> list[Path]:
    out: list[Path] = []
    for raw in paths:
        p = Path(raw).expanduser()
        if p.is_dir():
            out.extend(sorted(x for x in p.rglob("*") if x.is_file() and not x.name.startswith(".")))
        else:
            out.append(p)
    return out


def main(argv: list[str] | None = None) -> int:
    args = _build().parse_args(argv)
    settings = Settings.from_env(args.home)
    cmd = args.cmd
    if cmd == "health":
        report = run_health(settings, deep=args.deep)
        _p(report)
        return 0 if report["ok"] else 1
    if cmd == "verify-backup":
        try:
            m = verify_backup(Path(args.archive))
        except BackupError as exc:
            print(f"INVALID: {exc}", file=sys.stderr)
            return 1
        print(f"OK: {len(m['files'])} files, schema {m['schema_version']}, created {m['created_at']}")
        return 0
    if cmd == "restore":
        try:
            _p(restore_backup(settings, Path(args.archive)))
        except BackupError as exc:
            print(f"RESTORE FAILED (nothing was changed): {exc}", file=sys.stderr)
            return 1
        return 0
    if cmd == "serve":
        import ipaddress

        import uvicorn

        from ali.api import create_app
        try:
            loopback = ipaddress.ip_address(args.host).is_loopback
        except ValueError:
            loopback = args.host == "localhost"
        if not loopback and not settings.api_token:
            print("Refusing to listen on a non-loopback address without ALI_API_TOKEN set.", file=sys.stderr)
            return 2
        uvicorn.run(create_app(settings), host=args.host, port=args.port, log_level="info")
        return 0

    conn = open_db(settings)
    try:
        recover_interrupted_jobs(conn)
        if cmd == "init":
            _p({"home": str(settings.home), "stats": stats(conn)})
        elif cmd == "ingest":
            files = _files(args.paths)
            if args.key and len(files) != 1:
                print("--key requires exactly one file", file=sys.stderr)
                return 2
            bad = 0
            for f in files:
                r = ingest_path(conn, settings, f, source_key=args.key)
                bad += r.outcome == "failed"
                print(f"{r.outcome:<10} doc={r.document_id} v={r.version_no} chunks={r.n_chunks} {f}"
                      + (f"  ERROR: {r.error}" if r.error else "")
                      + (f"  (duplicate of doc {r.duplicate_of})" if r.duplicate_of else ""))
            return 1 if bad else 0
        elif cmd == "ingest-url":
            bad = 0
            for u in args.urls:
                r = ingest_url(conn, settings, u)
                bad += r.outcome == "failed"
                print(f"{r.outcome:<10} doc={r.document_id} v={r.version_no} chunks={r.n_chunks} {u}"
                      + (f"  ERROR: {r.error}" if r.error else ""))
            return 1 if bad else 0
        elif cmd == "search":
            res = search(conn, args.query, mode=args.mode, limit=args.limit,
                         filters={"language": args.language, "include_history": args.history})
            if args.json:
                _p(res)
            else:
                d = res["diagnostics"]
                print(f"{len(res['hits'])} result(s)  [mode={d['mode_used']}{' (fallback)' if d['fallback_used'] else ''}, "
                      f"{d['latency_ms']} ms]")
                for h in res["hits"]:
                    c = h["citation"]
                    snippet = " ".join(h["text"].split())[:220]
                    print(f"\n#{h['rank']}  {h['title']}  [{h['publisher']}]  {h['locator']}  bm25={h['signals']['bm25']}"
                          f"{'' if h['is_current'] else '  (HISTORICAL v' + str(h['version_no']) + ')'}")
                    print(f"    cite: doc={c['document_id']} v{c['version_no']} chars {c['start_char']}-{c['end_char']}  {c['url'] or c['source_key']}")
                    print(f"    {snippet}")
        elif cmd == "list":
            for d in list_documents(conn, limit=1000):
                print(f"{d['id']:>4}  v{d['version_no']}  {d['extraction_status']:<9} {d['language'] or '-':<8} "
                      f"{d['n_chunks']:>4} chunks  {d['title']}  <{d['source_key']}>")
        elif cmd == "show":
            doc = get_document(conn, args.document_id)
            if not doc:
                print("not found", file=sys.stderr)
                return 1
            _p(doc)
        elif cmd == "verify":
            raw = sys.stdin.read() if args.citation == "-" else Path(args.citation).read_text(encoding="utf-8")
            obj = json.loads(raw)
            cit = obj.get("citation", obj) if isinstance(obj, dict) else obj
            res = verify_citation(conn, settings, cit, deep=args.deep)
            _p(res)
            return 0 if res["ok"] else 1
        elif cmd == "delete":
            _p(delete_document(conn, settings, args.document_id))
        elif cmd == "jobs":
            for j in list_jobs(conn, 30):
                print(f"{j['id']:>4} {j['status']:<11} {j['outcome'] or '-':<10} {j['kind']:<4} {j['input_ref']}"
                      + (f"  ! {j['error_message']}" if j['error_message'] else ""))
        elif cmd == "reindex":
            _p(reindex(conn, settings))
        elif cmd == "gc":
            _p({"removed": gc_originals(conn, settings)})
        elif cmd == "stats":
            _p(stats(conn))
        elif cmd == "backup":
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            out = create_backup(settings, Path(args.out) if args.out else None, include_originals=not args.no_originals)
            print(out)
        elif cmd == "export":
            print(f"exported {export_jsonl(conn, Path(args.out), args.history)} version(s) to {args.out}")
    finally:
        conn.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
