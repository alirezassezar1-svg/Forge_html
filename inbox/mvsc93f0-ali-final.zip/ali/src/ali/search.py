"""Lexical search: exact phrase, BM25 keyword search, metadata filters, de-duplication, diagnostics.

Signals are kept separate and inspectable per hit:
  bm25  - SQLite FTS5 BM25 score (sign flipped so higher is better); raw, un-normalised, comparable
          only within one query. No cross-signal fusion happens in Milestone 1 (single lexical signal);
          Reciprocal Rank Fusion is introduced together with the semantic signal in Milestone 2.
"""

from __future__ import annotations

import json
import re
import sqlite3
import time
from dataclasses import dataclass
from typing import Any

from ali import hashing, textnorm
from ali.citations import build_citation
from ali.db import utcnow

_QUOTE_RE = re.compile(r'["“«]([^"”»]+)["”»]')
MODES = ("auto", "phrase", "all", "any")


@dataclass
class ParsedQuery:
    phrases: list[list[str]]
    terms: list[str]

    @property
    def all_tokens(self) -> list[str]:
        out: list[str] = []
        for p in self.phrases:
            out.extend(p)
        out.extend(self.terms)
        return out


def parse_query(q: str) -> ParsedQuery:
    phrases: list[list[str]] = []

    def grab(m: re.Match[str]) -> str:
        toks = textnorm.tokenize(textnorm.normalize(m.group(1)))
        if toks:
            phrases.append(toks)
        return " "

    rest = _QUOTE_RE.sub(grab, q)
    terms = textnorm.tokenize(textnorm.normalize(rest))
    return ParsedQuery(phrases, terms)


def build_fts_query(pq: ParsedQuery, mode: str) -> str:
    def quoted(tokens: list[str]) -> str:
        return '"' + " ".join(tokens) + '"'

    if mode == "phrase":
        return quoted(pq.all_tokens)
    parts = [quoted(p) for p in pq.phrases] + [quoted([t]) for t in pq.terms]
    return (" OR " if mode == "any" else " ").join(parts)


def find_spans(text: str, pq: ParsedQuery, mode: str) -> list[list[int]]:
    """Match offsets (relative to `text`), mapped back to the ORIGINAL text through the normaliser's offset map."""
    toks = textnorm.token_spans(textnorm.normalize_with_map(text))  # (token, orig_start, orig_end)
    names = [t[0] for t in toks]
    spans: list[tuple[int, int]] = []
    phrase_lists = [pq.all_tokens] if mode == "phrase" else pq.phrases
    for p in phrase_lists:
        n = len(p)
        for i in range(len(toks) - n + 1):
            if names[i:i + n] == p:
                spans.append((toks[i][1], toks[i + n - 1][2]))
    if mode != "phrase":
        wanted = set(pq.terms)
        for p in pq.phrases:
            wanted.update(p)
        spans.extend((s, e) for tok, s, e in toks if tok in wanted)
    out: list[list[int]] = []
    for s, e in sorted(spans):
        if out and s <= out[-1][1]:
            out[-1][1] = max(out[-1][1], e)
        else:
            out.append([s, e])
    return out


_SQL = """
SELECT c.id AS chunk_id, c.document_id, c.version_id, c.ordinal, c.start_char, c.end_char, c.page_start,
       c.locator, c.text, c.text_norm, bm25(chunks_fts) AS bm25,
       v.version_no, v.is_current, v.content_hash, v.text_hash, v.language, v.retrieved_at, v.published_at,
       v.url AS version_url, v.extraction_status,
       d.title, d.canonical_url, d.source_key, d.kind, p.name AS publisher
FROM chunks_fts
JOIN chunks c ON c.id = chunks_fts.rowid
JOIN document_versions v ON v.id = c.version_id
JOIN documents d ON d.id = c.document_id
LEFT JOIN publishers p ON p.id = d.publisher_id
WHERE chunks_fts MATCH ?
"""


def _run(conn: sqlite3.Connection, fts_query: str, filters: dict[str, Any], fetch: int) -> list[sqlite3.Row]:
    sql, params = _SQL, [fts_query]
    if not filters.get("include_history"):
        sql += " AND v.is_current = 1"
    if filters.get("language"):
        sql += " AND v.language = ?"
        params.append(filters["language"])
    if filters.get("publisher"):
        sql += " AND (p.key = ? OR p.name = ?)"
        params += [filters["publisher"], filters["publisher"]]
    if filters.get("kind"):
        sql += " AND d.kind = ?"
        params.append(filters["kind"])
    if filters.get("document_id"):
        sql += " AND d.id = ?"
        params.append(int(filters["document_id"]))
    if filters.get("published_after"):
        sql += " AND v.published_at >= ?"
        params.append(filters["published_after"])
    if filters.get("published_before"):
        sql += " AND v.published_at <= ?"
        params.append(filters["published_before"])
    sql += " ORDER BY bm25(chunks_fts), c.id LIMIT ?"
    params.append(fetch)
    return conn.execute(sql, params).fetchall()


def search(
    conn: sqlite3.Connection,
    q: str,
    *,
    mode: str = "auto",
    limit: int = 10,
    filters: dict[str, Any] | None = None,
    max_per_document: int | None = None,
    log: bool = True,
) -> dict[str, Any]:
    if mode not in MODES:
        raise ValueError(f"mode must be one of {MODES}")
    filters = {k: v for k, v in (filters or {}).items() if v not in (None, "", False)}
    pq = parse_query(q)
    if not pq.all_tokens:
        raise ValueError("query has no searchable terms")
    t0 = time.perf_counter()
    limit = max(1, min(int(limit), 100))
    fetch = max(limit * 5, 50)
    mode_used = "phrase" if mode == "phrase" else ("any" if mode == "any" else "all")
    fallback = False
    fts_q = build_fts_query(pq, mode_used)
    rows = _run(conn, fts_q, filters, fetch)
    if not rows and mode == "auto" and len(pq.phrases) + len(pq.terms) > 1:
        mode_used, fallback = "any", True
        fts_q = build_fts_query(pq, mode_used)
        rows = _run(conn, fts_q, filters, fetch)
    candidates = len(rows)

    hits: list[dict[str, Any]] = []
    seen_text: dict[str, dict[str, Any]] = {}
    per_doc: dict[int, int] = {}
    for r in rows:
        norm_key = hashing.sha256_text(r["text_norm"])
        if norm_key in seen_text:  # identical passage already returned (e.g. mirrored boilerplate)
            seen_text[norm_key]["also_in"].append(
                {"document_id": r["document_id"], "title": r["title"], "chunk_id": r["chunk_id"]})
            continue
        if max_per_document and per_doc.get(r["document_id"], 0) >= max_per_document:
            continue
        if len(hits) >= limit:
            break
        per_doc[r["document_id"]] = per_doc.get(r["document_id"], 0) + 1
        spans = find_spans(r["text"], pq, mode_used)
        hit = {
            "rank": len(hits) + 1,
            "chunk_id": r["chunk_id"], "document_id": r["document_id"], "version_id": r["version_id"],
            "version_no": r["version_no"], "is_current": bool(r["is_current"]),
            "title": r["title"], "publisher": r["publisher"], "source_key": r["source_key"],
            "url": r["version_url"] or r["canonical_url"], "language": r["language"], "kind": r["kind"],
            "locator": r["locator"], "page": r["page_start"],
            "start_char": r["start_char"], "end_char": r["end_char"],
            "text": r["text"], "highlights": spans,
            "signals": {"bm25": round(-float(r["bm25"]), 6)},
            "extraction_status": r["extraction_status"],
            "also_in": [],
            "citation": build_citation(r, spans, sorted(set(pq.all_tokens))),
        }
        seen_text[norm_key] = hit
        hits.append(hit)

    latency = (time.perf_counter() - t0) * 1000
    diag = {"fts_query": fts_q, "mode_requested": mode, "mode_used": mode_used, "fallback_used": fallback,
            "candidates": candidates, "returned": len(hits), "latency_ms": round(latency, 3), "filters": filters,
            "ranking": "bm25 (SQLite FTS5), higher is better; raw scores comparable within this query only"}
    if log:
        conn.execute(
            "INSERT INTO query_log(ts, query, fts_query, mode_requested, mode_used, filters, n_results, latency_ms, "
            "fallback_used, diagnostics) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (utcnow(), q[:1000], fts_q, mode, mode_used, json.dumps(filters), len(hits), latency, int(fallback),
             json.dumps(diag)))
    return {"query": q, "hits": hits, "diagnostics": diag}
