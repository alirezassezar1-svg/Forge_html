from ali.cli import main

raise SystemExit(main())
