"""Outbound-network safety: SSRF protection with validation at connect time.

Design: instead of validating a hostname and then letting the HTTP client resolve it again (which
allows DNS rebinding), the guard owns resolution. A custom httpcore network backend resolves the
host, rejects the connection if ANY resolved address is non-public, and connects to the validated IP
literal. TLS SNI / certificate checks still use the original hostname. Redirects are followed
manually by the fetcher so every hop's scheme/port is re-checked and every connection goes through
this backend again.
"""

from __future__ import annotations

import ipaddress
import socket
from urllib.parse import urlsplit

import httpcore


class BlockedDestination(Exception):
    """Raised when a URL or resolved address is not allowed."""


_EXTRA_BLOCKED = [
    ipaddress.ip_network("100.64.0.0/10"),  # carrier-grade NAT (not covered by is_private)
    ipaddress.ip_network("192.0.0.0/24"),
    ipaddress.ip_network("198.18.0.0/15"),
    ipaddress.ip_network("64:ff9b::/96"),   # NAT64 can embed private v4 addresses
    ipaddress.ip_network("2002::/16"),      # 6to4
]


def is_public_ip(ip: str) -> bool:
    addr = ipaddress.ip_address(ip)
    if isinstance(addr, ipaddress.IPv6Address):
        if addr.ipv4_mapped is not None:
            addr = addr.ipv4_mapped
    if (
        addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_multicast
        or addr.is_reserved or addr.is_unspecified or not addr.is_global
    ):
        return False
    return not any(addr in net for net in _EXTRA_BLOCKED if addr.version == net.version)


def validate_url_shape(url: str, allowed_ports: tuple[int, ...]) -> tuple[str, str, int]:
    """Cheap, DNS-free checks. Returns (scheme, host, port)."""
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https"):
        raise BlockedDestination(f"unsupported scheme: {parts.scheme or '(none)'}")
    if not parts.hostname:
        raise BlockedDestination("URL has no host")
    if parts.username or parts.password:
        raise BlockedDestination("credentials in URL are not allowed")
    try:
        port = parts.port or (443 if parts.scheme == "https" else 80)
    except ValueError as exc:
        raise BlockedDestination("invalid port") from exc
    if allowed_ports and port not in allowed_ports:
        raise BlockedDestination(f"port {port} is not allowed")
    return parts.scheme, parts.hostname, port


def resolve_public(host: str, port: int, allow_private: bool = False, resolver=None) -> list[str]:
    """Resolve host; raise unless every address is public (or allow_private is set)."""
    try:
        ipaddress.ip_address(host)
        addrs = [host]
    except ValueError:
        infos = (resolver or socket.getaddrinfo)(host, port, type=socket.SOCK_STREAM)
        addrs = []
        for info in infos:
            ip = info[4][0].split("%", 1)[0]
            if ip not in addrs:
                addrs.append(ip)
    if not addrs:
        raise BlockedDestination(f"{host} did not resolve")
    if not allow_private:
        for ip in addrs:
            if not is_public_ip(ip):
                raise BlockedDestination(f"{host} resolves to a non-public address ({ip})")
    return addrs


class GuardedBackend(httpcore.SyncBackend):
    """httpcore backend that validates the resolved IPs and connects to the validated literal."""

    def __init__(self, allow_private: bool = False, resolver=None):
        super().__init__()
        self.allow_private = allow_private
        self.resolver = resolver

    def connect_tcp(self, host, port, timeout=None, local_address=None, socket_options=None):
        addrs = resolve_public(host, port, self.allow_private, self.resolver)
        last_exc: Exception | None = None
        for ip in addrs:
            try:
                return super().connect_tcp(ip, port, timeout, local_address, socket_options)
            except Exception as exc:  # noqa: BLE001 - try next address
                last_exc = exc
        if last_exc is None:
            raise BlockedDestination(f"{host} has no usable address")
        raise last_exc
