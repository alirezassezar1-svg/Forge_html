"""Configuration. Plain dataclass + environment variables (no extra dependency needed)."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def _env_int(name: str, default: int) -> int:
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    try:
        return int(raw)
    except ValueError as exc:
        raise ValueError(f"environment variable {name} must be an integer, got {raw!r}") from exc


def _env_bool(name: str, default: bool) -> bool:
    raw = os.environ.get(name)
    if raw is None or raw == "":
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    home: Path
    chunk_max_chars: int = 1200
    chunk_overlap_chars: int = 150
    max_upload_bytes: int = 50 * 1024 * 1024
    max_download_bytes: int = 25 * 1024 * 1024
    max_pdf_pages: int = 2000
    max_redirects: int = 5
    fetch_timeout: float = 20.0
    allowed_ports: tuple[int, ...] = (80, 443)
    # Security-relevant: default False. Only tests / explicit local setups may enable it.
    allow_private_networks: bool = False
    respect_robots: bool = True
    user_agent: str = "ALI-KnowledgeEngine/0.1 (+personal research; contact: owner)"
    api_token: str | None = field(default=None, repr=False)  # never printed

    @property
    def db_path(self) -> Path:
        return self.home / "ali.db"

    @property
    def originals_dir(self) -> Path:
        return self.home / "originals"

    @property
    def backups_dir(self) -> Path:
        return self.home / "backups"

    def ensure_dirs(self) -> None:
        for d in (self.home, self.originals_dir, self.backups_dir):
            d.mkdir(parents=True, exist_ok=True)

    @classmethod
    def from_env(cls, home: str | os.PathLike[str] | None = None) -> Settings:
        base = Path(home or os.environ.get("ALI_HOME") or "ali_data").expanduser().resolve()
        return cls(
            home=base,
            chunk_max_chars=_env_int("ALI_CHUNK_MAX_CHARS", 1200),
            chunk_overlap_chars=_env_int("ALI_CHUNK_OVERLAP_CHARS", 150),
            max_upload_bytes=_env_int("ALI_MAX_UPLOAD_BYTES", 50 * 1024 * 1024),
            max_download_bytes=_env_int("ALI_MAX_DOWNLOAD_BYTES", 25 * 1024 * 1024),
            max_pdf_pages=_env_int("ALI_MAX_PDF_PAGES", 2000),
            allow_private_networks=_env_bool("ALI_ALLOW_PRIVATE_NETWORKS", False),
            respect_robots=_env_bool("ALI_RESPECT_ROBOTS", True),
            api_token=os.environ.get("ALI_API_TOKEN") or None,
        )
