"""Deterministic, offset-preserving chunking.

Invariants (enforced by tests): for every chunk `text[start:end]` is the chunk text exactly; chunks lie
inside one segment (page); every non-whitespace character is covered by at least one chunk;
no chunk exceeds `max_chars`.
"""

from __future__ import annotations

import bisect
import re
from dataclasses import dataclass

_SENT_RE = re.compile(r"(?<=[.!?؟۔…])\s+")
_LINE_RE = re.compile(r"[^\n]+")


@dataclass(frozen=True)
class RawChunk:
    start: int
    end: int
    page: int | None
    locator: str


def _split_oversized(text: str, s: int, e: int, max_chars: int) -> list[tuple[int, int]]:
    """Split [s,e) (no newlines) into pieces <= max_chars, preferring sentence then whitespace boundaries."""
    if e - s <= max_chars:
        return [(s, e)]
    pieces: list[tuple[int, int]] = []
    pos = s
    for m in _SENT_RE.finditer(text, s, e):
        if m.start() > pos:
            pieces.append((pos, m.start()))
        pos = m.end()
    if pos < e:
        pieces.append((pos, e))
    final: list[tuple[int, int]] = []
    for ps, pe in pieces:
        while pe - ps > max_chars:
            cut = text.rfind(" ", ps + 1, ps + max_chars + 1)
            if cut <= ps:  # no space: hard split (e.g. very long token)
                cut = ps + max_chars
            final.append((ps, cut))
            ps = cut
            while ps < pe and text[ps].isspace():
                ps += 1
        if pe > ps:
            final.append((ps, pe))
    return final


def _units(text: str, seg_start: int, seg_end: int, max_chars: int) -> list[tuple[int, int]]:
    units: list[tuple[int, int]] = []
    for m in _LINE_RE.finditer(text, seg_start, seg_end):
        s, e = m.start(), m.end()
        while s < e and text[s].isspace():
            s += 1
        while e > s and text[e - 1].isspace():
            e -= 1
        if e > s:
            units.extend(_split_oversized(text, s, e, max_chars))
    return units


def chunk_text(
    text: str,
    max_chars: int = 1200,
    overlap_chars: int = 150,
    segments: list[tuple[int, int, int | None]] | None = None,
) -> list[RawChunk]:
    if max_chars < 50:
        raise ValueError("max_chars must be >= 50")
    if not 0 <= overlap_chars < max_chars // 2:
        raise ValueError("overlap_chars must be >= 0 and < max_chars/2")
    segs = segments or [(0, len(text), None)]
    nl = [i for i, ch in enumerate(text) if ch == "\n"]

    def line_no(offset: int) -> int:
        return bisect.bisect_left(nl, offset) + 1

    chunks: list[RawChunk] = []
    for seg_start, seg_end, page in segs:
        units = _units(text, seg_start, seg_end, max_chars)
        i = 0
        n = len(units)
        while i < n:
            start = units[i][0]
            j = i
            while j + 1 < n and units[j + 1][1] - start <= max_chars:
                j += 1
            end = units[j][1]
            if page is not None:
                locator = f"page {page}"
            else:
                a, b = line_no(start), line_no(end - 1)
                locator = f"line {a}" if a == b else f"lines {a}-{b}"
            chunks.append(RawChunk(start, end, page, locator))
            if j + 1 >= n:
                break
            nxt = j + 1
            k = j
            while k > i and end - units[k][0] <= overlap_chars:
                nxt = k
                k -= 1
            i = max(nxt, i + 1)
    return chunks
