"""Read-side helpers for the document library, passages, jobs and statistics."""

from __future__ import annotations

import json
import sqlite3
from typing import Any


def _doc_row(r: sqlite3.Row) -> dict[str, Any]:
    return {k: r[k] for k in r.keys()}


def list_documents(conn: sqlite3.Connection, limit: int = 100, offset: int = 0) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT d.id, d.source_key, d.kind, d.title, d.canonical_url, d.created_at, d.updated_at, p.name AS publisher, "
        "v.id AS version_id, v.version_no, v.language, v.adapter, v.extraction_status, v.extraction_quality, "
        "v.retrieved_at, v.published_at, v.original_size, "
        "(SELECT COUNT(*) FROM chunks c WHERE c.version_id = v.id) AS n_chunks, "
        "(SELECT COUNT(*) FROM document_versions x WHERE x.document_id = d.id) AS n_versions, "
        "(SELECT COUNT(*) FROM document_aliases a WHERE a.document_id = d.id) AS n_aliases "
        "FROM documents d LEFT JOIN publishers p ON p.id = d.publisher_id "
        "JOIN document_versions v ON v.document_id = d.id AND v.is_current = 1 "
        "ORDER BY d.updated_at DESC, d.id DESC LIMIT ? OFFSET ?", (limit, offset)).fetchall()
    return [_doc_row(r) for r in rows]


def get_document(conn: sqlite3.Connection, document_id: int) -> dict[str, Any] | None:
    d = conn.execute(
        "SELECT d.*, p.name AS publisher FROM documents d LEFT JOIN publishers p ON p.id=d.publisher_id WHERE d.id=?",
        (document_id,)).fetchone()
    if not d:
        return None
    versions = conn.execute(
        "SELECT id, version_no, is_current, content_hash, text_hash, original_filename, original_size, adapter, url, "
        "http_status, retrieved_at, language, language_confidence, title, author, published_at, extraction_status, "
        "extraction_quality, extraction_warnings, metadata, created_at, superseded_at, LENGTH(text) AS text_length, "
        "(SELECT COUNT(*) FROM chunks c WHERE c.version_id = document_versions.id) AS n_chunks "
        "FROM document_versions WHERE document_id=? ORDER BY version_no DESC", (document_id,)).fetchall()
    out = _doc_row(d)
    out["versions"] = []
    for v in versions:
        vd = _doc_row(v)
        vd["extraction_warnings"] = json.loads(vd["extraction_warnings"] or "[]")
        vd["metadata"] = json.loads(vd["metadata"] or "{}")
        out["versions"].append(vd)
    out["aliases"] = [_doc_row(a) for a in conn.execute(
        "SELECT source_key, first_seen, last_seen FROM document_aliases WHERE document_id=?", (document_id,))]
    out["links"] = [_doc_row(link) for link in conn.execute(
        "SELECT l.target_url, l.target_host, l.anchor_text, l.is_external, l.in_content FROM links l "
        "JOIN document_versions v ON v.id=l.version_id AND v.is_current=1 WHERE l.document_id=? LIMIT 200",
        (document_id,))]
    return out


def get_passage(conn: sqlite3.Connection, version_id: int, start: int, end: int, context: int = 300) -> dict[str, Any] | None:
    v = conn.execute(
        "SELECT v.id, v.document_id, v.version_no, v.is_current, v.text, v.content_hash, v.retrieved_at, d.title, d.source_key "
        "FROM document_versions v JOIN documents d ON d.id=v.document_id WHERE v.id=?", (version_id,)).fetchone()
    if not v:
        return None
    n = len(v["text"])
    start = max(0, min(start, n))
    end = max(start, min(end, n))
    ctx = max(0, min(context, 5000))
    bs, be = max(0, start - ctx), min(n, end + ctx)
    return {
        "document_id": v["document_id"], "version_id": v["id"], "version_no": v["version_no"],
        "is_current": bool(v["is_current"]), "title": v["title"], "source_key": v["source_key"],
        "content_hash": v["content_hash"], "retrieved_at": v["retrieved_at"],
        "before": v["text"][bs:start], "passage": v["text"][start:end], "after": v["text"][end:be],
        "start_char": start, "end_char": end,
    }


def list_jobs(conn: sqlite3.Connection, limit: int = 50) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM ingestion_jobs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    out = []
    for r in rows:
        d = _doc_row(r)
        d["detail"] = json.loads(d["detail"] or "{}")
        d["errors"] = [_doc_row(e) for e in conn.execute(
            "SELECT stage, error_type, message, created_at FROM ingestion_errors WHERE job_id=? ORDER BY id", (r["id"],))]
        out.append(d)
    return out


def stats(conn: sqlite3.Connection) -> dict[str, Any]:
    q = lambda sql: conn.execute(sql).fetchone()[0]  # noqa: E731
    return {
        "documents": q("SELECT COUNT(*) FROM documents"),
        "versions": q("SELECT COUNT(*) FROM document_versions"),
        "current_versions": q("SELECT COUNT(*) FROM document_versions WHERE is_current=1"),
        "chunks": q("SELECT COUNT(*) FROM chunks"),
        "links": q("SELECT COUNT(*) FROM links"),
        "aliases": q("SELECT COUNT(*) FROM document_aliases"),
        "jobs": q("SELECT COUNT(*) FROM ingestion_jobs"),
        "queries_logged": q("SELECT COUNT(*) FROM query_log"),
    }
