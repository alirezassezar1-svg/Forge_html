-- ALI schema, migration 0001: core knowledge store (Milestone 1).
-- The database is the authoritative record. chunks/chunks_fts are derived and rebuildable
-- from document_versions.text (see `ali reindex`).
-- Later milestones add: entities/relationships, source_features, embeddings (separate migrations).

CREATE TABLE publishers (
    id          INTEGER PRIMARY KEY,
    key         TEXT NOT NULL UNIQUE,          -- host for web sources, 'local' for uploads
    name        TEXT NOT NULL,
    created_at  TEXT NOT NULL
);

CREATE TABLE documents (
    id            INTEGER PRIMARY KEY,
    source_key    TEXT NOT NULL UNIQUE,        -- canonical URL, or 'file:<path-or-name>' / user-supplied key
    kind          TEXT NOT NULL CHECK (kind IN ('file','url')),
    publisher_id  INTEGER REFERENCES publishers(id) ON DELETE SET NULL,
    title         TEXT,
    canonical_url TEXT,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);

-- Other source keys known to carry byte-identical content (syndication / mirrors / re-uploads).
CREATE TABLE document_aliases (
    id           INTEGER PRIMARY KEY,
    document_id  INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    source_key   TEXT NOT NULL UNIQUE,
    content_hash TEXT NOT NULL,
    first_seen   TEXT NOT NULL,
    last_seen    TEXT NOT NULL
);

CREATE TABLE document_versions (
    id                  INTEGER PRIMARY KEY,
    document_id         INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    version_no          INTEGER NOT NULL,
    is_current          INTEGER NOT NULL CHECK (is_current IN (0,1)),
    content_hash        TEXT NOT NULL,         -- sha256 of the original bytes
    text_hash           TEXT NOT NULL,         -- sha256 of the extracted text (UTF-8)
    original_filename   TEXT,
    original_path       TEXT,                  -- relative to originals dir (content addressed)
    original_size       INTEGER NOT NULL,
    media_type          TEXT,
    adapter             TEXT NOT NULL,         -- txt, md, csv, json, html, pdf
    url                 TEXT,                  -- final URL actually fetched (after redirects)
    http_status         INTEGER,
    retrieved_at        TEXT NOT NULL,
    language            TEXT,
    language_confidence REAL,
    title               TEXT,
    author              TEXT,
    published_at        TEXT,
    extraction_status   TEXT NOT NULL CHECK (extraction_status IN ('ok','partial','failed','needs_ocr')),
    extraction_quality  REAL,                  -- heuristic 0..1, see docs/ARCHITECTURE.md
    extraction_warnings TEXT NOT NULL DEFAULT '[]',   -- JSON array of strings
    text                TEXT NOT NULL,         -- extracted text; citation offsets refer to this
    page_spans          TEXT,                  -- JSON [[start,end,page],...] for paged formats
    metadata            TEXT NOT NULL DEFAULT '{}',   -- JSON
    created_at          TEXT NOT NULL,
    superseded_at       TEXT,
    UNIQUE (document_id, version_no)
);
CREATE UNIQUE INDEX uq_one_current_version ON document_versions(document_id) WHERE is_current = 1;
CREATE INDEX idx_versions_hash ON document_versions(content_hash);

CREATE TABLE chunks (
    id          INTEGER PRIMARY KEY,
    version_id  INTEGER NOT NULL REFERENCES document_versions(id) ON DELETE CASCADE,
    document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    ordinal     INTEGER NOT NULL,
    start_char  INTEGER NOT NULL,
    end_char    INTEGER NOT NULL,
    page_start  INTEGER,
    page_end    INTEGER,
    locator     TEXT NOT NULL,
    text        TEXT NOT NULL,                 -- exact slice: version.text[start_char:end_char]
    text_norm   TEXT NOT NULL,                 -- search-normalised form (derived)
    UNIQUE (version_id, ordinal),
    CHECK (end_char > start_char)
);
CREATE INDEX idx_chunks_document ON chunks(document_id);

CREATE VIRTUAL TABLE chunks_fts USING fts5(
    text_norm,
    content='chunks',
    content_rowid='id',
    tokenize='unicode61 remove_diacritics 0'
);
CREATE TRIGGER chunks_ai AFTER INSERT ON chunks BEGIN
    INSERT INTO chunks_fts(rowid, text_norm) VALUES (new.id, new.text_norm);
END;
CREATE TRIGGER chunks_ad AFTER DELETE ON chunks BEGIN
    INSERT INTO chunks_fts(chunks_fts, rowid, text_norm) VALUES ('delete', old.id, old.text_norm);
END;
CREATE TRIGGER chunks_au AFTER UPDATE ON chunks BEGIN
    INSERT INTO chunks_fts(chunks_fts, rowid, text_norm) VALUES ('delete', old.id, old.text_norm);
    INSERT INTO chunks_fts(rowid, text_norm) VALUES (new.id, new.text_norm);
END;

CREATE TABLE links (
    id          INTEGER PRIMARY KEY,
    version_id  INTEGER NOT NULL REFERENCES document_versions(id) ON DELETE CASCADE,
    document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    target_url  TEXT NOT NULL,
    target_host TEXT,
    anchor_text TEXT,
    rel         TEXT,
    is_external INTEGER NOT NULL CHECK (is_external IN (0,1)),
    in_content  INTEGER NOT NULL CHECK (in_content IN (0,1))
);
CREATE INDEX idx_links_version ON links(version_id);
CREATE INDEX idx_links_target ON links(target_url);

CREATE TABLE ingestion_jobs (
    id            INTEGER PRIMARY KEY,
    kind          TEXT NOT NULL CHECK (kind IN ('file','url')),
    input_ref     TEXT NOT NULL,
    status        TEXT NOT NULL CHECK (status IN ('running','succeeded','failed','interrupted')),
    outcome       TEXT,                        -- created | updated | unchanged | duplicate | failed
    document_id   INTEGER,
    version_id    INTEGER,
    detail        TEXT NOT NULL DEFAULT '{}',  -- JSON
    error_message TEXT,
    created_at    TEXT NOT NULL,
    finished_at   TEXT
);

CREATE TABLE ingestion_errors (
    id          INTEGER PRIMARY KEY,
    job_id      INTEGER NOT NULL REFERENCES ingestion_jobs(id) ON DELETE CASCADE,
    stage       TEXT NOT NULL,
    error_type  TEXT NOT NULL,
    message     TEXT NOT NULL,
    created_at  TEXT NOT NULL
);

CREATE TABLE settings (
    key        TEXT PRIMARY KEY,
    value      TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE query_log (
    id           INTEGER PRIMARY KEY,
    ts           TEXT NOT NULL,
    query        TEXT NOT NULL,
    fts_query    TEXT,
    mode_requested TEXT NOT NULL,
    mode_used    TEXT NOT NULL,
    filters      TEXT NOT NULL DEFAULT '{}',
    n_results    INTEGER NOT NULL,
    latency_ms   REAL NOT NULL,
    fallback_used INTEGER NOT NULL DEFAULT 0,
    diagnostics  TEXT NOT NULL DEFAULT '{}'
);
