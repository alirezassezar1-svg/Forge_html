"""Safe URL fetching: guarded connections, manual redirects, size caps, content-type allowlist."""

from __future__ import annotations

import urllib.robotparser
from dataclasses import dataclass
from urllib.parse import urljoin, urlsplit, urlunsplit

import httpx

from .config import Settings
from .netguard import BlockedDestination, GuardedBackend, validate_url_shape

ALLOWED_CONTENT_TYPES = {
    "text/html", "application/xhtml+xml", "text/plain", "text/markdown", "text/csv",
    "application/json", "application/pdf",
}


class FetchError(Exception):
    pass


@dataclass
class Fetched:
    requested_url: str
    final_url: str
    status: int
    content_type: str
    data: bytes
    redirects: list[str]


def canonicalize(url: str) -> str:
    p = urlsplit(url.strip())
    host = (p.hostname or "").lower()
    netloc = host
    default = 443 if p.scheme == "https" else 80
    if p.port and p.port != default:
        netloc = f"{host}:{p.port}"
    path = p.path or "/"
    return urlunsplit((p.scheme.lower(), netloc, path, p.query, ""))  # fragment dropped


def make_client(settings: Settings, resolver=None) -> httpx.Client:
    transport = httpx.HTTPTransport(retries=0)
    # httpx exposes no public hook for the network backend; replacing it on the pool is the
    # documented httpcore extension point. Verified by tests (loopback is blocked).
    transport._pool._network_backend = GuardedBackend(settings.allow_private_networks, resolver)  # noqa: SLF001
    if not isinstance(transport._pool._network_backend, GuardedBackend):  # noqa: SLF001
        raise RuntimeError("SSRF guard could not be installed (httpcore internals changed); refusing to fetch")
    return httpx.Client(
        transport=transport,
        timeout=settings.fetch_timeout,
        follow_redirects=False,
        trust_env=False,
        headers={"User-Agent": settings.user_agent, "Accept-Encoding": "gzip, deflate"},
    )


def _read_limited(resp: httpx.Response, limit: int) -> bytes:
    declared = resp.headers.get("content-length")
    if declared and declared.isdigit() and int(declared) > limit:
        raise FetchError(f"response too large ({declared} bytes; limit {limit})")
    buf = bytearray()
    for chunk in resp.iter_bytes():  # decoded bytes: bounds decompression bombs
        buf += chunk
        if len(buf) > limit:
            raise FetchError(f"response exceeded {limit} bytes after decoding")
    return bytes(buf)


def robots_allows(client: httpx.Client, url: str, settings: Settings) -> bool:
    """RFC 9309 semantics: unreachable/5xx/401/403 => disallow; other 4xx => allow; redirects followed
    (max 5) through the same guarded client."""
    p = urlsplit(url)
    robots_url = f"{p.scheme}://{p.netloc}/robots.txt"
    resp = None
    try:
        for _ in range(6):
            resp = client.get(robots_url)
            if resp.status_code in (301, 302, 303, 307, 308) and resp.headers.get("location"):
                robots_url = urljoin(robots_url, resp.headers["location"])
                validate_url_shape(robots_url, settings.allowed_ports if not settings.allow_private_networks else ())
                continue
            break
        else:
            return False
    except (httpx.HTTPError, BlockedDestination):
        return False  # unreachable robots.txt: be conservative
    if resp is None or resp.status_code >= 500 or resp.status_code in (401, 403) or 300 <= resp.status_code < 400:
        return False
    if resp.status_code >= 400:
        return True
    rp = urllib.robotparser.RobotFileParser()
    rp.parse(resp.text[:500_000].splitlines())
    return rp.can_fetch(settings.user_agent, url)


def fetch_url(url: str, settings: Settings, resolver=None, client: httpx.Client | None = None) -> Fetched:
    own = client is None
    client = client or make_client(settings, resolver)
    try:
        current = url.strip()
        redirects: list[str] = []
        for _ in range(settings.max_redirects + 1):
            validate_url_shape(current, settings.allowed_ports if not settings.allow_private_networks else ())
            if settings.respect_robots and not redirects and not robots_allows(client, current, settings):
                raise FetchError("blocked by robots.txt (or robots.txt unreachable)")
            try:
                with client.stream("GET", current) as resp:
                    if resp.status_code in (301, 302, 303, 307, 308):
                        loc = resp.headers.get("location")
                        if not loc:
                            raise FetchError("redirect without Location header")
                        current = urljoin(current, loc)
                        redirects.append(current)
                        continue
                    if resp.status_code >= 400:
                        raise FetchError(f"HTTP {resp.status_code}")
                    ctype = resp.headers.get("content-type", "").split(";")[0].strip().lower()
                    if ctype and ctype not in ALLOWED_CONTENT_TYPES:
                        raise FetchError(f"unsupported content type: {ctype}")
                    data = _read_limited(resp, settings.max_download_bytes)
                    return Fetched(url, current, resp.status_code, ctype, data, redirects)
            except httpx.HTTPError as exc:
                cause = exc.__cause__ or exc
                if isinstance(cause, BlockedDestination):
                    raise cause from exc
                raise FetchError(f"network error: {type(exc).__name__}: {exc}") from exc
        raise FetchError(f"too many redirects (limit {settings.max_redirects})")
    finally:
        if own:
            client.close()
