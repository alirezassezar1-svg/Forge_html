"""Text normalization for indexing and querying.

The ORIGINAL text is never modified or discarded. Normalization produces a derived string plus an
offset map so matches found in normalized text can be mapped back to original character offsets.

Rules (per character, so offsets stay mappable):
  * Arabic-script characters: NFKC (presentation forms -> base letters), then
      ي ى -> ی ; ك -> ک ; ة -> ه ; أ إ ٱ -> ا ; ؤ -> و ; ئ -> ی
    ("آ" is intentionally preserved), diacritics (harakat U+064B-065F, U+0670) and tatweel removed.
  * Other scripts: NFKD, combining marks removed, casefolded.
  * Decimal digits of any script -> ASCII digits.
  * ZWNJ (U+200C) -> space; other invisible format characters removed.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

_ARABIC_MAP = {
    "ي": "ی",  # Arabic yeh -> Persian yeh
    "ى": "ی",  # alef maksura -> Persian yeh
    "ك": "ک",  # Arabic kaf -> Persian keheh
    "ة": "ه",  # teh marbuta -> heh
    "أ": "ا",  # alef with hamza above -> alef
    "إ": "ا",  # alef with hamza below -> alef
    "ٱ": "ا",  # alef wasla -> alef
    "ؤ": "و",  # waw with hamza -> waw
    "ئ": "ی",  # yeh with hamza -> Persian yeh
}
_DROP = {"ـ", "ٰ"} | {chr(c) for c in range(0x064B, 0x0660)}
_TOKEN_RE = re.compile(r"[^\W_]+", re.UNICODE)


def _is_arabic_script(ch: str) -> bool:
    cp = ord(ch)
    return (0x0600 <= cp <= 0x06FF) or (0x0750 <= cp <= 0x077F) or (0xFB50 <= cp <= 0xFDFF) or (
        0xFE70 <= cp <= 0xFEFF
    )


def _norm_char(ch: str) -> str:
    if ch == "‌":
        return " "
    cat = unicodedata.category(ch)
    if cat == "Cf":
        return ""
    if cat == "Nd":
        return str(unicodedata.decimal(ch))
    if _is_arabic_script(ch):
        out = []
        for c in unicodedata.normalize("NFKC", ch):
            if c in _DROP:
                continue
            out.append(_ARABIC_MAP.get(c, c))
        return "".join(out)
    decomposed = unicodedata.normalize("NFKD", ch)
    kept = "".join(c for c in decomposed if not unicodedata.category(c).startswith("M"))
    return kept.casefold()


@dataclass
class Normalized:
    text: str
    # offsets[i] = index in ORIGINAL text of the character that produced text[i]
    offsets: list[int]


def normalize_with_map(text: str) -> Normalized:
    out: list[str] = []
    offsets: list[int] = []
    for i, ch in enumerate(text):
        piece = _norm_char(ch)
        for c in piece:
            out.append(c)
            offsets.append(i)
    return Normalized("".join(out), offsets)


def normalize(text: str) -> str:
    return normalize_with_map(text).text


def tokenize(normalized_text: str) -> list[str]:
    return _TOKEN_RE.findall(normalized_text)


def token_spans(norm: Normalized) -> list[tuple[str, int, int]]:
    """Tokens of the normalized text with (start, end) offsets in the ORIGINAL text (end exclusive)."""
    spans = []
    for m in _TOKEN_RE.finditer(norm.text):
        s, e = m.start(), m.end()
        spans.append((m.group(), norm.offsets[s], norm.offsets[e - 1] + 1))
    return spans
