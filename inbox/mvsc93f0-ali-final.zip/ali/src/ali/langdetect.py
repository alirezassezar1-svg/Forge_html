"""Lightweight script-based language heuristic (fa / ar / en / mixed / unknown).

This is an explicit heuristic, not a trained model. It is reported with a confidence value and is
documented as a known limitation; a model-based detector is evaluated in Milestone 2.
"""

from __future__ import annotations

import re

_ARABIC_RE = re.compile(r"[؀-ۿݐ-ݿﭐ-﷿ﹰ-﻿]")
_LATIN_RE = re.compile(r"[A-Za-z]")
_PERSIAN_LETTERS = set("پچژگیک")
_FA_WORDS = {"است", "این", "که", "را", "با", "برای", "های", "می", "از", "در", "به", "نیست", "شد"}
_AR_WORDS = {"في", "على", "هذا", "هذه", "التي", "الذي", "إلى", "عن", "من", "ما", "لا", "كان"}


def detect_language(text: str, sample: int = 20000) -> tuple[str, float]:
    s = text[:sample]
    arabic = len(_ARABIC_RE.findall(s))
    latin = len(_LATIN_RE.findall(s))
    total = arabic + latin
    if total < 10:
        return "unknown", 0.0
    ar_ratio = arabic / total
    if ar_ratio < 0.15:
        return "en", round(1 - ar_ratio, 2)
    if ar_ratio < 0.85:
        return "mixed", round(1 - abs(0.5 - ar_ratio), 2)
    words = re.findall(r"[؀-ۿ]+", s)
    fa_hits = sum(1 for w in words if w in _FA_WORDS)
    ar_hits = sum(1 for w in words if w in _AR_WORDS)
    fa_letters = sum(1 for ch in s if ch in _PERSIAN_LETTERS and ch not in "یک")
    if fa_hits + fa_letters > ar_hits:
        conf = (fa_hits + fa_letters) / max(1, fa_hits + fa_letters + ar_hits)
        return "fa", round(min(0.99, 0.5 + conf / 2), 2)
    if ar_hits > 0:
        return "ar", round(min(0.99, 0.5 + ar_hits / (ar_hits + fa_hits + 1) / 2), 2)
    return "fa", 0.5  # Arabic script, no discriminating markers: default to Persian (project locale)
