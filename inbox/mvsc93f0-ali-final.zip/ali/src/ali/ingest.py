"""Ingestion pipeline: bytes/path/URL -> preserved original + versioned extracted text + chunks + FTS index.

Atomicity: the original is written to a content-addressed file first (idempotent); everything else
(document, version, chunks, links, FTS rows via triggers, job record) commits in ONE transaction.
An interrupted run therefore leaves either a complete version or nothing; unreferenced originals are
removed by `gc_originals`. Jobs left in 'running' state are marked 'interrupted' on startup."""

from __future__ import annotations

import json
import os
import sqlite3
import traceback
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from ali import hashing, langdetect, textnorm
from ali.chunking import chunk_text
from ali.config import Settings
from ali.db import tx, utcnow
from ali.extract import ExtractedDocument, ExtractionError, detect_adapter, extract
from ali.fetch import FetchError, fetch_url
from ali.netguard import BlockedDestination


@dataclass
class IngestResult:
    job_id: int
    outcome: str  # created | updated | unchanged | duplicate | failed
    document_id: int | None = None
    version_id: int | None = None
    version_no: int | None = None
    duplicate_of: int | None = None
    extraction_status: str | None = None
    n_chunks: int = 0
    content_hash: str | None = None
    warnings: list[str] = field(default_factory=list)
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# ------------------------------------------------------------------ jobs
def start_job(conn: sqlite3.Connection, kind: str, input_ref: str) -> int:
    cur = conn.execute(
        "INSERT INTO ingestion_jobs(kind, input_ref, status, created_at) VALUES (?,?, 'running', ?)",
        (kind, input_ref, utcnow()),
    )
    if cur.lastrowid is None:
        raise RuntimeError("job insert returned no id")
    return cur.lastrowid


def _record_error(conn: sqlite3.Connection, job_id: int, stage: str, exc: BaseException | str) -> None:
    etype = type(exc).__name__ if isinstance(exc, BaseException) else "Error"
    conn.execute(
        "INSERT INTO ingestion_errors(job_id, stage, error_type, message, created_at) VALUES (?,?,?,?,?)",
        (job_id, stage, etype, str(exc)[:2000], utcnow()),
    )


def finish_job(
    conn: sqlite3.Connection, job_id: int, result: IngestResult, detail: dict[str, Any] | None = None
) -> None:
    status = "failed" if result.outcome == "failed" else "succeeded"
    conn.execute(
        "UPDATE ingestion_jobs SET status=?, outcome=?, document_id=?, version_id=?, detail=?, error_message=?, "
        "finished_at=? WHERE id=?",
        (status, result.outcome, result.document_id, result.version_id,
         json.dumps({**(detail or {}), "warnings": result.warnings, "n_chunks": result.n_chunks,
                     "extraction_status": result.extraction_status, "duplicate_of": result.duplicate_of}),
         result.error, utcnow(), job_id),
    )


def fail_job(conn: sqlite3.Connection, job_id: int, stage: str, exc: BaseException | str) -> IngestResult:
    _record_error(conn, job_id, stage, exc)
    res = IngestResult(job_id=job_id, outcome="failed", error=f"{stage}: {exc}"[:1000])
    finish_job(conn, job_id, res)
    return res


def recover_interrupted_jobs(conn: sqlite3.Connection) -> int:
    """Mark jobs left 'running' by a crash as 'interrupted'. Safe because ingestion commits atomically."""
    cur = conn.execute(
        "UPDATE ingestion_jobs SET status='interrupted', finished_at=?, "
        "error_message='process stopped before the job finished; no partial data was committed' "
        "WHERE status='running'",
        (utcnow(),),
    )
    return cur.rowcount


# ------------------------------------------------------------------ originals store
def original_relpath(sha: str) -> str:
    return f"{sha[:2]}/{sha}"


def store_original(settings: Settings, data: bytes, sha: str) -> str:
    rel = original_relpath(sha)
    dest = settings.originals_dir / rel
    if dest.exists() and dest.stat().st_size == len(data):
        return rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + f".tmp{os.getpid()}")
    with open(tmp, "wb") as fh:
        fh.write(data)
        fh.flush()
        os.fsync(fh.fileno())
    os.replace(tmp, dest)
    return rel


def gc_originals(conn: sqlite3.Connection, settings: Settings) -> list[str]:
    """Delete original files no document version references. Returns removed relative paths."""
    referenced = {r["original_path"] for r in conn.execute("SELECT DISTINCT original_path FROM document_versions") if r["original_path"]}
    removed: list[str] = []
    root = settings.originals_dir
    if not root.exists():
        return removed
    for f in root.rglob("*"):
        if f.is_file():
            rel = f.relative_to(root).as_posix()
            if rel not in referenced:
                f.unlink()
                removed.append(rel)
    return removed


# ------------------------------------------------------------------ chunk building
def build_chunk_rows(text: str, page_spans: list[Any] | None, settings: Settings) -> list[dict[str, Any]]:
    segs = [(int(s), int(e), int(p)) for s, e, p in page_spans] if page_spans else None
    rows = []
    for i, c in enumerate(chunk_text(text, settings.chunk_max_chars, settings.chunk_overlap_chars, segs)):
        piece = text[c.start:c.end]
        rows.append({
            "ordinal": i, "start": c.start, "end": c.end, "page": c.page, "locator": c.locator,
            "text": piece, "norm": textnorm.normalize(piece),
        })
    return rows


# ------------------------------------------------------------------ core ingestion
def _publisher_id(conn: sqlite3.Connection, key: str, name: str) -> int:
    conn.execute("INSERT OR IGNORE INTO publishers(key, name, created_at) VALUES (?,?,?)", (key, name, utcnow()))
    return int(conn.execute("SELECT id FROM publishers WHERE key=?", (key,)).fetchone()["id"])


def _choose_source_key(
    kind: str, explicit: str | None, filename: str | None, final_url: str | None, canonical: str | None
) -> str:
    if explicit:
        return explicit
    if kind == "url" and final_url:
        if canonical:
            ch, fh = urlsplit(canonical).hostname, urlsplit(final_url).hostname
            if ch and fh and ch.removeprefix("www.") == fh.removeprefix("www."):
                return canonical  # only trust canonical links on the same host
        return urlsplit(final_url)._replace(fragment="").geturl()
    return f"file:{filename or 'unnamed'}"


def ingest_bytes(
    conn: sqlite3.Connection,
    settings: Settings,
    data: bytes,
    *,
    filename: str | None,
    source_key: str | None = None,
    kind: str = "file",
    final_url: str | None = None,
    content_type: str | None = None,
    retrieved_at: str | None = None,
    http_status: int | None = None,
    fetch_meta: dict[str, Any] | None = None,
    job_id: int | None = None,
    input_ref: str | None = None,
) -> IngestResult:
    job = job_id or start_job(conn, kind, input_ref or source_key or filename or "unnamed")
    try:
        return _ingest(conn, settings, data, filename, source_key, kind, final_url, content_type,
                       retrieved_at, http_status, fetch_meta or {}, job)
    except Exception as exc:  # noqa: BLE001 - recorded on the job and returned, never swallowed
        if conn.in_transaction:
            conn.execute("ROLLBACK")
        _record_error(conn, job, "ingest", traceback.format_exc(limit=3))
        res = IngestResult(job_id=job, outcome="failed", error=f"ingest: {type(exc).__name__}: {exc}"[:1000])
        finish_job(conn, job, res)
        return res


def _ingest(
    conn: sqlite3.Connection, settings: Settings, data: bytes, filename: str | None, source_key: str | None,
    kind: str, final_url: str | None, content_type: str | None, retrieved_at: str | None,
    http_status: int | None, fetch_meta: dict[str, Any], job: int,
) -> IngestResult:
    if len(data) > settings.max_upload_bytes and kind == "file":
        return fail_job(conn, job, "validate", f"file larger than {settings.max_upload_bytes} bytes")
    if not data:
        return fail_job(conn, job, "validate", "empty input")
    sha = hashing.sha256_bytes(data)
    adapter = detect_adapter(filename or (urlsplit(final_url).path if final_url else None), content_type, data[:4096])
    if adapter is None:
        return fail_job(conn, job, "detect", f"unsupported file type (filename={filename!r}, content-type={content_type!r})")

    extraction_error: str | None = None
    try:
        doc = extract(data, adapter, filename, base_url=final_url, max_pdf_pages=settings.max_pdf_pages)
    except ExtractionError as exc:
        extraction_error = str(exc)
        doc = ExtractedDocument("", adapter, None, "failed", 0.0, [str(exc)])
        _record_error(conn, job, "extract", exc)
    except Exception as exc:  # noqa: BLE001
        extraction_error = f"{type(exc).__name__}: {exc}"
        doc = ExtractedDocument("", adapter, None, "failed", 0.0, [extraction_error])
        _record_error(conn, job, "extract", exc)

    key = _choose_source_key(kind, source_key, filename, final_url, doc.canonical_url)
    now = utcnow()
    retrieved = retrieved_at or now
    lang, lang_conf = langdetect.detect_language(doc.text)
    text_hash = hashing.sha256_text(doc.text)
    has_text = bool(doc.text.strip())

    existing = conn.execute("SELECT id FROM documents WHERE source_key=?", (key,)).fetchone()
    cur_version = None
    if existing:
        cur_version = conn.execute(
            "SELECT id, version_no, content_hash FROM document_versions WHERE document_id=? AND is_current=1",
            (existing["id"],),
        ).fetchone()
        if cur_version and cur_version["content_hash"] == sha:
            res = IngestResult(job, "unchanged", existing["id"], cur_version["id"], cur_version["version_no"],
                               content_hash=sha, warnings=doc.warnings)
            finish_job(conn, job, res, {"source_key": key})
            return res
        if not has_text:
            msg = extraction_error or "new version has no extractable text"
            res = fail_job(conn, job, "extract", f"{msg}; the previous version was kept")
            res.document_id, res.content_hash = existing["id"], sha
            return res
    else:
        alias = conn.execute("SELECT id, document_id, content_hash FROM document_aliases WHERE source_key=?", (key,)).fetchone()
        if alias and alias["content_hash"] == sha:
            with tx(conn):
                conn.execute("UPDATE document_aliases SET last_seen=? WHERE id=?", (now, alias["id"]))
                res = IngestResult(job, "duplicate", alias["document_id"], None, None, alias["document_id"],
                                   content_hash=sha)
                finish_job(conn, job, res, {"source_key": key, "alias": True})
            return res
        dup = conn.execute(
            "SELECT d.id AS doc_id FROM document_versions v JOIN documents d ON d.id=v.document_id "
            "WHERE v.content_hash=? AND v.is_current=1 LIMIT 1", (sha,)
        ).fetchone()
        if dup:
            with tx(conn):
                conn.execute("DELETE FROM document_aliases WHERE source_key=?", (key,))
                conn.execute(
                    "INSERT INTO document_aliases(document_id, source_key, content_hash, first_seen, last_seen) "
                    "VALUES (?,?,?,?,?)", (dup["doc_id"], key, sha, now, now))
                res = IngestResult(job, "duplicate", dup["doc_id"], None, None, dup["doc_id"], content_hash=sha)
                finish_job(conn, job, res, {"source_key": key})
            return res

    rel = store_original(settings, data, sha)
    chunk_rows = build_chunk_rows(doc.text, doc.page_spans, settings) if has_text else []
    host = (urlsplit(final_url).hostname or "").removeprefix("www.") if kind == "url" and final_url else ""
    pub_key = host or "local"
    pub_name = doc.publisher_name or (host if host else "Local files")
    title = doc.title or filename or key
    meta = {**doc.metadata, **fetch_meta}

    with tx(conn):
        pub_id = _publisher_id(conn, pub_key, pub_name)
        if existing:
            doc_id = int(existing["id"])
            version_no = int(cur_version["version_no"]) + 1 if cur_version else 1
            conn.execute("UPDATE document_versions SET is_current=0, superseded_at=? WHERE document_id=? AND is_current=1",
                         (now, doc_id))
            conn.execute("UPDATE documents SET title=?, canonical_url=?, publisher_id=?, updated_at=? WHERE id=?",
                         (title, doc.canonical_url, pub_id, now, doc_id))
            outcome = "updated"
        else:
            cur = conn.execute(
                "INSERT INTO documents(source_key, kind, publisher_id, title, canonical_url, created_at, updated_at) "
                "VALUES (?,?,?,?,?,?,?)", (key, kind, pub_id, title, doc.canonical_url, now, now))
            doc_id = int(cur.lastrowid or 0)
            version_no = 1
            outcome = "created"
        vcur = conn.execute(
            "INSERT INTO document_versions(document_id, version_no, is_current, content_hash, text_hash, "
            "original_filename, original_path, original_size, media_type, adapter, url, http_status, retrieved_at, "
            "language, language_confidence, title, author, published_at, extraction_status, extraction_quality, "
            "extraction_warnings, text, page_spans, metadata, created_at) "
            "VALUES (?,?,1,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (doc_id, version_no, sha, text_hash, filename, rel, len(data), (content_type or "").split(";")[0] or None,
             doc.adapter, final_url, http_status, retrieved, lang, lang_conf, doc.title, doc.author,
             doc.published_at, doc.status, doc.quality, json.dumps(doc.warnings, ensure_ascii=False), doc.text,
             json.dumps(doc.page_spans) if doc.page_spans else None, json.dumps(meta, ensure_ascii=False, default=str), now))
        version_id = int(vcur.lastrowid or 0)
        conn.executemany(
            "INSERT INTO chunks(version_id, document_id, ordinal, start_char, end_char, page_start, page_end, "
            "locator, text, text_norm) VALUES (?,?,?,?,?,?,?,?,?,?)",
            [(version_id, doc_id, r["ordinal"], r["start"], r["end"], r["page"], r["page"], r["locator"],
              r["text"], r["norm"]) for r in chunk_rows])
        conn.executemany(
            "INSERT INTO links(version_id, document_id, target_url, target_host, anchor_text, rel, is_external, in_content) "
            "VALUES (?,?,?,?,?,?,?,?)",
            [(version_id, doc_id, ln["target_url"], ln["target_host"], ln["anchor_text"], ln["rel"],
              int(ln["is_external"]), int(ln["in_content"])) for ln in doc.links])
        res = IngestResult(job, outcome, doc_id, version_id, version_no, None, doc.status, len(chunk_rows), sha, doc.warnings,
                           error=extraction_error)
        finish_job(conn, job, res, {"source_key": key, "adapter": doc.adapter, "original_path": rel})
    if extraction_error:
        conn.execute("UPDATE ingestion_jobs SET status='failed' WHERE id=?", (job,))
    return res


# ------------------------------------------------------------------ entry points
def ingest_path(conn: sqlite3.Connection, settings: Settings, path: str | Path, source_key: str | None = None) -> IngestResult:
    p = Path(path).expanduser()
    job = start_job(conn, "file", str(p))
    try:
        size = p.stat().st_size
        if size > settings.max_upload_bytes:
            return fail_job(conn, job, "read", f"file larger than {settings.max_upload_bytes} bytes")
        data = p.read_bytes()
    except OSError as exc:
        return fail_job(conn, job, "read", exc)
    key = source_key or f"file:{p.resolve().as_posix()}"
    return ingest_bytes(conn, settings, data, filename=p.name, source_key=key, kind="file", job_id=job, input_ref=str(p))


def ingest_url(
    conn: sqlite3.Connection, settings: Settings, url: str, resolver: Any = None, client: Any = None
) -> IngestResult:
    job = start_job(conn, "url", url)
    try:
        fetched = fetch_url(url, settings, resolver=resolver, client=client)
    except BlockedDestination as exc:
        return fail_job(conn, job, "blocked", exc)
    except FetchError as exc:
        return fail_job(conn, job, "fetch", exc)
    except Exception as exc:  # noqa: BLE001 - unexpected network-layer error, recorded on the job
        return fail_job(conn, job, "fetch", f"{type(exc).__name__}: {exc}")
    path_name = urlsplit(fetched.final_url).path.rsplit("/", 1)[-1] or None
    return ingest_bytes(
        conn, settings, fetched.data, filename=path_name, kind="url", final_url=fetched.final_url,
        content_type=fetched.content_type, retrieved_at=utcnow(), http_status=fetched.status,
        fetch_meta={"requested_url": fetched.requested_url, "redirects": fetched.redirects},
        job_id=job, input_ref=url,
    )


# ------------------------------------------------------------------ deletion and reindexing
def delete_document(conn: sqlite3.Connection, settings: Settings, document_id: int) -> dict[str, int]:
    row = conn.execute("SELECT id FROM documents WHERE id=?", (document_id,)).fetchone()
    if not row:
        raise KeyError(f"document {document_id} not found")
    counts = {
        "versions": conn.execute("SELECT COUNT(*) c FROM document_versions WHERE document_id=?", (document_id,)).fetchone()["c"],
        "chunks": conn.execute("SELECT COUNT(*) c FROM chunks WHERE document_id=?", (document_id,)).fetchone()["c"],
        "links": conn.execute("SELECT COUNT(*) c FROM links WHERE document_id=?", (document_id,)).fetchone()["c"],
        "aliases": conn.execute("SELECT COUNT(*) c FROM document_aliases WHERE document_id=?", (document_id,)).fetchone()["c"],
    }
    with tx(conn):
        conn.execute("DELETE FROM documents WHERE id=?", (document_id,))  # cascades; FTS rows removed by triggers
        conn.execute("UPDATE ingestion_jobs SET document_id=NULL, version_id=NULL WHERE document_id=?", (document_id,))
    counts["original_files_removed"] = len(gc_originals(conn, settings))
    return counts


def reindex(conn: sqlite3.Connection, settings: Settings) -> dict[str, int]:
    """Rebuild all derived data (chunks, normalised text, FTS index) from stored version text.
    Applies the current chunking settings."""
    versions = conn.execute("SELECT id, document_id, text, page_spans FROM document_versions ORDER BY id").fetchall()
    n_chunks = 0
    with tx(conn):
        conn.execute("DELETE FROM chunks")
        for v in versions:
            if not v["text"].strip():
                continue
            spans = json.loads(v["page_spans"]) if v["page_spans"] else None
            rows = build_chunk_rows(v["text"], spans, settings)
            conn.executemany(
                "INSERT INTO chunks(version_id, document_id, ordinal, start_char, end_char, page_start, page_end, "
                "locator, text, text_norm) VALUES (?,?,?,?,?,?,?,?,?,?)",
                [(v["id"], v["document_id"], r["ordinal"], r["start"], r["end"], r["page"], r["page"], r["locator"],
                  r["text"], r["norm"]) for r in rows])
            n_chunks += len(rows)
        conn.execute("INSERT INTO chunks_fts(chunks_fts) VALUES ('rebuild')")
    return {"versions": len(versions), "chunks": n_chunks}
