"""Health check: environment, schema, integrity, index consistency, preserved originals."""

from __future__ import annotations

import shutil
import sqlite3
import sys
from typing import Any

from ali import hashing
from ali.config import Settings
from ali.db import _migration_files, connect, fts5_available, schema_version


def _c(name: str, ok: bool, detail: str = "", severity: str = "error") -> dict[str, Any]:
    return {"name": name, "ok": bool(ok), "detail": detail, "severity": severity}


def run_health(settings: Settings, deep: bool = False) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []
    checks.append(_c("python>=3.11", sys.version_info >= (3, 11), sys.version.split()[0]))
    checks.append(_c("sqlite_fts5", fts5_available(), f"sqlite {sqlite3.sqlite_version}"))
    try:
        settings.ensure_dirs()
        probe = settings.home / ".write-test"
        probe.write_text("x")
        probe.unlink()
        checks.append(_c("data_dir_writable", True, str(settings.home)))
    except OSError as exc:
        checks.append(_c("data_dir_writable", False, str(exc)))
    free = shutil.disk_usage(settings.home).free if settings.home.exists() else 0
    checks.append(_c("disk_space>=500MB", free >= 500 * 1024 * 1024, f"{free // (1024 * 1024)} MB free", "warning"))
    checks.append(_c("tesseract_available(optional OCR)", shutil.which("tesseract") is not None,
                     "OCR adapter is not implemented yet; reported for planning", "info"))
    if not settings.db_path.exists():
        checks.append(_c("database_exists", False, "run `ali init`"))
        return _summarise(checks)
    conn = connect(settings.db_path, readonly=True)
    try:
        latest = max(v for v, _n, _s in _migration_files())
        have = schema_version(conn)
        checks.append(_c("schema_up_to_date", have == latest, f"schema {have}, code expects {latest}"))
        pragma = "integrity_check" if deep else "quick_check"
        res = conn.execute(f"PRAGMA {pragma}").fetchone()[0]
        checks.append(_c(f"sqlite_{pragma}", res == "ok", res))
        fk = conn.execute("PRAGMA foreign_key_check").fetchall()
        checks.append(_c("foreign_keys_consistent", not fk, f"{len(fk)} violations"))
        n_chunks = conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        n_fts = conn.execute("SELECT COUNT(*) FROM chunks_fts_docsize").fetchone()[0]
        checks.append(_c("fts_row_count_matches_chunks", n_chunks == n_fts, f"chunks={n_chunks} fts={n_fts}"))
        try:
            conn.execute("INSERT INTO chunks_fts(chunks_fts, rank) VALUES('integrity-check', 1)")
            checks.append(_c("fts_integrity_check", True))
        except sqlite3.DatabaseError as exc:
            # read-only connection cannot run the command on some builds; fall back to a writable one
            if "readonly" in str(exc).lower():
                w = connect(settings.db_path)
                try:
                    w.execute("INSERT INTO chunks_fts(chunks_fts, rank) VALUES('integrity-check', 1)")
                    checks.append(_c("fts_integrity_check", True))
                except sqlite3.DatabaseError as exc2:
                    checks.append(_c("fts_integrity_check", False, str(exc2)))
                finally:
                    w.close()
            else:
                checks.append(_c("fts_integrity_check", False, str(exc)))
        nocur = conn.execute("SELECT COUNT(*) FROM documents d WHERE NOT EXISTS "
                             "(SELECT 1 FROM document_versions v WHERE v.document_id=d.id AND v.is_current=1)").fetchone()[0]
        checks.append(_c("every_document_has_current_version", nocur == 0, f"{nocur} without"))
        missing, mismatched, referenced = [], [], set()
        for r in conn.execute("SELECT id, original_path, original_size, content_hash FROM document_versions"):
            referenced.add(r["original_path"])
            p = settings.originals_dir / r["original_path"]
            if not p.exists():
                missing.append(r["id"])
            elif p.stat().st_size != r["original_size"]:
                mismatched.append(r["id"])
            elif deep and hashing.sha256_bytes(p.read_bytes()) != r["content_hash"]:
                mismatched.append(r["id"])
        checks.append(_c("originals_present", not missing, f"missing for versions {missing[:10]}" if missing else "all present"))
        checks.append(_c("originals_intact" + ("(hash)" if deep else "(size)"), not mismatched,
                         f"mismatch for versions {mismatched[:10]}" if mismatched else "ok"))
        orphans = [f for f in settings.originals_dir.rglob("*") if f.is_file()
                   and f.relative_to(settings.originals_dir).as_posix() not in referenced]
        checks.append(_c("no_orphan_originals", not orphans, f"{len(orphans)} unreferenced files (run `ali gc`)", "warning"))
        running = conn.execute("SELECT COUNT(*) FROM ingestion_jobs WHERE status='running'").fetchone()[0]
        checks.append(_c("no_stuck_jobs", running == 0, f"{running} running (marked interrupted on next start)", "warning"))
    finally:
        conn.close()
    return _summarise(checks)


def _summarise(checks: list[dict[str, Any]]) -> dict[str, Any]:
    failed = [c for c in checks if not c["ok"] and c["severity"] == "error"]
    warned = [c for c in checks if not c["ok"] and c["severity"] == "warning"]
    return {"ok": not failed, "errors": len(failed), "warnings": len(warned), "checks": checks}
