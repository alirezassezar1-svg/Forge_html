"""HTTP API and static web UI.

Security model
- Mutating requests (POST/DELETE) must carry the custom header ``X-ALI-Request: 1`` (a cross-site form or
  simple fetch cannot add it without a CORS preflight, which this app never grants) and, when an Origin
  header is present, it must match the Host. This is the CSRF defence.
- If ``ALI_API_TOKEN`` is set, every /api request except /api/session and /api/login needs either an
  ``Authorization: Bearer`` header or the HttpOnly, SameSite=Strict session cookie issued by /api/login.
  The cookie value is an HMAC of a random per-process key, so the token itself is never stored client-side.
- Error responses never include tracebacks or settings.
- Documents are untrusted: the UI renders them with textContent only.
"""

from __future__ import annotations

import hashlib
import hmac
import secrets
from contextlib import contextmanager
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from fastapi import Depends, FastAPI, File, HTTPException, Query, Request, Response, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from ali import backup as backup_mod
from ali import citations, ingest, library, search
from ali.config import Settings
from ali.db import open_db
from ali.health import run_health

WEB_DIR = Path(__file__).parent / "web"
COOKIE = "ali_session"
MAX_URLS = 50


class LoginBody(BaseModel):
    token: str = Field(min_length=1, max_length=512)


class UrlsBody(BaseModel):
    urls: list[str] = Field(min_length=1, max_length=MAX_URLS)


def create_app(settings: Settings) -> FastAPI:
    app = FastAPI(title="ALI", docs_url=None, redoc_url=None, openapi_url=None)
    settings.ensure_dirs()
    session_key = secrets.token_bytes(32)

    def session_value() -> str:
        return hmac.new(session_key, b"ali-session", hashlib.sha256).hexdigest()

    @contextmanager
    def db():
        conn = open_db(settings)
        try:
            yield conn
        finally:
            conn.close()

    def _authed(request: Request) -> bool:
        if not settings.api_token:
            return True
        cookie = request.cookies.get(COOKIE, "")
        if cookie and hmac.compare_digest(cookie, session_value()):
            return True
        auth = request.headers.get("authorization", "")
        return auth.startswith("Bearer ") and hmac.compare_digest(auth[7:], settings.api_token)

    def guard(request: Request) -> None:
        if request.method not in ("GET", "HEAD", "OPTIONS"):
            if request.headers.get("x-ali-request") != "1":
                raise HTTPException(403, "missing X-ALI-Request header")
            origin = request.headers.get("origin")
            if origin and urlsplit(origin).netloc != request.headers.get("host", ""):
                raise HTTPException(403, "cross-origin request refused")
        if not _authed(request):
            raise HTTPException(401, "authentication required")

    @app.middleware("http")
    async def headers(request: Request, call_next):
        resp = await call_next(request)
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "no-referrer"
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        if request.url.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    # ------------------------------------------------------------- session
    @app.get("/api/session")
    def session(request: Request) -> dict[str, Any]:
        return {"auth_required": bool(settings.api_token), "authenticated": _authed(request)}

    @app.post("/api/login")
    def login(body: LoginBody, request: Request, response: Response) -> dict[str, Any]:
        if request.headers.get("x-ali-request") != "1":
            raise HTTPException(403, "missing X-ALI-Request header")
        if not settings.api_token or not hmac.compare_digest(body.token, settings.api_token):
            raise HTTPException(401, "invalid token")
        response.set_cookie(COOKIE, session_value(), httponly=True, samesite="strict",
                            secure=request.url.scheme == "https", max_age=12 * 3600, path="/")
        return {"ok": True}

    @app.post("/api/logout")
    def logout(response: Response) -> dict[str, Any]:
        response.delete_cookie(COOKIE, path="/")
        return {"ok": True}

    # ------------------------------------------------------------- read endpoints
    @app.get("/api/health", dependencies=[Depends(guard)])
    def health(deep: bool = False) -> dict[str, Any]:
        return run_health(settings, deep=deep)

    @app.get("/api/stats", dependencies=[Depends(guard)])
    def stats() -> dict[str, Any]:
        with db() as c:
            return library.stats(c)

    @app.get("/api/search", dependencies=[Depends(guard)])
    def do_search(q: str = Query(min_length=1, max_length=500), mode: str = "auto",
                  limit: int = Query(10, ge=1, le=100), language: str | None = None,
                  kind: str | None = None) -> dict[str, Any]:
        with db() as c:
            try:
                return search.search(c, q, mode=mode, limit=limit,
                                     filters={"language": language, "kind": kind})
            except ValueError as exc:
                raise HTTPException(422, str(exc)) from exc

    @app.get("/api/documents", dependencies=[Depends(guard)])
    def documents(limit: int = Query(100, ge=1, le=500), offset: int = Query(0, ge=0)) -> list[dict[str, Any]]:
        with db() as c:
            return library.list_documents(c, limit, offset)

    @app.get("/api/documents/{document_id}", dependencies=[Depends(guard)])
    def document(document_id: int) -> dict[str, Any]:
        with db() as c:
            d = library.get_document(c, document_id)
        if not d:
            raise HTTPException(404, "document not found")
        return d

    @app.get("/api/passage", dependencies=[Depends(guard)])
    def passage(version_id: int, start: int = Query(ge=0), end: int = Query(ge=0),
                context: int = Query(300, ge=0, le=5000)) -> dict[str, Any]:
        with db() as c:
            p = library.get_passage(c, version_id, start, end, context)
        if not p:
            raise HTTPException(404, "version not found")
        return p

    @app.get("/api/jobs", dependencies=[Depends(guard)])
    def jobs(limit: int = Query(50, ge=1, le=200)) -> list[dict[str, Any]]:
        with db() as c:
            return library.list_jobs(c, limit)

    # ------------------------------------------------------------- write endpoints
    @app.post("/api/citations/verify", dependencies=[Depends(guard)])
    def verify(citation: dict[str, Any], deep: bool = False) -> dict[str, Any]:
        with db() as c:
            return citations.verify_citation(c, settings, citation, deep=deep)

    @app.post("/api/upload", dependencies=[Depends(guard)])
    def upload(files: list[UploadFile] = File(...)) -> list[dict[str, Any]]:
        out = []
        with db() as c:
            for f in files:
                data = f.file.read(settings.max_upload_bytes + 1)
                if len(data) > settings.max_upload_bytes:
                    out.append({"filename": f.filename, "outcome": "failed",
                                "error": f"file larger than {settings.max_upload_bytes} bytes"})
                    continue
                r = ingest.ingest_bytes(c, settings, data, filename=Path(f.filename or "upload").name,
                                        source_key=f"upload:{Path(f.filename or 'upload').name}",
                                        kind="file", content_type=f.content_type)
                out.append({"filename": f.filename, **r.to_dict()})
        return out

    @app.post("/api/ingest-url", dependencies=[Depends(guard)])
    def ingest_urls(body: UrlsBody) -> list[dict[str, Any]]:
        out = []
        with db() as c:
            for u in body.urls:
                out.append({"url": u, **ingest.ingest_url(c, settings, u.strip()).to_dict()})
        return out

    @app.delete("/api/documents/{document_id}", dependencies=[Depends(guard)])
    def delete(document_id: int) -> dict[str, Any]:
        with db() as c:
            try:
                return ingest.delete_document(c, settings, document_id)
            except KeyError as exc:
                raise HTTPException(404, "document not found") from exc

    @app.post("/api/backup", dependencies=[Depends(guard)])
    def make_backup() -> dict[str, Any]:
        path = backup_mod.create_backup(settings)
        manifest = backup_mod.verify_backup(path)
        return {"file": path.name, "files": len(manifest["files"]), "verified": True}

    @app.post("/api/reindex", dependencies=[Depends(guard)])
    def reindex() -> dict[str, Any]:
        with db() as c:
            return ingest.reindex(c, settings)

    # ------------------------------------------------------------- errors and static UI
    @app.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception):  # noqa: ARG001
        from fastapi.responses import JSONResponse
        return JSONResponse({"detail": "internal error"}, status_code=500)

    @app.get("/", include_in_schema=False)
    def index() -> FileResponse:
        return FileResponse(WEB_DIR / "index.html", media_type="text/html")

    @app.get("/static/{name}", include_in_schema=False)
    def static(name: str) -> FileResponse:
        p = (WEB_DIR / name).resolve()
        if p.parent != WEB_DIR.resolve() or not p.is_file() or name == "index.html":
            raise HTTPException(404)
        return FileResponse(p)

    return app

