"""SQLite access and versioned migrations (stdlib sqlite3; FTS5 required)."""

from __future__ import annotations

import hashlib
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from importlib import resources
from pathlib import Path

from ali.config import Settings


def utcnow() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


class MigrationError(RuntimeError):
    pass


def connect(path: Path | str, *, readonly: bool = False) -> sqlite3.Connection:
    """Open a connection with the pragmas ALI relies on. Autocommit mode; use `tx()` for transactions."""
    uri = f"file:{Path(path).as_posix()}?mode={'ro' if readonly else 'rwc'}"
    conn = sqlite3.connect(uri, uri=True, isolation_level=None, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 30000")
    if not readonly:
        conn.execute("PRAGMA journal_mode = WAL")
        conn.execute("PRAGMA synchronous = NORMAL")
    return conn


@contextmanager
def tx(conn: sqlite3.Connection) -> Iterator[sqlite3.Connection]:
    """Explicit write transaction: BEGIN IMMEDIATE ... COMMIT, ROLLBACK on any exception."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
    except BaseException:
        conn.execute("ROLLBACK")
        raise
    else:
        conn.execute("COMMIT")


def fts5_available() -> bool:
    try:
        c = sqlite3.connect(":memory:")
        c.execute("CREATE VIRTUAL TABLE t USING fts5(a)")
        c.close()
        return True
    except sqlite3.Error:
        return False


def _migration_files() -> list[tuple[int, str, str]]:
    out: list[tuple[int, str, str]] = []
    for entry in resources.files("ali").joinpath("migrations").iterdir():
        name = entry.name
        if name.endswith(".sql"):
            version = int(name.split("_", 1)[0])
            out.append((version, name, entry.read_text(encoding="utf-8")))
    return sorted(out)


def migrate(conn: sqlite3.Connection) -> list[int]:
    """Apply pending migrations in order, each inside one transaction. Returns applied versions."""
    if not fts5_available():
        raise MigrationError("This SQLite build lacks FTS5, which ALI requires.")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS schema_migrations ("
        "version INTEGER PRIMARY KEY, name TEXT NOT NULL, checksum TEXT NOT NULL, applied_at TEXT NOT NULL)"
    )
    applied = {r["version"]: r["checksum"] for r in conn.execute("SELECT version, checksum FROM schema_migrations")}
    done: list[int] = []
    for version, name, sql in _migration_files():
        checksum = hashlib.sha256(sql.encode("utf-8")).hexdigest()
        if version in applied:
            if applied[version] != checksum:
                raise MigrationError(f"migration {name} was modified after being applied")
            continue
        # executescript() commits first, so wrap the script in its own explicit transaction.
        try:
            # SQL here comes only from migration files packaged with ALI; version/name/checksum are
            # derived from those files, never from user input.
            conn.executescript(
                "BEGIN IMMEDIATE;\n" + sql + "\n"
                f"INSERT INTO schema_migrations(version, name, checksum, applied_at) "  # nosec B608
                f"VALUES ({version}, '{name}', '{checksum}', '{utcnow()}');\nCOMMIT;"
            )
        except sqlite3.Error as exc:
            if conn.in_transaction:
                conn.execute("ROLLBACK")
            raise MigrationError(f"migration {name} failed: {exc}") from exc
        done.append(version)
    return done


def schema_version(conn: sqlite3.Connection) -> int:
    try:
        row = conn.execute("SELECT MAX(version) AS v FROM schema_migrations").fetchone()
    except sqlite3.Error:
        return 0
    return int(row["v"] or 0)


def open_db(settings: Settings, *, init: bool = True) -> sqlite3.Connection:
    settings.ensure_dirs()
    conn = connect(settings.db_path)
    if init:
        migrate(conn)
    return conn
