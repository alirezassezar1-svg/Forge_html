"""ALI - Adaptive Learning & Intelligence (Milestone 1: ingest -> index -> search -> cite -> verify)."""

__version__ = "0.1.0"
