"""Backup, restore and export.

Backup = zip with a consistent SQLite snapshot (SQLite online-backup API, safe while the app runs),
the preserved originals, and a manifest of SHA-256 hashes. Restore verifies the manifest, rejects
unsafe archive members, checks database integrity, and keeps the previous data under
backups/pre-restore-<timestamp>/ instead of deleting it."""

from __future__ import annotations

import hashlib
import json
import shutil
import sqlite3
import tempfile
import zipfile
from datetime import UTC, datetime
from pathlib import Path, PurePosixPath
from typing import Any

from ali import __version__
from ali.config import Settings
from ali.db import connect, migrate, schema_version

FORMAT = 1


class BackupError(Exception):
    pass


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def create_backup(settings: Settings, dest: Path | None = None, include_originals: bool = True) -> Path:
    settings.ensure_dirs()
    stamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
    dest = dest or settings.backups_dir / f"ali-backup-{stamp}.zip"
    dest.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=settings.home) as tmp:
        snap = Path(tmp) / "ali.db"
        src = connect(settings.db_path, readonly=True)
        try:
            dst = sqlite3.connect(snap)
            try:
                src.backup(dst)
            finally:
                dst.close()
            version = schema_version(src)
        finally:
            src.close()
        files: dict[str, dict[str, Any]] = {}
        files["db/ali.db"] = {"sha256": _sha256_file(snap), "size": snap.stat().st_size}
        originals: list[tuple[str, Path]] = []
        if include_originals and settings.originals_dir.exists():
            for f in sorted(settings.originals_dir.rglob("*")):
                if f.is_file() and ".tmp" not in f.name:
                    rel = "originals/" + f.relative_to(settings.originals_dir).as_posix()
                    files[rel] = {"sha256": _sha256_file(f), "size": f.stat().st_size}
                    originals.append((rel, f))
        manifest = {"format": FORMAT, "ali_version": __version__, "schema_version": version,
                    "created_at": datetime.now(UTC).isoformat(), "includes_originals": include_originals, "files": files}
        tmp_zip = dest.with_name(dest.name + ".partial")
        with zipfile.ZipFile(tmp_zip, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("manifest.json", json.dumps(manifest, indent=2))
            z.write(snap, "db/ali.db")
            for rel, f in originals:
                z.write(f, rel)
        tmp_zip.replace(dest)
    return dest


def _safe_member(name: str) -> bool:
    p = PurePosixPath(name)
    return not p.is_absolute() and ".." not in p.parts and "\\" not in name and (name == "manifest.json" or name.startswith(("db/", "originals/")))


def verify_backup(path: Path) -> dict[str, Any]:
    """Check archive structure and every file hash without extracting to the data directory."""
    try:
        z = zipfile.ZipFile(path)
    except (zipfile.BadZipFile, OSError) as exc:
        raise BackupError(f"not a valid backup archive: {exc}") from exc
    with z:
        names = z.namelist()
        if "manifest.json" not in names:
            raise BackupError("manifest.json missing")
        manifest = json.loads(z.read("manifest.json"))
        if manifest.get("format") != FORMAT:
            raise BackupError(f"unsupported backup format {manifest.get('format')!r}")
        declared = manifest["files"]
        for n in names:
            if not _safe_member(n):
                raise BackupError(f"unsafe archive member: {n!r}")
            if n != "manifest.json" and n not in declared:
                raise BackupError(f"archive member not in manifest: {n!r}")
        for n, meta in declared.items():
            if n not in names:
                raise BackupError(f"file listed in manifest is missing: {n!r}")
            info = z.getinfo(n)
            if info.file_size != meta["size"]:
                raise BackupError(f"size mismatch for {n!r}")
            h = hashlib.sha256()
            total = 0
            with z.open(n) as fh:
                for block in iter(lambda: fh.read(1 << 20), b""):
                    total += len(block)
                    if total > meta["size"]:
                        raise BackupError(f"{n!r} larger than declared (possible zip bomb)")
                    h.update(block)
            if h.hexdigest() != meta["sha256"]:
                raise BackupError(f"hash mismatch for {n!r}")
    return manifest


def restore_backup(settings: Settings, path: Path) -> dict[str, Any]:
    """Restore a verified backup. The application must be stopped. Existing data is moved aside."""
    manifest = verify_backup(path)
    settings.ensure_dirs()
    stamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
    staging = settings.home / f".restore-{stamp}"
    staging.mkdir()
    try:
        with zipfile.ZipFile(path) as z:
            for n in manifest["files"]:
                target = staging / n
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(n) as src, open(target, "wb") as out:
                    shutil.copyfileobj(src, out)
        check = sqlite3.connect(f"file:{(staging / 'db' / 'ali.db').as_posix()}?mode=ro", uri=True)
        try:
            integrity = check.execute("PRAGMA integrity_check").fetchone()[0]
            fk = check.execute("PRAGMA foreign_key_check").fetchall()
        finally:
            check.close()
        if integrity != "ok" or fk:
            raise BackupError(f"restored database failed integrity checks (integrity={integrity}, fk_violations={len(fk)})")
        aside = settings.backups_dir / f"pre-restore-{stamp}"
        aside.mkdir(parents=True, exist_ok=True)
        for p in (settings.db_path, Path(str(settings.db_path) + "-wal"), Path(str(settings.db_path) + "-shm")):
            if p.exists():
                shutil.move(str(p), aside / p.name)
        if settings.originals_dir.exists():
            shutil.move(str(settings.originals_dir), aside / "originals")
        shutil.move(str(staging / "db" / "ali.db"), settings.db_path)
        if (staging / "originals").exists():
            shutil.move(str(staging / "originals"), settings.originals_dir)
        else:
            settings.originals_dir.mkdir(parents=True, exist_ok=True)
    finally:
        shutil.rmtree(staging, ignore_errors=True)
    conn = connect(settings.db_path)
    try:
        applied = migrate(conn)
    finally:
        conn.close()
    return {"restored_from": str(path), "previous_data_moved_to": str(aside), "files": len(manifest["files"]),
            "migrations_applied_after_restore": applied}


def export_jsonl(conn: sqlite3.Connection, dest: Path, include_history: bool = False) -> int:
    """Portable knowledge export: one JSON object per document version (text + provenance)."""
    sql = ("SELECT d.id AS document_id, d.source_key, d.kind, d.title AS doc_title, v.id AS version_id, v.version_no, "
           "v.is_current, v.content_hash, v.text_hash, v.url, v.retrieved_at, v.language, v.published_at, v.author, "
           "v.extraction_status, v.extraction_warnings, v.text FROM document_versions v "
           "JOIN documents d ON d.id=v.document_id")
    if not include_history:
        sql += " WHERE v.is_current=1"
    n = 0
    with open(dest, "w", encoding="utf-8") as out:
        for r in conn.execute(sql + " ORDER BY d.id, v.version_no"):
            obj = {k: r[k] for k in r.keys()}
            obj["extraction_warnings"] = json.loads(obj["extraction_warnings"])
            out.write(json.dumps(obj, ensure_ascii=False) + "\n")
            n += 1
    return n
