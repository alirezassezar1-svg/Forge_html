"use strict";
const I18N = {
  en: {search:"Search",library:"Library",add:"Add",jobs:"Jobs",system:"System",q:"Search your knowledge…",go:"Search",
    empty:"No results.",nodocs:"No documents yet.",upload:"Upload files",urls:"URLs, one per line",ingest:"Ingest",
    loading:"Working…",verify:"Verify citation",deep:"Verify against original",close:"Close",del:"Delete",confirmDel:"Delete this document and all derived data?",
    health:"Health check",backup:"Create backup",reindex:"Rebuild index",login:"Access token",signin:"Sign in",stats:"Statistics",
    open:"Open passage",cur:"current",old:"historical",err:"Error",done:"Done",mode:"Mode",page:"page"},
  fa: {search:"جستجو",library:"کتابخانه",add:"افزودن",jobs:"کارها",system:"سیستم",q:"در دانش خود جستجو کنید…",go:"جستجو",
    empty:"نتیجه‌ای یافت نشد.",nodocs:"هنوز سندی وجود ندارد.",upload:"بارگذاری فایل",urls:"آدرس‌ها، هر خط یکی",ingest:"افزودن",
    loading:"در حال انجام…",verify:"تأیید ارجاع",deep:"تأیید با فایل اصلی",close:"بستن",del:"حذف",confirmDel:"این سند و همه داده‌های مشتق‌شده حذف شود؟",
    health:"بررسی سلامت",backup:"ساخت پشتیبان",reindex:"بازسازی ایندکس",login:"توکن دسترسی",signin:"ورود",stats:"آمار",
    open:"نمایش بخش",cur:"فعلی",old:"تاریخی",err:"خطا",done:"انجام شد",mode:"حالت",page:"صفحه"}
};
let lang = "en", view = "search";
try { lang = localStorage.getItem("ali_lang") || (navigator.language||"").startsWith("fa") ? "fa" : "en"; } catch (e) { /* storage unavailable */ }
const t = k => I18N[lang][k] || k;
const $ = s => document.querySelector(s);
function el(tag, props = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") n.className = v; else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) n.setAttribute(k, v);
  }
  for (const c of kids.flat()) n.append(c instanceof Node ? c : document.createTextNode(String(c)));
  return n;
}
function toast(msg, cls = "") { const d = el("div", {class: cls}, msg); $("#toast").append(d); setTimeout(() => d.remove(), 4500); }
async function api(path, opts = {}) {
  const o = {credentials: "same-origin", headers: {"X-ALI-Request": "1"}, ...opts};
  if (opts.json !== undefined) { o.method = o.method || "POST"; o.body = JSON.stringify(opts.json); o.headers["Content-Type"] = "application/json"; delete o.json; }
  const r = await fetch(path, o);
  let body = null; try { body = await r.json(); } catch (e) { /* non-JSON */ }
  if (r.status === 401) { showLogin(); throw new Error("401"); }
  if (!r.ok) throw new Error((body && body.detail && (typeof body.detail === "string" ? body.detail : JSON.stringify(body.detail))) || ("HTTP " + r.status));
  return body;
}
async function busy(btn, fn) {
  btn.disabled = true; const old = btn.textContent; btn.textContent = t("loading");
  try { return await fn(); } catch (e) { if (e.message !== "401") toast(t("err") + ": " + e.message, "er"); } finally { btn.disabled = false; btn.textContent = old; }
}
function hl(text, spans) {
  const f = document.createDocumentFragment(); let p = 0;
  for (const [s, e] of (spans || []).slice().sort((a, b) => a[0] - b[0])) {
    if (s < p || e > text.length) continue;
    f.append(text.slice(p, s), el("mark", {}, text.slice(s, e))); p = e;
  }
  f.append(text.slice(p)); return f;
}
const dlg = $("#dlg");
$("#dlg-close").addEventListener("click", () => dlg.close());
function openDlg(...nodes) { $("#dlg-body").replaceChildren(...nodes); $("#dlg-close").textContent = t("close"); dlg.showModal(); }

function applyLang() {
  document.documentElement.lang = lang; document.documentElement.dir = lang === "fa" ? "rtl" : "ltr";
  $("#lang").textContent = lang === "fa" ? "EN" : "فا";
  const tabs = $("#tabs"); tabs.replaceChildren(...["search", "library", "add", "jobs", "system"].map(v =>
    el("button", {role: "tab", "aria-selected": String(v === view), onclick: () => { view = v; applyLang(); render(); }}, t(v))));
}
$("#lang").addEventListener("click", () => { lang = lang === "fa" ? "en" : "fa"; try { localStorage.setItem("ali_lang", lang); } catch (e) { /* ignore */ } applyLang(); render(); });

function showLogin() {
  const inp = el("input", {type: "password", autocomplete: "current-password", "aria-label": t("login")});
  const btn = el("button", {class: "primary", type: "button"}, t("signin"));
  btn.addEventListener("click", () => busy(btn, async () => { await api("/api/login", {json: {token: inp.value}}); inp.value = ""; render(); }));
  $("#main").replaceChildren(el("div", {class: "card"}, el("div", {class: "row"}, inp, btn)));
}

async function renderSearch() {
  const q = el("input", {type: "search", placeholder: t("q"), "aria-label": t("search")});
  const mode = el("select", {"aria-label": t("mode")}, ...["auto", "all", "any", "phrase"].map(m => el("option", {value: m}, m)));
  const btn = el("button", {class: "primary", type: "button"}, t("go"));
  const out = el("div");
  const run = () => busy(btn, async () => {
    if (!q.value.trim()) return;
    const r = await api(`/api/search?q=${encodeURIComponent(q.value)}&mode=${mode.value}&limit=20`);
    out.replaceChildren(el("div", {class: "meta"}, `${r.hits.length} · ${r.diagnostics.mode_used} · ${r.diagnostics.latency_ms} ms`),
      ...(r.hits.length ? r.hits.map(hitCard) : [el("div", {class: "empty"}, t("empty"))]));
  });
  btn.addEventListener("click", run); q.addEventListener("keydown", e => { if (e.key === "Enter") run(); });
  $("#main").replaceChildren(el("div", {class: "row"}, q, mode, btn), out);
}
function hitCard(h) {
  const c = h.citation;
  return el("div", {class: "card"},
    el("strong", {}, h.title || h.source_key),
    el("div", {class: "meta"}, h.publisher || "", h.locator || "", h.page ? `${t("page")} ${h.page}` : "",
      el("span", {class: h.is_current ? "ok" : "wr"}, h.is_current ? t("cur") : t("old")), `v${h.version_no}`),
    el("div", {class: "snip", dir: "auto"}, hl(h.text, h.highlights)),
    el("div", {class: "row"}, el("button", {type: "button", onclick: () => openCitation(c)}, t("open"))));
}
async function openCitation(c) {
  const p = await api(`/api/passage?version_id=${c.version_id}&start=${c.start_char}&end=${c.end_char}&context=300`).catch(e => { toast(e.message, "er"); return null; });
  if (!p) return;
  const res = el("div");
  const mk = deep => { const b = el("button", {type: "button"}, deep ? t("deep") : t("verify"));
    b.addEventListener("click", () => busy(b, async () => {
      const r = await api(`/api/citations/verify?deep=${deep}`, {json: c});
      res.replaceChildren(el("div", {class: r.ok ? "ok" : "er"}, r.ok ? "✔ OK" : "✖ FAILED"),
        el("table", {}, ...r.checks.map(k => el("tr", {}, el("td", {class: k.ok ? "ok" : "er"}, k.ok ? "✔" : "✖"), el("td", {}, k.check), el("td", {}, k.detail || "")))));
    })); return b; };
  openDlg(el("h2", {}, p.title || p.source_key),
    el("div", {class: "meta"}, `doc ${p.document_id} · v${p.version_no} · chars ${p.start_char}-${p.end_char}`, p.is_current ? t("cur") : t("old")),
    el("div", {class: "snip", dir: "auto"}, p.before, el("mark", {}, p.passage), p.after),
    el("div", {class: "row"}, mk(false), mk(true)), res);
}

async function renderLibrary() {
  const docs = await api("/api/documents");
  const main = $("#main");
  if (!docs.length) return main.replaceChildren(el("div", {class: "empty"}, t("nodocs")));
  main.replaceChildren(...docs.map(d => el("div", {class: "card"}, el("strong", {dir: "auto"}, d.title || d.source_key),
    el("div", {class: "meta"}, d.publisher || "", d.language || "", d.kind || "", `${d.n_chunks ?? ""}`),
    el("div", {class: "row"},
      el("button", {type: "button", class: "danger", onclick: async ev => {
        if (!confirm(t("confirmDel"))) return;
        await busy(ev.target, async () => { await api(`/api/documents/${d.id}`, {method: "DELETE"}); toast(t("done"), "ok"); renderLibrary(); });
      }}, t("del"))))));
}

function renderAdd() {
  const files = el("input", {type: "file", multiple: "multiple", "aria-label": t("upload")});
  const ub = el("button", {class: "primary", type: "button"}, t("upload"));
  const urls = el("textarea", {"aria-label": t("urls"), placeholder: t("urls"), dir: "ltr"});
  const ib = el("button", {class: "primary", type: "button"}, t("ingest"));
  const out = el("div");
  const show = rs => out.replaceChildren(...rs.map(r => el("div", {class: "card"},
    el("span", {class: r.outcome === "failed" ? "er" : "ok"}, r.outcome), " ", r.filename || r.url || "", r.error ? ` — ${r.error}` : "",
    r.warnings && r.warnings.length ? el("div", {class: "meta wr"}, r.warnings.join("; ")) : "")));
  ub.addEventListener("click", () => busy(ub, async () => {
    if (!files.files.length) return; const fd = new FormData(); for (const f of files.files) fd.append("files", f);
    show(await api("/api/upload", {method: "POST", body: fd})); files.value = "";
  }));
  ib.addEventListener("click", () => busy(ib, async () => {
    const list = urls.value.split("\n").map(s => s.trim()).filter(Boolean); if (!list.length) return;
    show(await api("/api/ingest-url", {json: {urls: list}}));
  }));
  $("#main").replaceChildren(el("div", {class: "card"}, files, el("div", {class: "row"}, ub)),
    el("div", {class: "card"}, urls, el("div", {class: "row"}, ib)), out);
}

async function renderJobs() {
  const js = await api("/api/jobs");
  $("#main").replaceChildren(...(js.length ? js.map(j => el("div", {class: "card"},
    el("span", {class: j.status === "failed" ? "er" : j.status === "succeeded" ? "ok" : "wr"}, j.status), ` #${j.id} ${j.kind} `,
    el("span", {class: "meta", dir: "auto"}, j.input_ref || ""),
    ...(j.errors || []).map(e => el("div", {class: "er meta"}, `${e.stage}: ${e.message}`)))) : [el("div", {class: "empty"}, t("empty"))]));
}

async function renderSystem() {
  const [st, h] = await Promise.all([api("/api/stats"), api("/api/health")]);
  const hb = el("button", {type: "button"}, t("health")), bb = el("button", {type: "button"}, t("backup")), rb = el("button", {type: "button"}, t("reindex"));
  const hout = el("div");
  const showHealth = r => hout.replaceChildren(el("div", {class: r.ok ? "ok" : "er"}, r.ok ? "✔ healthy" : "✖ problems"),
    el("table", {}, ...r.checks.map(c => el("tr", {}, el("td", {class: c.ok ? "ok" : (c.severity === "warning" ? "wr" : "er")}, c.ok ? "✔" : "✖"), el("td", {}, c.name), el("td", {}, c.detail)))));
  showHealth(h);
  hb.addEventListener("click", () => busy(hb, async () => showHealth(await api("/api/health?deep=true"))));
  bb.addEventListener("click", () => busy(bb, async () => { const r = await api("/api/backup", {json: {}}); toast(`${t("done")}: ${r.file} (${r.files} files, verified)`, "ok"); }));
  rb.addEventListener("click", () => busy(rb, async () => { await api("/api/reindex", {json: {}}); toast(t("done"), "ok"); }));
  $("#main").replaceChildren(el("div", {class: "card"}, el("strong", {}, t("stats")), el("pre", {}, JSON.stringify(st, null, 2))),
    el("div", {class: "row"}, hb, bb, rb), hout);
}

const VIEWS = {search: renderSearch, library: renderLibrary, add: renderAdd, jobs: renderJobs, system: renderSystem};
async function render() {
  try {
    const s = await api("/api/session");
    if (s.auth_required && !s.authenticated) return showLogin();
    await VIEWS[view]();
  } catch (e) { if (e.message !== "401") $("#main").replaceChildren(el("div", {class: "card er"}, t("err") + ": " + e.message)); }
}
applyLang(); render();
