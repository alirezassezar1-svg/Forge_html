"""Citations and their verification.

A citation is a plain JSON-serialisable dict that pins an exact passage:
(version_id, start_char, end_char) into document_versions.text, the quote itself, and the hash of the
preserved original. `verify_citation` re-checks every claim against the database and the stored
original file, returning each check separately (no short-circuit, no silent pass)."""

from __future__ import annotations

import sqlite3
from typing import Any

from ali import hashing, textnorm
from ali.config import Settings
from ali.extract import detect_adapter, extract


def build_citation(row: sqlite3.Row, rel_spans: list[list[int]], query_terms: list[str]) -> dict[str, Any]:
    base = int(row["start_char"])
    return {
        "document_id": row["document_id"],
        "version_id": row["version_id"],
        "version_no": row["version_no"],
        "chunk_id": row["chunk_id"],
        "start_char": base,
        "end_char": int(row["end_char"]),
        "page": row["page_start"],
        "locator": row["locator"],
        "quote": row["text"],
        "highlights": [[base + s, base + e] for s, e in rel_spans],
        "query_terms": query_terms,
        "content_hash": row["content_hash"],
        "text_hash": row["text_hash"],
        "source_key": row["source_key"],
        "url": row["version_url"] or row["canonical_url"],
        "retrieved_at": row["retrieved_at"],
        "is_current": bool(row["is_current"]),
    }


def _check(name: str, ok: bool, detail: str = "") -> dict[str, Any]:
    return {"check": name, "ok": bool(ok), "detail": detail}


def verify_citation(
    conn: sqlite3.Connection, settings: Settings, citation: dict[str, Any], deep: bool = False
) -> dict[str, Any]:
    """Verify that a citation resolves to the stated passage. `deep` also re-extracts the preserved
    original and compares the extracted text hash (detects extraction drift or file tampering)."""
    checks: list[dict[str, Any]] = []
    try:
        vid = int(citation["version_id"])
        start, end = int(citation["start_char"]), int(citation["end_char"])
        quote = str(citation["quote"])
    except (KeyError, TypeError, ValueError) as exc:
        return {"ok": False, "checks": [_check("citation_well_formed", False, f"missing/invalid field: {exc}")],
                "is_current": None}
    checks.append(_check("citation_well_formed", 0 <= start < end))
    v = conn.execute(
        "SELECT id, document_id, version_no, is_current, content_hash, text_hash, text, original_path, adapter, "
        "original_filename, url FROM document_versions WHERE id=?", (vid,)).fetchone()
    checks.append(_check("version_exists", v is not None, f"version_id={vid}"))
    if v is None:
        return {"ok": False, "checks": checks, "is_current": None}
    checks.append(_check("document_matches", citation.get("document_id") in (None, v["document_id"]),
                         f"document_id={v['document_id']}"))
    checks.append(_check("content_hash_matches_version", citation.get("content_hash") in (None, v["content_hash"])))
    text = v["text"]
    checks.append(_check("range_inside_text", end <= len(text), f"len(text)={len(text)}"))
    checks.append(_check("quote_matches_text", text[start:end] == quote, "version.text[start:end] == quote"))
    hl_ok = True
    for h in citation.get("highlights") or []:
        try:
            hs, he = int(h[0]), int(h[1])
        except (TypeError, ValueError, IndexError):
            hl_ok = False
            continue
        if not (start <= hs < he <= end):
            hl_ok = False
            continue
        if citation.get("query_terms"):
            toks = set(textnorm.tokenize(textnorm.normalize(text[hs:he])))
            if not toks & set(citation["query_terms"]):
                hl_ok = False
    checks.append(_check("highlights_inside_quote_and_match_terms", hl_ok))
    ck = citation.get("chunk_id")
    if ck is not None:
        row = conn.execute("SELECT version_id, start_char, end_char FROM chunks WHERE id=?", (ck,)).fetchone()
        same = bool(row and row["version_id"] == vid and row["start_char"] == start and row["end_char"] == end)
        # informational: chunk ids are derived data and change after `ali reindex`
        checks.append({"check": "chunk_id_still_resolves", "ok": True, "informational": True,
                       "detail": "yes" if same else "chunk id changed or removed (index rebuilt); offsets still verified"})
    orig = settings.originals_dir / v["original_path"] if v["original_path"] else None
    if orig is None or not orig.exists():
        checks.append(_check("original_file_present", False, "preserved original is missing"))
        data = None
    else:
        data = orig.read_bytes()
        checks.append(_check("original_file_present", True))
        checks.append(_check("original_hash_matches", hashing.sha256_bytes(data) == v["content_hash"],
                             "sha256(original file) == content_hash"))
    if deep and data is not None:
        adapter = v["adapter"] if v["adapter"] in ("txt", "md", "csv", "json", "html", "pdf") else detect_adapter(
            v["original_filename"], None, data[:4096]) or "txt"
        try:
            again = extract(data, adapter, v["original_filename"], base_url=v["url"], max_pdf_pages=settings.max_pdf_pages)
            same_text = hashing.sha256_text(again.text) == v["text_hash"]
            checks.append(_check("reextraction_reproduces_text", same_text, "sha256(re-extracted text) == text_hash"))
        except Exception as exc:  # noqa: BLE001
            checks.append(_check("reextraction_reproduces_text", False, f"{type(exc).__name__}: {exc}"))
    ok = all(c["ok"] for c in checks)
    return {"ok": ok, "checks": checks, "is_current": bool(v["is_current"]),
            "note": None if v["is_current"] else "this passage belongs to a superseded (historical) version"}
