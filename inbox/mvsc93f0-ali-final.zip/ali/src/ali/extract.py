"""Extraction adapters: bytes -> ExtractedDocument. Each adapter records warnings instead of silently
dropping content. Supported: txt, md, csv, json, html, pdf (text layer). Scanned PDFs are reported as
`needs_ocr` (OCR adapter arrives in a later milestone)."""

from __future__ import annotations

import csv
import io
import json
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any
from urllib.parse import urljoin, urlsplit

from bs4 import BeautifulSoup, Comment, Tag
from charset_normalizer import from_bytes

SUPPORTED_ADAPTERS = ("txt", "md", "csv", "json", "html", "pdf")


class ExtractionError(Exception):
    pass


@dataclass
class ExtractedDocument:
    text: str
    adapter: str
    title: str | None = None
    status: str = "ok"  # ok | partial | failed | needs_ocr
    quality: float = 1.0
    warnings: list[str] = field(default_factory=list)
    page_spans: list[tuple[int, int, int]] | None = None  # (start, end, page)
    metadata: dict[str, Any] = field(default_factory=dict)
    links: list[dict[str, Any]] = field(default_factory=list)
    author: str | None = None
    published_at: str | None = None
    publisher_name: str | None = None
    canonical_url: str | None = None


# ------------------------------------------------------------------ type detection
_EXT = {
    ".txt": "txt", ".text": "txt", ".md": "md", ".markdown": "md", ".csv": "csv", ".tsv": "csv",
    ".json": "json", ".html": "html", ".htm": "html", ".xhtml": "html", ".pdf": "pdf",
}
_CT = {
    "text/plain": "txt", "text/markdown": "md", "text/csv": "csv", "application/json": "json",
    "text/html": "html", "application/xhtml+xml": "html", "application/pdf": "pdf",
}


def detect_adapter(filename: str | None, content_type: str | None, head: bytes) -> str | None:
    if head.startswith(b"%PDF-"):
        return "pdf"
    ct = (content_type or "").split(";")[0].strip().lower()
    lowered = head[:2048].lstrip().lower()
    if lowered.startswith((b"<!doctype html", b"<html")) or (ct == "text/html"):
        return "html"
    if filename:
        dot = filename.rfind(".")
        if dot != -1 and filename[dot:].lower() in _EXT:
            return _EXT[filename[dot:].lower()]
    if ct in _CT:
        return _CT[ct]
    if ct.startswith("text/"):
        return "txt"
    return None


# ------------------------------------------------------------------ helpers
_CTRL_RE = re.compile(r"[\x00-\x08\x0b\x0e-\x1f\x7f]")


def decode_text(data: bytes, warnings: list[str], meta: dict[str, Any]) -> str:
    if data.startswith(b"\xef\xbb\xbf"):
        data = data[3:]
        enc, text = "utf-8-sig", None
    else:
        enc, text = None, None
    if enc is None:
        try:
            text = data.decode("utf-8")
            enc = "utf-8"
        except UnicodeDecodeError:
            best = from_bytes(data).best()
            if best is not None:
                text, enc = str(best), best.encoding
                warnings.append(f"decoded using detected encoding {best.encoding}")
            else:
                text, enc = data.decode("utf-8", errors="replace"), "utf-8 (lossy)"
                warnings.append("could not detect encoding; undecodable bytes replaced with U+FFFD")
    elif text is None:
        text = data.decode("utf-8", errors="replace")
    meta["encoding"] = enc
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    cleaned = _CTRL_RE.sub("", text)
    if len(cleaned) != len(text):
        warnings.append(f"removed {len(text) - len(cleaned)} control characters")
    return cleaned


def _quality_from_replacements(text: str, warnings: list[str]) -> float:
    n = text.count("�")
    if n:
        warnings.append(f"{n} replacement characters present")
        return max(0.0, 1.0 - min(1.0, n / max(1, len(text)) * 20))
    return 1.0


# ------------------------------------------------------------------ adapters
def extract_text(data: bytes, filename: str | None, adapter: str = "txt") -> ExtractedDocument:
    warnings: list[str] = []
    meta: dict[str, Any] = {}
    text = decode_text(data, warnings, meta)
    title = None
    if adapter == "md":
        m = re.search(r"^\s{0,3}#\s+(.+?)\s*#*\s*$", text, re.MULTILINE)
        if m:
            title = m.group(1).strip()
    if not title and filename:
        title = filename.rsplit("/", 1)[-1].rsplit("\\", 1)[-1].rsplit(".", 1)[0] or None
    quality = _quality_from_replacements(text, warnings)
    status = "ok" if text.strip() else "failed"
    if not text.strip():
        warnings.append("document contains no text")
        quality = 0.0
    return ExtractedDocument(text, adapter, title, status, quality, warnings, metadata=meta)


def extract_json(data: bytes, filename: str | None) -> ExtractedDocument:
    warnings: list[str] = []
    meta: dict[str, Any] = {}
    raw = decode_text(data, warnings, meta)
    try:
        obj = json.loads(raw)
    except json.JSONDecodeError as exc:
        doc = extract_text(data, filename, "txt")
        doc.adapter = "json"
        doc.status = "partial"
        doc.quality = min(doc.quality, 0.5)
        doc.warnings.append(f"invalid JSON ({exc.msg} at line {exc.lineno}); indexed as plain text")
        return doc
    text = json.dumps(obj, ensure_ascii=False, indent=2)
    title = obj.get("title") if isinstance(obj, dict) and isinstance(obj.get("title"), str) else None
    if not title and filename:
        title = filename.rsplit("/", 1)[-1].rsplit(".", 1)[0] or None
    meta["json_root_type"] = type(obj).__name__
    return ExtractedDocument(text, "json", title, "ok", _quality_from_replacements(text, warnings), warnings, metadata=meta)


def extract_csv(data: bytes, filename: str | None) -> ExtractedDocument:
    warnings: list[str] = []
    meta: dict[str, Any] = {}
    raw = decode_text(data, warnings, meta)
    sample = raw[:8192]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        delim = dialect.delimiter
    except csv.Error:
        delim = "\t" if (filename or "").lower().endswith(".tsv") else ","
        warnings.append(f"delimiter not detected; assumed {delim!r}")
    csv.field_size_limit(1_000_000)
    rows = list(csv.reader(io.StringIO(raw, newline=""), delimiter=delim))
    rows = [r for r in rows if any(c.strip() for c in r)]
    if not rows:
        return ExtractedDocument("", "csv", None, "failed", 0.0, warnings + ["CSV has no rows"], metadata=meta)
    header = [h.strip() or f"col{i + 1}" for i, h in enumerate(rows[0])]
    lines = [f"columns: {' | '.join(header)}"]
    ragged = 0
    for n, row in enumerate(rows[1:], start=1):
        if len(row) != len(header):
            ragged += 1
        parts = []
        for i, cell in enumerate(row):
            cell = " ".join(cell.split())
            if cell:
                name = header[i] if i < len(header) else f"extra{i + 1 - len(header)}"
                parts.append(f"{name}: {cell}")
        lines.append(f"[row {n}] " + "; ".join(parts))
    quality = 1.0
    status = "ok"
    if ragged:
        warnings.append(f"{ragged} of {len(rows) - 1} rows have a column count different from the header")
        quality = max(0.3, 1.0 - ragged / max(1, len(rows) - 1))
        status = "partial"
    meta.update({"delimiter": delim, "columns": header, "rows": len(rows) - 1})
    title = filename.rsplit("/", 1)[-1].rsplit(".", 1)[0] if filename else None
    return ExtractedDocument("\n".join(lines), "csv", title, status, quality, warnings, metadata=meta)


def extract_pdf(data: bytes, filename: str | None, max_pages: int = 2000) -> ExtractedDocument:
    from pypdf import PdfReader
    from pypdf.errors import PyPdfError

    warnings: list[str] = []
    try:
        reader = PdfReader(io.BytesIO(data), strict=False)
        if reader.is_encrypted:
            try:
                ok = reader.decrypt("")
            except Exception:  # noqa: BLE001 - pypdf raises varied errors on bad crypto
                ok = 0
            if not ok:
                return ExtractedDocument("", "pdf", None, "failed", 0.0, ["PDF is password protected"])
            warnings.append("PDF was encrypted with an empty password")
        n_pages = len(reader.pages)
    except (PyPdfError, ValueError, OSError, KeyError, TypeError, AttributeError, RecursionError) as exc:
        raise ExtractionError(f"malformed PDF: {exc}") from exc
    if n_pages > max_pages:
        warnings.append(f"PDF has {n_pages} pages; only the first {max_pages} were extracted")
        n_pages_used = max_pages
    else:
        n_pages_used = n_pages
    parts: list[str] = []
    spans: list[tuple[int, int, int]] = []
    pos = 0
    pages_with_text = 0
    for i in range(n_pages_used):
        try:
            page_text = reader.pages[i].extract_text() or ""
        except Exception as exc:  # noqa: BLE001 - one bad page must not kill the document
            page_text = ""
            warnings.append(f"page {i + 1}: text extraction failed ({type(exc).__name__})")
        page_text = page_text.replace("\r\n", "\n").replace("\r", "\n")
        page_text = _CTRL_RE.sub("", page_text).strip("\n")
        if len(page_text.strip()) >= 20:
            pages_with_text += 1
        elif not page_text.strip():
            warnings.append(f"page {i + 1}: no text layer")
        if parts:
            pos += 2  # "\n\n" separator
        spans.append((pos, pos + len(page_text), i + 1))
        parts.append(page_text)
        pos += len(page_text)
    text = "\n\n".join(parts)
    md = reader.metadata
    title = str(md.title).strip() if md and md.title else None
    author = str(md.author).strip() if md and md.author else None
    meta: dict[str, Any] = {"pages": n_pages}
    if md and md.creation_date:
        try:
            meta["created"] = md.creation_date.isoformat()
        except (ValueError, AttributeError, OverflowError):
            meta["created_unparsed"] = True  # malformed PDF date: recorded, not fatal
    quality = pages_with_text / n_pages_used if n_pages_used else 0.0
    if pages_with_text == 0:
        status = "needs_ocr"
        warnings.append("no extractable text layer; this looks like a scanned PDF and needs OCR")
    elif pages_with_text < n_pages_used:
        status = "partial"
    else:
        status = "ok"
    if not title and filename:
        title = filename.rsplit("/", 1)[-1].rsplit(".", 1)[0] or None
    return ExtractedDocument(text, "pdf", title, status, round(quality, 3), warnings, spans, meta, author=author)


# ------------------------------------------------------------------ HTML
_BLOCK = {
    "p", "div", "section", "article", "main", "li", "ul", "ol", "h1", "h2", "h3", "h4", "h5", "h6",
    "tr", "table", "blockquote", "pre", "figure", "figcaption", "dl", "dt", "dd", "hr", "details", "summary",
}
_DROP_TAGS = ["script", "style", "noscript", "template", "svg", "iframe", "canvas", "object", "embed", "head"]
_BOILER_TAGS = ["nav", "aside", "footer", "form", "button", "select", "dialog"]
_BOILER_ROLES = {"navigation", "banner", "contentinfo", "complementary", "search"}
_BOILER_TOKENS = {
    "nav", "navbar", "navigation", "menu", "sidebar", "footer", "cookie", "cookies", "consent",
    "advert", "ads", "ad", "popup", "modal", "share", "social", "breadcrumb", "breadcrumbs", "newsletter",
}


def _boiler_by_attrs(tag: Tag) -> bool:
    if not isinstance(tag, Tag) or tag.attrs is None:
        return False
    role = (tag.get("role") or "")
    if isinstance(role, str) and role.lower() in _BOILER_ROLES:
        return True
    cls = tag.get("class") or []
    cls = cls if isinstance(cls, list) else [cls]
    toks = set()
    for v in [*cls, tag.get("id") or ""]:
        toks.update(t for t in re.split(r"[^a-z0-9]+", str(v).lower()) if t)
    return bool(toks & _BOILER_TOKENS)


def _norm_url(url: str) -> str:
    parts = urlsplit(url.strip())
    return parts._replace(fragment="").geturl()


def _meta(soup: BeautifulSoup, *names: str) -> str | None:
    for name in names:
        tag = soup.find("meta", attrs={"property": name}) or soup.find("meta", attrs={"name": name})
        if tag and tag.get("content"):
            return str(tag["content"]).strip() or None
    return None


def _text_of(root: Tag) -> str:
    for br in root.find_all("br"):
        br.replace_with("\n")
    for t in root.find_all(["td", "th"]):
        t.insert_before(" ")
        t.insert_after(" | ")
    for t in root.find_all(_BLOCK):
        t.insert_before("\n")
        t.insert_after("\n")
    raw = root.get_text()
    lines = [re.sub(r"[ \t  ]+", " ", ln).strip() for ln in raw.split("\n")]
    lines = [re.sub(r"(\s*\|)+$", "", ln).strip() for ln in lines]
    text = "\n".join(lines)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def extract_html(data: bytes, filename: str | None, base_url: str | None = None) -> ExtractedDocument:
    warnings: list[str] = []
    meta: dict[str, Any] = {}
    raw = decode_text(data, warnings, meta)
    soup = BeautifulSoup(raw, "lxml")
    for c in soup.find_all(string=lambda s: isinstance(s, Comment)):
        c.extract()

    title = None
    if soup.title and soup.title.string:
        title = " ".join(soup.title.string.split())
    og_title = _meta(soup, "og:title")
    if not title and og_title:
        title = og_title
    if not title:
        h1 = soup.find("h1")
        if h1:
            title = " ".join(h1.get_text().split()) or None

    publisher = _meta(soup, "og:site_name", "application-name")
    author = _meta(soup, "author", "article:author", "dc.creator")
    published = _meta(soup, "article:published_time", "date", "pubdate", "dc.date", "dc.date.issued", "datePublished")
    if not published:
        t = soup.find("time", attrs={"datetime": True})
        if t:
            published = str(t["datetime"]).strip()
    canonical = None
    link = soup.find("link", rel=lambda v: v and "canonical" in (v if isinstance(v, list) else [v]))
    if link and link.get("href"):
        canonical = _norm_url(urljoin(base_url or "", str(link["href"])))
    html_tag = soup.find("html")
    declared_lang = str(html_tag.get("lang")) if html_tag and html_tag.get("lang") else None
    if declared_lang:
        meta["declared_lang"] = declared_lang
    description = _meta(soup, "description", "og:description")
    if description:
        meta["description"] = description[:500]

    body = soup.body or soup
    total_before = len(" ".join(body.get_text().split()))

    # Choose content root, with a guard against teaser <article>s that hide the real content.
    root: Tag = body
    used_fallback = False
    for sel in ("article", "main", "[role=main]"):
        cand = body.select_one(sel)
        if cand is not None:
            if len(" ".join(cand.get_text().split())) >= 0.3 * total_before or total_before < 500:
                root = cand
            else:
                used_fallback = True
            break

    # Links first (before boilerplate removal), flag whether they sit inside the content root.
    base_host = urlsplit(base_url).hostname if base_url else None
    links: list[dict[str, Any]] = []
    for a in body.find_all("a", href=True)[:5000]:
        href = str(a["href"]).strip()
        if not href or href.startswith(("#", "javascript:", "mailto:", "tel:", "data:")):
            continue
        absolute = _norm_url(urljoin(base_url or "", href))
        sp = urlsplit(absolute)
        if sp.scheme not in ("http", "https"):
            continue
        host = sp.hostname
        in_content = root is body or root in a.parents
        rel = a.get("rel")
        links.append({
            "target_url": absolute,
            "target_host": host,
            "anchor_text": " ".join(a.get_text().split())[:300],
            "rel": " ".join(rel) if isinstance(rel, list) else (rel or None),
            "is_external": bool(base_host and host and host.removeprefix("www.") != base_host.removeprefix("www.")),
            "in_content": bool(in_content),
        })
        if len(links) >= 2000:
            warnings.append("more than 2000 links; only the first 2000 were recorded")
            break

    removed = 0
    for tag in root.find_all(_DROP_TAGS):
        tag.decompose()
        removed += 1
    for tag in root.find_all(_BOILER_TAGS):
        tag.decompose()
        removed += 1
    for tag in list(root.find_all(True)):
        if tag.parent is not None and tag is not root and _boiler_by_attrs(tag):
            tag.decompose()
            removed += 1
    meta["boilerplate_elements_removed"] = removed
    text = _text_of(root)
    if root is not body:
        meta["content_root"] = root.name
    if used_fallback:
        warnings.append("article/main element looked like a teaser; used the whole body")

    quality = 1.0
    status = "ok"
    if len(text) < 200:
        quality = 0.4
        status = "partial" if text else "failed"
        warnings.append("very little text extracted; the page may be rendered by JavaScript or blocked")
    if total_before and len(text) / total_before < 0.2:
        warnings.append("more than 80% of page text was classified as boilerplate; verify extraction")
        quality = min(quality, 0.7)
    quality = min(quality, _quality_from_replacements(text, warnings))
    if published:
        published = _normalise_date(published)
    return ExtractedDocument(
        text, "html", title, status, quality, warnings, None, meta, links, author, published, publisher, canonical
    )


def _normalise_date(value: str) -> str | None:
    value = value.strip()
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).isoformat()
    except ValueError:
        pass
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", value)
    return m.group(0) if m else None


def extract(data: bytes, adapter: str, filename: str | None = None, base_url: str | None = None, max_pdf_pages: int = 2000) -> ExtractedDocument:
    if adapter in ("txt", "md"):
        return extract_text(data, filename, adapter)
    if adapter == "csv":
        return extract_csv(data, filename)
    if adapter == "json":
        return extract_json(data, filename)
    if adapter == "html":
        return extract_html(data, filename, base_url)
    if adapter == "pdf":
        return extract_pdf(data, filename, max_pdf_pages)
    raise ExtractionError(f"no adapter for {adapter!r}")
