-- ALI schema v1 (Milestone 1). The database is the authoritative record;
-- chunks_fts is DERIVED data and can be rebuilt from chunks (ali reindex).

CREATE TABLE publishers (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  domain TEXT
);

CREATE TABLE documents (
  id INTEGER PRIMARY KEY,
  source_key TEXT NOT NULL UNIQUE,         -- canonical URL or file:<name>; identity for updates
  kind TEXT NOT NULL CHECK (kind IN ('file','url')),
  title TEXT,
  publisher_id INTEGER REFERENCES publishers(id) ON DELETE SET NULL,
  canonical_url TEXT,
  original_filename TEXT,
  language TEXT,
  current_version_id INTEGER,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE document_versions (
  id INTEGER PRIMARY KEY,
  document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  version_no INTEGER NOT NULL,
  is_current INTEGER NOT NULL DEFAULT 1,
  content_hash TEXT NOT NULL,              -- sha256 of ORIGINAL bytes
  text_hash TEXT NOT NULL,                 -- sha256 of extracted_text (UTF-8)
  mime_type TEXT,
  original_path TEXT,                      -- relative to originals dir (content-addressed)
  original_size INTEGER,
  extracted_text TEXT NOT NULL,
  language TEXT,
  language_confidence REAL,
  title TEXT,
  extraction_status TEXT NOT NULL CHECK (extraction_status IN ('ok','partial','no_text')),
  extraction_quality REAL,                 -- 0..1 heuristic, see docs/ARCHITECTURE.md
  warnings TEXT NOT NULL DEFAULT '[]',     -- JSON array of strings
  page_spans TEXT,                         -- JSON [[start,end],...] per page (PDF only)
  metadata TEXT NOT NULL DEFAULT '{}',     -- JSON
  retrieved_at TEXT NOT NULL,
  UNIQUE (document_id, version_no)
);
CREATE INDEX idx_versions_hash ON document_versions(content_hash);
CREATE INDEX idx_versions_doc ON document_versions(document_id, is_current);

CREATE TABLE chunks (
  id INTEGER PRIMARY KEY,
  version_id INTEGER NOT NULL REFERENCES document_versions(id) ON DELETE CASCADE,
  document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  ordinal INTEGER NOT NULL,
  char_start INTEGER NOT NULL,             -- offsets into document_versions.extracted_text
  char_end INTEGER NOT NULL,
  page_start INTEGER,
  page_end INTEGER,
  text TEXT NOT NULL,                      -- == extracted_text[char_start:char_end]
  text_hash TEXT NOT NULL,
  UNIQUE (version_id, ordinal)
);
CREATE INDEX idx_chunks_doc ON chunks(document_id);
CREATE INDEX idx_chunks_hash ON chunks(text_hash);

-- Derived index over NORMALIZED chunk text; rowid = chunks.id. Only current versions are indexed.
CREATE VIRTUAL TABLE chunks_fts USING fts5(norm_text, tokenize = "unicode61 remove_diacritics 0");

CREATE TABLE links (
  id INTEGER PRIMARY KEY,
  version_id INTEGER NOT NULL REFERENCES document_versions(id) ON DELETE CASCADE,
  document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  dest_url TEXT NOT NULL,
  anchor_text TEXT,
  is_internal INTEGER NOT NULL
);
CREATE INDEX idx_links_doc ON links(document_id);
CREATE INDEX idx_links_dest ON links(dest_url);

CREATE TABLE ingestion_jobs (
  id INTEGER PRIMARY KEY,
  kind TEXT NOT NULL,                      -- file | url
  target TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('running','created','updated','unchanged','duplicate','failed')),
  document_id INTEGER,
  version_id INTEGER,
  duplicate_of INTEGER,
  message TEXT,
  started_at TEXT NOT NULL,
  finished_at TEXT
);

CREATE TABLE ingestion_errors (
  id INTEGER PRIMARY KEY,
  job_id INTEGER NOT NULL REFERENCES ingestion_jobs(id) ON DELETE CASCADE,
  error_type TEXT NOT NULL,
  detail TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE query_log (
  id INTEGER PRIMARY KEY,
  query TEXT NOT NULL,
  mode TEXT,
  filters TEXT,
  n_results INTEGER,
  latency_ms REAL,
  created_at TEXT NOT NULL
);

CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
