"""SSRF-safe URL fetching.

Defences (each is covered by tests):
- only http/https, no embedded credentials, port allowlist;
- DNS resolved by us, *every* returned address must be globally routable (loopback, private,
  link-local, multicast, reserved, CGNAT, IPv4-mapped/6to4/NAT64 forms of those are refused);
- the connection is pinned to the validated IP (no second resolution => no DNS rebinding window);
  Host header and TLS SNI/certificate verification still use the original hostname;
- redirects are followed manually and every hop is re-validated and re-resolved;
- response size is capped on *decoded* bytes (decompression bombs), plus timeouts;
- environment proxies are ignored (trust_env=False) so the guard cannot be bypassed by them;
- optional robots.txt policy following RFC 9309 semantics for unavailable files.
"""

from __future__ import annotations

import ipaddress
import socket
import urllib.robotparser
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import UTC, datetime
from urllib.parse import urljoin, urlsplit

import httpx

from ali.config import Settings

Resolver = Callable[[str, int], list[str]]

ALLOWED_CONTENT_TYPES = (
    "text/html", "application/xhtml+xml", "text/plain", "text/markdown", "text/csv",
    "application/json", "application/pdf", "application/octet-stream", "binary/octet-stream",
)


class BlockedDestination(Exception):
    """The URL or its resolved address is not allowed."""


class FetchError(Exception):
    """Network-level or protocol-level failure."""


class UnsupportedContent(FetchError):
    pass


def default_resolver(host: str, port: int) -> list[str]:
    infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    out: list[str] = []
    for fam, _t, _p, _c, sockaddr in infos:
        if fam in (socket.AF_INET, socket.AF_INET6):
            ip = str(sockaddr[0]).split("%", 1)[0]
            if ip not in out:
                out.append(ip)
    return out


def is_public_ip(ip: str) -> bool:
    addr = ipaddress.ip_address(ip)
    if isinstance(addr, ipaddress.IPv6Address):
        if addr.ipv4_mapped is not None:
            return is_public_ip(str(addr.ipv4_mapped))
        if addr.sixtofour is not None and not is_public_ip(str(addr.sixtofour)):
            return False
        if addr.teredo is not None:
            return False
        # NAT64 well-known prefix 64:ff9b::/96 embeds an IPv4 address
        if addr in ipaddress.ip_network("64:ff9b::/96"):
            return is_public_ip(str(ipaddress.IPv4Address(int(addr) & 0xFFFFFFFF)))
    return addr.is_global and not addr.is_multicast


@dataclass(frozen=True)
class CheckedURL:
    url: str
    scheme: str
    host: str
    port: int
    ip: str  # validated address the connection will be pinned to


def check_url(url: str, settings: Settings, resolver: Resolver = default_resolver) -> CheckedURL:
    try:
        parts = urlsplit(url.strip())
        port = parts.port
    except ValueError as exc:
        raise BlockedDestination(f"invalid URL: {exc}") from exc
    if parts.scheme not in ("http", "https"):
        raise BlockedDestination(f"unsupported scheme {parts.scheme!r}")
    if parts.username or parts.password:
        raise BlockedDestination("credentials in URL are not allowed")
    host = parts.hostname
    if not host:
        raise BlockedDestination("URL has no host")
    port = port or (443 if parts.scheme == "https" else 80)
    if port not in settings.allowed_ports and not settings.allow_private_networks:
        raise BlockedDestination(f"port {port} is not allowed")
    try:
        ipaddress.ip_address(host)
        candidates = [host]
    except ValueError:
        try:
            candidates = resolver(host, port)
        except OSError as exc:
            raise FetchError(f"DNS resolution failed for {host}: {exc}") from exc
    if not candidates:
        raise FetchError(f"no addresses for {host}")
    for ip in candidates:
        if not settings.allow_private_networks and not is_public_ip(ip):
            raise BlockedDestination(f"{host} resolves to a non-public address ({ip})")
    return CheckedURL(url.strip(), parts.scheme, host, port, candidates[0])


@dataclass
class FetchResult:
    requested_url: str
    final_url: str
    status: int
    content_type: str | None
    body: bytes
    headers: dict[str, str]
    redirects: list[str] = field(default_factory=list)
    retrieved_at: str = ""


class SafeFetcher:
    def __init__(
        self,
        settings: Settings,
        resolver: Resolver = default_resolver,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.resolver = resolver
        self._client = httpx.Client(
            transport=transport,
            timeout=httpx.Timeout(settings.fetch_timeout_s, connect=10.0),
            follow_redirects=False,
            trust_env=False,
            headers={"User-Agent": settings.user_agent, "Accept-Encoding": "gzip, deflate"},
        )
        self._robots: dict[str, urllib.robotparser.RobotFileParser | bool] = {}

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> SafeFetcher:
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # -------------------------------------------------------------- core fetch
    def _request(self, checked: CheckedURL, max_bytes: int, accept: str) -> tuple[httpx.Response, bytes]:
        parts = urlsplit(checked.url)
        ip_host = f"[{checked.ip}]" if ":" in checked.ip else checked.ip
        default_port = 443 if checked.scheme == "https" else 80
        netloc = ip_host if checked.port == default_port else f"{ip_host}:{checked.port}"
        pinned = parts._replace(netloc=netloc).geturl()
        host_header = checked.host if checked.port == default_port else f"{checked.host}:{checked.port}"
        ext = {"sni_hostname": checked.host} if checked.scheme == "https" else {}
        try:
            with self._client.stream(
                "GET", pinned, headers={"Host": host_header, "Accept": accept}, extensions=ext
            ) as resp:
                if 300 <= resp.status_code < 400:
                    return resp, b""
                declared = resp.headers.get("content-length")
                if declared and declared.isdigit() and int(declared) > max_bytes:
                    raise FetchError(f"response too large ({declared} bytes > {max_bytes})")
                ct = resp.headers.get("content-type", "").split(";")[0].strip().lower()
                if ct and not (ct.startswith("text/") or ct in ALLOWED_CONTENT_TYPES):
                    raise UnsupportedContent(f"unsupported content type {ct!r}")
                chunks: list[bytes] = []
                size = 0
                for part in resp.iter_bytes():
                    size += len(part)
                    if size > max_bytes:
                        raise FetchError(f"response exceeded {max_bytes} bytes (after decoding)")
                    chunks.append(part)
                return resp, b"".join(chunks)
        except httpx.HTTPError as exc:
            raise FetchError(f"{type(exc).__name__}: {exc}") from exc

    def fetch(self, url: str, max_bytes: int | None = None, accept: str = "*/*") -> FetchResult:
        limit = max_bytes or self.settings.max_download_bytes
        current = url.strip()
        redirects: list[str] = []
        for _hop in range(self.settings.max_redirects + 1):
            checked = check_url(current, self.settings, self.resolver)
            resp, body = self._request(checked, limit, accept)
            if 300 <= resp.status_code < 400 and resp.headers.get("location"):
                nxt = urljoin(current, resp.headers["location"])
                redirects.append(nxt)
                current = nxt
                continue
            hdrs = {k.lower(): v for k, v in resp.headers.items() if k.lower() in {
                "content-type", "last-modified", "etag", "content-language", "date", "content-length"}}
            return FetchResult(
                requested_url=url.strip(), final_url=current, status=resp.status_code,
                content_type=resp.headers.get("content-type"), body=body, headers=hdrs,
                redirects=redirects, retrieved_at=datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
            )
        raise FetchError(f"too many redirects (> {self.settings.max_redirects})")

    # -------------------------------------------------------------- robots.txt (RFC 9309 semantics)
    def robots_allows(self, url: str) -> tuple[bool, str]:
        parts = urlsplit(url)
        origin = f"{parts.scheme}://{parts.netloc}"
        if origin not in self._robots:
            rp: urllib.robotparser.RobotFileParser | bool
            try:
                res = self.fetch(f"{origin}/robots.txt", max_bytes=512 * 1024, accept="text/plain")
                if res.status == 200:
                    rp = urllib.robotparser.RobotFileParser()
                    rp.parse(res.body.decode("utf-8", errors="replace").splitlines())
                elif 400 <= res.status < 500:
                    rp = True  # no robots file => everything allowed
                else:
                    rp = False  # server error => treat as disallowed (RFC 9309 2.3.1.4)
            except BlockedDestination:
                raise
            except FetchError:
                rp = False  # unreachable => disallowed
            self._robots[origin] = rp
        policy = self._robots[origin]
        if policy is True:
            return True, "no robots.txt"
        if policy is False:
            return False, "robots.txt unavailable (server error/unreachable); treated as disallowed"
        assert isinstance(policy, urllib.robotparser.RobotFileParser)
        allowed = policy.can_fetch(self.settings.user_agent, url)
        return allowed, "allowed by robots.txt" if allowed else "disallowed by robots.txt"
