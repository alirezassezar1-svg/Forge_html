"""Head-to-head evaluation of overlapping components (Build-Before-Buy policy, step 6/8).
Candidates: 'existing' = modules left by the previous session (ali.textnorm, ali.langdetect, ali.netguard + ali.fetch)
            'new'      = modules written this session (ali.textproc, ali.netsafe)
Run: python tools/compare_components.py"""

from __future__ import annotations

import gzip
import socket
import threading
import types
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from ali import langdetect as old_lang
from ali import textnorm as old_norm
from ali import textproc as new_tp

R: list[tuple[str, str, str, str]] = []  # (area, case, candidate, result)


def rec(area, case, cand, ok, note=""):
    R.append((area, case, cand, ("PASS" if ok else "FAIL") + (f" ({note})" if note else "")))


# ---------------------------------------------------------------- normalisation
def norm_cases():
    cases = [
        ("arabic yeh/kaf fold", "كتاب يك", "کتاب یک"),
        ("digits (Persian/Arabic-Indic)", "۱۲۳ ٤٥٦", "123 456"),
        ("ZWNJ -> space", "می‌خواهم", "می خواهم"),
        ("harakat removed", "مُحَمَّد", "محمد"),
        ("tatweel removed", "سـلام", "سلام"),
        ("latin accents + case", "Café", "cafe"),
        ("presentation forms", "ﻻ", "لا"),
    ]
    for name, mod in (("existing:textnorm", old_norm), ("new:textproc", new_tp)):
        for case, src, want in cases:
            got = mod.normalize(src)
            rec("normalize", case, name, got == want, f"got {got!r}" if got != want else "")
        # offset mapping: every normalised char maps to a valid original offset
        s = "كتاب‌های ۱۲۳ Café"
        if name.startswith("existing"):
            n = old_norm.normalize_with_map(s)
            ok = len(n.text) == len(n.offsets) and all(0 <= o < len(s) for o in n.offsets)
        else:
            t, idx = new_tp.normalize_with_map(s)
            ok = len(t) == len(idx) and all(0 <= o < len(s) for o in idx)
        rec("normalize", "offset map valid", name, ok)
    # آ vs ا: design difference
    rec("normalize", "keeps آ distinct from ا (آب != اب)", "existing:textnorm", old_norm.normalize("آب") != old_norm.normalize("اب"))
    rec("normalize", "keeps آ distinct from ا (آب != اب)", "new:textproc", new_tp.normalize("آب") != new_tp.normalize("اب"))


# ---------------------------------------------------------------- language detection
LANG = [
    ("fa pure", "این یک متن فارسی است که برای آزمایش تشخیص زبان نوشته شده و در آن کلمات رایج وجود دارد.", "fa"),
    ("fa technical + English terms", "در این پروژه از پایگاه داده SQLite و موتور جستجوی FTS5 برای ایندکس کردن اسناد استفاده می‌کنیم و API پایتون ساده‌ای دارد که سرعت بالایی را فراهم می‌کند.", "fa"),
    ("fa with heavy English", "ما از Python و FastAPI و SQLite و Docker و Redis در این backend استفاده می‌کنیم تا deployment ساده باشد.", "fa"),
    ("en", "The quick brown fox jumps over the lazy dog and it is in the garden with the cat that was there.", "en"),
    ("ar", "هذا نص عربي كتب من أجل اختبار الكشف عن اللغة وهو في الكتاب الذي كان على الطاولة", "ar"),
    ("en with one Persian word", "This document explains how the search engine works and why the word سلام appears in the example of the test.", "en"),
    ("digits only", "12345 67890 11121 31415 16171", "und"),
    ("empty", "", "und"),
    ("short fa", "سلام دنیا", "und"),
]


def lang_cases():
    for case, text, want in LANG:
        o, _ = old_lang.detect_language(text)
        n, _ = new_tp.detect_language(text)
        # existing returns 'unknown'; treat as 'und'
        o = "und" if o == "unknown" else o
        rec("language", case, "existing:langdetect", o == want, f"got {o}" if o != want else "")
        rec("language", case, "new:textproc", n == want, f"got {n}" if n != want else "")


# ---------------------------------------------------------------- network guards
class Handler(BaseHTTPRequestHandler):
    seen_hosts: list[str] = []

    def log_message(self, *a):  # silence
        pass

    def do_GET(self):  # noqa: N802
        Handler.seen_hosts.append(self.headers.get("Host", ""))
        if self.path == "/ok":
            body = b"hello world"
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/redir":
            self.send_response(302)
            self.send_header("Location", "http://b.test/secret")
            self.send_header("Content-Length", "0")
            self.end_headers()
        elif self.path == "/bomb":
            body = gzip.compress(b"\0" * (30 * 1024 * 1024))
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.send_header("Content-Encoding", "gzip")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/png":
            self.send_response(200)
            self.send_header("Content-Type", "image/png")
            self.send_header("Content-Length", "3")
            self.end_headers()
            self.wfile.write(b"abc")
        elif self.path == "/robots.txt":
            self.send_response(404)
            self.send_header("Content-Length", "0")
            self.end_headers()
        else:
            self.send_response(404)
            self.send_header("Content-Length", "0")
            self.end_headers()


def net_cases():
    from ali import fetch as old_fetch
    from ali import netguard as old_guard
    from ali import netsafe as new_net
    from ali.config import Settings

    srv = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    port = srv.server_address[1]
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    attempts: list[str] = []
    real_cc = socket.create_connection

    def fake_cc(address, timeout=None, source_address=None, **kw):
        attempts.append(str(address[0]))
        return real_cc(("127.0.0.1", port), timeout)

    socket.create_connection = fake_cc
    calls = {"rebind": 0}

    def resolver(host, p):
        table = {
            "a.test": ["93.184.216.34"], "b.test": ["10.0.0.5"], "localhost": ["127.0.0.1"],
            "mixed.test": ["93.184.216.34", "127.0.0.1"], "2130706433": ["127.0.0.1"],  # getaddrinfo accepts decimal IPs
        }
        if host == "rebind.test":
            calls["rebind"] += 1
            return ["93.184.216.34"] if calls["rebind"] == 1 else ["127.0.0.1"]
        if host in table:
            return table[host]
        raise OSError("no such host")

    def new_fetch(url, max_bytes=None):
        s = Settings(home=__import__("pathlib").Path("/tmp/x"), respect_robots=False, max_download_bytes=max_bytes or 1_000_000)
        with new_net.SafeFetcher(s, resolver=resolver) as f:
            r = f.fetch(url)
            return r.status, r.body, r.final_url

    def old_fetch_fn(url, max_bytes=None):
        s = types.SimpleNamespace(allowed_ports=(80, 443), allow_private_networks=False, respect_robots=False,
                                  fetch_timeout=5.0, max_redirects=5, user_agent="t", max_upload_bytes=max_bytes or 1_000_000)
        def gai(host, p, type=None):  # existing code expects a socket.getaddrinfo-compatible resolver
            return [(socket.AF_INET6 if ":" in ip else socket.AF_INET, socket.SOCK_STREAM, 6, "", (ip, p)) for ip in resolver(host, p)]
        r = old_fetch.fetch_url(url, s, resolver=gai)
        return r.status, r.data, r.final_url

    impls = {"existing:netguard+fetch": old_fetch_fn, "new:netsafe": new_fetch}
    blocked_names = {"BlockedDestination"}
    scenarios = [
        ("literal loopback", f"http://127.0.0.1:{port}/ok", "blocked"),
        ("localhost hostname", "http://localhost/ok", "blocked"),
        ("cloud metadata 169.254.169.254", "http://169.254.169.254/latest/meta-data", "blocked"),
        ("IPv6 loopback", "http://[::1]/ok", "blocked"),
        ("IPv4-mapped IPv6 loopback", "http://[::ffff:127.0.0.1]/ok", "blocked"),
        ("decimal-encoded IP 2130706433", "http://2130706433/ok", "blocked"),
        ("file scheme", "file:///etc/passwd", "blocked"),
        ("ftp scheme", "ftp://a.test/ok", "blocked"),
        ("credentials in URL", "http://user:pw@a.test/ok", "blocked"),
        ("non-allowed port", "http://a.test:8080/ok", "blocked"),
        ("hostname resolving to private", "http://b.test/ok", "blocked"),
        ("mixed public+loopback answer", "http://mixed.test/ok", "blocked"),
        ("redirect to private host", "http://a.test/redir", "blocked"),
        ("public host fetch ok", "http://a.test/ok", "ok"),
        ("gzip bomb capped", "http://a.test/bomb", "error"),
        ("unsupported content type", "http://a.test/png", "error"),
    ]
    for cname, fn in impls.items():
        for case, url, want in scenarios:
            attempts.clear()
            Handler.seen_hosts.clear()
            try:
                status, body, _final = fn(url)
                got = "ok" if status == 200 else "error"
                note = ""
            except Exception as exc:  # noqa: BLE001
                got = "blocked" if type(exc).__name__ in blocked_names else "error"
                note = type(exc).__name__
            private_touched = [a for a in attempts if a.startswith(("127.", "10.", "169.254", "::1"))]
            ok = got == want and not private_touched
            if case == "public host fetch ok":
                ok = ok and attempts == ["93.184.216.34"] and Handler.seen_hosts == ["a.test"]
                note = f"connected to {attempts}, Host header {Handler.seen_hosts}"
            rec("network", case, cname, ok, note if not ok or case == "public host fetch ok" else "")
        # DNS rebinding: 2nd resolution would return loopback; connection must go only to the validated IP
        attempts.clear()
        calls["rebind"] = 0
        try:
            fn("http://rebind.test/ok")
        except Exception:  # noqa: BLE001
            pass
        rec("network", "DNS rebinding: never connects to 2nd (loopback) answer", cname,
            not any(a.startswith("127.") for a in attempts), f"attempts={attempts}, resolver calls={calls['rebind']}")
    socket.create_connection = real_cc
    srv.shutdown()


def main():
    norm_cases()
    lang_cases()
    net_cases()
    width = max(len(c) for _, c, _, _ in R)
    for area in ("normalize", "language", "network"):
        print(f"\n== {area}")
        for a, case, cand, res in R:
            if a == area:
                print(f"  {case:<{width}}  {cand:<26} {res}")
    print("\n== summary")
    for cand in sorted({c for _, _, c, _ in R}):
        rs = [r for _, _, c, r in R if c == cand]
        print(f"  {cand:<26} {sum(r.startswith('PASS') for r in rs)}/{len(rs)} pass")


if __name__ == "__main__":
    main()
