"""Text normalisation, tokenisation and language detection.

Design rule: the stored text is never altered by search normalisation. `normalize_with_map`
returns a *derived* string for indexing plus a map back to offsets in the original, so matches
can be highlighted and cited at exact positions of the original text.
"""

from __future__ import annotations

import hashlib
import re
import unicodedata

# Persian/Arabic folding (recall oriented; original text is always kept)
_FOLD = {
    "ي": "ی",  # Arabic yeh -> Persian yeh
    "ى": "ی",  # alef maksura -> Persian yeh
    "ك": "ک",  # Arabic kaf -> Persian keheh
    "ة": "ه",  # teh marbuta -> heh
    "ؤ": "و",  # waw with hamza -> waw
    "أ": "ا",  # alef with hamza above -> alef
    "إ": "ا",  # alef with hamza below -> alef
    "ٱ": "ا",  # alef wasla -> alef
}
_DROP = {"ـ", "‍", "‎", "‏", "‪", "‫", "‬", "﻿", "⁦", "⁧", "⁨", "⁩"}
_TOKEN_RE = re.compile(r"[^\W_]+", re.UNICODE)


def normalize_with_map(text: str) -> tuple[str, list[int]]:
    """Return (normalised_text, index_map) where index_map[i] is the offset in `text` that produced
    normalised character i. Folds: NFKD + dropping combining marks (Latin accents, Arabic harakat),
    casefold, Arabic->Persian letter variants, tatweel/format marks removed, ZWNJ -> space,
    all Unicode decimal digits -> ASCII digits, any whitespace -> single space (length preserving)."""
    out: list[str] = []
    idx: list[int] = []
    for i, ch in enumerate(text):
        if ch in _DROP:
            continue
        if ch == "‌":
            out.append(" ")
            idx.append(i)
            continue
        if ch.isspace():
            out.append(" ")
            idx.append(i)
            continue
        cat = unicodedata.category(ch)
        if cat == "Nd":
            out.append(str(unicodedata.digit(ch)))
            idx.append(i)
            continue
        ch = _FOLD.get(ch, ch)
        for sub in unicodedata.normalize("NFKD", ch):
            if unicodedata.category(sub) == "Mn":
                continue
            for folded in _FOLD.get(sub, sub).casefold():
                out.append(folded)
                idx.append(i)
    return "".join(out), idx


def normalize(text: str) -> str:
    return normalize_with_map(text)[0]


def tokenize(norm_text: str) -> list[str]:
    """Tokens of already-normalised text (letters/digits runs)."""
    return _TOKEN_RE.findall(norm_text)


def tokens_with_spans(norm_text: str) -> list[tuple[str, int, int]]:
    return [(m.group(0), m.start(), m.end()) for m in _TOKEN_RE.finditer(norm_text)]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# ---------------------------------------------------------------- language detection
_EN_STOP = frozenset(
    "the of and to in is that it for as with was on are by this be or from at an have not but they which "
    "you were their has had can will its more also".split()
)
_FA_WORDS = frozenset("و در به از که این را با است برای آن یک هم تا بر می شود شده های کرد خود".split())
_AR_WORDS = frozenset("في من على إلى أن هذا التي الذي ما لا عن مع كان هذه ذلك قد كل أو".split())
_FA_LETTERS = set("پچژگکی")  # پ چ ژ گ ک ی
_AR_LETTERS = set("يكةىؤئ")  # ي ك ة ى ؤ ئ


def _is_arabic_script(cp: int) -> bool:
    return (
        0x0600 <= cp <= 0x06FF
        or 0x0750 <= cp <= 0x077F
        or 0x08A0 <= cp <= 0x08FF
        or 0xFB50 <= cp <= 0xFDFF
        or 0xFE70 <= cp <= 0xFEFF
    )


def detect_language(text: str, sample_chars: int = 20000) -> tuple[str, float]:
    """Return (code, confidence). Codes: 'fa', 'ar', 'en', 'und'. Heuristic by script and function
    words; intentionally conservative. Other languages are reported as 'und'."""
    sample = text[:sample_chars]
    arabic = latin = 0
    for ch in sample:
        if not ch.isalpha():
            continue
        cp = ord(ch)
        if _is_arabic_script(cp):
            arabic += 1
        elif cp < 0x250:
            latin += 1
    total = arabic + latin
    if total < 20:
        return "und", 0.0
    if arabic >= latin:
        ratio = arabic / total
        fa_score = sum(1 for ch in sample if ch in _FA_LETTERS)
        ar_score = sum(1 for ch in sample if ch in _AR_LETTERS)
        words = sample.split()
        fa_score += 3 * sum(1 for w in words if w in _FA_WORDS)
        ar_score += 3 * sum(1 for w in words if w in _AR_WORDS)
        if fa_score == 0 and ar_score == 0:
            return "und", 0.0
        if fa_score >= ar_score:
            return "fa", round(min(0.99, ratio * (fa_score / (fa_score + ar_score))), 3)
        return "ar", round(min(0.99, ratio * (ar_score / (fa_score + ar_score))), 3)
    ratio = latin / total
    words = [w.lower() for w in re.findall(r"[A-Za-z]+", sample)]
    if not words:
        return "und", 0.0
    stop_ratio = sum(1 for w in words if w in _EN_STOP) / len(words)
    if stop_ratio >= 0.12:
        return "en", round(min(0.99, ratio * min(1.0, stop_ratio / 0.25)), 3)
    return "und", 0.0
