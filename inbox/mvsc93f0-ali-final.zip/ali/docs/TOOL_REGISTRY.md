# Internal tool registry (Build-Before-Buy item 10)

Decision log for the build-before-buy policy. "Build" = in-house module; "Use" = external dependency.
All entries version 0.1.0. Tests are in `tests/`.

| Tool | Decision | Purpose / interface | Dependencies | Permissions | Tests |
|---|---|---|---|---|---|
| `ali.textnorm` | Build | Persian/Arabic/Latin normalization with offset map. `normalize(text)`, `tokenize` | stdlib | none | test_milestone1 (Persian) |
| `ali.langdetect` | Build | Script-ratio language detection fa/ar/en/mixed/und | stdlib | none | existing comparison in `docs/superseded/` |
| `ali.netguard` | Build | SSRF guard: IP classification, validated resolution, guarded connect | httpcore | outbound network | 16 tests |
| `ali.fetch` | Build on httpx | Redirect-revalidating, size-limited fetch, robots.txt | httpx (Use) | outbound network | local-server test |
| `ali.extract` | Build on pypdf/bs4/lxml | TXT/MD/CSV/JSON/HTML/PDF adapters with warnings | pypdf, bs4, lxml (Use) | read untrusted bytes | adapter tests |
| `ali.db` / migrations | Build on sqlite3 | Versioned schema, FTS5, transactions | stdlib | filesystem | health + all tests |
| `ali.search` | Build on FTS5 | BM25, phrase, filters, highlights, diagnostics | stdlib | read DB | search tests |
| `ali.citations` | Build | Pinned-passage citations; deep verify vs. original | stdlib | read DB/files | roundtrip + tamper |
| `ali.backup` | Build | Hash-manifested zip backup/verify/restore/export | stdlib | filesystem | backup tests |
| `ali.api` + web UI | Build on FastAPI | HTTP API, CSRF header, token session, static UI | fastapi, uvicorn (Use) | listens on a port | tests/test_api.py + browser run |

External dependencies were used only where rebuilding would be wasteful or unsafe (HTTP stack, PDF parsing,
HTML parsing, web framework). Not installed (no implemented feature needs them yet): sentence-transformers,
torch, faiss, SQLAlchemy/Alembic (plain SQL migrations suffice), pandas (csv module suffices).
