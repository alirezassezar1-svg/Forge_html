# Known limitations (Milestone 1)
- Lexical search only (SQLite FTS5 BM25). No semantic/cross-language retrieval, reranking or link graph yet.
- No source-credibility scoring, evidence comparison or LLM answers yet (Milestones 2-3). The UI shows retrieved passages, not synthesized answers.
- OCR for scanned PDFs is not implemented (Tesseract is only detected by the health check).
- Persian search uses normalization + whitespace/ZWNJ tokenization, no stemming: "کتاب" will not match "کتاب‌ها" unless the text contains it.
- Single user. One shared API token; no accounts, roles or rate limiting. Do not expose to the public internet without a TLS reverse proxy.
- Windows scripts were written but not executed on Windows. The mobile test ran in Chromium with an iPhone-sized viewport, not on a physical iPhone.
- Fetching real public URLs was not tested (the sandbox's network is allowlisted); the fetch path was tested against a local server with private networks explicitly enabled.
- Coverage is 72 %; `cli.py` has no automated tests (it was smoke-tested manually).
