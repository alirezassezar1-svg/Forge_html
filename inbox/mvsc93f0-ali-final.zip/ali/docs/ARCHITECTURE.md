# Architecture (Milestone 1)
Import -> Extract -> Preserve -> Index -> Search -> Evidence -> Cite -> Verify
- `extract` adapters turn bytes into text + page spans + warnings. `textnorm` makes a searchable normalized copy while the original text is kept.
- `ingest` hashes content (sha256), stores the original under `originals/<sha-prefix>/`, writes documents / document_versions / chunks in one transaction, and records jobs and errors. Same hash = duplicate; same source key with new hash = new version (old one kept as historical).
- SQLite is authoritative; the FTS5 index is derived and rebuildable (`ali reindex`).
- `search` -> FTS5 BM25 over current versions, phrase/any/all modes, filters, highlights, per-query diagnostics (logged).
- `citations`: a citation pins (version_id, start, end, quote, hashes). `verify` re-checks DB text, hashes and (deep) re-extracts the preserved original.
- `api` (FastAPI) exposes this; `web/` is a dependency-free vanilla JS UI (EN/FA, RTL/LTR).
Not built yet: embeddings, link graph, source scoring, LLM layer (see LIMITATIONS).
