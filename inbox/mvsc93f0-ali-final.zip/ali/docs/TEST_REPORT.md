# Test report — ALI Milestone 1
Run on: Linux sandbox, Python 3.13.17, 2 vCPU, 8 GB RAM, SQLite 3.53.1 (FTS5). Results below were produced by actually running the commands; nothing is estimated.

| Check | Result |
|---|---|
| `pytest` (unit/integration/security/API) | **37 passed, 0 failed**; coverage 72 % |
| Browser UI test (Chromium, 390×844 touch viewport, EN + FA/RTL) | **10/10 pass**: upload, blocked URL, search highlight, Persian query, deep citation verify, no horizontal overflow (LTR and RTL), touch targets ≥ 44 px, no console errors |
| `ruff check src tests` | clean |
| `bandit -r src` | 0 issues (1 documented `# nosec B608`) |
| `pip-audit` | no known vulnerabilities (project itself not on PyPI, skipped) |
| `ali health` | all checks OK |

## Spec acceptance list (section 12)
PASS: 1 TXT · 2 CSV · 3 PDF text+pages · 4 URL fetch (local server only) · 5 blocked destinations · 6 duplicates · 7 changed source · 8 exact phrase · 10 citation passage recovery · 15 deletion + derived data · 16 backup/restore (+corruption rejected) · 18 secrets · 19 prompt-injection text treated as data · 20 mobile viewport (Chromium emulation).
Partial: 4 (real public internet not reachable from sandbox) · 9 Persian lexical search passes; **semantic** search not built.
NOT BUILT (later milestones): 11 evidence answers · 12 insufficient-evidence reporting · 13 conflicting sources · 14 compact feature reconstruction · 17 model-provider failure handling.

## Performance (500 synthetic docs ≈ 4 KB each, 2,833 chunks, this machine)
Ingestion 117 docs/s · search median 13–19 ms, p95 ≤ 25 ms (EN and FA, phrase and keyword) · peak RSS 45 MB · DB 12 MB.
Retrieval-quality metrics (Recall@k, MRR) were **not** measured: no labelled evaluation set exists yet.

## Not verified
Windows scripts (never run on Windows) · physical iPhone · real public URL fetch · behaviour behind a TLS reverse proxy.
