# Deployment and phone access
## Windows (local)
`scripts\install.bat` then `scripts\start.bat`, open http://127.0.0.1:8765. Data lives in `ali_data\` (override with `ALI_HOME`).
## iPhone on the same Wi-Fi
1. `set ALI_API_TOKEN=<long random string>` then `scripts\start.bat --host 0.0.0.0`.
2. Allow Python through Windows Firewall for private networks.
3. Find the PC's IP (`ipconfig`), open `http://<ip>:8765` in Safari, sign in with the token. Traffic is unencrypted on your LAN: acceptable at home, not elsewhere.
## Linux server
1. Create a non-root user, `python3 -m venv`, `pip install .`, set `ALI_HOME=/var/lib/ali`, `ALI_API_TOKEN` (via a root-only env file).
2. Run `ali serve --host 127.0.0.1 --port 8765` under systemd (`NoNewPrivileges=yes`, `ProtectSystem=strict`, `ReadWritePaths=/var/lib/ali`).
3. Put nginx or Caddy in front with TLS (Let's Encrypt); proxy to 127.0.0.1:8765 and pass `X-Forwarded-Proto`. Block all outbound traffic from the service user except 80/443 where possible (adds defence in depth to the SSRF guard).
4. Back up with `ali backup` on a schedule and copy archives off the machine; test `ali verify-backup`.
GitHub Pages cannot host this app (it needs a Python backend).
