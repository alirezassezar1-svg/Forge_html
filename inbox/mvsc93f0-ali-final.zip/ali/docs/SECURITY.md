# Security
- **SSRF**: only http/https on ports 80/443; every resolved IP must be public (loopback, private, link-local, metadata, multicast, reserved blocked); the connection goes to the validated IP; redirects are re-validated (max 5); size and time limits apply.
- **CSRF**: all POST/DELETE need header `X-ALI-Request: 1`, and an `Origin` header (if present) must match `Host`.
- **Auth**: set `ALI_API_TOKEN`. `ali serve` refuses a non-loopback `--host` without it. Login sets an HttpOnly, SameSite=Strict cookie holding an HMAC session value, never the token. Comparisons are constant-time. There is no rate limiting yet: use a long random token.
- **Untrusted content**: documents are rendered with `textContent` only; CSP forbids inline scripts; text in documents is evidence, never executed or fed to an instruction channel (no LLM is wired in yet).
- **Secrets**: token excluded from `repr`, exports, errors. 500 errors return a generic message.
- **Archives**: backup members are path-checked, size-checked against the manifest and hash-verified before restore; restore keeps the old data aside.
- **Tooling results**: ruff clean; bandit 0 issues (one documented `nosec` for migration SQL built from packaged files); pip-audit: no known vulnerabilities in installed dependencies at test time.
