from dataclasses import replace

import pytest
from fastapi.testclient import TestClient

from ali.api import create_app

H = {"X-ALI-Request": "1"}


@pytest.fixture
def client(settings):
    return TestClient(create_app(settings), base_url="http://testserver")


def upload(c, name="a.txt", text="TEST DATA. Quokkas are marsupials."):
    return c.post("/api/upload", files={"files": (name, text.encode(), "text/plain")}, headers=H)


def test_index_and_static(client):
    assert "<title>ALI</title>" in client.get("/").text
    assert client.get("/static/app.js").status_code == 200
    assert client.get("/static/index.html").status_code == 404
    assert client.get("/static/..%2fapi.py").status_code == 404
    r = client.get("/")
    assert "script-src 'self'" in r.headers["content-security-policy"]


def test_upload_search_passage_verify_delete(client):
    r = upload(client)
    assert r.status_code == 200 and r.json()[0]["outcome"] == "created"
    hits = client.get("/api/search", params={"q": "marsupials"}).json()["hits"]
    assert hits
    cit = hits[0]["citation"]
    p = client.get("/api/passage", params={"version_id": cit["version_id"], "start": cit["start_char"], "end": cit["end_char"]})
    assert "marsupials" in p.json()["passage"]
    v = client.post("/api/citations/verify?deep=true", json=cit, headers=H).json()
    assert v["ok"]
    assert client.post("/api/citations/verify", json=dict(cit, quote="x"), headers=H).json()["ok"] is False
    doc_id = hits[0]["document_id"]
    assert client.delete(f"/api/documents/{doc_id}", headers=H).status_code == 200
    assert client.get("/api/search", params={"q": "marsupials"}).json()["hits"] == []
    assert client.delete(f"/api/documents/{doc_id}", headers=H).status_code == 404


def test_csrf_header_required(client):
    assert client.post("/api/upload", files={"files": ("a.txt", b"x", "text/plain")}).status_code == 403
    r = client.post("/api/reindex", headers={**H, "Origin": "http://evil.example"})
    assert r.status_code == 403


def test_blocked_url_reported(client):
    r = client.post("/api/ingest-url", json={"urls": ["http://127.0.0.1/", "http://169.254.169.254/"]}, headers=H)
    assert [x["outcome"] for x in r.json()] == ["failed", "failed"]
    jobs = client.get("/api/jobs").json()
    assert jobs and jobs[0]["errors"]


def test_empty_query_and_validation(client):
    assert client.get("/api/search", params={"q": ""}).status_code == 422
    assert client.get("/api/search", params={"q": "!!!"}).status_code == 422


def test_health_backup_stats(client):
    upload(client)
    assert client.get("/api/health").json()["ok"] is True
    b = client.post("/api/backup", headers=H).json()
    assert b["verified"] and b["file"].endswith(".zip")
    assert client.get("/api/stats").json()["documents"] == 1


def test_auth_required_and_cookie_session(settings):
    c = TestClient(create_app(replace(settings, api_token="s3cret-token")), base_url="http://testserver")
    assert c.get("/api/stats").status_code == 401
    assert c.get("/api/session").json() == {"auth_required": True, "authenticated": False}
    assert c.post("/api/login", json={"token": "wrong"}, headers=H).status_code == 401
    assert c.post("/api/login", json={"token": "s3cret-token"}).status_code == 403  # no CSRF header
    r = c.post("/api/login", json={"token": "s3cret-token"}, headers=H)
    assert r.status_code == 200
    sc = r.headers["set-cookie"].lower()
    assert "httponly" in sc and "samesite=strict" in sc and "s3cret-token" not in sc
    assert c.get("/api/stats").status_code == 200
    assert TestClient(create_app(replace(settings, api_token="s3cret-token"))).get(
        "/api/stats", headers={"Authorization": "Bearer s3cret-token"}).status_code == 200


def test_errors_do_not_leak(settings, monkeypatch):
    app = create_app(settings)
    import ali.api as api
    monkeypatch.setattr(api.library, "stats", lambda c: 1 / 0)
    c = TestClient(app, raise_server_exceptions=False)
    r = c.get("/api/stats")
    assert r.status_code == 500 and "ZeroDivision" not in r.text and "Traceback" not in r.text
