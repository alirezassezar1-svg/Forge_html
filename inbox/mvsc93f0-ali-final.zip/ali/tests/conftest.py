import pytest

from ali.config import Settings
from ali.db import open_db


@pytest.fixture
def settings(tmp_path):
    return Settings.from_env(tmp_path / "home")


@pytest.fixture
def conn(settings):
    settings.ensure_dirs()
    c = open_db(settings)
    yield c
    c.close()
