@echo off
REM Clean reset: deletes the virtual environment ONLY. Your data (ali_data) is kept unless you delete it yourself.
cd /d "%~dp0\.."
if exist .venv rmdir /s /q .venv
echo Virtual environment removed. Data directory left untouched.
