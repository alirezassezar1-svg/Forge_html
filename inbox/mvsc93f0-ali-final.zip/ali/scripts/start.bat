@echo off
REM Starts ALI on http://127.0.0.1:8765 . For phone access set ALI_API_TOKEN and pass --host 0.0.0.0 (see docs/DEPLOYMENT.md)
setlocal
cd /d "%~dp0\.."
call .venv\Scripts\activate.bat || (echo Run scripts\install.bat first. & exit /b 1)
if "%ALI_HOME%"=="" set ALI_HOME=%CD%\ali_data
ali serve %*
