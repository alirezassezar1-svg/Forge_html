@echo off
REM ALI installer for Windows 11. NOT yet executed on Windows by the author (written on Linux) - see docs/TEST_REPORT.md
setlocal
cd /d "%~dp0\.."
where py >nul 2>nul && (set PY=py -3) || (set PY=python)
%PY% -c "import sys; assert sys.version_info>=(3,11), 'Python 3.11+ required'" || (echo Python 3.11 or newer is required. & exit /b 1)
if not exist .venv ( %PY% -m venv .venv || exit /b 1 )
call .venv\Scripts\activate.bat || exit /b 1
python -m pip install --upgrade pip || exit /b 1
pip install -e ".[test,dev]" || exit /b 1
ali init || exit /b 1
ali health || exit /b 1
echo.
echo Install finished. Start with scripts\start.bat
