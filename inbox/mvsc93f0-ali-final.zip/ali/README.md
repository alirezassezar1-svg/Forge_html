# ALI — Adaptive Learning & Intelligence (Milestone 1)
Personal evidence-oriented knowledge engine: import documents, preserve originals, search (English + Persian), and get verifiable citations. See `docs/LIMITATIONS.md` for what is **not** built yet.

## Quick start
Windows: `scripts\install.bat`, then `scripts\start.bat` → http://127.0.0.1:8765
Any OS: `python -m venv .venv && . .venv/bin/activate && pip install -e ".[test,dev]"` (pinned versions tested: `requirements.lock`)
CLI: `ali init`, `ali ingest sample_data`, `ali search "calcium absorption"`, `ali search '"exact phrase"'`, `ali health`, `ali backup`, `ali restore <file>`, `ali serve`.
Tests: `pytest` · Lint: `ruff check src tests` · Security: `bandit -r src`, `pip-audit`.

## Using the web UI
Tabs: Search (modes auto/all/any/phrase; click *Open passage* for the cited passage and *Verify* buttons), Library (delete), Add (upload files or URLs), Jobs (real ingestion results and errors), System (stats, health, backup, reindex). The button "فا"/"EN" switches Persian (RTL) and English (LTR).

## راهنمای فارسی
- نصب: `scripts\install.bat` و سپس `scripts\start.bat`؛ بعد آدرس http://127.0.0.1:8765 را باز کنید.
- با دکمه «فا / EN» بالای صفحه زبان و جهت (راست‌به‌چپ) عوض می‌شود.
- جستجوی فارسی ی/ک عربی و فارسی، ارقام فارسی و عربی، نیم‌فاصله و اعراب را یکسان می‌بیند، ولی ریشه‌یابی ندارد.
- برای عبارت دقیق آن را داخل گیومه بگذارید: `"جذب کلسیم"`.
- داده‌ی نمونه در `sample_data/` فقط آزمایشی است.

## Configuration (environment)
`ALI_HOME` data dir · `ALI_API_TOKEN` access token (required for non-loopback hosts). Phone/server setup: `docs/DEPLOYMENT.md`. Clean reset: `scripts\reset.bat` (removes only `.venv`); delete `ali_data` yourself to erase data.
