/**
 * Private Knowledge AI – Client-Only PWA
 * Entry Point
 */
import { initDB, getSetting } from './db/db.js';
import { initRouter, register } from './router.js';
import { renderDashboard } from './pages/dashboard.js';
import { renderIngest } from './pages/ingest.js';
import { renderSources } from './pages/sources.js';
import { renderChat } from './pages/chat.js';
import { renderSearch } from './pages/search.js';
import { renderSettings, applyTheme } from './pages/settings.js';
import { buildIndex } from './services/retriever.js';

async function bootstrap() {
  try {
    // 1. Init DB
    await initDB();

    // 2. Apply theme
    const theme = await getSetting('theme');
    applyTheme(theme || 'auto');

    // 3. Register routes
    register('/', renderDashboard);
    register('/ingest', renderIngest);
    register('/sources', renderSources);
    register('/chat', renderChat);
    register('/search', renderSearch);
    register('/settings', renderSettings);

    // 4. Init router
    initRouter('#page-container');

    // 5. Build search index in background
    buildIndex().catch(err => console.warn('Index build failed', err));

    // 6. Online/Offline status
    updateOnlineStatus();
    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);

    console.log('[App] Private Knowledge AI ready (Client-Only)');
  } catch (err) {
    console.error('[App] Bootstrap failed', err);
    document.getElementById('page-container').innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">⚠️</div>
        <h3>خطا در راه‌اندازی</h3>
        <p>${err.message}</p>
        <p class="mt-1">لطفاً صفحه را رفرش کنید یا حافظه مرورگر را پاک کنید.</p>
      </div>
    `;
  }
}

function updateOnlineStatus() {
  const bar = document.getElementById('status-bar');
  const text = document.getElementById('status-text');
  if (!bar || !text) return;

  if (navigator.onLine) {
    bar.classList.add('hidden');
  } else {
    bar.classList.remove('hidden');
    bar.classList.remove('online');
    text.textContent = 'حالت آفلاین — فقط دانش ذخیره‌شده در دسترس است';
  }
}

// Start
bootstrap();
