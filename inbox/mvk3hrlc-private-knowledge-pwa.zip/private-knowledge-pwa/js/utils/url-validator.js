/**
 * Client-side URL validation (best-effort)
 * Note: Real SSRF protection is impossible in the browser.
 */

const PRIVATE_IP_RANGES = [
  /^localhost$/i,
  /^127\./,
  /^10\./,
  /^172\.(1[6-9]|2[0-9]|3[0-1])\./,
  /^192\.168\./,
  /^169\.254\./,
  /^0\./,
  /^\[::1\]$/,
  /^\[fc/i,
  /^\[fd/i,
  /^\[fe80/i
];

export function validateUrl(input) {
  const result = {
    valid: false,
    url: null,
    error: null
  };

  if (!input || typeof input !== 'string') {
    result.error = 'آدرس وارد نشده است';
    return result;
  }

  let urlString = input.trim();

  // Auto-add https if missing
  if (!/^https?:\/\//i.test(urlString)) {
    urlString = 'https://' + urlString;
  }

  let parsed;
  try {
    parsed = new URL(urlString);
  } catch {
    result.error = 'آدرس نامعتبر است';
    return result;
  }

  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    result.error = 'فقط پروتکل‌های http و https مجاز هستند';
    return result;
  }

  const hostname = parsed.hostname;

  for (const pattern of PRIVATE_IP_RANGES) {
    if (pattern.test(hostname)) {
      result.error = 'آدرس‌های محلی و خصوصی مجاز نیستند';
      return result;
    }
  }

  // Block obvious metadata endpoints
  if (hostname === 'metadata.google.internal' ||
      hostname.endsWith('.internal') ||
      hostname === '169.254.169.254') {
    result.error = 'آدرس‌های داخلی و متادیتا مجاز نیستند';
    return result;
  }

  result.valid = true;
  result.url = parsed.href;
  return result;
}
