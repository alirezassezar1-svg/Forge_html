/**
 * IndexedDB Schema Definition for Private Knowledge AI (Client-Only)
 */

export const DB_NAME = 'PrivateKnowledgeDB';
export const DB_VERSION = 1;

/**
 * Dexie schema stores
 */
export const stores = {
  settings: 'key, value',
  sources: '++id, url, finalUrl, title, createdAt, updatedAt, status, *tags',
  versions: '++id, sourceId, versionNumber, contentHash, title, retrievedAt, approved, approvedAt, status',
  chunks: '++id, versionId, sourceId, order, heading, textLength',
  embeddings: '++id, chunkId, versionId, model',
  conversations: '++id, title, createdAt, updatedAt',
  messages: '++id, conversationId, role, createdAt',
  evidence: '++id, messageId, chunkId, versionId, score',
  jobs: '++id, type, status, createdAt, updatedAt',
  audit: '++id, action, timestamp'
};

/**
 * Default settings
 */
export const defaultSettings = {
  theme: 'auto',
  language: 'fa',
  embeddingModel: 'Xenova/all-MiniLM-L6-v2',
  llmModel: null,               // set when WebLLM is loaded
  chunkSize: 500,
  chunkOverlap: 80,
  topK: 6,
  pinEnabled: false,
  pinHash: null,
  lastBackupAt: null
};
