/**
 * Database layer using Dexie.js
 */
import { DB_NAME, DB_VERSION, stores, defaultSettings } from './schema.js';

const db = new Dexie(DB_NAME);

db.version(DB_VERSION).stores(stores);

/**
 * Initialize database and default settings
 */
export async function initDB() {
  try {
    await db.open();
    // Ensure default settings exist
    const existing = await db.settings.get('theme');
    if (!existing) {
      const entries = Object.entries(defaultSettings).map(([key, value]) => ({ key, value }));
      await db.settings.bulkPut(entries);
    }
    console.log('[DB] Initialized successfully');
    return true;
  } catch (err) {
    console.error('[DB] Init failed', err);
    throw err;
  }
}

/**
 * Settings helpers
 */
export async function getSetting(key) {
  const row = await db.settings.get(key);
  return row ? row.value : defaultSettings[key];
}

export async function setSetting(key, value) {
  await db.settings.put({ key, value });
}

export async function getAllSettings() {
  const rows = await db.settings.toArray();
  const obj = { ...defaultSettings };
  rows.forEach(r => { obj[r.key] = r.value; });
  return obj;
}

/**
 * Sources
 */
export async function createSource({ url, finalUrl, title }) {
  const now = Date.now();
  const id = await db.sources.add({
    url,
    finalUrl: finalUrl || url,
    title: title || url,
    createdAt: now,
    updatedAt: now,
    status: 'pending',
    tags: []
  });
  return id;
}

export async function getSources() {
  return db.sources.orderBy('updatedAt').reverse().toArray();
}

export async function getSource(id) {
  return db.sources.get(id);
}

export async function updateSource(id, changes) {
  changes.updatedAt = Date.now();
  await db.sources.update(id, changes);
}

/**
 * Versions (immutable after creation except approval)
 */
export async function createVersion(data) {
  const existing = await db.versions
    .where({ sourceId: data.sourceId })
    .toArray();
  const versionNumber = existing.length + 1;

  const id = await db.versions.add({
    sourceId: data.sourceId,
    versionNumber,
    contentHash: data.contentHash,
    title: data.title,
    extractedText: data.extractedText,
    qualityReport: data.qualityReport,
    retrievedAt: data.retrievedAt || Date.now(),
    httpStatus: data.httpStatus,
    contentType: data.contentType,
    finalUrl: data.finalUrl,
    approved: false,
    approvedAt: null,
    status: 'preview',
    extractionMethod: data.extractionMethod || 'readability-v1'
  });
  return id;
}

export async function getVersions(sourceId) {
  return db.versions.where('sourceId').equals(sourceId).reverse().sortBy('versionNumber');
}

export async function getVersion(id) {
  return db.versions.get(id);
}

export async function approveVersion(versionId) {
  const version = await db.versions.get(versionId);
  if (!version) throw new Error('Version not found');

  await db.transaction('rw', db.versions, db.sources, async () => {
    await db.versions.update(versionId, {
      approved: true,
      approvedAt: Date.now(),
      status: 'approved'
    });
    await db.sources.update(version.sourceId, {
      status: 'active',
      title: version.title,
      updatedAt: Date.now()
    });
  });
}

/**
 * Chunks
 */
export async function saveChunks(versionId, sourceId, chunks) {
  const records = chunks.map((c, i) => ({
    versionId,
    sourceId,
    order: i,
    heading: c.heading || null,
    text: c.text,
    textLength: c.text.length,
    startOffset: c.startOffset || 0,
    endOffset: c.endOffset || c.text.length
  }));
  await db.chunks.bulkAdd(records);
  return records.length;
}

export async function getChunksByVersion(versionId) {
  return db.chunks.where('versionId').equals(versionId).sortBy('order');
}

export async function getApprovedChunks() {
  const approvedVersions = await db.versions.where('approved').equals(1).primaryKeys();
  if (!approvedVersions.length) return [];
  return db.chunks.where('versionId').anyOf(approvedVersions).toArray();
}

/**
 * Conversations & Messages
 */
export async function createConversation(title = 'گفتگوی جدید') {
  const now = Date.now();
  return db.conversations.add({
    title,
    createdAt: now,
    updatedAt: now
  });
}

export async function getConversations() {
  return db.conversations.orderBy('updatedAt').reverse().toArray();
}

export async function addMessage(conversationId, role, content, meta = {}) {
  const id = await db.messages.add({
    conversationId,
    role,
    content,
    createdAt: Date.now(),
    ...meta
  });
  await db.conversations.update(conversationId, { updatedAt: Date.now() });
  return id;
}

export async function getMessages(conversationId) {
  return db.messages.where('conversationId').equals(conversationId).sortBy('createdAt');
}

/**
 * Evidence
 */
export async function saveEvidence(messageId, items) {
  const records = items.map(item => ({
    messageId,
    chunkId: item.chunkId,
    versionId: item.versionId,
    score: item.score,
    excerpt: item.excerpt
  }));
  await db.evidence.bulkAdd(records);
}

export async function getEvidence(messageId) {
  return db.evidence.where('messageId').equals(messageId).toArray();
}

/**
 * Jobs
 */
export async function createJob(type, payload = {}) {
  return db.jobs.add({
    type,
    status: 'pending',
    progress: 0,
    payload,
    result: null,
    error: null,
    createdAt: Date.now(),
    updatedAt: Date.now()
  });
}

export async function updateJob(id, changes) {
  changes.updatedAt = Date.now();
  await db.jobs.update(id, changes);
}

export async function getJob(id) {
  return db.jobs.get(id);
}

/**
 * Export / Import helpers
 */
export async function exportAllData() {
  const data = {
    exportedAt: new Date().toISOString(),
    version: DB_VERSION,
    settings: await db.settings.toArray(),
    sources: await db.sources.toArray(),
    versions: await db.versions.toArray(),
    chunks: await db.chunks.toArray(),
    conversations: await db.conversations.toArray(),
    messages: await db.messages.toArray(),
    evidence: await db.evidence.toArray()
  };
  return data;
}

export async function importData(data) {
  if (!data || !data.version) throw new Error('Invalid backup file');

  await db.transaction('rw',
    db.settings, db.sources, db.versions, db.chunks,
    db.conversations, db.messages, db.evidence,
    async () => {
      await Promise.all([
        db.settings.clear(),
        db.sources.clear(),
        db.versions.clear(),
        db.chunks.clear(),
        db.conversations.clear(),
        db.messages.clear(),
        db.evidence.clear()
      ]);

      if (data.settings?.length) await db.settings.bulkPut(data.settings);
      if (data.sources?.length) await db.sources.bulkPut(data.sources);
      if (data.versions?.length) await db.versions.bulkPut(data.versions);
      if (data.chunks?.length) await db.chunks.bulkPut(data.chunks);
      if (data.conversations?.length) await db.conversations.bulkPut(data.conversations);
      if (data.messages?.length) await db.messages.bulkPut(data.messages);
      if (data.evidence?.length) await db.evidence.bulkPut(data.evidence);
    }
  );
}

export async function wipeAllData() {
  await db.delete();
  await db.open();
  const entries = Object.entries(defaultSettings).map(([key, value]) => ({ key, value }));
  await db.settings.bulkPut(entries);
}

export { db };
export default db;
