/**
 * Settings Page
 */
import {
  getAllSettings,
  setSetting,
  exportAllData,
  importData,
  wipeAllData
} from '../db/db.js';
import { showToast } from '../utils/toast.js';

export async function renderSettings() {
  const settings = await getAllSettings();
  const container = document.getElementById('page-container');

  container.innerHTML = `
    <div class="page-header">
      <h1 class="page-title">تنظیمات</h1>
      <p class="page-subtitle">پیکربندی محلی و پشتیبان‌گیری</p>
    </div>

    <div class="card">
      <div class="card-title mb-1">ظاهر</div>
      <div class="form-group">
        <label class="form-label">پوسته</label>
        <select id="theme-select" class="form-select">
          <option value="auto" ${settings.theme === 'auto' ? 'selected' : ''}>خودکار (سیستم)</option>
          <option value="light" ${settings.theme === 'light' ? 'selected' : ''}>روشن</option>
          <option value="dark" ${settings.theme === 'dark' ? 'selected' : ''}>تاریک</option>
        </select>
      </div>
    </div>

    <div class="card">
      <div class="card-title mb-1">پشتیبان‌گیری و بازیابی</div>
      <p class="card-meta mb-2">تمام داده‌ها فقط روی این دستگاه ذخیره می‌شوند. پشتیبان‌گیری منظم توصیه می‌شود.</p>
      <div class="flex gap-1" style="flex-wrap:wrap;">
        <button id="btn-export" class="btn btn-primary">خروجی پشتیبان (JSON)</button>
        <label class="btn btn-secondary" style="cursor:pointer;">
          بازیابی از فایل
          <input type="file" id="import-file" accept=".json" hidden />
        </label>
      </div>
    </div>

    <div class="card">
      <div class="card-title mb-1" style="color:var(--danger);">منطقه خطر</div>
      <p class="card-meta mb-2">پاک کردن تمام داده‌ها غیرقابل بازگشت است.</p>
      <button id="btn-wipe" class="btn btn-danger">پاک کردن تمام دانش</button>
    </div>

    <div class="card">
      <div class="card-title mb-1">درباره</div>
      <div class="card-body" style="font-size:0.9rem;">
        <p><strong>دانش خصوصی</strong> — نسخه کاملاً بدون سرور</p>
        <p class="mt-1">تمام پردازش‌ها و ذخیره‌سازی روی دستگاه شما انجام می‌شود.</p>
        <p class="mt-1 card-meta">نسخه ۱.۰ · Client-Only PWA</p>
      </div>
    </div>
  `;

  // Theme
  document.getElementById('theme-select').addEventListener('change', async (e) => {
    const value = e.target.value;
    await setSetting('theme', value);
    applyTheme(value);
    showToast('پوسته تغییر کرد', 'success');
  });

  // Export
  document.getElementById('btn-export').addEventListener('click', async () => {
    try {
      const data = await exportAllData();
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `private-knowledge-backup-${new Date().toISOString().slice(0,10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showToast('فایل پشتیبان دانلود شد', 'success');
    } catch (err) {
      showToast('خطا در خروجی: ' + err.message, 'error');
    }
  });

  // Import
  document.getElementById('import-file').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      if (!confirm('تمام داده‌های فعلی با محتوای فایل جایگزین می‌شوند. ادامه می‌دهید؟')) return;
      await importData(data);
      showToast('بازیابی با موفقیت انجام شد. صفحه را رفرش کنید.', 'success');
    } catch (err) {
      showToast('خطا در بازیابی: ' + err.message, 'error');
    }
  });

  // Wipe
  document.getElementById('btn-wipe').addEventListener('click', async () => {
    if (!confirm('آیا مطمئن هستید؟ تمام منابع، گفتگوها و تنظیمات پاک خواهند شد.')) return;
    if (!confirm('این عمل غیرقابل بازگشت است. تأیید نهایی؟')) return;
    try {
      await wipeAllData();
      showToast('تمام داده‌ها پاک شدند', 'success');
      setTimeout(() => location.reload(), 1000);
    } catch (err) {
      showToast('خطا: ' + err.message, 'error');
    }
  });
}

export function applyTheme(theme) {
  const root = document.documentElement;
  if (theme === 'auto') {
    root.removeAttribute('data-theme');
  } else {
    root.setAttribute('data-theme', theme);
  }
}
