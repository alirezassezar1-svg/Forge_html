/**
 * Sources Library Page
 */
import { getSources, getVersions } from '../db/db.js';
import { navigate } from '../router.js';

export async function renderSources() {
  const sources = await getSources();
  const container = document.getElementById('page-container');

  if (sources.length === 0) {
    container.innerHTML = `
      <div class="page-header">
        <h1 class="page-title">منابع</h1>
      </div>
      <div class="empty-state">
        <div class="empty-state-icon">📚</div>
        <h3>هنوز منبعی وجود ندارد</h3>
        <p>از بخش «افزودن» یک آدرس وب اضافه کنید.</p>
        <a href="/ingest" data-route="/ingest" class="btn btn-primary mt-2">افزودن منبع</a>
      </div>
    `;
    return;
  }

  let html = `
    <div class="page-header">
      <h1 class="page-title">منابع دانش</h1>
      <p class="page-subtitle">${sources.length} منبع</p>
    </div>
  `;

  for (const s of sources) {
    const versions = await getVersions(s.id);
    const approved = versions.filter(v => v.approved);

    html += `
      <div class="card" data-source-id="${s.id}">
        <div class="card-header">
          <div style="flex:1;">
            <div class="card-title">${escapeHtml(s.title || 'بدون عنوان')}</div>
            <div class="card-meta ltr" style="word-break:break-all;">${escapeHtml(s.finalUrl || s.url)}</div>
          </div>
          <span class="badge ${s.status === 'active' ? 'badge-success' : 'badge-warning'}">
            ${s.status === 'active' ? 'فعال' : 'در انتظار'}
          </span>
        </div>
        <div class="card-body">
          <div class="card-meta">
            نسخه‌ها: ${versions.length} |
            تأییدشده: ${approved.length} |
            آخرین به‌روزرسانی: ${formatDate(s.updatedAt)}
          </div>
        </div>
      </div>
    `;
  }

  container.innerHTML = html;
}

function formatDate(ts) {
  if (!ts) return '—';
  return new Date(ts).toLocaleDateString('fa-IR', {
    year: 'numeric', month: 'short', day: 'numeric'
  });
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
