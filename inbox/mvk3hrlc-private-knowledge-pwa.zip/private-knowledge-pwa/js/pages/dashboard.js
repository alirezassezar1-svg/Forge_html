/**
 * Dashboard Page
 */
import { getSources, getConversations } from '../db/db.js';

export async function renderDashboard() {
  const sources = await getSources();
  const conversations = await getConversations();
  const approvedCount = sources.filter(s => s.status === 'active').length;

  const container = document.getElementById('page-container');
  container.innerHTML = `
    <div class="page-header">
      <h1 class="page-title">داشبورد</h1>
      <p class="page-subtitle">دانش شخصی کاملاً محلی</p>
    </div>

    <div class="card">
      <div class="card-header">
        <div>
          <div class="card-title">خلاصه وضعیت</div>
        </div>
      </div>
      <div class="card-body">
        <div class="flex gap-2" style="flex-wrap: wrap;">
          <div style="flex:1; min-width:120px;">
            <div style="font-size:1.8rem; font-weight:700; color:var(--accent);">${sources.length}</div>
            <div class="card-meta">کل منابع</div>
          </div>
          <div style="flex:1; min-width:120px;">
            <div style="font-size:1.8rem; font-weight:700; color:var(--success);">${approvedCount}</div>
            <div class="card-meta">تأیید شده</div>
          </div>
          <div style="flex:1; min-width:120px;">
            <div style="font-size:1.8rem; font-weight:700;">${conversations.length}</div>
            <div class="card-meta">گفتگوها</div>
          </div>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-header">
        <div class="card-title">شروع سریع</div>
      </div>
      <div class="card-body">
        <p class="mb-2">برای شروع یک آدرس وب اضافه کنید یا سؤال بپرسید.</p>
        <div class="flex gap-1" style="flex-wrap:wrap;">
          <a href="/ingest" data-route="/ingest" class="btn btn-primary">افزودن منبع</a>
          <a href="/chat" data-route="/chat" class="btn btn-secondary">شروع گفتگو</a>
          <a href="/sources" data-route="/sources" class="btn btn-ghost">مشاهده منابع</a>
        </div>
      </div>
    </div>

    ${sources.length === 0 ? `
      <div class="empty-state">
        <div class="empty-state-icon">📚</div>
        <h3>هنوز منبعی ندارید</h3>
        <p>اولین آدرس وب خود را اضافه کنید تا دانش خصوصی‌تان شکل بگیرد.</p>
      </div>
    ` : `
      <h2 style="font-size:1.1rem; margin:20px 0 12px;">آخرین منابع</h2>
      ${sources.slice(0, 5).map(s => `
        <div class="card">
          <div class="card-header">
            <div>
              <div class="card-title">${escapeHtml(s.title || s.url)}</div>
              <div class="card-meta ltr">${escapeHtml(s.finalUrl || s.url)}</div>
            </div>
            <span class="badge ${s.status === 'active' ? 'badge-success' : 'badge-warning'}">
              ${s.status === 'active' ? 'فعال' : 'در انتظار'}
            </span>
          </div>
        </div>
      `).join('')}
    `}
  `;
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
