/**
 * Chat Page – Evidence-based answers using local retrieval
 */
import {
  createConversation,
  getConversations,
  addMessage,
  getMessages,
  saveEvidence
} from '../db/db.js';
import { search, buildContext } from '../services/retriever.js';
import { showToast } from '../utils/toast.js';

let currentConversationId = null;

export async function renderChat() {
  const container = document.getElementById('page-container');

  // Get or create a conversation
  let conversations = await getConversations();
  if (conversations.length === 0) {
    currentConversationId = await createConversation('گفتگوی اصلی');
  } else {
    currentConversationId = conversations[0].id;
  }

  const messages = await getMessages(currentConversationId);

  container.innerHTML = `
    <div class="page-header">
      <h1 class="page-title">گفتگو با دانش</h1>
      <p class="page-subtitle">پاسخ‌ها بر اساس منابع تأییدشده شما تولید می‌شوند</p>
    </div>

    <div id="chat-messages" class="chat-messages">
      ${messages.length === 0 ? `
        <div class="empty-state">
          <div class="empty-state-icon">💬</div>
          <h3>هنوز پیامی نیست</h3>
          <p>سؤال خود را در مورد منابع ذخیره‌شده بپرسید.</p>
        </div>
      ` : messages.map(m => renderMessage(m)).join('')}
    </div>

    <div class="chat-input-bar">
      <input type="text" id="chat-input" class="form-input"
             placeholder="سؤال خود را بنویسید..." autocomplete="off" />
      <button id="btn-send" class="btn btn-primary">ارسال</button>
    </div>
  `;

  const input = document.getElementById('chat-input');
  const btn = document.getElementById('btn-send');

  btn.addEventListener('click', () => sendMessage());
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  // Scroll to bottom
  scrollToBottom();
}

function renderMessage(m) {
  const cls = m.role === 'user' ? 'message-user' : 'message-assistant';
  return `
    <div class="message ${cls}" data-id="${m.id}">
      <div>${escapeHtml(m.content)}</div>
      <div class="message-meta">${formatTime(m.createdAt)}</div>
    </div>
  `;
}

async function sendMessage() {
  const input = document.getElementById('chat-input');
  const btn = document.getElementById('btn-send');
  const text = input.value.trim();
  if (!text) return;

  input.value = '';
  btn.disabled = true;

  // Add user message
  const userMsgId = await addMessage(currentConversationId, 'user', text);
  appendMessage({ id: userMsgId, role: 'user', content: text, createdAt: Date.now() });

  // Show thinking
  const thinkingId = 'thinking-' + Date.now();
  const messagesEl = document.getElementById('chat-messages');
  messagesEl.insertAdjacentHTML('beforeend', `
    <div class="message message-assistant" id="${thinkingId}">
      <div>در حال جستجو در دانش...</div>
    </div>
  `);
  scrollToBottom();

  try {
    // Retrieve
    const { results, mode, message } = await search(text, { topK: 5 });

    let answer;
    let evidenceItems = [];

    if (!results.length) {
      answer = message || 'متأسفانه در منابع تأییدشده شما مدرک کافی برای پاسخ به این سؤال پیدا نشد. لطفاً منابع مرتبط بیشتری اضافه کنید.';
    } else {
      // Build a simple evidence-based answer (no real LLM in this base version)
      // In a full version this would call WebLLM with the context
      const context = buildContext(results);
      answer = generateSimpleAnswer(text, results);
      evidenceItems = results.map(r => ({
        chunkId: r.chunkId,
        versionId: r.versionId,
        score: r.score,
        excerpt: r.excerpt
      }));
    }

    // Remove thinking
    document.getElementById(thinkingId)?.remove();

    // Save assistant message
    const assistantMsgId = await addMessage(currentConversationId, 'assistant', answer);
    if (evidenceItems.length) {
      await saveEvidence(assistantMsgId, evidenceItems);
    }

    // Render with citations
    const msgEl = document.createElement('div');
    msgEl.className = 'message message-assistant';
    msgEl.dataset.id = assistantMsgId;
    msgEl.innerHTML = `
      <div>${escapeHtml(answer)}</div>
      ${results.length ? `
        <div class="mt-1">
          ${results.map((r, i) => `
            <span class="citation" title="${escapeHtml(r.sourceTitle)}">
              [${i + 1}] ${escapeHtml(r.sourceTitle.substring(0, 30))}
            </span>
          `).join('')}
        </div>
      ` : ''}
      <div class="message-meta">${formatTime(Date.now())}</div>
    `;
    messagesEl.appendChild(msgEl);
    scrollToBottom();

  } catch (err) {
    document.getElementById(thinkingId)?.remove();
    showToast('خطا در تولید پاسخ: ' + err.message, 'error');
  } finally {
    btn.disabled = false;
    input.focus();
  }
}

/**
 * Simple extractive answer generator (placeholder for real local LLM)
 */
function generateSimpleAnswer(question, results) {
  if (!results.length) {
    return 'مدرک کافی یافت نشد.';
  }

  let answer = `بر اساس ${results.length} بخش مرتبط از منابع شما:\n\n`;

  results.slice(0, 3).forEach((r, i) => {
    answer += `${i + 1}. از «${r.sourceTitle}»:\n${r.excerpt}\n\n`;
  });

  answer += '---\nتوجه: این پاسخ استخراجی از منابع شماست. برای پاسخ‌های تولیدی پیشرفته‌تر می‌توانید مدل زبانی محلی (WebLLM) را فعال کنید.';

  return answer;
}

function appendMessage(m) {
  const messagesEl = document.getElementById('chat-messages');
  // Remove empty state if present
  const empty = messagesEl.querySelector('.empty-state');
  if (empty) empty.remove();

  messagesEl.insertAdjacentHTML('beforeend', renderMessage(m));
  scrollToBottom();
}

function scrollToBottom() {
  const el = document.getElementById('chat-messages');
  if (el) el.scrollTop = el.scrollHeight;
}

function formatTime(ts) {
  return new Date(ts).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/\n/g, '<br>');
}
