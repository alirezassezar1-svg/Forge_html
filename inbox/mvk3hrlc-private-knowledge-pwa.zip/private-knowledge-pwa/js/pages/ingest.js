/**
 * Ingestion / Add Source Page
 */
import { previewUrl, savePreview } from '../services/ingestion.js';
import { approveVersion } from '../db/db.js';
import { indexVersion } from '../services/retriever.js';
import { showToast } from '../utils/toast.js';

let currentPreview = null;
let currentVersionId = null;

export async function renderIngest() {
  const container = document.getElementById('page-container');
  container.innerHTML = `
    <div class="page-header">
      <h1 class="page-title">افزودن منبع</h1>
      <p class="page-subtitle">آدرس وب مورد نظر را وارد کنید</p>
    </div>

    <div class="card">
      <div class="form-group">
        <label class="form-label" for="url-input">آدرس صفحه</label>
        <input type="url" id="url-input" class="form-input url-input"
               placeholder="https://example.com/article" dir="ltr" />
        <p class="form-hint">فقط آدرس‌هایی که خودتان انتخاب می‌کنید پردازش می‌شوند.</p>
      </div>
      <button id="btn-preview" class="btn btn-primary btn-block">بررسی و استخراج</button>
    </div>

    <div id="preview-area" class="hidden"></div>
  `;

  document.getElementById('btn-preview').addEventListener('click', handlePreview);
  document.getElementById('url-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') handlePreview();
  });
}

async function handlePreview() {
  const input = document.getElementById('url-input');
  const btn = document.getElementById('btn-preview');
  const area = document.getElementById('preview-area');

  const url = input.value.trim();
  if (!url) {
    showToast('لطفاً یک آدرس وارد کنید', 'error');
    return;
  }

  btn.disabled = true;
  btn.textContent = 'در حال دریافت...';
  area.classList.add('hidden');
  currentPreview = null;
  currentVersionId = null;

  try {
    const preview = await previewUrl(url);
    currentPreview = preview;

    const q = preview.qualityReport;
    const levelClass = q.level === 'good' ? 'quality-ok' :
                       q.level === 'medium' ? 'quality-warn' : 'quality-bad';

    area.innerHTML = `
      <div class="card mt-2">
        <div class="card-header">
          <div>
            <div class="card-title">${escapeHtml(preview.title)}</div>
            <div class="card-meta ltr">${escapeHtml(preview.finalUrl)}</div>
          </div>
          <span class="badge ${q.level === 'good' ? 'badge-success' : q.level === 'medium' ? 'badge-warning' : 'badge-danger'}">
            امتیاز کیفیت: ${q.score}
          </span>
        </div>

        <div class="quality-report">
          <div class="quality-item">
            <span>طول متن</span>
            <span class="${levelClass}">${q.textLength.toLocaleString('fa-IR')} کاراکتر</span>
          </div>
          <div class="quality-item">
            <span>وضعیت HTTP</span>
            <span>${q.httpStatus || '—'}</span>
          </div>
          ${q.warnings.length ? `
            <div class="mt-1">
              <strong>هشدارها:</strong>
              <ul style="margin:6px 0 0 16px; padding:0;">
                ${q.warnings.map(w => `<li class="quality-warn">${escapeHtml(w)}</li>`).join('')}
              </ul>
            </div>
          ` : '<p class="quality-ok mt-1">هشدار خاصی وجود ندارد</p>'}
        </div>

        <div class="card-body" style="max-height:240px; overflow-y:auto; white-space:pre-wrap; font-size:0.9rem;">
          ${escapeHtml(preview.extractedText.substring(0, 2000))}
          ${preview.extractedText.length > 2000 ? '…' : ''}
        </div>

        <div class="mt-2 flex gap-1">
          <button id="btn-approve" class="btn btn-primary">تأیید و افزودن به دانش</button>
          <button id="btn-discard" class="btn btn-secondary">رد کردن</button>
        </div>
      </div>
    `;

    area.classList.remove('hidden');

    document.getElementById('btn-approve').addEventListener('click', handleApprove);
    document.getElementById('btn-discard').addEventListener('click', () => {
      area.classList.add('hidden');
      currentPreview = null;
      showToast('پیش‌نمایش رد شد', 'info');
    });

  } catch (err) {
    showToast(err.message, 'error', 5000);
    area.innerHTML = `
      <div class="card mt-2">
        <div class="card-body" style="color:var(--danger);">
          <strong>خطا:</strong> ${escapeHtml(err.message)}
        </div>
      </div>
    `;
    area.classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.textContent = 'بررسی و استخراج';
  }
}

async function handleApprove() {
  if (!currentPreview) return;

  const btn = document.getElementById('btn-approve');
  btn.disabled = true;
  btn.textContent = 'در حال ذخیره...';

  try {
    const { sourceId, versionId } = await savePreview(currentPreview);
    currentVersionId = versionId;

    // Approve immediately for simplicity in this version
    await approveVersion(versionId);
    await indexVersion(versionId);

    showToast('منبع با موفقیت اضافه و ایندکس شد', 'success');
    document.getElementById('preview-area').innerHTML = `
      <div class="card mt-2">
        <div class="card-body text-center">
          <p style="color:var(--success); font-weight:600;">✓ منبع تأیید و به پایگاه دانش اضافه شد</p>
          <a href="/sources" data-route="/sources" class="btn btn-secondary mt-2">مشاهده منابع</a>
        </div>
      </div>
    `;
  } catch (err) {
    showToast(err.message, 'error');
    btn.disabled = false;
    btn.textContent = 'تأیید و افزودن به دانش';
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
