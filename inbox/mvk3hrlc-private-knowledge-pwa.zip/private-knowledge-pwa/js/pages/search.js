/**
 * Full-text Search Page
 */
import { search } from '../services/retriever.js';
import { showToast } from '../utils/toast.js';

export async function renderSearch() {
  const container = document.getElementById('page-container');
  container.innerHTML = `
    <div class="page-header">
      <h1 class="page-title">جستجو در دانش</h1>
      <p class="page-subtitle">جستجوی کامل‌متن روی منابع تأییدشده</p>
    </div>

    <div class="card">
      <div class="form-group">
        <input type="search" id="search-input" class="form-input"
               placeholder="عبارت مورد نظر را بنویسید..." />
      </div>
      <button id="btn-search" class="btn btn-primary btn-block">جستجو</button>
    </div>

    <div id="search-results" class="mt-2"></div>
  `;

  const input = document.getElementById('search-input');
  const btn = document.getElementById('btn-search');

  const doSearch = async () => {
    const q = input.value.trim();
    if (!q) return;

    btn.disabled = true;
    btn.textContent = 'در حال جستجو...';
    const resultsEl = document.getElementById('search-results');
    resultsEl.innerHTML = `<div class="loading-screen"><div class="spinner"></div></div>`;

    try {
      const { results, mode, total, message } = await search(q, { topK: 12 });

      if (!results.length) {
        resultsEl.innerHTML = `
          <div class="empty-state">
            <h3>نتیجه‌ای یافت نشد</h3>
            <p>${message || 'عبارت دیگری را امتحان کنید یا منابع بیشتری اضافه کنید.'}</p>
          </div>
        `;
        return;
      }

      resultsEl.innerHTML = `
        <p class="card-meta mb-1">${total} نتیجه (حالت: ${mode === 'fulltext' ? 'کامل‌متن' : mode})</p>
        ${results.map(r => `
          <div class="card">
            <div class="card-header">
              <div>
                <div class="card-title">${escapeHtml(r.sourceTitle)}</div>
                <div class="card-meta">نسخه ${r.versionNumber} · امتیاز ${r.score?.toFixed(2) || '—'}</div>
              </div>
            </div>
            <div class="card-body" style="font-size:0.9rem;">
              ${r.heading ? `<strong>${escapeHtml(r.heading)}</strong><br>` : ''}
              ${escapeHtml(r.excerpt)}
            </div>
            ${r.sourceUrl ? `<div class="card-meta ltr" style="font-size:0.75rem; word-break:break-all;">${escapeHtml(r.sourceUrl)}</div>` : ''}
          </div>
        `).join('')}
      `;
    } catch (err) {
      showToast(err.message, 'error');
      resultsEl.innerHTML = '';
    } finally {
      btn.disabled = false;
      btn.textContent = 'جستجو';
    }
  };

  btn.addEventListener('click', doSearch);
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter') doSearch();
  });
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
