/**
 * Lightweight client-side router using History API
 */

const routes = {};
let currentRoute = null;
let pageContainer = null;

export function initRouter(containerSelector = '#page-container') {
  pageContainer = document.querySelector(containerSelector);
  if (!pageContainer) throw new Error('Page container not found');

  // Intercept link clicks
  document.addEventListener('click', (e) => {
    const link = e.target.closest('[data-route]');
    if (link) {
      e.preventDefault();
      navigate(link.getAttribute('data-route'));
    }
  });

  // Handle browser back/forward
  window.addEventListener('popstate', () => {
    render(window.location.pathname);
  });

  // Initial render
  render(window.location.pathname || '/');
}

export function register(path, handler) {
  routes[path] = handler;
}

export function navigate(path) {
  if (path === currentRoute) return;
  window.history.pushState({}, '', path);
  render(path);
}

async function render(path) {
  // Normalize
  path = path.split('?')[0];
  if (path.length > 1 && path.endsWith('/')) path = path.slice(0, -1);

  currentRoute = path;

  // Update nav active state
  document.querySelectorAll('.nav-item').forEach(item => {
    const route = item.getAttribute('data-route');
    item.classList.toggle('active', route === path);
  });

  const handler = routes[path] || routes['/404'] || routes['/'];

  if (!handler) {
    pageContainer.innerHTML = `<div class="empty-state"><h3>صفحه یافت نشد</h3></div>`;
    return;
  }

  // Show loading
  pageContainer.innerHTML = `
    <div class="loading-screen">
      <div class="spinner"></div>
      <p>در حال بارگذاری...</p>
    </div>
  `;

  try {
    const content = await handler();
    if (typeof content === 'string') {
      pageContainer.innerHTML = content;
    }
    // If handler returns nothing, it is expected to have rendered itself
  } catch (err) {
    console.error('Route error', err);
    pageContainer.innerHTML = `
      <div class="empty-state">
        <div class="empty-state-icon">⚠️</div>
        <h3>خطا در بارگذاری صفحه</h3>
        <p>${err.message}</p>
      </div>
    `;
  }
}

export function getCurrentRoute() {
  return currentRoute;
}
