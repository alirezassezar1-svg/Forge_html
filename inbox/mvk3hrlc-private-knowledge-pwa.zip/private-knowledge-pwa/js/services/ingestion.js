/**
 * Client-side URL Ingestion Engine
 */
import { validateUrl } from '../utils/url-validator.js';
import { sha256 } from '../utils/hash.js';
import {
  createSource,
  createVersion,
  updateSource,
  getSource
} from '../db/db.js';

const MAX_RESPONSE_SIZE = 2 * 1024 * 1024; // 2 MB
const FETCH_TIMEOUT = 15000;

/**
 * Extract main content using a simple readability-like approach
 * (In production you would load Mozilla Readability via import)
 */
function extractContent(html, url) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');

  // Remove unwanted elements
  const removeSelectors = [
    'script', 'style', 'noscript', 'iframe', 'nav', 'footer',
    'header', 'aside', '.sidebar', '.nav', '.menu', '.advertisement',
    '.ads', '#comments', '.comment', '[role="navigation"]'
  ];
  removeSelectors.forEach(sel => {
    doc.querySelectorAll(sel).forEach(el => el.remove());
  });

  // Try article or main first
  let contentEl = doc.querySelector('article') ||
                  doc.querySelector('main') ||
                  doc.querySelector('[role="main"]') ||
                  doc.querySelector('.post-content') ||
                  doc.querySelector('.entry-content') ||
                  doc.body;

  const title = doc.querySelector('title')?.textContent?.trim() ||
                doc.querySelector('h1')?.textContent?.trim() ||
                url;

  // Get text with some structure
  const text = contentEl.innerText || contentEl.textContent || '';
  const cleanText = text
    .replace(/\n{3,}/g, '\n\n')
    .replace(/[ \t]+/g, ' ')
    .trim();

  return {
    title: title.substring(0, 300),
    text: cleanText,
    length: cleanText.length
  };
}

/**
 * Generate quality report
 */
function buildQualityReport(extracted, httpStatus, contentType) {
  const report = {
    httpStatus,
    contentType,
    textLength: extracted.length,
    hasTitle: !!extracted.title && extracted.title.length > 5,
    warnings: [],
    score: 100
  };

  if (extracted.length < 200) {
    report.warnings.push('متن استخراج‌شده بسیار کوتاه است');
    report.score -= 40;
  } else if (extracted.length < 500) {
    report.warnings.push('متن نسبتاً کوتاه است');
    report.score -= 15;
  }

  if (!report.hasTitle) {
    report.warnings.push('عنوان معتبری یافت نشد');
    report.score -= 10;
  }

  if (httpStatus && httpStatus >= 400) {
    report.warnings.push(`کد وضعیت HTTP: ${httpStatus}`);
    report.score -= 30;
  }

  if (contentType && !contentType.includes('text/html') && !contentType.includes('text/plain')) {
    report.warnings.push(`نوع محتوا پشتیبانی محدود دارد: ${contentType}`);
    report.score -= 20;
  }

  report.score = Math.max(0, report.score);
  report.level = report.score >= 70 ? 'good' : report.score >= 40 ? 'medium' : 'poor';

  return report;
}

/**
 * Fetch and extract a URL
 */
export async function previewUrl(rawUrl) {
  const validation = validateUrl(rawUrl);
  if (!validation.valid) {
    throw new Error(validation.error);
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), FETCH_TIMEOUT);

  try {
    const response = await fetch(validation.url, {
      method: 'GET',
      signal: controller.signal,
      redirect: 'follow',
      headers: {
        'Accept': 'text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.8'
      }
    });

    clearTimeout(timeoutId);

    const contentType = response.headers.get('content-type') || '';
    const contentLength = parseInt(response.headers.get('content-length') || '0', 10);

    if (contentLength > MAX_RESPONSE_SIZE) {
      throw new Error('حجم صفحه بیش از حد مجاز است (۲ مگابایت)');
    }

    const buffer = await response.arrayBuffer();
    if (buffer.byteLength > MAX_RESPONSE_SIZE) {
      throw new Error('حجم صفحه بیش از حد مجاز است');
    }

    const decoder = new TextDecoder('utf-8');
    const html = decoder.decode(buffer);

    const extracted = extractContent(html, validation.url);
    const contentHash = await sha256(extracted.text);
    const qualityReport = buildQualityReport(extracted, response.status, contentType);

    return {
      requestedUrl: rawUrl,
      finalUrl: response.url,
      httpStatus: response.status,
      contentType,
      title: extracted.title,
      extractedText: extracted.text,
      contentHash,
      qualityReport,
      retrievedAt: Date.now()
    };
  } catch (err) {
    clearTimeout(timeoutId);
    if (err.name === 'AbortError') {
      throw new Error('زمان درخواست به پایان رسید');
    }
    // CORS or network errors are common in pure client-side
    throw new Error(
      err.message.includes('Failed to fetch') || err.name === 'TypeError'
        ? 'دسترسی به این آدرس از مرورگر ممکن نیست (احتمالاً محدودیت CORS). بسیاری از سایت‌ها اجازه خواندن مستقیم از مرورگر را نمی‌دهند.'
        : err.message
    );
  }
}

/**
 * Save preview as a new source + version (pending approval)
 */
export async function savePreview(previewData) {
  // Check if source with same finalUrl exists
  let sourceId;
  const existingSources = await (await import('../db/db.js')).db.sources
    .where('finalUrl').equals(previewData.finalUrl).first();

  if (existingSources) {
    sourceId = existingSources.id;
    // Check for duplicate content hash
    const versions = await (await import('../db/db.js')).db.versions
      .where('sourceId').equals(sourceId).toArray();
    const duplicate = versions.find(v => v.contentHash === previewData.contentHash);
    if (duplicate) {
      throw new Error('محتوای یکسان قبلاً ذخیره شده است (نسخه ' + duplicate.versionNumber + ')');
    }
  } else {
    sourceId = await createSource({
      url: previewData.requestedUrl,
      finalUrl: previewData.finalUrl,
      title: previewData.title
    });
  }

  const versionId = await createVersion({
    sourceId,
    contentHash: previewData.contentHash,
    title: previewData.title,
    extractedText: previewData.extractedText,
    qualityReport: previewData.qualityReport,
    retrievedAt: previewData.retrievedAt,
    httpStatus: previewData.httpStatus,
    contentType: previewData.contentType,
    finalUrl: previewData.finalUrl
  });

  return { sourceId, versionId };
}
