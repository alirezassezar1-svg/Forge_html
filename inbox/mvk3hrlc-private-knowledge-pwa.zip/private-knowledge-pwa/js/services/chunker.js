/**
 * Heading-aware text chunker
 */
export function chunkText(text, options = {}) {
  const {
    chunkSize = 500,
    chunkOverlap = 80
  } = options;

  if (!text || text.length === 0) return [];

  // Split by headings first (simple heuristic)
  const headingRegex = /^(#{1,6}\s+.+|[A-Z][^\n]{10,80})\n/gm;
  const sections = [];
  let lastIndex = 0;
  let match;

  // Simple paragraph-based chunking (more reliable without full markdown)
  const paragraphs = text.split(/\n\s*\n/).filter(p => p.trim().length > 0);

  const chunks = [];
  let current = '';
  let currentHeading = null;

  for (const para of paragraphs) {
    const trimmed = para.trim();

    // Detect possible heading
    const isHeading = trimmed.length < 100 &&
      (trimmed.endsWith(':') || /^[۰-۹0-9]+\./.test(trimmed) || trimmed === trimmed.toUpperCase());

    if (isHeading && current.length > 0) {
      // flush current
      chunks.push({
        heading: currentHeading,
        text: current.trim(),
        startOffset: 0,
        endOffset: current.length
      });
      current = '';
      currentHeading = trimmed;
    } else if (isHeading) {
      currentHeading = trimmed;
    }

    if (current.length + trimmed.length + 1 > chunkSize && current.length > 0) {
      chunks.push({
        heading: currentHeading,
        text: current.trim(),
        startOffset: 0,
        endOffset: current.length
      });

      // overlap
      const words = current.split(/\s+/);
      const overlapWords = words.slice(-Math.floor(chunkOverlap / 5));
      current = overlapWords.join(' ') + '\n\n' + trimmed;
    } else {
      current = current ? current + '\n\n' + trimmed : trimmed;
    }
  }

  if (current.trim()) {
    chunks.push({
      heading: currentHeading,
      text: current.trim(),
      startOffset: 0,
      endOffset: current.length
    });
  }

  return chunks.filter(c => c.text.length > 30);
}
