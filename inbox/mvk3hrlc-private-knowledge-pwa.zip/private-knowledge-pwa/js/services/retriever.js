/**
 * Hybrid local retriever (Full-text first)
 * Vector search can be added later with Transformers.js
 */
import { getApprovedChunks, getVersion, getSource } from '../db/db.js';
import { chunkText } from './chunker.js';
import { saveChunks } from '../db/db.js';

let miniSearch = null;
let indexedVersionIds = new Set();

/**
 * Build or rebuild the full-text index from approved chunks
 */
export async function buildIndex() {
  const chunks = await getApprovedChunks();

  miniSearch = new MiniSearch({
    fields: ['text', 'heading'],
    storeFields: ['id', 'versionId', 'sourceId', 'heading', 'text', 'order'],
    searchOptions: {
      boost: { heading: 2 },
      fuzzy: 0.2,
      prefix: true
    }
  });

  if (chunks.length > 0) {
    // MiniSearch needs an id field
    const docs = chunks.map(c => ({
      ...c,
      id: c.id
    }));
    miniSearch.addAll(docs);
    indexedVersionIds = new Set(chunks.map(c => c.versionId));
  }

  console.log(`[Retriever] Indexed ${chunks.length} chunks`);
  return chunks.length;
}

/**
 * Ensure a newly approved version is chunked and indexed
 */
export async function indexVersion(versionId) {
  const version = await getVersion(versionId);
  if (!version || !version.approved) return;

  // Check if already chunked
  const existing = await (await import('../db/db.js')).db.chunks
    .where('versionId').equals(versionId).count();

  if (existing === 0) {
    const chunks = chunkText(version.extractedText, {
      chunkSize: 500,
      chunkOverlap: 80
    });
    await saveChunks(versionId, version.sourceId, chunks);
  }

  // Rebuild index (simple approach for small personal knowledge bases)
  await buildIndex();
}

/**
 * Search approved knowledge
 */
export async function search(query, options = {}) {
  const { topK = 6 } = options;

  if (!miniSearch) {
    await buildIndex();
  }

  if (!miniSearch || miniSearch.documentCount === 0) {
    return {
      results: [],
      mode: 'empty',
      message: 'هنوز دانشی تأیید نشده است'
    };
  }

  const results = miniSearch.search(query, { combineWith: 'AND' });

  // Enrich with source info
  const enriched = [];
  for (const r of results.slice(0, topK)) {
    const version = await getVersion(r.versionId);
    const source = await getSource(r.sourceId);
    enriched.push({
      chunkId: r.id,
      versionId: r.versionId,
      sourceId: r.sourceId,
      score: r.score,
      heading: r.heading,
      text: r.text,
      excerpt: r.text.substring(0, 280) + (r.text.length > 280 ? '…' : ''),
      sourceTitle: source?.title || version?.title || 'بدون عنوان',
      sourceUrl: source?.finalUrl || version?.finalUrl,
      retrievedAt: version?.retrievedAt,
      versionNumber: version?.versionNumber
    });
  }

  return {
    results: enriched,
    mode: 'fulltext',
    total: results.length
  };
}

/**
 * Get context string for LLM prompt
 */
export function buildContext(results) {
  if (!results.length) return '';

  return results.map((r, i) => {
    return `[${i + 1}] منبع: ${r.sourceTitle} (نسخه ${r.versionNumber})\n${r.excerpt}`;
  }).join('\n\n');
}
