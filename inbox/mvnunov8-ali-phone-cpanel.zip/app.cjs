// نقطه شروع برای cPanel Node.js Selector (Passenger)
// Startup file: app.cjs
import('./server/index.mjs').catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
