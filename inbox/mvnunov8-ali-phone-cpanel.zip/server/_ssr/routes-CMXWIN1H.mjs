import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toGregorian, r as toJalaali, t as jalaaliMonthLength } from "../_libs/jalaali-js.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CMXWIN1H.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TRACKS = [
	{
		id: "t1",
		title: "شب تیتانیوم",
		artist: "ALI",
		hue: "#5E5CE6"
	},
	{
		id: "t2",
		title: "باران شیشه",
		artist: "ALI",
		hue: "#64D2FF"
	},
	{
		id: "t3",
		title: "اتاق روشن",
		artist: "ALI",
		hue: "#FF9F0A"
	},
	{
		id: "t4",
		title: "کویر آرام",
		artist: "ALI",
		hue: "#C4A484"
	}
];
var listeners = /* @__PURE__ */ new Set();
var ctx = null;
var master = null;
var timer = null;
var step = 0;
var playing = false;
var trackIndex = 0;
var volume = .7;
function emit() {
	listeners.forEach((fn) => fn());
}
function ensure() {
	if (!ctx) {
		ctx = new (window.AudioContext || window.webkitAudioContext)();
		master = ctx.createGain();
		master.gain.value = volume * .15;
		master.connect(ctx.destination);
	}
	return ctx;
}
var PATTERNS = [
	[
		220,
		277,
		330,
		277,
		196,
		247,
		294,
		247
	],
	[
		196,
		247,
		294,
		392,
		294,
		247,
		220,
		196
	],
	[
		262,
		330,
		392,
		330,
		294,
		349,
		440,
		349
	],
	[
		174,
		220,
		262,
		220,
		196,
		233,
		294,
		233
	]
];
function blip(freq, dur, type, gain) {
	if (!ctx || !master) return;
	const o = ctx.createOscillator();
	const g = ctx.createGain();
	o.type = type;
	o.frequency.value = freq;
	g.gain.setValueAtTime(gain, ctx.currentTime);
	g.gain.exponentialRampToValueAtTime(.001, ctx.currentTime + dur);
	o.connect(g);
	g.connect(master);
	o.start();
	o.stop(ctx.currentTime + dur + .02);
}
function tickMusic() {
	if (!playing || !ctx) return;
	const pat = PATTERNS[trackIndex % PATTERNS.length];
	const freq = pat[step % pat.length];
	blip(freq, .28, "triangle", .9);
	if (step % 2 === 0) blip(freq / 2, .32, "sine", .45);
	step += 1;
}
var music = {
	tracks: TRACKS,
	get playing() {
		return playing;
	},
	get trackIndex() {
		return trackIndex;
	},
	get track() {
		return TRACKS[trackIndex];
	},
	subscribe(fn) {
		listeners.add(fn);
		return () => {
			listeners.delete(fn);
		};
	},
	setVolume(v) {
		volume = v;
		if (master && ctx) master.gain.value = v * .15;
	},
	async toggle() {
		const c = ensure();
		if (c.state === "suspended") await c.resume();
		playing = !playing;
		if (playing) {
			if (timer == null) timer = window.setInterval(tickMusic, 320);
			tickMusic();
		} else if (timer != null) {
			window.clearInterval(timer);
			timer = null;
		}
		emit();
	},
	async playIndex(i) {
		trackIndex = (i + TRACKS.length) % TRACKS.length;
		step = 0;
		if (!playing) await music.toggle();
		else emit();
	},
	next() {
		trackIndex = (trackIndex + 1) % TRACKS.length;
		step = 0;
		emit();
	},
	prev() {
		trackIndex = (trackIndex - 1 + TRACKS.length) % TRACKS.length;
		step = 0;
		emit();
	}
};
function tapSound(enabled) {
	if (!enabled) return;
	try {
		const c = ensure();
		if (c.state === "suspended") c.resume();
		blip(880, .04, "sine", .25);
		if (navigator.vibrate) navigator.vibrate(8);
	} catch {}
}
function beepAlarm() {
	try {
		const c = ensure();
		if (c.state === "suspended") c.resume();
		blip(880, .18, "sine", 1);
		window.setTimeout(() => blip(1175, .22, "sine", 1), 200);
	} catch {}
}
function padHit(freq) {
	try {
		const c = ensure();
		if (c.state === "suspended") c.resume();
		blip(freq, .18, "square", .35);
	} catch {}
}
var DOCK = [
	"phone",
	"safari",
	"messages",
	"music"
];
var DEFAULT_HOME = [
	"camera",
	"photos",
	"weather",
	"clock",
	"maps",
	"notes",
	"calendar",
	"reminders",
	"appstore",
	"settings",
	"calculator",
	"files",
	"mail",
	"health",
	"wallet",
	"stocks",
	"translate",
	"compass",
	"voicememo",
	"contacts",
	"books",
	"podcasts",
	"shortcuts",
	"fitness"
];
var APPS = {
	phone: {
		fa: "تلفن",
		en: "Phone",
		cat: "main",
		core: true,
		blurbFa: "شماره‌گیری، مخاطبان و تماس",
		blurbEn: "Keypad, contacts and calls"
	},
	safari: {
		fa: "سافاری",
		en: "Safari",
		cat: "main",
		core: true,
		blurbFa: "وب و افزودن به صفحه اصلی",
		blurbEn: "Web and Add to Home Screen"
	},
	messages: {
		fa: "پیام‌ها",
		en: "Messages",
		cat: "main",
		core: true,
		blurbFa: "گفتگوهای روی دستگاه",
		blurbEn: "On-device conversations"
	},
	music: {
		fa: "موسیقی",
		en: "Music",
		cat: "main",
		core: true,
		blurbFa: "پخش آهنگ‌های اصلی",
		blurbEn: "Original tracks"
	},
	camera: {
		fa: "دوربین",
		en: "Camera",
		cat: "main",
		core: true,
		blurbFa: "عکس با دوربین دستگاه",
		blurbEn: "Shoot with the device camera"
	},
	photos: {
		fa: "عکس‌ها",
		en: "Photos",
		cat: "main",
		core: true,
		blurbFa: "گالری و علاقه‌مندی",
		blurbEn: "Library and favorites"
	},
	weather: {
		fa: "هواشناسی",
		en: "Weather",
		cat: "life",
		core: true,
		blurbFa: "دمای واقعی همین‌جا",
		blurbEn: "Live local forecast"
	},
	clock: {
		fa: "ساعت",
		en: "Clock",
		cat: "tools",
		core: true,
		blurbFa: "زنگ، زمان‌سنج، کرونومتر",
		blurbEn: "Alarms, timer, stopwatch"
	},
	maps: {
		fa: "نقشه",
		en: "Maps",
		cat: "life",
		core: true,
		blurbFa: "نقشه و موقعیت",
		blurbEn: "Map and location"
	},
	notes: {
		fa: "یادداشت",
		en: "Notes",
		cat: "create",
		core: true,
		blurbFa: "یادداشت سریع",
		blurbEn: "Quick notes"
	},
	calendar: {
		fa: "تقویم",
		en: "Calendar",
		cat: "life",
		core: true,
		blurbFa: "تقویم شمسی و رویداد",
		blurbEn: "Month and events"
	},
	reminders: {
		fa: "یادآورها",
		en: "Reminders",
		cat: "life",
		core: true,
		blurbFa: "فهرست کارها",
		blurbEn: "To-dos"
	},
	appstore: {
		fa: "اپ استور",
		en: "App Store",
		cat: "main",
		core: true,
		blurbFa: "نصب اپ و وب‌اپ",
		blurbEn: "Install apps and web apps"
	},
	settings: {
		fa: "تنظیمات",
		en: "Settings",
		cat: "tools",
		core: true,
		blurbFa: "ظاهر، صدا، زبان",
		blurbEn: "Look, sound, language"
	},
	calculator: {
		fa: "ماشین‌حساب",
		en: "Calculator",
		cat: "tools",
		core: true,
		blurbFa: "حساب چهارعمل",
		blurbEn: "Arithmetic"
	},
	files: {
		fa: "فایل‌ها",
		en: "Files",
		cat: "tools",
		core: true,
		blurbFa: "پوشه و فایل متنی",
		blurbEn: "Folders and text files"
	},
	mail: {
		fa: "ایمیل",
		en: "Mail",
		cat: "main",
		core: true,
		blurbFa: "صندوق روی دستگاه",
		blurbEn: "On-device inbox"
	},
	health: {
		fa: "سلامت",
		en: "Health",
		cat: "life",
		core: true,
		blurbFa: "حلقه‌ها و آب",
		blurbEn: "Rings and water"
	},
	wallet: {
		fa: "کیف پول",
		en: "Wallet",
		cat: "life",
		core: true,
		blurbFa: "کارت‌های نمایشی",
		blurbEn: "Visual cards"
	},
	stocks: {
		fa: "سهام",
		en: "Stocks",
		cat: "life",
		core: true,
		blurbFa: "نمودار بازار نمونه",
		blurbEn: "Sample market charts"
	},
	translate: {
		fa: "ترجمه",
		en: "Translate",
		cat: "tools",
		core: true,
		blurbFa: "واژه‌نامه آفلاین",
		blurbEn: "Offline dictionary"
	},
	compass: {
		fa: "قطب‌نما",
		en: "Compass",
		cat: "tools",
		core: true,
		blurbFa: "جهت دستگاه",
		blurbEn: "Device heading"
	},
	voicememo: {
		fa: "یادداشت صوتی",
		en: "Voice Memos",
		cat: "create",
		core: true,
		blurbFa: "ضبط صدا",
		blurbEn: "Record audio"
	},
	contacts: {
		fa: "مخاطبان",
		en: "Contacts",
		cat: "main",
		core: true,
		blurbFa: "دفترچه تلفن",
		blurbEn: "Address book"
	},
	books: {
		fa: "کتاب",
		en: "Books",
		cat: "create",
		core: true,
		blurbFa: "داستان کوتاه",
		blurbEn: "Short stories"
	},
	podcasts: {
		fa: "پادکست",
		en: "Podcasts",
		cat: "create",
		core: true,
		blurbFa: "اپیزود و پخش",
		blurbEn: "Episodes"
	},
	shortcuts: {
		fa: "میانبرها",
		en: "Shortcuts",
		cat: "tools",
		core: true,
		blurbFa: "کارهای یک‌ضربه",
		blurbEn: "One-tap actions"
	},
	fitness: {
		fa: "تناسب",
		en: "Fitness",
		cat: "life",
		core: true,
		blurbFa: "تمرین با زمان",
		blurbEn: "Timed workouts"
	},
	news: {
		fa: "اخبار",
		en: "News",
		cat: "life",
		core: false,
		blurbFa: "تیترهای نمونه",
		blurbEn: "Sample headlines"
	},
	tv: {
		fa: "تماشا",
		en: "TV",
		cat: "create",
		core: false,
		blurbFa: "پوستر و پخش",
		blurbEn: "Posters and player"
	},
	homeapp: {
		fa: "خانه",
		en: "Home",
		cat: "life",
		core: false,
		blurbFa: "چراغ اتاق‌ها",
		blurbEn: "Room lights"
	},
	find: {
		fa: "پیدا کن",
		en: "Find",
		cat: "life",
		core: false,
		blurbFa: "رادار این دستگاه",
		blurbEn: "This device"
	},
	journal: {
		fa: "دفتر روزانه",
		en: "Journal",
		cat: "create",
		core: false,
		blurbFa: "خاطره روزانه",
		blurbEn: "Daily journal"
	},
	passwords: {
		fa: "رمزها",
		en: "Passwords",
		cat: "tools",
		core: false,
		blurbFa: "یادداشت رمز، فقط همین دستگاه",
		blurbEn: "Local-only secrets"
	},
	measure: {
		fa: "اندازه",
		en: "Measure",
		cat: "tools",
		core: false,
		blurbFa: "خط‌کش و تراز",
		blurbEn: "Ruler and level"
	},
	tips: {
		fa: "نکته‌ها",
		en: "Tips",
		cat: "tools",
		core: false,
		blurbFa: "کار با این آیفون",
		blurbEn: "How to use this iPhone"
	},
	studio: {
		fa: "استودیو",
		en: "Studio",
		cat: "create",
		core: false,
		blurbFa: "پد ریتم",
		blurbEn: "Drum pads"
	},
	sheets: {
		fa: "جدول",
		en: "Sheets",
		cat: "create",
		core: false,
		blurbFa: "جدول کوچک",
		blurbEn: "Tiny spreadsheet"
	},
	writer: {
		fa: "نوشته",
		en: "Writer",
		cat: "create",
		core: false,
		blurbFa: "متن بلند",
		blurbEn: "Long-form writing"
	},
	board: {
		fa: "تخته",
		en: "Board",
		cat: "create",
		core: false,
		blurbFa: "یادداشت چسبان",
		blurbEn: "Sticky notes"
	},
	magnifier: {
		fa: "ذره‌بین",
		en: "Magnifier",
		cat: "tools",
		core: false,
		blurbFa: "زوم دوربین",
		blurbEn: "Camera zoom"
	}
};
var WALLPAPERS = [
	{
		id: "aurora",
		url: "/wallpapers/aurora.jpg",
		fa: "شفق",
		en: "Aurora"
	},
	{
		id: "dune",
		url: "/wallpapers/dune.jpg",
		fa: "کویر",
		en: "Dune"
	},
	{
		id: "ocean",
		url: "/wallpapers/ocean.jpg",
		fa: "اقیانوس",
		en: "Ocean"
	},
	{
		id: "mist",
		url: "/wallpapers/mist.jpg",
		fa: "مه",
		en: "Mist"
	}
];
var CITIES = [
	{
		fa: "تهران",
		en: "Tehran",
		lat: 35.6892,
		lon: 51.389,
		tz: "Asia/Tehran"
	},
	{
		fa: "شیراز",
		en: "Shiraz",
		lat: 29.5918,
		lon: 52.5837,
		tz: "Asia/Tehran"
	},
	{
		fa: "اصفهان",
		en: "Isfahan",
		lat: 32.6539,
		lon: 51.666,
		tz: "Asia/Tehran"
	},
	{
		fa: "مشهد",
		en: "Mashhad",
		lat: 36.2605,
		lon: 59.6168,
		tz: "Asia/Tehran"
	},
	{
		fa: "کیش",
		en: "Kish",
		lat: 26.532,
		lon: 53.98,
		tz: "Asia/Tehran"
	},
	{
		fa: "شیکاگو",
		en: "Chicago",
		lat: 41.8781,
		lon: -87.6298,
		tz: "America/Chicago"
	},
	{
		fa: "دبی",
		en: "Dubai",
		lat: 25.2048,
		lon: 55.2708,
		tz: "Asia/Dubai"
	},
	{
		fa: "استانبول",
		en: "Istanbul",
		lat: 41.0082,
		lon: 28.9784,
		tz: "Europe/Istanbul"
	},
	{
		fa: "پاریس",
		en: "Paris",
		lat: 48.8566,
		lon: 2.3522,
		tz: "Europe/Paris"
	},
	{
		fa: "توکیو",
		en: "Tokyo",
		lat: 35.6762,
		lon: 139.6503,
		tz: "Asia/Tokyo"
	}
];
var JM = [
	"فروردین",
	"اردیبهشت",
	"خرداد",
	"تیر",
	"مرداد",
	"شهریور",
	"مهر",
	"آبان",
	"آذر",
	"دی",
	"بهمن",
	"اسفند"
];
var GM = [
	"January",
	"February",
	"March",
	"April",
	"May",
	"June",
	"July",
	"August",
	"September",
	"October",
	"November",
	"December"
];
var WD_FA = [
	"یکشنبه",
	"دوشنبه",
	"سه‌شنبه",
	"چهارشنبه",
	"پنجشنبه",
	"جمعه",
	"شنبه"
];
var WD_EN = [
	"Sunday",
	"Monday",
	"Tuesday",
	"Wednesday",
	"Thursday",
	"Friday",
	"Saturday"
];
function faNum(input, lang) {
	const s = String(input);
	if (lang !== "fa") return s;
	return s.replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)] ?? d);
}
function uid(prefix = "id") {
	return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}
function formatClock(d, lang) {
	return faNum(`${lang === "en" ? d.getHours() % 12 || 12 : d.getHours()}:${d.getMinutes().toString().padStart(2, "0")}`, lang);
}
function formatLockDate(d, lang) {
	if (lang === "en") return `${WD_EN[d.getDay()]}, ${GM[d.getMonth()]} ${d.getDate()}`;
	const j = toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
	return `${WD_FA[d.getDay()]} ${faNum(j.jd, "fa")} ${JM[j.jm - 1]}`;
}
function jalaliParts(d) {
	return toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
}
function monthTitle(view, lang) {
	if (lang === "en") return `${GM[view.m - 1]} ${view.y}`;
	return `${JM[view.m - 1]} ${faNum(view.y, "fa")}`;
}
function monthGrid(view, lang) {
	if (lang === "en") {
		const start = new Date(view.y, view.m - 1, 1).getDay();
		const days = new Date(view.y, view.m, 0).getDate();
		const cells = [];
		for (let i = 0; i < start; i++) cells.push({
			key: `e${i}`,
			label: "",
			inMonth: false
		});
		for (let d = 1; d <= days; d++) {
			const dt = new Date(view.y, view.m - 1, d);
			const key = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
			cells.push({
				key,
				label: String(d),
				inMonth: true
			});
		}
		return cells;
	}
	const len = jalaaliMonthLength(view.y, view.m);
	const g = toGregorian(view.y, view.m, 1);
	const start = new Date(g.gy, g.gm - 1, g.gd).getDay();
	const cells = [];
	for (let i = 0; i < start; i++) cells.push({
		key: `e${i}`,
		label: "",
		inMonth: false
	});
	for (let d = 1; d <= len; d++) {
		const gg = toGregorian(view.y, view.m, d);
		const key = `${gg.gy}-${String(gg.gm).padStart(2, "0")}-${String(gg.gd).padStart(2, "0")}`;
		cells.push({
			key,
			label: faNum(d, "fa"),
			inMonth: true
		});
	}
	return cells;
}
function todayKey(d) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function shiftMonth(view, dir, lang) {
	let m = view.m + dir;
	let y = view.y;
	if (m > 12) {
		m = 1;
		y += 1;
	} else if (m < 1) {
		m = 12;
		y -= 1;
	}
	if (lang === "fa" && m === 12) {}
	return {
		y,
		m
	};
}
function initialView(d, lang) {
	if (lang === "en") return {
		y: d.getFullYear(),
		m: d.getMonth() + 1
	};
	const j = jalaliParts(d);
	return {
		y: j.jy,
		m: j.jm
	};
}
var DICT = [
	{
		fa: "سلام",
		en: "hello"
	},
	{
		fa: "خداحافظ",
		en: "goodbye"
	},
	{
		fa: "ممنون",
		en: "thank you"
	},
	{
		fa: "لطفاً",
		en: "please"
	},
	{
		fa: "بله",
		en: "yes"
	},
	{
		fa: "نه",
		en: "no"
	},
	{
		fa: "آب",
		en: "water"
	},
	{
		fa: "نان",
		en: "bread"
	},
	{
		fa: "خانه",
		en: "home"
	},
	{
		fa: "تلفن",
		en: "phone"
	},
	{
		fa: "کتاب",
		en: "book"
	},
	{
		fa: "عشق",
		en: "love"
	},
	{
		fa: "دوست",
		en: "friend"
	},
	{
		fa: "زمان",
		en: "time"
	},
	{
		fa: "روز",
		en: "day"
	},
	{
		fa: "شب",
		en: "night"
	},
	{
		fa: "شهر",
		en: "city"
	},
	{
		fa: "ماشین",
		en: "car"
	},
	{
		fa: "غذا",
		en: "food"
	},
	{
		fa: "قهوه",
		en: "coffee"
	},
	{
		fa: "کار",
		en: "work"
	},
	{
		fa: "مدرسه",
		en: "school"
	},
	{
		fa: "موسیقی",
		en: "music"
	},
	{
		fa: "عکس",
		en: "photo"
	},
	{
		fa: "باران",
		en: "rain"
	},
	{
		fa: "آفتاب",
		en: "sun"
	},
	{
		fa: "دریا",
		en: "sea"
	},
	{
		fa: "کوه",
		en: "mountain"
	},
	{
		fa: "امروز",
		en: "today"
	},
	{
		fa: "فردا",
		en: "tomorrow"
	},
	{
		fa: "دیروز",
		en: "yesterday"
	},
	{
		fa: "خانواده",
		en: "family"
	},
	{
		fa: "نام",
		en: "name"
	},
	{
		fa: "آدرس",
		en: "address"
	},
	{
		fa: "کمک",
		en: "help"
	},
	{
		fa: "زیبا",
		en: "beautiful"
	},
	{
		fa: "بزرگ",
		en: "big"
	},
	{
		fa: "کوچک",
		en: "small"
	},
	{
		fa: "سریع",
		en: "fast"
	},
	{
		fa: "آرام",
		en: "slow"
	}
];
function blankSheet() {
	return Array.from({ length: 8 }, () => Array.from({ length: 4 }, () => ""));
}
var DEFAULT_DATA = {
	lang: "fa",
	wallpaper: WALLPAPERS[0].url,
	brightness: 1,
	volume: .7,
	wifi: true,
	bluetooth: true,
	airplane: false,
	cellular: true,
	lowPower: false,
	silent: false,
	flashlight: false,
	finish: "black",
	home: DEFAULT_HOME,
	installed: [],
	notes: [{
		id: "n1",
		title: "ایده آیفون",
		body: "آیکون‌ها ۶۰ نقطه هستند. چهار ستون. داک بدون اسم. برای نصب اپ برو به اپ استور.",
		updated: 176118e7
	}, {
		id: "n2",
		title: "خرید",
		body: "قهوه، نان، باتری ساعت.",
		updated: 17611e8
	}],
	contacts: [
		{
			id: "c1",
			name: "سارا نادری",
			phone: "09120001111",
			color: "#34C759"
		},
		{
			id: "c2",
			name: "امیر حسینی",
			phone: "09123334455",
			color: "#0A84FF"
		},
		{
			id: "c3",
			name: "نیکا",
			phone: "09351112233",
			color: "#FF9F0A"
		},
		{
			id: "c4",
			name: "دفتر",
			phone: "02188001234",
			color: "#8E8E93"
		}
	],
	threads: {
		c1: {
			unread: 1,
			messages: [
				{
					id: "m1",
					from: "them",
					text: "فردا ساعت ۱۰ همون کافه؟",
					at: 1761182e6
				},
				{
					id: "m2",
					from: "me",
					text: "آره، میز کنار پنجره.",
					at: 17611823e5
				},
				{
					id: "m3",
					from: "them",
					text: "عالی. عکس منو رو هم بفرست.",
					at: 1761184e6
				}
			]
		},
		c2: {
			unread: 0,
			messages: [{
				id: "m4",
				from: "them",
				text: "فایل پروژه رو گذاشتم توی فایل‌ها.",
				at: 1761e9
			}]
		}
	},
	events: [{
		id: "e1",
		title: "قرار کافه",
		day: "2026-10-24",
		time: "10:00",
		color: "#0A84FF"
	}, {
		id: "e2",
		title: "تمرین",
		day: "2026-10-25",
		time: "18:30",
		color: "#30D158"
	}],
	reminders: [
		{
			id: "r1",
			title: "شارژ ساعت",
			done: false
		},
		{
			id: "r2",
			title: "پاسخ ایمیل دفتر",
			done: false
		},
		{
			id: "r3",
			title: "والپیپر جدید",
			done: true
		}
	],
	files: [
		{
			id: "f-doc",
			name: "Documents",
			kind: "folder",
			parent: null
		},
		{
			id: "f-dl",
			name: "Downloads",
			kind: "folder",
			parent: null
		},
		{
			id: "f1",
			name: "یادداشت.txt",
			kind: "text",
			parent: "f-doc",
			body: "این یک فایل متنی روی همین دستگاه است."
		}
	],
	photos: [
		{
			id: "ph1",
			url: "/wallpapers/dune.jpg",
			at: 1761e9
		},
		{
			id: "ph2",
			url: "/wallpapers/ocean.jpg",
			at: 17609e8
		},
		{
			id: "ph3",
			url: "/wallpapers/mist.jpg",
			at: 17608e8,
			fav: true
		}
	],
	alarms: [{
		id: "a1",
		hour: 7,
		minute: 0,
		on: false,
		label: "بیدارباش"
	}, {
		id: "a2",
		hour: 22,
		minute: 30,
		on: false,
		label: "خاموشی"
	}],
	webApps: [],
	mails: [{
		id: "ml1",
		from: "ALI Phone",
		subject: "به آیفون مجازی خوش آمدی",
		body: "از اپ استور هر برنامه‌ای را نصب کن. در سافاری هم می‌توانی سایت را به صفحهٔ اصلی اضافه کنی. همه چیز روی همین دستگاه می‌ماند.",
		read: false,
		at: 176118e7
	}, {
		id: "ml2",
		from: "سارا",
		subject: "منوی کافه",
		body: "اسپرسو و چیزکیک. اگر دیر کردم شروع کن.",
		read: true,
		at: 1761e9
	}],
	journal: [{
		id: "j1",
		body: "اولین روز با این آیفون. صفحهٔ اصلی دقیقاً چهار ستون است.",
		at: 176118e7
	}],
	secrets: [],
	cards: [{
		id: "cd1",
		label: "ALI",
		last4: "1616",
		color: "#1c1c1e",
		holder: "ALI PHONE"
	}, {
		id: "cd2",
		label: "Cash",
		last4: "0420",
		color: "#0A84FF",
		holder: "EVERYDAY"
	}],
	docs: [{
		id: "d1",
		title: "بدون عنوان",
		body: ""
	}],
	sheets: [{
		id: "s1",
		name: "بودجه",
		cells: blankSheet()
	}],
	stickies: [{
		id: "st1",
		text: "ایده",
		x: 24,
		y: 24,
		color: "#FFE066"
	}, {
		id: "st2",
		text: "بعداً",
		x: 150,
		y: 90,
		color: "#FFD6E0"
	}],
	water: 2,
	workouts: [],
	recents: [{
		id: "rc1",
		name: "سارا نادری",
		number: "09120001111",
		at: 176118e7
	}],
	lights: {
		"اتاق": true,
		"آشپزخانه": false,
		"کار": true
	}
};
function available(data, id) {
	if (id.startsWith("web:")) return data.webApps.some((w) => w.id === id);
	const meta = APPS[id];
	if (!meta) return false;
	return meta.core || data.installed.includes(id);
}
function webOf(data, id) {
	return data.webApps.find((w) => w.id === id);
}
var CALC0 = {
	disp: "0",
	acc: null,
	op: null,
	fresh: true,
	error: false
};
function parseDisp(s) {
	const n = Number(s.replace("−", "-"));
	return Number.isFinite(n) ? n : NaN;
}
function formatNum(n) {
	if (!Number.isFinite(n)) return "خطا";
	const abs = Math.abs(n);
	if (abs !== 0 && (abs >= 1e9 || abs < 1e-9)) return n.toExponential(4).replace("+", "").replace("-", "−");
	let s = String(Number(n.toPrecision(10)));
	if (s.replace("-", "").replace(".", "").length > 9) s = n.toExponential(4).replace("+", "");
	return s.replace("-", "−");
}
function compute(a, op, b) {
	if (op === "+") return a + b;
	if (op === "−") return a - b;
	if (op === "×") return a * b;
	if (b === 0) return NaN;
	return a / b;
}
function calcKey(state, key) {
	if (key === "AC" || key === "C" && state.error) return { ...CALC0 };
	if (state.error && key !== "AC") return { ...CALC0 };
	if (key === "C") return {
		...state,
		disp: "0",
		fresh: true
	};
	if (key === "±") {
		if (state.disp === "0") return state;
		const neg = state.disp.startsWith("−");
		return {
			...state,
			disp: neg ? state.disp.slice(1) : `−${state.disp}`
		};
	}
	if (key === "%") {
		const cur = parseDisp(state.disp);
		if (state.op && state.acc != null && (state.op === "+" || state.op === "−")) return {
			...state,
			disp: formatNum(state.acc * (cur / 100)),
			fresh: true
		};
		return {
			...state,
			disp: formatNum(cur / 100),
			fresh: true
		};
	}
	if (key === "+" || key === "−" || key === "×" || key === "÷") {
		const cur = parseDisp(state.disp);
		if (state.acc != null && state.op && !state.fresh) {
			const r = compute(state.acc, state.op, cur);
			if (!Number.isFinite(r)) return {
				...CALC0,
				disp: "خطا",
				error: true
			};
			return {
				disp: formatNum(r),
				acc: r,
				op: key,
				fresh: true,
				error: false
			};
		}
		return {
			...state,
			acc: cur,
			op: key,
			fresh: true,
			error: false
		};
	}
	if (key === "=") {
		if (state.acc == null || !state.op) return state;
		const r = compute(state.acc, state.op, parseDisp(state.disp));
		if (!Number.isFinite(r)) return {
			...CALC0,
			disp: "خطا",
			error: true
		};
		return {
			disp: formatNum(r),
			acc: null,
			op: null,
			fresh: true,
			error: false
		};
	}
	if (/^[0-9.]$/.test(key)) {
		if (state.fresh) return {
			...state,
			disp: key === "." ? "0." : key,
			fresh: false,
			error: false
		};
		if (key === "." && state.disp.includes(".")) return state;
		if (state.disp.replace("−", "").replace(".", "").length >= 9) return state;
		const next = state.disp === "0" && key !== "." ? key : state.disp + key;
		return {
			...state,
			disp: next
		};
	}
	return state;
}
function mergeSaved(raw) {
	if (!raw || typeof raw !== "object") return DEFAULT_DATA;
	const s = raw;
	const home = Array.isArray(s.home) ? s.home.filter((id) => typeof id === "string") : DEFAULT_DATA.home;
	return {
		...DEFAULT_DATA,
		...s,
		home,
		installed: Array.isArray(s.installed) ? s.installed.filter((id) => typeof id === "string") : [],
		webApps: Array.isArray(s.webApps) ? s.webApps : [],
		notes: Array.isArray(s.notes) ? s.notes : DEFAULT_DATA.notes,
		contacts: Array.isArray(s.contacts) ? s.contacts : DEFAULT_DATA.contacts,
		threads: s.threads && typeof s.threads === "object" ? s.threads : DEFAULT_DATA.threads,
		events: Array.isArray(s.events) ? s.events : DEFAULT_DATA.events,
		reminders: Array.isArray(s.reminders) ? s.reminders : DEFAULT_DATA.reminders,
		files: Array.isArray(s.files) ? s.files : DEFAULT_DATA.files,
		photos: Array.isArray(s.photos) ? s.photos : DEFAULT_DATA.photos,
		alarms: Array.isArray(s.alarms) ? s.alarms : DEFAULT_DATA.alarms,
		mails: Array.isArray(s.mails) ? s.mails : DEFAULT_DATA.mails,
		journal: Array.isArray(s.journal) ? s.journal : DEFAULT_DATA.journal,
		secrets: Array.isArray(s.secrets) ? s.secrets : [],
		cards: Array.isArray(s.cards) ? s.cards : DEFAULT_DATA.cards,
		docs: Array.isArray(s.docs) ? s.docs : DEFAULT_DATA.docs,
		sheets: Array.isArray(s.sheets) ? s.sheets : DEFAULT_DATA.sheets,
		stickies: Array.isArray(s.stickies) ? s.stickies : DEFAULT_DATA.stickies,
		recents: Array.isArray(s.recents) ? s.recents : DEFAULT_DATA.recents,
		lights: s.lights && typeof s.lights === "object" ? s.lights : DEFAULT_DATA.lights,
		workouts: Array.isArray(s.workouts) ? s.workouts : [],
		lang: s.lang === "en" ? "en" : "fa",
		wallpaper: typeof s.wallpaper === "string" ? s.wallpaper : DEFAULT_DATA.wallpaper,
		finish: s.finish === "natural" || s.finish === "desert" || s.finish === "white" || s.finish === "black" ? s.finish : "black"
	};
}
var KEY = "aliphone.v1";
var Ctx = (0, import_react.createContext)(null);
function PhoneProvider({ children }) {
	const [data, setData] = (0, import_react.useState)(DEFAULT_DATA);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [now, setNow] = (0, import_react.useState)(null);
	const [locked, setLocked] = (0, import_react.useState)(false);
	const [app, setApp] = (0, import_react.useState)(null);
	const [recents, setRecents] = (0, import_react.useState)([]);
	const [memos, setMemos] = (0, import_react.useState)([]);
	const [call, setCall] = (0, import_react.useState)(null);
	const [timer, setTimer] = (0, import_react.useState)(null);
	const [ringing, setRinging] = (0, import_react.useState)(null);
	const [battery, setBattery] = (0, import_react.useState)(86);
	const fired = (0, import_react.useMemo)(() => ({ key: "" }), []);
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(KEY);
			if (raw) setData(mergeSaved(JSON.parse(raw)));
		} catch {}
		setReady(true);
		setNow(/* @__PURE__ */ new Date());
		const t = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 1e3);
		const bat = navigator;
		if (bat.getBattery) bat.getBattery().then((b) => setBattery(Math.round(b.level * 100))).catch(() => {});
		return () => window.clearInterval(t);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!ready) return;
		try {
			localStorage.setItem(KEY, JSON.stringify(data));
		} catch {
			const slim = {
				...data,
				photos: data.photos.filter((p) => !p.url.startsWith("data:")).slice(0, 6)
			};
			try {
				localStorage.setItem(KEY, JSON.stringify(slim));
			} catch {}
		}
	}, [data, ready]);
	(0, import_react.useEffect)(() => {
		music.setVolume(data.silent ? 0 : data.volume);
	}, [data.volume, data.silent]);
	(0, import_react.useEffect)(() => {
		if (!now) return;
		const key = `${now.getFullYear()}-${now.getMonth()}-${now.getDate()}-${now.getHours()}-${now.getMinutes()}`;
		if (now.getSeconds() > 1) return;
		const hit = data.alarms.find((a) => a.on && a.hour === now.getHours() && a.minute === now.getMinutes());
		if (hit && fired.key !== key) {
			fired.key = key;
			setRinging(hit);
			if (!data.silent) beepAlarm();
		}
	}, [
		now,
		data.alarms,
		data.silent,
		fired
	]);
	(0, import_react.useEffect)(() => {
		if (!timer || !now) return;
		if (now.getTime() >= timer.endsAt) {
			setTimer(null);
			if (!data.silent) beepAlarm();
			setRinging({
				id: "timer",
				hour: 0,
				minute: 0,
				on: true,
				label: data.lang === "fa" ? "زمان‌سنج" : "Timer"
			});
		}
	}, [
		now,
		timer,
		data.silent,
		data.lang
	]);
	const update = (patch) => {
		setData((d) => typeof patch === "function" ? patch(d) : {
			...d,
			...patch
		});
	};
	const lang = data.lang;
	const api = (0, import_react.useMemo)(() => {
		const unread = Object.values(data.threads).reduce((n, t) => n + (t.unread || 0), 0);
		return {
			data,
			now,
			rtl: lang === "fa",
			lang,
			locked,
			setLocked,
			app,
			openApp: (id) => {
				if (!available(data, id) && id !== "camera") return;
				setLocked(false);
				setApp(id);
				setRecents((r) => [id, ...r.filter((x) => x !== id)].slice(0, 8));
			},
			closeApp: () => setApp(null),
			recents,
			closeRecent: (id) => {
				setRecents((r) => r.filter((x) => x !== id));
				setApp((cur) => cur === id ? null : cur);
			},
			update,
			install: (id) => {
				update((d) => {
					if (d.installed.includes(id) || APPS[id]?.core) {
						if (d.home.includes(id) || DOCK.includes(id)) return d;
						return {
							...d,
							home: [...d.home, id]
						};
					}
					return {
						...d,
						installed: [...d.installed, id],
						home: [...d.home, id]
					};
				});
			},
			uninstall: (id) => {
				update((d) => {
					if (APPS[id]?.core) return {
						...d,
						home: d.home.filter((x) => x !== id)
					};
					return {
						...d,
						installed: d.installed.filter((x) => x !== id),
						home: d.home.filter((x) => x !== id),
						webApps: d.webApps.filter((w) => w.id !== id)
					};
				});
				setRecents((r) => r.filter((x) => x !== id));
				setApp((cur) => cur === id ? null : cur);
			},
			addWeb: (w) => {
				const id = `web:${uid("w")}`;
				update((d) => ({
					...d,
					webApps: [...d.webApps, {
						...w,
						id
					}],
					home: [...d.home, id]
				}));
				return id;
			},
			moveHome: (from, to) => {
				update((d) => {
					const h = d.home.slice();
					if (from < 0 || from >= h.length || to < 0 || to >= h.length) return d;
					const [it] = h.splice(from, 1);
					if (!it) return d;
					h.splice(to, 0, it);
					return {
						...d,
						home: h
					};
				});
			},
			nameOf: (id) => {
				const w = webOf(data, id);
				if (w) return w.name;
				const m = APPS[id];
				return m ? lang === "fa" ? m.fa : m.en : id;
			},
			isAvail: (id) => available(data, id),
			web: (id) => webOf(data, id),
			memos,
			addMemo: (m) => setMemos((xs) => [m, ...xs]),
			call,
			startCall: (name, number) => {
				setCall({
					name,
					number,
					started: Date.now()
				});
				setLocked(false);
				update((d) => ({
					...d,
					recents: [{
						id: uid("rc"),
						name,
						number,
						at: Date.now()
					}, ...d.recents].slice(0, 20)
				}));
			},
			endCall: () => setCall(null),
			timer,
			setTimer,
			ringing,
			dismissAlarm: () => setRinging(null),
			battery,
			unread
		};
	}, [
		data,
		now,
		lang,
		locked,
		app,
		recents,
		memos,
		call,
		timer,
		ringing,
		battery
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ctx.Provider, {
		value: api,
		children
	});
}
function usePhone() {
	const v = (0, import_react.useContext)(Ctx);
	if (!v) throw new Error("phone");
	return v;
}
function Screen({ title, back, right, children, scroll = true, padTop = true }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app",
		style: padTop ? void 0 : { paddingTop: 0 },
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nav",
				children: [
					back ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "nav-back",
						onClick: back,
						"aria-label": "back",
						children: "‹"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
					back ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "nav-title",
						children: title
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: right })
				]
			}),
			title && !back ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "large",
				children: title
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: scroll ? "app-scroll" : "app-fill",
				children
			})
		]
	});
}
function Group({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "group",
		children
	});
}
function Row({ label, value, onClick, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		className: "row",
		onClick,
		type: "button",
		children: [
			icon,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }),
			value != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "value",
				children: value
			})
		]
	});
}
function Toggle({ on, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: `switch ${on ? "on" : ""}`,
		onClick,
		"aria-pressed": on,
		type: "button",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {})
	});
}
function useT() {
	const { rtl } = usePhone();
	return (fa, en) => rtl ? fa : en;
}
function hands(now) {
	const d = now ?? new Date(2026, 9, 23, 9, 41, 0);
	const h = d.getHours() % 12 + d.getMinutes() / 60;
	const m = d.getMinutes() + d.getSeconds() / 60;
	const s = d.getSeconds();
	return {
		h: h * 30,
		m: m * 6,
		s: s * 6
	};
}
function IosIcon({ id, now, web }) {
	const uid = (0, import_react.useId)().replace(/:/g, "");
	if (web || id.startsWith("web:")) {
		const color = web?.color ?? "#0A84FF";
		const letter = (web?.name || "W").slice(0, 1);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "ios-glyph",
			"aria-hidden": true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				viewBox: "0 0 60 60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "60",
					height: "60",
					fill: color
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "30",
					y: "39",
					textAnchor: "middle",
					fontSize: "28",
					fontWeight: "700",
					fill: "#fff",
					fontFamily: "system-ui",
					children: letter
				})]
			})
		});
	}
	const { h, m, s } = hands(now);
	const day = now ? now.getDate() : 23;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "ios-glyph",
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 60 60",
			children: [
				id === "phone" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: `${uid}g`,
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0",
							stopColor: "#5BF675"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "1",
							stopColor: "#1EBE45"
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: `url(#${uid}g)`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						fill: "#fff",
						d: "M18.2 14.6c1.2-1.2 3.1-1.3 4.4-.2l3.4 2.9c1.1.9 1.3 2.5.5 3.7l-1.8 2.6a2 2 0 0 0-.1 1.9c1.2 2.4 3.1 4.6 5.4 6.4 1.6 1.2 3.4 2.1 5.4 2.7.6.2 1.3 0 1.7-.5l2-2.6c.8-1.1 2.4-1.3 3.6-.6l3.6 2.4c1.4 1 1.7 2.9.8 4.3l-1.6 2.4c-1.2 1.8-3.2 2.9-5.4 3-6.2.2-12.2-3.4-17.1-8.6-4.6-4.9-7.6-10.8-7-16.4.2-2 .1-3.4 1.2-4.4z"
					})
				] }),
				id === "messages" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: `${uid}g`,
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0",
							stopColor: "#5BF675"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "1",
							stopColor: "#1EBE45"
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: `url(#${uid}g)`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						fill: "#fff",
						d: "M30 12c10.5 0 19 7.4 19 16.5S40.5 45 30 45c-1.6 0-3.2-.2-4.7-.5L15 50l2.4-7.2C14.2 40.2 11 35.6 11 28.5 11 19.4 19.5 12 30 12z"
					})
				] }),
				id === "safari" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "30",
						r: "20",
						fill: "none",
						stroke: "#d0e8ff",
						strokeWidth: "4"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
						stroke: "#8e8e93",
						strokeWidth: "1",
						children: Array.from({ length: 12 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
							x1: "30",
							y1: "12",
							x2: "30",
							y2: i % 3 === 0 ? 16 : 14.5,
							transform: `rotate(${i * 30} 30 30)`
						}, i))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
						points: "30,14 33.2,30 30,33",
						fill: "#ff3b30"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
						points: "30,46 26.8,30 30,27",
						fill: "#e8eef5",
						stroke: "#c5ced8",
						strokeWidth: "0.4"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "30",
						r: "2.3",
						fill: "#fff",
						stroke: "#bfc6ce"
					})
				] }),
				id === "music" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: `${uid}g`,
						x1: "0",
						y1: "1",
						x2: "1",
						y2: "0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0",
							stopColor: "#FB2C4B"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "1",
							stopColor: "#FF5A7A"
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: `url(#${uid}g)`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						fill: "#fff",
						d: "M26 16h4v18.2a6.2 6.2 0 1 1-2.6-5V20l12-2.4V32a6.2 6.2 0 1 1-2.6-5V16.2L26 18.6V16z"
					})
				] }),
				id === "camera" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#1c1c1e"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "32",
						r: "12",
						fill: "none",
						stroke: "#8e8e93",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "32",
						r: "7",
						fill: "#2c2c2e",
						stroke: "#0A84FF",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "27.5",
						cy: "29.5",
						r: "2",
						fill: "#9ad",
						opacity: "0.8"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "18",
						y: "14",
						width: "10",
						height: "5",
						rx: "1.5",
						fill: "#3a3a3c"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "44",
						cy: "18",
						r: "2",
						fill: "#FFD60A"
					})
				] }),
				id === "photos" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#fff"
					}),
					[
						"#FFD60A",
						"#FF9F0A",
						"#FF375F",
						"#BF5AF2",
						"#0A84FF",
						"#64D2FF",
						"#30D158",
						"#FF453A"
					].map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
						cx: "30",
						cy: "16",
						rx: "5.2",
						ry: "9",
						fill: c,
						transform: `rotate(${i * 45} 30 30)`
					}, c)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "30",
						r: "5",
						fill: "#fff"
					})
				] }),
				id === "weather" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: `${uid}g`,
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0",
							stopColor: "#4DA3FF"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "1",
							stopColor: "#0A62E0"
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: `url(#${uid}g)`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "24",
						cy: "24",
						r: "8",
						fill: "#FFD60A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						fill: "#fff",
						d: "M18 36h22a7 7 0 0 0 1.2-13.9 9 9 0 0 0-17.4 2.2A6.5 6.5 0 0 0 18 36z"
					})
				] }),
				id === "clock" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#000"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "30",
						r: "20",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "30",
						r: "1.6",
						fill: "#000"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "30",
						y1: "30",
						x2: "30",
						y2: "16",
						stroke: "#111",
						strokeWidth: "2.2",
						strokeLinecap: "round",
						transform: `rotate(${h} 30 30)`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "30",
						y1: "30",
						x2: "30",
						y2: "13",
						stroke: "#111",
						strokeWidth: "1.6",
						strokeLinecap: "round",
						transform: `rotate(${m} 30 30)`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "30",
						y1: "32",
						x2: "30",
						y2: "13",
						stroke: "#FF3B30",
						strokeWidth: "1",
						strokeLinecap: "round",
						transform: `rotate(${s} 30 30)`
					})
				] }),
				id === "maps" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#C8E6A0"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M0 38c10-8 18-4 28-8s16-2 32 6v24H0z",
						fill: "#6EC8F0"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M8 10h18l6 14H14z",
						fill: "#F4E3A0"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "26",
						y: "0",
						width: "7",
						height: "42",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "28.2",
						y: "0",
						width: "2.6",
						height: "42",
						fill: "#FFD60A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M40 14c-4 0-6 3.2-6 6.4 0 4.6 6 10.6 6 10.6s6-6 6-10.6c0-3.2-2-6.4-6-6.4z",
						fill: "#FF3B30"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "40",
						cy: "20.2",
						r: "2.2",
						fill: "#fff"
					})
				] }),
				id === "notes" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#FFCC00"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "14",
						y: "12",
						width: "32",
						height: "36",
						rx: "2",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M14 18h32",
						stroke: "#FFCC00",
						strokeWidth: "4"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M18 26h24M18 32h24M18 38h16",
						stroke: "#E5E5EA",
						strokeWidth: "2",
						strokeLinecap: "round"
					})
				] }),
				id === "calendar" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "16",
						fill: "#FF3B30"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						x: "30",
						y: "46",
						textAnchor: "middle",
						fontSize: "26",
						fontWeight: "700",
						fill: "#1c1c1e",
						fontFamily: "-apple-system, system-ui",
						children: day
					})
				] }),
				id === "reminders" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "18",
						cy: "20",
						r: "5",
						fill: "#0A84FF"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M16 20.2l1.4 1.4 3-3.2",
						stroke: "#fff",
						strokeWidth: "1.4",
						fill: "none"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "27",
						y: "17",
						width: "20",
						height: "3",
						rx: "1.5",
						fill: "#d1d1d6"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "18",
						cy: "32",
						r: "5",
						fill: "#FF9F0A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "27",
						y: "30",
						width: "16",
						height: "3",
						rx: "1.5",
						fill: "#d1d1d6"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "18",
						cy: "44",
						r: "5",
						fill: "#30D158"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "27",
						y: "42",
						width: "18",
						height: "3",
						rx: "1.5",
						fill: "#d1d1d6"
					})
				] }),
				id === "appstore" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: `${uid}g`,
						x1: "0",
						y1: "0",
						x2: "1",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0",
							stopColor: "#1AA1FF"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "1",
							stopColor: "#0070F0"
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: `url(#${uid}g)`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M30 12l6 16h-5l4 14-16-18h6z",
						fill: "#fff"
					})
				] }),
				id === "settings" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#8E8E93"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
						fill: "#fff",
						children: [Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
							x: "27",
							y: "10",
							width: "6",
							height: "8",
							rx: "1.5",
							transform: `rotate(${i * 45} 30 30)`
						}, i)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "30",
							cy: "30",
							r: "10"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "30",
						r: "5.5",
						fill: "#8E8E93"
					})
				] }),
				id === "calculator" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#1c1c1e"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "18",
						cy: "18",
						r: "7",
						fill: "#FF9F0A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M18 14.5v7M14.5 18h7",
						stroke: "#fff",
						strokeWidth: "1.6"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "42",
						cy: "18",
						r: "7",
						fill: "#505055"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M39 18h6",
						stroke: "#fff",
						strokeWidth: "1.6"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "18",
						cy: "42",
						r: "7",
						fill: "#505055"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M15.2 42h5.6M18 39.2v5.6",
						stroke: "#fff",
						strokeWidth: "1.5"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "42",
						cy: "42",
						r: "7",
						fill: "#505055"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M39 42h6M42 39v6",
						stroke: "#fff",
						strokeWidth: "1.5"
					})
				] }),
				id === "files" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: `${uid}g`,
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0",
							stopColor: "#5AC8FA"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "1",
							stopColor: "#007AFF"
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						fill: `url(#${uid}g)`,
						d: "M10 22a4 4 0 0 1 4-4h10l4 4h18a4 4 0 0 1 4 4v16a4 4 0 0 1-4 4H14a4 4 0 0 1-4-4V22z"
					})
				] }),
				id === "mail" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: `${uid}g`,
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0",
							stopColor: "#4DA3FF"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "1",
							stopColor: "#0A62E0"
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: `url(#${uid}g)`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "12",
						y: "18",
						width: "36",
						height: "24",
						rx: "3",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M14 20l16 12L46 20",
						fill: "none",
						stroke: "#0A62E0",
						strokeWidth: "2"
					})
				] }),
				id === "health" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "60",
					height: "60",
					fill: "#fff"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					fill: "#FF2D55",
					d: "M30 46s-14-8.6-14-16a8 8 0 0 1 14-4 8 8 0 0 1 14 4c0 7.4-14 16-14 16z"
				})] }),
				id === "wallet" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#1c1c1e"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "12",
						y: "28",
						width: "36",
						height: "18",
						rx: "3",
						fill: "#30D158",
						transform: "rotate(-8 30 36)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "12",
						y: "22",
						width: "36",
						height: "18",
						rx: "3",
						fill: "#0A84FF"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "12",
						y: "16",
						width: "36",
						height: "18",
						rx: "3",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "16",
						y: "22",
						width: "12",
						height: "3",
						rx: "1",
						fill: "#e5e5ea"
					})
				] }),
				id === "stocks" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#000"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M10 42l10-8 8 5 14-18 8 6",
						fill: "none",
						stroke: "#fff",
						strokeWidth: "2.4",
						strokeLinejoin: "round",
						strokeLinecap: "round"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M40 16h10v10",
						fill: "none",
						stroke: "#30D158",
						strokeWidth: "2.2"
					})
				] }),
				id === "translate" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#1c1c1e"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "10",
						y: "14",
						width: "26",
						height: "22",
						rx: "6",
						fill: "#0A84FF"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						x: "23",
						y: "30",
						textAnchor: "middle",
						fontSize: "14",
						fontWeight: "700",
						fill: "#fff",
						children: "A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "24",
						y: "26",
						width: "26",
						height: "22",
						rx: "6",
						fill: "#FF9F0A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
						x: "37",
						y: "42",
						textAnchor: "middle",
						fontSize: "13",
						fontWeight: "700",
						fill: "#fff",
						children: "文"
					})
				] }),
				id === "compass" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#000"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "30",
						r: "20",
						fill: "#1c1c1e",
						stroke: "#fff",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
						points: "30,14 33,30 30,32",
						fill: "#FF3B30"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
						points: "30,46 27,30 30,28",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "30",
						r: "2",
						fill: "#000",
						stroke: "#fff"
					})
				] }),
				id === "voicememo" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#000"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M12 32h3l2-6 3 14 3-18 3 16 3-12 3 8 2-4h3",
						fill: "none",
						stroke: "#fff",
						strokeWidth: "2",
						strokeLinejoin: "round",
						strokeLinecap: "round"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "46",
						cy: "20",
						r: "4",
						fill: "#FF3B30"
					})
				] }),
				id === "contacts" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#8E8E93"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "24",
						r: "8",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						fill: "#fff",
						d: "M14 48c2-8 8-12 16-12s14 4 16 12z"
					})
				] }),
				id === "books" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#FF9500"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						fill: "#fff",
						d: "M12 16h16c3 0 5 2 5 5v24c-2-2-4-3-7-3H12V16z"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						fill: "#fff5e6",
						d: "M48 16H32c-3 0-5 2-5 5v24c2-2 4-3 7-3h14V16z"
					})
				] }),
				id === "podcasts" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: `${uid}g`,
						x1: "0",
						y1: "0",
						x2: "1",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0",
							stopColor: "#D07CFF"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "1",
							stopColor: "#7D2AE8"
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: `url(#${uid}g)`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "24",
						r: "6",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						fill: "#fff",
						d: "M18 46c1.5-7 6-10 12-10s10.5 3 12 10z"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M14 28a16 16 0 0 1 32 0",
						fill: "none",
						stroke: "#fff",
						strokeWidth: "2",
						opacity: "0.85"
					})
				] }),
				id === "shortcuts" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: `${uid}g`,
						x1: "0",
						y1: "1",
						x2: "1",
						y2: "0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0",
							stopColor: "#2E5BFF"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "1",
							stopColor: "#64D2FF"
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: `url(#${uid}g)`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "14",
						y: "14",
						width: "14",
						height: "14",
						rx: "4",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "32",
						y: "14",
						width: "14",
						height: "14",
						rx: "4",
						fill: "#FFD60A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "14",
						y: "32",
						width: "14",
						height: "14",
						rx: "4",
						fill: "#FF375F"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "32",
						y: "32",
						width: "14",
						height: "14",
						rx: "4",
						fill: "#30D158"
					})
				] }),
				id === "fitness" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#000"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "30",
						r: "16",
						fill: "none",
						stroke: "#FF2D55",
						strokeWidth: "4",
						strokeDasharray: "70 40",
						strokeLinecap: "round",
						transform: "rotate(-80 30 30)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "30",
						r: "11",
						fill: "none",
						stroke: "#30D158",
						strokeWidth: "4",
						strokeDasharray: "48 30",
						strokeLinecap: "round",
						transform: "rotate(40 30 30)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "30",
						r: "6",
						fill: "none",
						stroke: "#64D2FF",
						strokeWidth: "4",
						strokeDasharray: "24 20",
						strokeLinecap: "round"
					})
				] }),
				id === "news" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "60",
					height: "60",
					fill: "#fff"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
					x: "30",
					y: "42",
					textAnchor: "middle",
					fontSize: "34",
					fontWeight: "800",
					fill: "#FF2D55",
					fontFamily: "Georgia, serif",
					children: "N"
				})] }),
				id === "tv" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#000"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "12",
						y: "16",
						width: "36",
						height: "26",
						rx: "4",
						fill: "#1c1c1e",
						stroke: "#fff",
						strokeWidth: "1.4"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", {
						points: "27,23 27,35 38,29",
						fill: "#fff"
					})
				] }),
				id === "homeapp" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						fill: "#FF9F0A",
						d: "M30 14l16 14h-4v14H18V28h-4z"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "26",
						y: "32",
						width: "8",
						height: "10",
						fill: "#fff"
					})
				] }),
				id === "find" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
						id: `${uid}g`,
						x1: "0",
						y1: "0",
						x2: "0",
						y2: "1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "0",
							stopColor: "#5BF675"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
							offset: "1",
							stopColor: "#1EBE45"
						})]
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: `url(#${uid}g)`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "30",
						r: "14",
						fill: "none",
						stroke: "#fff",
						strokeWidth: "2",
						opacity: "0.85"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "30",
						r: "8",
						fill: "none",
						stroke: "#fff",
						strokeWidth: "2"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "30",
						r: "3",
						fill: "#fff"
					})
				] }),
				id === "journal" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#FFD6E8"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "16",
						y: "12",
						width: "28",
						height: "36",
						rx: "3",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M22 22h16M22 28h16M22 34h10",
						stroke: "#FF2D55",
						strokeWidth: "1.6",
						strokeLinecap: "round"
					})
				] }),
				id === "passwords" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#1c1c1e"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "26",
						r: "8",
						fill: "none",
						stroke: "#FFD60A",
						strokeWidth: "3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "27",
						y: "32",
						width: "6",
						height: "12",
						rx: "1",
						fill: "#FFD60A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "27",
						y: "38",
						width: "10",
						height: "3",
						rx: "1",
						fill: "#FFD60A"
					})
				] }),
				id === "measure" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "14",
						y: "16",
						width: "32",
						height: "28",
						rx: "3",
						fill: "none",
						stroke: "#111",
						strokeWidth: "2"
					}),
					Array.from({ length: 7 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: 18 + i * 4,
						y1: "16",
						x2: 18 + i * 4,
						y2: i % 2 ? 22 : 26,
						stroke: "#111",
						strokeWidth: "1.4"
					}, i))
				] }),
				id === "tips" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "30",
						cy: "26",
						r: "10",
						fill: "#FFD60A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "27",
						y: "36",
						width: "6",
						height: "8",
						rx: "2",
						fill: "#FFD60A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "25",
						y: "44",
						width: "10",
						height: "3",
						rx: "1.5",
						fill: "#d1d1d6"
					})
				] }),
				id === "studio" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#2c1a4a"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "22",
						cy: "32",
						r: "8",
						fill: "#FF375F"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "38",
						cy: "26",
						r: "7",
						fill: "#FFD60A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "40",
						cy: "40",
						r: "5",
						fill: "#64D2FF"
					})
				] }),
				id === "sheets" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#30D158"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "12",
						y: "14",
						width: "36",
						height: "32",
						rx: "2",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M12 24h36M12 34h36M24 14v32M36 14v32",
						stroke: "#30D158",
						strokeWidth: "1.4"
					})
				] }),
				id === "writer" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#FF9500"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "16",
						y: "12",
						width: "24",
						height: "32",
						rx: "2",
						fill: "#fff"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M34 38l8 8-4 1-5-7z",
						fill: "#FFD60A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M20 20h14M20 26h14M20 32h8",
						stroke: "#FF9500",
						strokeWidth: "1.6",
						strokeLinecap: "round"
					})
				] }),
				id === "board" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#1c1c1e"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "10",
						y: "12",
						width: "22",
						height: "18",
						rx: "3",
						fill: "#FFE066",
						transform: "rotate(-6 21 21)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "28",
						y: "18",
						width: "22",
						height: "18",
						rx: "3",
						fill: "#FFD6E0",
						transform: "rotate(5 39 27)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						x: "16",
						y: "32",
						width: "24",
						height: "16",
						rx: "3",
						fill: "#C8F7C5"
					})
				] }),
				id === "magnifier" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						width: "60",
						height: "60",
						fill: "#8E8E93"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "26",
						cy: "26",
						r: "12",
						fill: "none",
						stroke: "#fff",
						strokeWidth: "4"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M35 35l10 10",
						stroke: "#fff",
						strokeWidth: "4",
						strokeLinecap: "round"
					})
				] }),
				!APPS_KNOWN.has(id) && !id.startsWith("web:") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "60",
					height: "60",
					fill: "#3a3a3c"
				})
			]
		})
	});
}
var APPS_KNOWN = /* @__PURE__ */ new Set([
	"phone",
	"messages",
	"safari",
	"music",
	"camera",
	"photos",
	"weather",
	"clock",
	"maps",
	"notes",
	"calendar",
	"reminders",
	"appstore",
	"settings",
	"calculator",
	"files",
	"mail",
	"health",
	"wallet",
	"stocks",
	"translate",
	"compass",
	"voicememo",
	"contacts",
	"books",
	"podcasts",
	"shortcuts",
	"fitness",
	"news",
	"tv",
	"homeapp",
	"find",
	"journal",
	"passwords",
	"measure",
	"tips",
	"studio",
	"sheets",
	"writer",
	"board",
	"magnifier"
]);
var STORY_FA = `شب روی شیشهٔ تیتانیوم، شهر مثل یک جزیرهٔ روشن بود.\n\nعلی گوشی را برداشت. نه برای اینکه گم شود، برای اینکه همهٔ ابزارهایش را همان‌جا، اندازهٔ واقعی، کنار هم داشته باشد: نقشه، یادداشت، زنگ ساعت، و یک آهنگ که مال خودش بود.\n\nفردا قرار کافه است. امشب فقط صفحهٔ اصلی را مرتب می‌کند. چهار ستون. داک پایین. یک اپ تازه از اپ استور.\n\nوقتی چراغ‌قوه را خاموش کرد، کویر والپیپر هنوز گرم بود.`;
var STORY_EN = `The city sat on the glass like a bright island.\n\nThis phone is a place to keep the day: a map, a note, an alarm, a song that belongs to nobody else.\n\nTomorrow is the café. Tonight the home screen is enough. Four columns. A dock. One new app from the store.`;
function ExtraApps({ id }) {
	switch (id) {
		case "mail": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailApp, {});
		case "health": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HealthApp, {});
		case "wallet": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletApp, {});
		case "stocks": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StocksApp, {});
		case "translate": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TranslateApp, {});
		case "compass": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompassApp, {});
		case "voicememo": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemoApp, {});
		case "contacts": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactsApp, {});
		case "books": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BooksApp, {});
		case "podcasts": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PodcastsApp, {});
		case "shortcuts": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShortcutsApp, {});
		case "fitness": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FitnessApp, {});
		case "news": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NewsApp, {});
		case "tv": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TvApp, {});
		case "homeapp": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeApp, {});
		case "find": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FindApp, {});
		case "journal": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JournalApp, {});
		case "passwords": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PassApp, {});
		case "measure": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeasureApp, {});
		case "tips": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TipsApp, {});
		case "studio": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StudioApp, {});
		case "sheets": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetsApp, {});
		case "writer": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WriterApp, {});
		case "board": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BoardApp, {});
		case "magnifier": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MagApp, {});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
			title: id,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "warn",
				children: "…"
			})
		});
	}
}
function MailApp() {
	const phone = usePhone();
	const t = useT();
	const [id, setId] = (0, import_react.useState)(null);
	const [draft, setDraft] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		to: "",
		subject: "",
		body: ""
	});
	const mail = phone.data.mails.find((m) => m.id === id);
	if (draft) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("نامهٔ تازه", "New Message"),
		back: () => setDraft(false),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				placeholder: t("به", "To"),
				value: form.to,
				onChange: (e) => setForm({
					...form,
					to: e.target.value
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				placeholder: t("موضوع", "Subject"),
				value: form.subject,
				onChange: (e) => setForm({
					...form,
					subject: e.target.value
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: "area",
				value: form.body,
				onChange: (e) => setForm({
					...form,
					body: e.target.value
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "get open",
				style: { marginInlineStart: 16 },
				onClick: () => {
					phone.update((d) => ({
						...d,
						mails: [{
							id: uid("ml"),
							from: t("من", "Me"),
							subject: form.subject || t("بدون موضوع", "No subject"),
							body: form.body,
							read: true,
							at: Date.now()
						}, ...d.mails]
					}));
					setDraft(false);
				},
				children: t("بفرست", "Send")
			})
		]
	});
	if (mail) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: mail.subject,
		back: () => setId(null),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "section-label",
			children: mail.from
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "reader",
			children: mail.body
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: t("ایمیل", "Mail"),
		right: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "text-btn",
			onClick: () => setDraft(true),
			children: "✎"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: phone.data.mails.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: m.subject,
			value: m.read ? "" : "●",
			onClick: () => {
				setId(m.id);
				phone.update((d) => ({
					...d,
					mails: d.mails.map((x) => x.id === m.id ? {
						...x,
						read: true
					} : x)
				}));
			}
		}, m.id)) })
	});
}
function HealthApp() {
	const phone = usePhone();
	const t = useT();
	const move = Math.min(1, phone.data.workouts.reduce((n, w) => n + w.seconds, 0) / 1800);
	const exercise = Math.min(1, phone.data.workouts.length / 3);
	const stand = Math.min(1, phone.data.water / 8);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("سلامت", "Health"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			className: "rings",
			viewBox: "0 0 120 120",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "60",
					cy: "60",
					r: "48",
					fill: "none",
					stroke: "#3a2030",
					strokeWidth: "10"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "60",
					cy: "60",
					r: "48",
					fill: "none",
					stroke: "#ff2d55",
					strokeWidth: "10",
					strokeDasharray: `${move * 300} 400`,
					strokeLinecap: "round",
					transform: "rotate(-90 60 60)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "60",
					cy: "60",
					r: "34",
					fill: "none",
					stroke: "#14321c",
					strokeWidth: "10"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "60",
					cy: "60",
					r: "34",
					fill: "none",
					stroke: "#30d158",
					strokeWidth: "10",
					strokeDasharray: `${exercise * 214} 300`,
					strokeLinecap: "round",
					transform: "rotate(-90 60 60)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "60",
					cy: "60",
					r: "20",
					fill: "none",
					stroke: "#12323a",
					strokeWidth: "10"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
					cx: "60",
					cy: "60",
					r: "20",
					fill: "none",
					stroke: "#64d2ff",
					strokeWidth: "10",
					strokeDasharray: `${stand * 126} 200`,
					strokeLinecap: "round",
					transform: "rotate(-90 60 60)"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: t("لیوان آب", "Water"),
			value: faNum(phone.data.water, phone.lang),
			onClick: () => phone.update({ water: Math.min(12, phone.data.water + 1) })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: t("کم کن", "Less"),
			onClick: () => phone.update({ water: Math.max(0, phone.data.water - 1) })
		})] })]
	});
}
function WalletApp() {
	const phone = usePhone();
	const t = useT();
	const [form, setForm] = (0, import_react.useState)({
		label: "",
		last4: "",
		holder: ""
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("کیف پول", "Wallet"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "warn",
				children: t("کارت‌ها فقط نمایشی‌اند و پرداخت واقعی نیستند.", "Cards are visual only. No real payments.")
			}),
			phone.data.cards.map((c, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					margin: "10px 16px",
					background: c.color,
					borderRadius: 16,
					padding: 16,
					minHeight: 90,
					transform: `translateY(${-i * 4}px)`
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: c.label }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: {
							fontSize: 22,
							letterSpacing: 2,
							marginTop: 12
						},
						children: ["•••• ", faNum(c.last4, phone.lang)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: { opacity: .8 },
						children: c.holder
					})
				]
			}, c.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				placeholder: t("نام کارت", "Card name"),
				value: form.label,
				onChange: (e) => setForm({
					...form,
					label: e.target.value
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				placeholder: "1234",
				value: form.last4,
				onChange: (e) => setForm({
					...form,
					last4: e.target.value.slice(0, 4)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "get open",
				style: { marginInlineStart: 16 },
				onClick: () => {
					if (!form.label || form.last4.length < 4) return;
					phone.update((d) => ({
						...d,
						cards: [...d.cards, {
							id: uid("cd"),
							label: form.label,
							last4: form.last4,
							holder: form.holder || "ALI",
							color: "#5E5CE6"
						}]
					}));
					setForm({
						label: "",
						last4: "",
						holder: ""
					});
				},
				children: t("افزودن کارت", "Add card")
			})
		]
	});
}
var STOCKS = [
	{
		s: "ALI",
		p: 128.4,
		d: 1.8,
		line: [
			20,
			22,
			21,
			24,
			28,
			26,
			30,
			34
		]
	},
	{
		s: "GLASS",
		p: 54.1,
		d: -.6,
		line: [
			30,
			28,
			29,
			27,
			26,
			24,
			25,
			22
		]
	},
	{
		s: "DUNE",
		p: 76,
		d: .4,
		line: [
			14,
			16,
			15,
			18,
			17,
			19,
			21,
			20
		]
	}
];
function StocksApp() {
	const phone = usePhone();
	const t = useT();
	const [i, setI] = (0, import_react.useState)(null);
	if (i != null) {
		const st = STOCKS[i];
		const max = Math.max(...st.line);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
			title: st.s,
			back: () => setI(null),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "wx-hero",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "temp",
						style: { fontSize: 56 },
						children: faNum(st.p.toFixed(2), phone.lang)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: { color: st.d >= 0 ? "#30d158" : "#ff453a" },
						children: [st.d > 0 ? "+" : "", faNum(st.d.toFixed(2), phone.lang)]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 100 40",
					style: {
						width: "100%",
						height: 140
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
						fill: "none",
						stroke: "#30d158",
						strokeWidth: "2",
						points: st.line.map((n, idx) => `${idx * 14},${40 - n / max * 34}`).join(" ")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "warn",
					children: t("نمودار نمونه است، نه قیمت بازار.", "Sample chart, not a live market.")
				})
			]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: t("سهام", "Stocks"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: STOCKS.map((st, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: st.s,
			value: `${faNum(st.p.toFixed(1), phone.lang)}`,
			onClick: () => setI(idx)
		}, st.s)) })
	});
}
function TranslateApp() {
	usePhone();
	const t = useT();
	const [q, setQ] = (0, import_react.useState)("");
	const [faFirst, setFaFirst] = (0, import_react.useState)(true);
	const query = q.trim().toLowerCase();
	const hits = DICT.filter((d) => d.fa.includes(query) || d.en.includes(query));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("ترجمه", "Translate"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nav",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: faFirst ? "فارسی" : "English" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "text-btn",
						onClick: () => setFaFirst((v) => !v),
						children: "⇄"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: faFirst ? "English" : "فارسی" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				value: q,
				placeholder: t("کلمه", "Word"),
				onChange: (e) => setQ(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: (query ? hits : DICT.slice(0, 8)).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: faFirst ? d.fa : d.en,
				value: faFirst ? d.en : d.fa
			}, d.en)) }),
			query && hits.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "warn",
				children: t("در واژه‌نامهٔ آفلاین نیست.", "Not in the offline dictionary.")
			})
		]
	});
}
function CompassApp() {
	const phone = usePhone();
	const t = useT();
	const [heading, setHeading] = (0, import_react.useState)(null);
	const [need, setNeed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (typeof DeviceOrientationEvent.requestPermission === "function") setNeed(true);
		const on = (e) => {
			const extra = e;
			if (typeof extra.webkitCompassHeading === "number") setHeading(extra.webkitCompassHeading);
			else if (e.alpha != null) setHeading(360 - e.alpha);
		};
		window.addEventListener("deviceorientation", on);
		return () => window.removeEventListener("deviceorientation", on);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("قطب‌نما", "Compass"),
		children: [
			need && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "get open",
				style: { margin: 16 },
				onClick: () => {
					DeviceOrientationEvent.requestPermission?.();
				},
				children: t("اجازه بده", "Allow")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					width: 220,
					height: 220,
					margin: "30px auto",
					borderRadius: "50%",
					border: "2px solid #fff",
					position: "relative",
					transform: `rotate(${-(heading ?? 0)}deg)`
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
					style: {
						position: "absolute",
						top: 8,
						left: "50%",
						transform: "translateX(-50%)",
						color: "#ff453a"
					},
					children: "N"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
					style: {
						position: "absolute",
						bottom: 8,
						left: "50%"
					},
					children: "S"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: {
					textAlign: "center",
					fontSize: 28
				},
				children: heading == null ? "—" : faNum(`${Math.round(heading)}°`, phone.lang)
			})
		]
	});
}
function MemoApp() {
	const phone = usePhone();
	const t = useT();
	const rec = (0, import_react.useRef)(null);
	const chunks = (0, import_react.useRef)([]);
	const [on, setOn] = (0, import_react.useState)(false);
	const [sec, setSec] = (0, import_react.useState)(0);
	const [err, setErr] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!on) return;
		const id = window.setInterval(() => setSec((s) => s + 1), 1e3);
		return () => window.clearInterval(id);
	}, [on]);
	async function toggle() {
		if (on && rec.current) {
			rec.current.stop();
			setOn(false);
			return;
		}
		try {
			const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
			const mr = new MediaRecorder(stream);
			chunks.current = [];
			mr.ondataavailable = (e) => {
				if (e.data.size) chunks.current.push(e.data);
			};
			mr.onstop = () => {
				const blob = new Blob(chunks.current, { type: mr.mimeType || "audio/webm" });
				const url = URL.createObjectURL(blob);
				phone.addMemo({
					id: uid("vm"),
					url,
					seconds: sec,
					at: Date.now()
				});
				stream.getTracks().forEach((tr) => tr.stop());
				setSec(0);
			};
			mr.start();
			rec.current = mr;
			setSec(0);
			setOn(true);
		} catch {
			setErr(t("میکروفون اجازه نداد.", "Microphone permission denied."));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("یادداشت صوتی", "Voice Memos"),
		children: [
			err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "warn",
				children: err
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					textAlign: "center",
					padding: 16
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lock-time",
					style: { fontSize: 48 },
					children: faNum(sec, phone.lang)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "call-btn",
					style: { background: on ? "#ff453a" : "#ff375f" },
					onClick: () => void toggle(),
					children: on ? "■" : "●"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: phone.memos.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "row",
				style: {
					display: "flex",
					gap: 8
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [faNum(m.seconds, phone.lang), "s"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
					controls: true,
					src: m.url,
					style: {
						flex: 1,
						height: 32
					}
				})]
			}, m.id)) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "warn",
				children: t("ضبط‌ها تا وقتی این صفحه باز است می‌مانند.", "Recordings stay for this visit.")
			})
		]
	});
}
function ContactsApp() {
	const phone = usePhone();
	const t = useT();
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		phone: ""
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("مخاطبان", "Contacts"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				placeholder: t("نام", "Name"),
				value: form.name,
				onChange: (e) => setForm({
					...form,
					name: e.target.value
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				placeholder: "09…",
				value: form.phone,
				onChange: (e) => setForm({
					...form,
					phone: e.target.value
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "get open",
				style: { marginInlineStart: 16 },
				onClick: () => {
					if (!form.name.trim()) return;
					phone.update((d) => ({
						...d,
						contacts: [...d.contacts, {
							id: uid("c"),
							name: form.name.trim(),
							phone: form.phone,
							color: "#0A84FF"
						}]
					}));
					setForm({
						name: "",
						phone: ""
					});
				},
				children: t("افزودن", "Add")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: phone.data.contacts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: c.name,
				value: faNum(c.phone, phone.lang),
				onClick: () => phone.startCall(c.name, c.phone)
			}, c.id)) })
		]
	});
}
function BooksApp() {
	const phone = usePhone();
	const t = useT();
	const text = phone.rtl ? STORY_FA : STORY_EN;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: t("کتاب", "Books"),
		right: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "text-btn",
			onClick: () => speechSynthesis.speak(new SpeechSynthesisUtterance(text)),
			children: "▶"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
			className: "reader book-text",
			children: text
		})
	});
}
var SHOWS = [{
	fa: "شب تیتانیوم",
	en: "Titanium Night",
	bodyFa: "دربارهٔ ساختن یک گوشی که واقعاً دستت باشد.",
	bodyEn: "On making a phone that feels like it is yours."
}, {
	fa: "چهار ستون",
	en: "Four Columns",
	bodyFa: "چرا آیکون آیفون ۶۰ نقطه است و شلوغ نمی‌شود.",
	bodyEn: "Why a 60-point icon keeps the grid calm."
}];
function PodcastsApp() {
	const phone = usePhone();
	const t = useT();
	const [play, setPlay] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: t("پادکست", "Podcasts"),
		children: SHOWS.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "store-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "meta",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: phone.rtl ? s.fa : s.en }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: phone.rtl ? s.bodyFa : s.bodyEn })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "get open",
				onClick: () => {
					setPlay(i);
					const u = new SpeechSynthesisUtterance(phone.rtl ? s.bodyFa : s.bodyEn);
					u.lang = phone.rtl ? "fa-IR" : "en-US";
					speechSynthesis.cancel();
					speechSynthesis.speak(u);
				},
				children: play === i ? "●" : "▶"
			})]
		}, s.en))
	});
}
function ShortcutsApp() {
	const phone = usePhone();
	const t = useT();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: t("میانبرها", "Shortcuts"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pad-grid",
			children: [
				{
					fa: "چراغ‌قوه",
					en: "Flashlight",
					run: () => phone.update({ flashlight: !phone.data.flashlight })
				},
				{
					fa: "دوربین",
					en: "Camera",
					run: () => phone.openApp("camera")
				},
				{
					fa: "یادداشت تازه",
					en: "New note",
					run: () => phone.update((d) => ({
						...d,
						notes: [{
							id: uid("n"),
							title: t("سریع", "Quick"),
							body: "",
							updated: Date.now()
						}, ...d.notes]
					}))
				},
				{
					fa: "وای‌فای",
					en: "Wi-Fi",
					run: () => phone.update({ wifi: !phone.data.wifi })
				},
				{
					fa: "قفل",
					en: "Lock",
					run: () => phone.setLocked(true)
				},
				{
					fa: "زنگ یک دقیقه",
					en: "Alarm +1 min",
					run: () => {
						const n = /* @__PURE__ */ new Date();
						const minute = (n.getMinutes() + 1) % 60;
						const hour = minute === 0 ? (n.getHours() + 1) % 24 : n.getHours();
						phone.update((d) => ({
							...d,
							alarms: [...d.alarms, {
								id: uid("a"),
								hour,
								minute,
								on: true,
								label: t("میانبر", "Shortcut")
							}]
						}));
					}
				}
			].map((it) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "pad",
				style: { background: "#0A84FF" },
				onClick: it.run,
				children: phone.rtl ? it.fa : it.en
			}, it.en))
		})
	});
}
function FitnessApp() {
	const phone = usePhone();
	const t = useT();
	const [run, setRun] = (0, import_react.useState)(null);
	const [sec, setSec] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!run) return;
		const id = window.setInterval(() => setSec(Math.floor((Date.now() - run.start) / 1e3)), 500);
		return () => window.clearInterval(id);
	}, [run]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("تناسب", "Fitness"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					textAlign: "center",
					fontSize: 48
				},
				children: faNum(`${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`, phone.lang)
			}),
			!run ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pad-grid",
				children: [
					{
						fa: "پیاده‌روی",
						en: "Walk"
					},
					{
						fa: "دو",
						en: "Run"
					},
					{
						fa: "دوچرخه",
						en: "Cycle"
					}
				].map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "pad",
					style: {
						background: "#30d158",
						color: "#042"
					},
					onClick: () => {
						setRun({
							kind: phone.rtl ? k.fa : k.en,
							start: Date.now()
						});
						setSec(0);
					},
					children: phone.rtl ? k.fa : k.en
				}, k.en))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "get open",
				style: { margin: 16 },
				onClick: () => {
					phone.update((d) => ({
						...d,
						workouts: [{
							id: uid("w"),
							kind: run.kind,
							seconds: sec,
							at: Date.now()
						}, ...d.workouts]
					}));
					setRun(null);
					setSec(0);
				},
				children: t("پایان تمرین", "End workout")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: phone.data.workouts.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: w.kind,
				value: faNum(`${Math.floor(w.seconds / 60)}m`, phone.lang)
			}, w.id)) })
		]
	});
}
function NewsApp() {
	const phone = usePhone();
	const t = useT();
	const items = [
		{
			fa: "صفحهٔ اصلی خلوت‌تر شد",
			en: "A calmer home screen",
			body: t("چهار ستون، آیکون ۶۰ نقطه‌ای، داک بدون برچسب.", "Four columns, 60-point icons, a dock without labels.")
		},
		{
			fa: "هوای شهر",
			en: "City weather",
			body: t("هواشناسی از Open-Meteo می‌خواند.", "Weather reads Open-Meteo.")
		},
		{
			fa: "اپ خودت را بساز",
			en: "Build your own app",
			body: t("در اپ استور دکمهٔ ساخت، یک صفحهٔ HTML نصب می‌کند.", "App Store → Create installs a small HTML app.")
		}
	];
	const [i, setI] = (0, import_react.useState)(null);
	if (i != null) {
		const it = items[i];
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
			title: phone.rtl ? it.fa : it.en,
			back: () => setI(null),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "reader",
				children: it.body
			})
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: t("اخبار", "News"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: items.map((it, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: phone.rtl ? it.fa : it.en,
			onClick: () => setI(idx)
		}, it.en)) })
	});
}
function TvApp() {
	const phone = usePhone();
	const t = useT();
	const shows = [
		{
			fa: "کویر",
			en: "Dune",
			color: "#C4A484"
		},
		{
			fa: "شفق",
			en: "Aurora",
			color: "#5E5CE6"
		},
		{
			fa: "اقیانوس",
			en: "Ocean",
			color: "#0A84FF"
		}
	];
	const [play, setPlay] = (0, import_react.useState)(null);
	if (play != null) {
		const s = shows[play];
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
			title: phone.rtl ? s.fa : s.en,
			back: () => setPlay(null),
			scroll: false,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "app-fill",
				style: {
					background: s.color,
					alignItems: "center",
					justifyContent: "center",
					fontSize: 42
				},
				children: "▶"
			})
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: t("تماشا", "TV"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "wall-pick",
			children: shows.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				style: {
					background: s.color,
					color: "#fff",
					font: "inherit",
					fontSize: 18
				},
				onClick: () => setPlay(i),
				children: phone.rtl ? s.fa : s.en
			}, s.en))
		})
	});
}
function HomeApp() {
	const phone = usePhone();
	const t = useT();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: t("خانه", "Home"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: Object.entries(phone.data.lights).map(([room, on]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: room,
			value: on ? t("روشن", "On") : t("خاموش", "Off"),
			onClick: () => phone.update((d) => ({
				...d,
				lights: {
					...d.lights,
					[room]: !on
				}
			}))
		}, room)) })
	});
}
function FindApp() {
	usePhone();
	const t = useT();
	const [where, setWhere] = (0, import_react.useState)(t("در حال جستجو…", "Searching…"));
	(0, import_react.useEffect)(() => {
		navigator.geolocation?.getCurrentPosition((p) => setWhere(`${p.coords.latitude.toFixed(4)}, ${p.coords.longitude.toFixed(4)}`), () => setWhere("near you"));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("پیدا کن", "Find"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "finder",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: { textAlign: "center" },
				children: "ALI Phone"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: {
					textAlign: "center",
					color: "#8e8e93"
				},
				children: where
			})
		]
	});
}
function JournalApp() {
	const phone = usePhone();
	const t = useT();
	const [text, setText] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("دفتر روزانه", "Journal"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: "area",
				value: text,
				placeholder: t("امروز…", "Today…"),
				onChange: (e) => setText(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "get open",
				style: { marginInlineStart: 16 },
				onClick: () => {
					if (!text.trim()) return;
					phone.update((d) => ({
						...d,
						journal: [{
							id: uid("j"),
							body: text.trim(),
							at: Date.now()
						}, ...d.journal]
					}));
					setText("");
				},
				children: t("ذخیره", "Save")
			}),
			phone.data.journal.map((j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "reader",
				children: j.body
			}, j.id))
		]
	});
}
function PassApp() {
	const phone = usePhone();
	const t = useT();
	const [form, setForm] = (0, import_react.useState)({
		site: "",
		user: "",
		pass: ""
	});
	const [show, setShow] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("رمزها", "Passwords"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "warn",
				children: t("فقط روی همین دستگاه ذخیره می‌شود و رمزنگاری بانکی نیست. رمز واقعی نگذار.", "Stored only on this device, not a secure vault. Do not save real passwords.")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				placeholder: t("سایت", "Site"),
				value: form.site,
				onChange: (e) => setForm({
					...form,
					site: e.target.value
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				placeholder: t("نام کاربری", "User"),
				value: form.user,
				onChange: (e) => setForm({
					...form,
					user: e.target.value
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				placeholder: t("رمز", "Password"),
				value: form.pass,
				onChange: (e) => setForm({
					...form,
					pass: e.target.value
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "get open",
				style: { marginInlineStart: 16 },
				onClick: () => {
					if (!form.site) return;
					phone.update((d) => ({
						...d,
						secrets: [...d.secrets, {
							id: uid("pw"),
							...form
						}]
					}));
					setForm({
						site: "",
						user: "",
						pass: ""
					});
				},
				children: t("ذخیره", "Save")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: phone.data.secrets.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: s.site,
				value: show === s.id ? s.pass : "••••",
				onClick: () => setShow(show === s.id ? null : s.id)
			}, s.id)) })
		]
	});
}
function MeasureApp() {
	const phone = usePhone();
	const t = useT();
	const [tilt, setTilt] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const on = (e) => setTilt(Math.round(e.gamma || 0));
		window.addEventListener("deviceorientation", on);
		return () => window.removeEventListener("deviceorientation", on);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("اندازه", "Measure"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "section-label",
				children: t("خط‌کش تقریبی (پیکسل به سانتی)", "Approximate ruler")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
				margin: 16,
				height: 80,
				background: "repeating-linear-gradient(90deg,#fff 0 1px,transparent 1px 37.8px)",
				borderRadius: 8
			} }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: { textAlign: "center" },
				children: t("هر خانه حدود ۱ سانتی‌متر روی نمایشگر ۹۶dpi.", "Each mark is about 1 cm at 96dpi.")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "section-label",
				children: t("تراز", "Level")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "level",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { style: { left: `calc(50% + ${Math.max(-140, Math.min(140, tilt * 3))}px)` } })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				style: { textAlign: "center" },
				children: faNum(`${tilt}°`, phone.lang)
			})
		]
	});
}
function TipsApp() {
	const t = useT();
	const tips = [
		t("برای باز کردن قفل، به بالا بکش یا دکمهٔ پایین را بزن.", "Swipe up on the lock screen, or tap the hint."),
		t("مرکز کنترل: از بالا سمت باتری به پایین بکش.", "Control Center: swipe down from the battery side."),
		t("اعلان‌ها: از بالا سمت ساعت به پایین بکش.", "Notifications: swipe down from the clock side."),
		t("نوار خانه را بزن تا از اپ برگردی. دوباره بزن تا اپ‌های باز را ببینی.", "Tap the home bar to leave an app. Tap again for the app switcher."),
		t("در اپ استور «گرفتن» اپ را روی صفحه می‌گذارد. «ساخت» یک وب‌اپ یا HTML نصب می‌کند.", "App Store Get puts an app on the home screen. Create installs a web or HTML app."),
		t("نگه‌داشتن آیکون: حذف یا ویرایش صفحه.", "Hold an icon to remove it or edit the home screen."),
		t("آیکون‌ها ۶۰ نقطه هستند، چهار ستون، مثل آیفون واقعی.", "Icons are 60 points, four columns, like a real iPhone.")
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: t("نکته‌ها", "Tips"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: tips.map((tip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, { label: tip }, tip)) })
	});
}
function StudioApp() {
	const t = useT();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: t("استودیو", "Studio"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "pad-grid",
			children: [
				{
					n: "Kick",
					f: 80,
					c: "#FF375F"
				},
				{
					n: "Snare",
					f: 180,
					c: "#FF9F0A"
				},
				{
					n: "Hat",
					f: 640,
					c: "#FFD60A"
				},
				{
					n: "Tom",
					f: 140,
					c: "#30D158"
				},
				{
					n: "Clap",
					f: 420,
					c: "#64D2FF"
				},
				{
					n: "Bass",
					f: 55,
					c: "#0A84FF"
				},
				{
					n: "Bell",
					f: 880,
					c: "#BF5AF2"
				},
				{
					n: "Chord",
					f: 262,
					c: "#FF6482"
				}
			].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "pad",
				style: {
					background: p.c,
					color: "#111"
				},
				onClick: () => padHit(p.f),
				children: p.n
			}, p.n))
		})
	});
}
function SheetsApp() {
	const phone = usePhone();
	const t = useT();
	const sheet = phone.data.sheets[0];
	if (!sheet) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("جدول", "Sheets"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("table", {
			className: "sheet-grid",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: sheet.cells.map((row, r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: row.map((cell, c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: cell,
				onChange: (e) => {
					const value = e.target.value;
					phone.update((d) => ({
						...d,
						sheets: d.sheets.map((s) => s.id !== sheet.id ? s : {
							...s,
							cells: s.cells.map((rr, ri) => ri === r ? rr.map((cc, ci) => ci === c ? value : cc) : rr)
						})
					}));
				}
			}) }, c)) }, r)) })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "text-btn",
			onClick: () => phone.update((d) => ({
				...d,
				sheets: [...d.sheets, {
					id: uid("s"),
					name: t("برگ", "Sheet"),
					cells: blankSheet()
				}]
			})),
			children: t("برگ تازه", "New sheet")
		})]
	});
}
function WriterApp() {
	const phone = usePhone();
	const t = useT();
	const doc = phone.data.docs[0];
	if (!doc) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("نوشته", "Writer"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "field",
			value: doc.title,
			onChange: (e) => phone.update((d) => ({
				...d,
				docs: d.docs.map((x) => x.id === doc.id ? {
					...x,
					title: e.target.value
				} : x)
			}))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			className: "area",
			style: { minHeight: 280 },
			value: doc.body,
			onChange: (e) => phone.update((d) => ({
				...d,
				docs: d.docs.map((x) => x.id === doc.id ? {
					...x,
					body: e.target.value
				} : x)
			}))
		})]
	});
}
function BoardApp() {
	const phone = usePhone();
	const t = useT();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("تخته", "Board"),
		scroll: false,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "text-btn",
			onClick: () => phone.update((d) => ({
				...d,
				stickies: [...d.stickies, {
					id: uid("st"),
					text: t("جدید", "New"),
					x: 20 + d.stickies.length * 12,
					y: 20,
					color: "#C8F7C5"
				}]
			})),
			children: "+"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "board",
			children: phone.data.stickies.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				className: "sticky",
				style: {
					left: s.x,
					top: s.y,
					background: s.color
				},
				value: s.text,
				onChange: (e) => phone.update((d) => ({
					...d,
					stickies: d.stickies.map((x) => x.id === s.id ? {
						...x,
						text: e.target.value
					} : x)
				})),
				onPointerDown: (e) => {
					const sx = e.clientX;
					const sy = e.clientY;
					const ox = s.x;
					const oy = s.y;
					const move = (ev) => {
						phone.update((d) => ({
							...d,
							stickies: d.stickies.map((x) => x.id === s.id ? {
								...x,
								x: ox + ev.clientX - sx,
								y: oy + ev.clientY - sy
							} : x)
						}));
					};
					const up = () => {
						window.removeEventListener("pointermove", move);
						window.removeEventListener("pointerup", up);
					};
					window.addEventListener("pointermove", move);
					window.addEventListener("pointerup", up);
				}
			}, s.id))
		})]
	});
}
function MagApp() {
	usePhone();
	const t = useT();
	const video = (0, import_react.useRef)(null);
	const [zoom, setZoom] = (0, import_react.useState)(1.5);
	const [err, setErr] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let stream = null;
		navigator.mediaDevices?.getUserMedia({ video: true }).then((s) => {
			stream = s;
			if (video.current) video.current.srcObject = s;
		}).catch(() => setErr(t("دوربین نیست", "No camera")));
		return () => stream?.getTracks().forEach((tr) => tr.stop());
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("ذره‌بین", "Magnifier"),
		scroll: false,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "cam-view",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: video,
				autoPlay: true,
				playsInline: true,
				muted: true,
				style: { transform: `scale(${zoom})` }
			}), err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "warn",
				children: err
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			min: 1,
			max: 4,
			step: .1,
			value: zoom,
			onChange: (e) => setZoom(Number(e.target.value))
		})]
	});
}
function AppView({ id }) {
	const web = usePhone().web(id);
	if (web?.html) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HtmlApp, {
		name: web.name,
		html: web.html
	});
	if (web?.url) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WebFrame, {
		title: web.name,
		url: web.url
	});
	switch (id) {
		case "phone": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneApp, {});
		case "messages": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessagesApp, {});
		case "safari": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SafariApp, {});
		case "music": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MusicApp, {});
		case "camera": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CameraApp, {});
		case "photos": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotosApp, {});
		case "weather": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeatherApp, {});
		case "clock": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockApp, {});
		case "maps": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapsApp, {});
		case "notes": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesApp, {});
		case "calendar": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarApp, {});
		case "reminders": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RemindersApp, {});
		case "calculator": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalculatorApp, {});
		case "settings": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsApp, {});
		case "appstore": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StoreApp, {});
		case "files": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilesApp, {});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExtraApps, { id });
	}
}
function PhoneApp() {
	const phone = usePhone();
	const t = useT();
	const [tab, setTab] = (0, import_react.useState)("key");
	const [digits, setDigits] = (0, import_react.useState)("");
	const [sec, setSec] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (!phone.call) return;
		const id = window.setInterval(() => setSec(Math.floor((Date.now() - phone.call.started) / 1e3)), 500);
		return () => window.clearInterval(id);
	}, [phone.call]);
	if (phone.call) {
		const c = phone.call;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
			title: t("تماس", "Call"),
			scroll: false,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "call-screen",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "who",
						children: c.name || faNum(c.number, phone.lang)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "num",
						children: faNum(`${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`, phone.lang)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "call-btn end-btn",
						"aria-label": "end",
						onClick: phone.endCall,
						children: "⌁"
					})
				]
			})
		});
	}
	const keys = [
		"1",
		"2",
		"3",
		"4",
		"5",
		"6",
		"7",
		"8",
		"9",
		"*",
		"0",
		"#"
	];
	const sub = {
		"2": "ABC",
		"3": "DEF",
		"4": "GHI",
		"5": "JKL",
		"6": "MNO",
		"7": "PQRS",
		"8": "TUV",
		"9": "WXYZ"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: t("تلفن", "Phone"),
		scroll: false,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "app-fill",
			children: [
				tab === "key" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							textAlign: "center",
							fontSize: 34,
							minHeight: 48,
							letterSpacing: 1
						},
						children: faNum(digits || "", phone.lang)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "keypad",
						children: keys.map((k) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "key",
							onClick: () => setDigits((d) => (d + k).slice(0, 16)),
							children: [faNum(k, phone.lang), sub[k] && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: sub[k] })]
						}, k))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "call-btn",
						"aria-label": "call",
						onClick: () => {
							if (!digits) return;
							const hit = phone.data.contacts.find((c) => c.phone === digits);
							phone.startCall(hit?.name || "", digits);
						},
						children: "☎"
					}),
					digits && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "text-btn",
						onClick: () => setDigits((d) => d.slice(0, -1)),
						children: "⌫"
					})
				] }),
				tab === "recents" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "app-scroll",
					children: phone.data.recents.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: r.name || faNum(r.number, phone.lang),
						value: faNum(r.number, phone.lang),
						onClick: () => phone.startCall(r.name, r.number)
					}, r.id))
				}),
				(tab === "contacts" || tab === "fav") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "app-scroll",
					children: phone.data.contacts.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: c.name,
						value: faNum(c.phone, phone.lang),
						onClick: () => phone.startCall(c.name, c.phone)
					}, c.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "tabs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: tab === "fav" ? "on" : "",
							onClick: () => setTab("fav"),
							children: t("علاقه‌مندی", "Favorites")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: tab === "recents" ? "on" : "",
							onClick: () => setTab("recents"),
							children: t("اخیر", "Recents")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: tab === "contacts" ? "on" : "",
							onClick: () => setTab("contacts"),
							children: t("مخاطبان", "Contacts")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: tab === "key" ? "on" : "",
							onClick: () => setTab("key"),
							children: t("صفحه کلید", "Keypad")
						})
					]
				})
			]
		})
	});
}
function MessagesApp() {
	const phone = usePhone();
	const t = useT();
	const [open, setOpen] = (0, import_react.useState)(null);
	const [text, setText] = (0, import_react.useState)("");
	const contact = phone.data.contacts.find((c) => c.id === open);
	function send() {
		if (!open || !text.trim()) return;
		const body = text.trim();
		setText("");
		phone.update((d) => {
			const th = d.threads[open] ?? {
				messages: [],
				unread: 0
			};
			return {
				...d,
				threads: {
					...d.threads,
					[open]: {
						unread: 0,
						messages: [...th.messages, {
							id: uid("m"),
							from: "me",
							text: body,
							at: Date.now()
						}]
					}
				}
			};
		});
		window.setTimeout(() => {
			const reply = t("باشه، دیدمت.", "Got it.");
			phone.update((d) => {
				const th = d.threads[open] ?? {
					messages: [],
					unread: 0
				};
				return {
					...d,
					threads: {
						...d.threads,
						[open]: {
							...th,
							messages: [...th.messages, {
								id: uid("m"),
								from: "them",
								text: reply,
								at: Date.now()
							}]
						}
					}
				};
			});
		}, 700);
	}
	if (open && contact) {
		const msgs = phone.data.threads[open]?.messages ?? [];
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
			title: contact.name,
			back: () => setOpen(null),
			scroll: false,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "app-scroll",
				children: msgs.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `bubble-row ${m.from}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "msg",
						children: m.text
					})
				}, m.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "composer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: text,
					placeholder: t("پیام", "Message"),
					onChange: (e) => setText(e.target.value),
					onKeyDown: (e) => e.key === "Enter" && send()
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "text-btn",
					onClick: send,
					children: t("بفرست", "Send")
				})]
			})]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: t("پیام‌ها", "Messages"),
		children: phone.data.contacts.map((c) => {
			const th = phone.data.threads[c.id];
			const last = th?.messages[th.messages.length - 1];
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: c.name,
				value: th?.unread ? faNum(th.unread, phone.lang) : "",
				onClick: () => {
					setOpen(c.id);
					phone.update((d) => ({
						...d,
						threads: {
							...d.threads,
							[c.id]: {
								...d.threads[c.id] ?? { messages: [] },
								unread: 0,
								messages: d.threads[c.id]?.messages ?? []
							}
						}
					}));
				},
				icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					style: {
						color: "#8e8e93",
						fontSize: 13
					},
					children: last?.text.slice(0, 18)
				})
			}, c.id);
		})
	});
}
var BOOKMARKS = [
	{
		fa: "ویکی‌پدیا",
		en: "Wikipedia",
		url: "https://fa.wikipedia.org"
	},
	{
		fa: "نقشه",
		en: "Map",
		url: "https://www.openstreetmap.org"
	},
	{
		fa: "هوا",
		en: "Weather",
		url: "https://open-meteo.com"
	}
];
function SafariApp() {
	const phone = usePhone();
	const t = useT();
	const [url, setUrl] = (0, import_react.useState)("");
	const [current, setCurrent] = (0, import_react.useState)(null);
	const [adding, setAdding] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	function go(raw) {
		const u = /^https?:\/\//.test(raw) ? raw : `https://${raw}`;
		setCurrent(u);
		setUrl(u);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("سافاری", "Safari"),
		scroll: false,
		right: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "text-btn",
			onClick: () => {
				setName(t("وب", "Web"));
				setAdding(true);
			},
			children: "+"
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "composer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: url,
					placeholder: "example.com",
					onChange: (e) => setUrl(e.target.value),
					onKeyDown: (e) => e.key === "Enter" && go(url)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "text-btn",
					onClick: () => go(url),
					children: t("برو", "Go")
				})]
			}),
			!current && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "app-scroll",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "section-label",
					children: t("نشان‌شده‌ها", "Bookmarks")
				}), BOOKMARKS.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: phone.rtl ? b.fa : b.en,
					value: b.url.replace("https://", ""),
					onClick: () => go(b.url)
				}, b.url))]
			}),
			current && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
				className: "map-frame",
				title: "safari",
				src: current,
				sandbox: "allow-scripts allow-forms allow-popups"
			}),
			adding && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sheet",
				style: { zIndex: 40 },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "large",
						children: t("افزودن به صفحهٔ اصلی", "Add to Home Screen")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: t("نام", "Name")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "get open",
						onClick: () => {
							if (!name.trim() || !current) return;
							phone.addWeb({
								name: name.trim(),
								url: current,
								color: "#0A84FF"
							});
							setAdding(false);
						},
						children: t("افزودن", "Add")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "text-btn",
						onClick: () => setAdding(false),
						children: t("لغو", "Cancel")
					})
				]
			})
		]
	});
}
function WebFrame({ title, url }) {
	const phone = usePhone();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title,
		back: phone.closeApp,
		scroll: false,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
			className: "map-frame",
			title,
			src: url,
			sandbox: "allow-scripts allow-forms allow-popups"
		})
	});
}
function HtmlApp({ name, html }) {
	const phone = usePhone();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: name,
		back: phone.closeApp,
		scroll: false,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
			className: "map-frame",
			title: name,
			sandbox: "allow-scripts",
			srcDoc: html
		})
	});
}
function MusicApp() {
	usePhone();
	const t = useT();
	const [, setN] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => music.subscribe(() => setN((n) => n + 1)), []);
	const tr = music.track;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: t("موسیقی", "Music"),
		scroll: false,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "app-fill",
			style: {
				alignItems: "center",
				padding: 16
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: {
					width: 220,
					height: 220,
					borderRadius: 24,
					background: tr.hue,
					margin: "12px auto"
				} }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
					style: { fontSize: 22 },
					children: tr.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: { color: "#8e8e93" },
					children: tr.artist
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					style: {
						display: "flex",
						gap: 18,
						marginTop: 18
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "bubble",
							onClick: () => music.prev(),
							children: "⏮"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "bubble on",
							onClick: () => void music.toggle(),
							children: music.playing ? "❚❚" : "▶"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "bubble",
							onClick: () => music.next(),
							children: "⏭"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "app-scroll",
					style: {
						width: "100%",
						marginTop: 16
					},
					children: music.tracks.map((track, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: track.title,
						value: track.artist,
						onClick: () => void music.playIndex(i)
					}, track.id))
				})
			]
		})
	});
}
function CameraApp() {
	const phone = usePhone();
	const t = useT();
	const video = (0, import_react.useRef)(null);
	const [err, setErr] = (0, import_react.useState)("");
	const [zoom, setZoom] = (0, import_react.useState)(1);
	(0, import_react.useEffect)(() => {
		let stream = null;
		(async () => {
			try {
				stream = await navigator.mediaDevices.getUserMedia({
					video: { facingMode: "environment" },
					audio: false
				});
				if (video.current) video.current.srcObject = stream;
			} catch {
				setErr(t("دوربین در این پیش‌نمایش در دسترس نیست. شاتر یک عکس نمونه می‌سازد.", "Camera is blocked here. The shutter saves a sample photo."));
			}
		})();
		return () => stream?.getTracks().forEach((tr) => tr.stop());
	}, []);
	function shoot() {
		const v = video.current;
		let url = phone.data.wallpaper;
		if (v && v.videoWidth) {
			const c = document.createElement("canvas");
			c.width = 480;
			c.height = Math.round(480 * (v.videoHeight / v.videoWidth));
			c.getContext("2d").drawImage(v, 0, 0, c.width, c.height);
			url = c.toDataURL("image/jpeg", .62);
		}
		phone.update((d) => ({
			...d,
			photos: [{
				id: uid("ph"),
				url,
				at: Date.now()
			}, ...d.photos].slice(0, 16)
		}));
		phone.openApp("photos");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app",
		style: { paddingTop: 54 },
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "cam-view",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
					ref: video,
					autoPlay: true,
					playsInline: true,
					muted: true,
					style: { transform: `scale(${zoom})` }
				}),
				err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "warn",
					children: err
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "shutter",
					"aria-label": "shutter",
					onClick: shoot,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "range",
			min: 1,
			max: 3,
			step: .1,
			value: zoom,
			onChange: (e) => setZoom(Number(e.target.value)),
			style: { margin: 8 }
		})]
	});
}
function PhotosApp() {
	const phone = usePhone();
	const t = useT();
	const [open, setOpen] = (0, import_react.useState)(null);
	const photo = phone.data.photos.find((p) => p.id === open);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("عکس‌ها", "Photos"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "photo-grid",
			children: phone.data.photos.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => setOpen(p.id),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: p.url,
					alt: ""
				})
			}, p.id))
		}), photo && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "viewer",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nav",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "text-btn",
						onClick: () => setOpen(null),
						children: t("بستن", "Close")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "text-btn",
						onClick: () => phone.update((d) => ({
							...d,
							photos: d.photos.map((p) => p.id === photo.id ? {
								...p,
								fav: !p.fav
							} : p)
						})),
						children: photo.fav ? "★" : "☆"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "text-btn",
						onClick: () => {
							phone.update((d) => ({
								...d,
								photos: d.photos.filter((p) => p.id !== photo.id)
							}));
							setOpen(null);
						},
						children: t("حذف", "Delete")
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: photo.url,
				alt: ""
			})]
		})]
	});
}
function WeatherApp() {
	const phone = usePhone();
	const t = useT();
	const [city, setCity] = (0, import_react.useState)(CITIES[5]);
	const [wx, setWx] = (0, import_react.useState)(null);
	const [err, setErr] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let stop = false;
		const url = `https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}&current=temperature_2m,weather_code&hourly=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=6`;
		fetch(url).then((r) => r.json()).then((j) => {
			if (stop) return;
			const hours = j.hourly.time.slice(0, 12).map((time, i) => ({
				t: time.slice(11, 16),
				c: Math.round(j.hourly.temperature_2m[i])
			}));
			const days = j.daily.time.map((_, i) => ({
				max: Math.round(j.daily.temperature_2m_max[i]),
				min: Math.round(j.daily.temperature_2m_min[i]),
				code: j.daily.weather_code[i]
			}));
			setWx({
				temp: Math.round(j.current.temperature_2m),
				code: j.current.weather_code,
				hours,
				days
			});
		}).catch(() => setErr(t("هوا این لحظه نرسید", "Forecast unavailable")));
		return () => {
			stop = true;
		};
	}, [city]);
	const label = (code) => {
		if (code === 0) return t("آفتابی", "Clear");
		if (code < 3) return t("نیمه‌ابری", "Partly cloudy");
		if (code < 50) return t("ابری", "Cloudy");
		if (code < 70) return t("باران", "Rain");
		if (code < 80) return t("برف", "Snow");
		return t("رگبار", "Showers");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: phone.rtl ? city.fa : city.en,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "chips",
				children: CITIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: c.en === city.en ? "on" : "",
					onClick: () => setCity(c),
					children: phone.rtl ? c.fa : c.en
				}, c.en))
			}),
			err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "warn",
				children: err
			}),
			wx && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "wx-hero",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "temp",
						children: [faNum(wx.temp, phone.lang), "°"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: label(wx.code) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hour-row",
					children: wx.hours.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: faNum(h.t, phone.lang) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", { children: [faNum(h.c, phone.lang), "°"] })] }, h.t))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: wx.days.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: i === 0 ? t("امروز", "Today") : t(`روز ${i + 1}`, `Day ${i + 1}`),
					value: `${faNum(d.min, phone.lang)}°  ${faNum(d.max, phone.lang)}°`
				}, i)) })
			] })
		]
	});
}
function ClockApp() {
	const phone = usePhone();
	const t = useT();
	const [tab, setTab] = (0, import_react.useState)("world");
	const [sw, setSw] = (0, import_react.useState)({
		run: false,
		base: 0,
		since: 0
	});
	const [laps, setLaps] = (0, import_react.useState)([]);
	const [, bump] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => bump((n) => n + 1), 200);
		return () => window.clearInterval(id);
	}, []);
	const elapsed = sw.base + (sw.run ? Date.now() - sw.since : 0);
	const [mins, setMins] = (0, import_react.useState)(1);
	function fmt(ms) {
		const s = Math.floor(ms / 1e3);
		return faNum(`${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}.${String(Math.floor(ms % 1e3 / 10)).padStart(2, "0")}`, phone.lang);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("ساعت", "Clock"),
		scroll: tab !== "stop",
		children: [
			tab === "world" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: CITIES.filter((_, i) => [
				0,
				5,
				6,
				8,
				9
			].includes(i)).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: phone.rtl ? c.fa : c.en,
				value: phone.now ? faNum(new Intl.DateTimeFormat("en-GB", {
					timeZone: c.tz,
					hour: "2-digit",
					minute: "2-digit",
					hour12: false
				}).format(phone.now), phone.lang) : "—"
			}, c.en)) }),
			tab === "alarm" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [phone.data.alarms.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: a.label,
				value: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					style: {
						display: "flex",
						alignItems: "center",
						gap: 8
					},
					children: [faNum(`${String(a.hour).padStart(2, "0")}:${String(a.minute).padStart(2, "0")}`, phone.lang), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: a.on,
						onClick: () => phone.update((d) => ({
							...d,
							alarms: d.alarms.map((x) => x.id === a.id ? {
								...x,
								on: !x.on
							} : x)
						}))
					})]
				})
			}) }, a.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "text-btn",
				onClick: () => {
					const n = phone.now ?? /* @__PURE__ */ new Date();
					phone.update((d) => ({
						...d,
						alarms: [...d.alarms, {
							id: uid("a"),
							hour: n.getHours(),
							minute: (n.getMinutes() + 1) % 60,
							on: true,
							label: t("زنگ", "Alarm")
						}]
					}));
				},
				children: t("زنگ جدید", "Add alarm")
			})] }),
			tab === "stop" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: { textAlign: "center" },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "lock-time",
						style: { fontSize: 56 },
						children: fmt(elapsed)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: {
							display: "flex",
							justifyContent: "center",
							gap: 12
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "get",
								onClick: () => setLaps((l) => [elapsed, ...l].slice(0, 8)),
								children: t("دور", "Lap")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "get open",
								onClick: () => setSw((s) => s.run ? {
									run: false,
									base: s.base + Date.now() - s.since,
									since: 0
								} : {
									run: true,
									base: s.base,
									since: Date.now()
								}),
								children: sw.run ? t("توقف", "Stop") : t("شروع", "Start")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "get",
								onClick: () => {
									setSw({
										run: false,
										base: 0,
										since: 0
									});
									setLaps([]);
								},
								children: t("صفر", "Reset")
							})
						]
					}),
					laps.map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: t(`دور ${laps.length - i}`, `Lap ${laps.length - i}`),
						value: fmt(l)
					}, i))
				]
			}),
			tab === "timer" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					textAlign: "center",
					padding: 16
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "lock-time",
						style: { fontSize: 64 },
						children: [
							faNum(mins, phone.lang),
							" ",
							t("دقیقه", "min")
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: 1,
						max: 60,
						value: mins,
						onChange: (e) => setMins(Number(e.target.value))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "get open",
						onClick: () => phone.setTimer({
							endsAt: Date.now() + mins * 6e4,
							total: mins * 6e4
						}),
						children: t("شروع زمان‌سنج", "Start timer")
					}),
					phone.timer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t("در حال اجرا — روی جزیره پویا هم هست", "Running — also on the Dynamic Island") }),
					phone.timer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "text-btn",
						onClick: () => phone.setTimer(null),
						children: t("لغو", "Cancel")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "tabs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: tab === "world" ? "on" : "",
						onClick: () => setTab("world"),
						children: t("جهان", "World")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: tab === "alarm" ? "on" : "",
						onClick: () => setTab("alarm"),
						children: t("زنگ", "Alarm")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: tab === "stop" ? "on" : "",
						onClick: () => setTab("stop"),
						children: t("کرونومتر", "Stopwatch")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: tab === "timer" ? "on" : "",
						onClick: () => setTab("timer"),
						children: t("زمان‌سنج", "Timer")
					})
				]
			})
		]
	});
}
function MapsApp() {
	const phone = usePhone();
	const [city, setCity] = (0, import_react.useState)(CITIES[0]);
	const [me, setMe] = (0, import_react.useState)("");
	const box = `${city.lon - .08},${city.lat - .05},${city.lon + .08},${city.lat + .05}`;
	const src = `https://www.openstreetmap.org/export/embed.html?bbox=${encodeURIComponent(box)}&layer=mapnik&marker=${city.lat}%2C${city.lon}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: phone.rtl ? "نقشه" : "Maps",
		scroll: false,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "chips",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => {
						navigator.geolocation?.getCurrentPosition((p) => {
							setCity({
								fa: "من",
								en: "Me",
								lat: p.coords.latitude,
								lon: p.coords.longitude,
								tz: "UTC"
							});
							setMe(`${p.coords.latitude.toFixed(3)}, ${p.coords.longitude.toFixed(3)}`);
						}, () => setMe(phone.rtl ? "موقعیت رد شد" : "Location denied"));
					},
					children: phone.rtl ? "موقعیت من" : "My location"
				}), CITIES.slice(0, 8).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: c.en === city.en ? "on" : "",
					onClick: () => setCity(c),
					children: phone.rtl ? c.fa : c.en
				}, c.en))]
			}),
			me && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "warn",
				children: me
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
				className: "map-frame",
				title: "map",
				src
			})
		]
	});
}
function NotesApp() {
	const phone = usePhone();
	const t = useT();
	const [id, setId] = (0, import_react.useState)(null);
	const note = phone.data.notes.find((n) => n.id === id);
	if (note) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: note.title || t("یادداشت", "Note"),
		back: () => setId(null),
		right: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "text-btn",
			onClick: () => {
				phone.update((d) => ({
					...d,
					notes: d.notes.filter((n) => n.id !== note.id)
				}));
				setId(null);
			},
			children: t("حذف", "Delete")
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			className: "field",
			value: note.title,
			onChange: (e) => phone.update((d) => ({
				...d,
				notes: d.notes.map((n) => n.id === note.id ? {
					...n,
					title: e.target.value,
					updated: Date.now()
				} : n)
			}))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			className: "area",
			value: note.body,
			onChange: (e) => phone.update((d) => ({
				...d,
				notes: d.notes.map((n) => n.id === note.id ? {
					...n,
					body: e.target.value,
					updated: Date.now()
				} : n)
			}))
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: t("یادداشت", "Notes"),
		right: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "text-btn",
			onClick: () => {
				const n = {
					id: uid("n"),
					title: "",
					body: "",
					updated: Date.now()
				};
				phone.update((d) => ({
					...d,
					notes: [n, ...d.notes]
				}));
				setId(n.id);
			},
			children: "+"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: phone.data.notes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: n.title || t("بدون عنوان", "New note"),
			value: n.body.slice(0, 16),
			onClick: () => setId(n.id)
		}, n.id)) })
	});
}
function CalendarApp() {
	const phone = usePhone();
	const t = useT();
	const [view, setView] = (0, import_react.useState)(() => initialView(/* @__PURE__ */ new Date(), phone.lang));
	const [sel, setSel] = (0, import_react.useState)(null);
	const [title, setTitle] = (0, import_react.useState)("");
	const cells = monthGrid(view, phone.lang);
	const today = phone.now ? todayKey(phone.now) : "";
	const dayEvents = phone.data.events.filter((e) => e.day === sel);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("تقویم", "Calendar"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "nav",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "text-btn",
						onClick: () => setView((v) => shiftMonth(v, -1, phone.lang)),
						children: "‹"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: monthTitle(view, phone.lang) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "text-btn",
						onClick: () => setView((v) => shiftMonth(v, 1, phone.lang)),
						children: "›"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "cal-grid",
				children: [(phone.rtl ? [
					"ی",
					"د",
					"س",
					"چ",
					"پ",
					"ج",
					"ش"
				] : [
					"S",
					"M",
					"T",
					"W",
					"T",
					"F",
					"S"
				]).map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
					className: "wd",
					children: d
				}, i)), cells.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: `${c.key === sel ? "on" : ""} ${c.key === today ? "today" : ""}`,
					disabled: !c.inMonth,
					onClick: () => setSel(c.key),
					children: c.label
				}, c.key))]
			}),
			sel && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "section-label",
					children: faNum(sel, phone.lang)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: dayEvents.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: e.title,
					value: e.time || ""
				}, e.id)) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: "field",
					value: title,
					placeholder: t("رویداد تازه", "New event"),
					onChange: (e) => setTitle(e.target.value)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "get open",
					style: { marginInlineStart: 16 },
					onClick: () => {
						if (!title.trim()) return;
						phone.update((d) => ({
							...d,
							events: [...d.events, {
								id: uid("e"),
								title: title.trim(),
								day: sel,
								color: "#0A84FF"
							}]
						}));
						setTitle("");
					},
					children: t("افزودن", "Add")
				})
			] })
		]
	});
}
function RemindersApp() {
	const phone = usePhone();
	const t = useT();
	const [text, setText] = (0, import_react.useState)("");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("یادآورها", "Reminders"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "composer",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: text,
				placeholder: t("کار تازه", "New reminder"),
				onChange: (e) => setText(e.target.value)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "text-btn",
				onClick: () => {
					if (!text.trim()) return;
					phone.update((d) => ({
						...d,
						reminders: [{
							id: uid("r"),
							title: text.trim(),
							done: false
						}, ...d.reminders]
					}));
					setText("");
				},
				children: "+"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: phone.data.reminders.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: r.done ? `✓ ${r.title}` : r.title,
			onClick: () => phone.update((d) => ({
				...d,
				reminders: d.reminders.map((x) => x.id === r.id ? {
					...x,
					done: !x.done
				} : x)
			}))
		}, r.id)) })]
	});
}
function CalculatorApp() {
	const phone = usePhone();
	const [st, setSt] = (0, import_react.useState)(CALC0);
	const keys = [
		"AC",
		"±",
		"%",
		"÷",
		"7",
		"8",
		"9",
		"×",
		"4",
		"5",
		"6",
		"−",
		"1",
		"2",
		"3",
		"+",
		"0",
		".",
		"="
	];
	const clear = st.fresh || st.disp === "0" ? "AC" : "C";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "app",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "calc",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "calc-disp",
				children: faNum(st.disp, phone.lang)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "calc-grid",
				children: keys.map((k) => {
					const label = k === "AC" ? clear : k;
					const cls = k === "0" ? "ck zero" : "÷×−+= ".includes(k) || k === "÷" || k === "×" || k === "−" || k === "+" || k === "=" ? "ck op" : k === "AC" || k === "±" || k === "%" ? "ck fn" : "ck";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: cls,
						onClick: () => setSt((s) => calcKey(s, label === "C" ? "C" : k)),
						children: label === "AC" || label === "C" ? label : faNum(label, phone.lang)
					}, k);
				})
			})]
		})
	});
}
function SettingsApp() {
	const phone = usePhone();
	const t = useT();
	const d = phone.data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("تنظیمات", "Settings"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "section-label",
				children: t("ظاهر", "Appearance")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "wall-pick",
				children: WALLPAPERS.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: d.wallpaper === w.url ? "on" : "",
					onClick: () => phone.update({ wallpaper: w.url }),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: w.url,
						alt: phone.rtl ? w.fa : w.en
					})
				}, w.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: [
				"black",
				"natural",
				"desert",
				"white"
			].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
				label: f === "black" ? t("تیتانیوم مشکی", "Black Titanium") : f === "natural" ? t("تیتانیوم طبیعی", "Natural") : f === "desert" ? t("تیتانیوم صحرایی", "Desert") : t("سفید", "White"),
				value: d.finish === f ? "✓" : "",
				onClick: () => phone.update({ finish: f })
			}, f)) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "section-label",
				children: t("عمومی", "General")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: t("زبان", "Language"),
					value: d.lang === "fa" ? "فارسی" : "English",
					onClick: () => phone.update({ lang: d.lang === "fa" ? "en" : "fa" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: t("صدا", "Sounds"),
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: !d.silent,
						onClick: () => phone.update({ silent: !d.silent })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: t("کم‌مصرف", "Low Power"),
					value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: d.lowPower,
						onClick: () => phone.update({ lowPower: !d.lowPower })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: t("روشنایی", "Brightness"),
					value: faNum(Math.round(d.brightness * 100), phone.lang),
					onClick: () => phone.update({ brightness: d.brightness > .6 ? .45 : 1 })
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "section-label",
				children: t("درباره", "About")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Group, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: t("نام", "Name"),
					value: "ALI Phone"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: t("مدل", "Model"),
					value: "iPhone 16 Pro Max"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: t("نسخه", "Version"),
					value: "iOS 18"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
					label: t("پاک کردن دادهٔ دستگاه", "Erase device data"),
					onClick: () => {
						localStorage.removeItem("aliphone.v1");
						window.location.reload();
					}
				})
			] })
		]
	});
}
function StoreApp() {
	const phone = usePhone();
	const t = useT();
	const [q, setQ] = (0, import_react.useState)("");
	const [make, setMake] = (0, import_react.useState)(false);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		url: "",
		html: "",
		color: "#5E5CE6"
	});
	const list = Object.entries(APPS).filter(([id, m]) => {
		if (DOCK.includes(id)) return false;
		return (phone.rtl ? m.fa : m.en).toLowerCase().includes(q.trim().toLowerCase());
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: t("اپ استور", "App Store"),
		right: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "text-btn",
			onClick: () => setMake(true),
			children: t("ساخت", "Create")
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "field",
				placeholder: t("جستجو", "Search"),
				value: q,
				onChange: (e) => setQ(e.target.value)
			}),
			list.map(([id, m]) => {
				const onHome = phone.data.home.includes(id);
				const have = m.core || phone.data.installed.includes(id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "store-card",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IosIcon, {
							id,
							now: phone.now
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "meta",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: phone.rtl ? m.fa : m.en }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: phone.rtl ? m.blurbFa : m.blurbEn })]
						}),
						have && onHome ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "get open",
							onClick: () => phone.openApp(id),
							children: t("باز", "Open")
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "get",
							onClick: () => phone.install(id),
							children: t("گرفتن", "Get")
						})
					]
				}, id);
			}),
			phone.data.webApps.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "store-card",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IosIcon, {
						id: w.id,
						now: phone.now,
						web: w
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "meta",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: w.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: w.url || "HTML" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "get open",
						onClick: () => phone.openApp(w.id),
						children: t("باز", "Open")
					})
				]
			}, w.id)),
			make && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sheet",
				style: {
					zIndex: 40,
					overflow: "auto"
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "large",
						children: t("اپ تازه", "New app")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						placeholder: t("نام", "Name"),
						value: form.name,
						onChange: (e) => setForm({
							...form,
							name: e.target.value
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						placeholder: "https://",
						value: form.url,
						onChange: (e) => setForm({
							...form,
							url: e.target.value
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						className: "area",
						placeholder: t("یا HTML کوچک", "or a small HTML app"),
						value: form.html,
						onChange: (e) => setForm({
							...form,
							html: e.target.value
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "field",
						value: form.color,
						onChange: (e) => setForm({
							...form,
							color: e.target.value
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "get open",
						onClick: () => {
							if (!form.name.trim()) return;
							const url = form.url.trim() ? /^https?:/.test(form.url) ? form.url.trim() : `https://${form.url.trim()}` : void 0;
							phone.addWeb({
								name: form.name.trim(),
								url,
								html: form.html.trim() || void 0,
								color: form.color || "#5E5CE6"
							});
							setMake(false);
						},
						children: t("نصب روی صفحهٔ اصلی", "Install on Home Screen")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "text-btn",
						onClick: () => setMake(false),
						children: t("بستن", "Close")
					})
				]
			})
		]
	});
}
function FilesApp() {
	const phone = usePhone();
	const t = useT();
	const [folder, setFolder] = (0, import_react.useState)(null);
	const [open, setOpen] = (0, import_react.useState)(null);
	const items = phone.data.files.filter((f) => f.parent === folder);
	const cur = phone.data.files.find((f) => f.id === folder);
	const file = phone.data.files.find((f) => f.id === open);
	if (file && file.kind === "text") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Screen, {
		title: file.name,
		back: () => setOpen(null),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			className: "area",
			value: file.body || "",
			onChange: (e) => phone.update((d) => ({
				...d,
				files: d.files.map((f) => f.id === file.id ? {
					...f,
					body: e.target.value
				} : f)
			}))
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Screen, {
		title: cur?.name || t("فایل‌ها", "Files"),
		back: folder ? () => setFolder(cur?.parent ?? null) : void 0,
		right: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "text-btn",
			onClick: () => {
				const name = t("یادداشت تازه.txt", "Note.txt");
				phone.update((d) => ({
					...d,
					files: [...d.files, {
						id: uid("f"),
						name,
						kind: "text",
						parent: folder,
						body: ""
					}]
				}));
			},
			children: "+"
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Group, { children: items.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
			label: f.name,
			value: f.kind === "folder" ? "›" : "",
			onClick: () => f.kind === "folder" ? setFolder(f.id) : setOpen(f.id)
		}, f.id)) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "text-btn",
			onClick: () => phone.update((d) => ({
				...d,
				files: [...d.files, {
					id: uid("f"),
					name: t("پوشه", "Folder"),
					kind: "folder",
					parent: folder
				}]
			})),
			children: t("پوشهٔ جدید", "New folder")
		})]
	});
}
var FINISH = {
	black: {
		bg: "linear-gradient(180deg,#4a4946 0%,#2a2927 18%,#161514 60%,#0c0b0a)",
		btn: "#3a3937"
	},
	natural: {
		bg: "linear-gradient(180deg,#d5cfc7,#9a948c 40%,#6e6860)",
		btn: "#b7b1a9"
	},
	desert: {
		bg: "linear-gradient(180deg,#f0d2b4,#c49a70 38%,#8a5e3c)",
		btn: "#d7b08a"
	},
	white: {
		bg: "linear-gradient(180deg,#ffffff,#e4e4ea 50%,#c8c8d0)",
		btn: "#f2f2f6"
	}
};
function Phone() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stage, {}) });
}
function Stage() {
	const phone = usePhone();
	const [fit, setFit] = (0, import_react.useState)({
		mode: "desk",
		scale: .72
	});
	(0, import_react.useEffect)(() => {
		const measure = () => {
			const vw = window.innerWidth;
			const vh = window.innerHeight;
			if (vw < 560) setFit({
				mode: "fill",
				scale: 1
			});
			else setFit({
				mode: "desk",
				scale: Math.max(.34, Math.min((vw - 36) / 476, (vh - 24) / 992, 1))
			});
		};
		measure();
		window.addEventListener("resize", measure);
		return () => window.removeEventListener("resize", measure);
	}, []);
	const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScreenBody, {});
	if (fit.mode === "fill") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "ali",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "screen fill",
			children: inner
		})
	});
	const fin = FINISH[phone.data.finish];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "ali",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "stage",
			style: { transform: `scale(${fit.scale})` },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "chassis",
				style: { background: fin.bg },
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "side-btn action",
						style: { background: fin.btn },
						"aria-label": "Action",
						onClick: () => phone.update({ flashlight: !phone.data.flashlight })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "side-btn silent",
						style: { background: fin.btn },
						"aria-label": "Silent",
						onClick: () => phone.update({ silent: !phone.data.silent })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "side-btn vol-up",
						style: { background: fin.btn },
						"aria-label": "Volume up",
						onClick: () => phone.update({ volume: Math.min(1, phone.data.volume + .1) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "side-btn vol-down",
						style: { background: fin.btn },
						"aria-label": "Volume down",
						onClick: () => phone.update({ volume: Math.max(0, phone.data.volume - .1) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "side-btn power",
						style: { background: fin.btn },
						"aria-label": "Lock",
						onClick: () => phone.setLocked(true)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "side-btn camera",
						style: { background: fin.btn },
						"aria-label": "Camera",
						onClick: () => phone.openApp("camera")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "screen",
						children: inner
					})
				]
			})
		})
	});
}
function ScreenBody() {
	const phone = usePhone();
	const { data, lang } = phone;
	const paperLight = data.wallpaper.includes("mist");
	const inkOnGlass = paperLight ? "dark" : "light";
	const [cc, setCc] = (0, import_react.useState)(false);
	const [nc, setNc] = (0, import_react.useState)(false);
	const [spot, setSpot] = (0, import_react.useState)(false);
	const [switcher, setSwitcher] = (0, import_react.useState)(false);
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [menu, setMenu] = (0, import_react.useState)(null);
	const [page, setPage] = (0, import_react.useState)(0);
	const [dragX, setDragX] = (0, import_react.useState)(0);
	const [dragging, setDragging] = (0, import_react.useState)(false);
	const [islandOpen, setIslandOpen] = (0, import_react.useState)(false);
	(0, import_react.useRef)(null);
	const sound = !data.silent;
	const home = data.home.filter((id) => available(data, id));
	const pages = Math.max(1, Math.ceil(home.length / 24));
	const pageCount = pages + 1;
	(0, import_react.useEffect)(() => {
		if (page > pageCount - 1) setPage(pageCount - 1);
	}, [page, pageCount]);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			const tag = e.target?.tagName;
			if (tag === "INPUT" || tag === "TEXTAREA") return;
			if (e.key === "Escape") {
				if (cc || nc || spot || menu) {
					setCc(false);
					setNc(false);
					setSpot(false);
					setMenu(null);
				} else if (switcher) setSwitcher(false);
				else if (phone.app) phone.closeApp();
				else if (phone.locked) phone.setLocked(false);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		cc,
		nc,
		spot,
		menu,
		switcher,
		phone
	]);
	function goHome() {
		setSwitcher(false);
		setCc(false);
		setNc(false);
		setSpot(false);
		setMenu(null);
		setEditing(false);
		if (phone.app) phone.closeApp();
		else setSwitcher(true);
	}
	const rtl = lang === "fa";
	const ccSide = rtl ? "left" : "right";
	const ncSide = rtl ? "right" : "left";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "wall",
			style: { backgroundImage: `url(${data.wallpaper})` }
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "safe",
			dir: rtl ? "rtl" : "ltr",
			children: [
				!phone.locked && !phone.app && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Home$1, {
					page,
					pages,
					pageCount,
					dragX,
					dragging,
					editing,
					paperLight,
					onDrag: (x, active) => {
						setDragX(x);
						setDragging(active);
					},
					onPage: (p) => setPage(Math.max(0, Math.min(pageCount - 1, p))),
					onEdit: setEditing,
					onMenu: setMenu,
					onSpot: () => setSpot(true)
				}),
				phone.app && !phone.locked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppView, { id: phone.app }),
				switcher && !phone.locked && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "switcher",
					onClick: () => setSwitcher(false),
					children: [phone.recents.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						style: {
							margin: "auto",
							opacity: .8
						},
						children: rtl ? "برنامهٔ بازی نیست" : "No open apps"
					}), phone.recents.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						style: { position: "relative" },
						onClick: (e) => e.stopPropagation(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "card-app",
							style: { backgroundImage: `url(${data.wallpaper})` },
							onClick: () => {
								phone.openApp(id);
								setSwitcher(false);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IosIcon, {
								id,
								now: phone.now,
								web: phone.web(id)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: phone.nameOf(id) })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "kill",
							"aria-label": "close",
							onClick: () => phone.closeRecent(id),
							style: { position: "absolute" },
							children: "×"
						})]
					}, id))]
				}),
				phone.locked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
					ink: inkOnGlass,
					onUnlock: () => {
						tapSound(sound);
						phone.setLocked(false);
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, {
					ink: phone.app && !phone.locked ? "light" : inkOnGlass,
					hideTime: phone.locked
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Island, {
					open: islandOpen,
					onToggle: () => setIslandOpen((v) => !v)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: `hot ${ncSide}`,
					"aria-label": "notifications",
					onPointerDown: (e) => startEdge(e, () => setNc(true))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: `hot ${ccSide}`,
					"aria-label": "control center",
					onPointerDown: (e) => startEdge(e, () => setCc(true))
				}),
				editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "done-pill",
					onClick: () => setEditing(false),
					children: rtl ? "تمام" : "Done"
				}),
				nc && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notifications, { onClose: () => setNc(false) }),
				cc && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Control, {
					onClose: () => setCc(false),
					onLock: () => {
						setCc(false);
						phone.setLocked(true);
					}
				}),
				spot && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spotlight, { onClose: () => setSpot(false) }),
				menu && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContextMenu, {
					id: menu.id,
					x: menu.x,
					y: menu.y,
					onClose: () => setMenu(null),
					onEdit: () => {
						setEditing(true);
						setMenu(null);
					}
				}),
				phone.ringing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "alarm-banner",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: phone.ringing.label }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: rtl ? "زنگ" : "Alarm" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: phone.dismissAlarm,
							children: rtl ? "متوقف کن" : "Stop"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `home-ind ${paperLight && !phone.app ? "dark" : ""}` }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "home-hit",
					"aria-label": rtl ? "خانه" : "Home",
					onClick: () => {
						tapSound(sound);
						goHome();
					},
					onPointerDown: (e) => {
						const y0 = e.clientY;
						const start = Date.now();
						const move = (ev) => {
							if (y0 - ev.clientY > 40) {
								cleanup();
								setSwitcher(true);
								if (phone.app) phone.closeApp();
							}
						};
						const up = () => {
							if (Date.now() - start > 450) setSwitcher(true);
							cleanup();
						};
						const cleanup = () => {
							window.removeEventListener("pointermove", move);
							window.removeEventListener("pointerup", up);
						};
						window.addEventListener("pointermove", move);
						window.addEventListener("pointerup", up);
					}
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "dimmer",
			style: { opacity: (1 - data.brightness) * .72 }
		}),
		data.flashlight && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "torch" })
	] });
}
function startEdge(e, open) {
	const y0 = e.clientY;
	const move = (ev) => {
		if (ev.clientY - y0 > 24) {
			open();
			cleanup();
		}
	};
	const cleanup = () => {
		window.removeEventListener("pointermove", move);
		window.removeEventListener("pointerup", cleanup);
	};
	window.addEventListener("pointermove", move);
	window.addEventListener("pointerup", cleanup);
}
function Status({ ink, hideTime }) {
	const { data, now, battery, lang } = usePhone();
	const bars = data.airplane ? 0 : data.cellular ? 4 : 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `status ${ink}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: hideTime ? "" : formatClock(now ?? new Date(2026, 9, 23, 9, 41), lang) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "status-sys",
			children: [
				data.silent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": true,
					children: "☾"
				}),
				data.airplane ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-label": "airplane",
					children: "✈"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "sig",
					"aria-hidden": true,
					children: [
						4,
						6,
						8,
						11
					].map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
						className: i < bars ? "" : "off",
						style: { height: h }
					}, h))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": true,
					style: { opacity: data.wifi ? 1 : .35 },
					children: "⌂"
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: `bat ${data.lowPower ? "low" : ""}`,
					"aria-label": "battery",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { style: { width: `${Math.max(8, battery)}%` } })
				})
			]
		})]
	});
}
function Island({ open, onToggle }) {
	useMusicTick();
	const phone = usePhone();
	const [tick, setTick] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		let on = false;
		const id = window.setInterval(() => {
			on = !on;
			setTick((n) => n + (on ? 1 : 0));
		}, 400);
		return () => window.clearInterval(id);
	}, []);
	const { call, timer, now, data, lang } = phone;
	let title = "";
	let sub = "";
	let showEq = false;
	if (call) {
		const sec = Math.max(0, Math.floor((Date.now() - call.started) / 1e3));
		title = call.name || call.number;
		sub = faNum(`${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`, lang);
	} else if (data.flashlight) {
		title = lang === "fa" ? "چراغ‌قوه" : "Flashlight";
		sub = lang === "fa" ? "روشن" : "On";
	} else if (timer && now) {
		const left = Math.max(0, Math.ceil((timer.endsAt - now.getTime()) / 1e3));
		title = lang === "fa" ? "زمان‌سنج" : "Timer";
		sub = faNum(`${Math.floor(left / 60)}:${String(left % 60).padStart(2, "0")}`, lang);
	}
	const activeCall = Boolean(call || data.flashlight || timer && now || music.playing);
	if (music.playing && !call) {
		title = music.track.title;
		sub = music.track.artist;
		showEq = true;
	}
	if (!activeCall && !open) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: "island",
		"aria-label": "Dynamic Island",
		onClick: onToggle
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		className: `island ${open ? "open" : ""}`,
		onClick: onToggle,
		"aria-label": "Dynamic Island",
		children: [
			showEq && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "eq",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				style: { textAlign: "start" },
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "island-title",
					children: title || (lang === "fa" ? "ALI Phone" : "ALI Phone")
				}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "island-sub",
					children: sub || (lang === "fa" ? "جزیره پویا" : "Dynamic Island")
				})]
			}),
			!open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "island-sub",
				children: sub
			})
		]
	});
}
function Home$1({ page, pages, pageCount, dragX, dragging, editing, paperLight, onDrag, onPage, onEdit, onMenu, onSpot }) {
	const phone = usePhone();
	const home = phone.data.home.filter((id) => available(phone.data, id));
	const origin = (0, import_react.useRef)(null);
	const long = (0, import_react.useRef)(null);
	function cells(p) {
		const out = home.slice(p * 24, p * 24 + 24).slice();
		while (out.length < 24) out.push("");
		return out;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `home ${editing ? "editing" : ""}`,
		onPointerDown: (e) => {
			if (e.target.closest("button")) {
				const btn = e.target.closest("button");
				const id = btn?.getAttribute("data-app");
				if (id && !editing) long.current = window.setTimeout(() => {
					const r = btn.getBoundingClientRect();
					onMenu({
						id,
						x: r.left,
						y: r.bottom + 6
					});
				}, 480);
				return;
			}
			origin.current = {
				x: e.clientX,
				y: e.clientY,
				page
			};
		},
		onPointerMove: (e) => {
			if (!origin.current) return;
			const dx = e.clientX - origin.current.x;
			const dy = e.clientY - origin.current.y;
			if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
				if (long.current) window.clearTimeout(long.current);
			}
			if (Math.abs(dx) > 12 && Math.abs(dx) > Math.abs(dy)) onDrag(dx, true);
		},
		onPointerUp: (e) => {
			if (long.current) window.clearTimeout(long.current);
			if (!origin.current) return;
			const dx = e.clientX - origin.current.x;
			const dy = e.clientY - origin.current.y;
			if (dragging) {
				if (dx < -50) onPage(origin.current.page + 1);
				else if (dx > 50) onPage(origin.current.page - 1);
				onDrag(0, false);
			} else if (dy > 50 && Math.abs(dy) > Math.abs(dx) && origin.current.y > 70) onSpot();
			origin.current = null;
		},
		onPointerCancel: () => {
			origin.current = null;
			onDrag(0, false);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pager",
				dir: "ltr",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `pager-track ${dragging ? "drag" : ""}`,
					style: { transform: `translateX(calc(${-page * 100}% + ${dragX}px))` },
					children: [Array.from({ length: pages }).map((_, p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "page",
						dir: phone.rtl ? "rtl" : "ltr",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "page-grid",
							children: cells(p).map((id, i) => id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, {
								id,
								editing,
								paperLight,
								onOpen: () => {
									if (editing) return;
									tapSound(!phone.data.silent);
									phone.openApp(id);
								}
							}, id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "icon-btn" }, `e${p}-${i}`))
						})
					}, p)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "page",
						dir: phone.rtl ? "rtl" : "ltr",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Library, {
							paperLight,
							onEdit: () => onEdit(true)
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `dots ${paperLight ? "dark" : ""}`,
				children: Array.from({ length: pageCount }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: i === page ? "on" : "" }, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "dock-wrap",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "dock-pill" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "dock-grid",
					dir: phone.rtl ? "rtl" : "ltr",
					children: DOCK.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, {
						id,
						labeled: false,
						editing: false,
						paperLight,
						onOpen: () => {
							tapSound(!phone.data.silent);
							phone.openApp(id);
						}
					}, id))
				})]
			})
		]
	});
}
function AppIcon({ id, onOpen, editing, paperLight, labeled = true }) {
	const phone = usePhone();
	const removable = !DOCK.includes(id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		className: "icon-btn",
		"data-app": id,
		"aria-label": phone.nameOf(id),
		onClick: onOpen,
		children: [
			editing && removable && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "xbtn",
				onClick: (e) => {
					e.stopPropagation();
					phone.uninstall(id);
				},
				children: "×"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IosIcon, {
				id,
				now: phone.now,
				web: phone.web(id)
			}),
			id === "messages" && phone.unread > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "badge",
				children: faNum(phone.unread, phone.lang)
			}),
			id === "calendar" ? null : null,
			labeled && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `label ${paperLight ? "dark" : ""}`,
				children: phone.nameOf(id)
			})
		]
	});
}
function Library({ paperLight, onEdit }) {
	const phone = usePhone();
	const [q, setQ] = (0, import_react.useState)("");
	const ids = Object.keys(APPS).filter((id) => available(phone.data, id));
	const webs = phone.data.webApps.map((w) => w.id);
	const all = [...ids, ...webs].filter((id) => phone.nameOf(id).toLowerCase().includes(q.trim().toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "lib",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: `search ${paperLight ? "dark" : ""}`,
				placeholder: phone.rtl ? "کتابخانه برنامه" : "App Library",
				value: q,
				onChange: (e) => setQ(e.target.value)
			}),
			q ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lib-grid",
				style: { marginTop: 16 },
				children: all.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, {
					id,
					editing: false,
					paperLight,
					onOpen: () => phone.openApp(id)
				}, id))
			}) : [
				{
					id: "main",
					fa: "اصلی",
					en: "Main"
				},
				{
					id: "life",
					fa: "زندگی",
					en: "Life"
				},
				{
					id: "tools",
					fa: "ابزارها",
					en: "Tools"
				},
				{
					id: "create",
					fa: "ساختن",
					en: "Create"
				}
			].map((c) => {
				const list = all.filter((id) => APPS[id]?.cat === c.id || id.startsWith("web:") && c.id === "create");
				if (!list.length) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: phone.rtl ? c.fa : c.en }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lib-grid",
					children: list.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, {
						id,
						editing: false,
						paperLight,
						onOpen: () => phone.openApp(id)
					}, id))
				})] }, c.id);
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "text-btn",
				onClick: onEdit,
				style: { color: "#fff" },
				children: phone.rtl ? "ویرایش صفحهٔ اصلی" : "Edit Home Screen"
			})
		]
	});
}
function ContextMenu({ id, x, y, onClose, onEdit }) {
	const phone = usePhone();
	const core = Boolean(APPS[id]?.core);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		style: {
			position: "absolute",
			inset: 0,
			zIndex: 35
		},
		onClick: onClose
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "menu",
		style: {
			left: Math.min(x, 220),
			top: Math.min(y, 520)
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: () => {
					phone.openApp(id);
					onClose();
				},
				children: phone.rtl ? "باز کردن" : "Open"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onEdit,
				children: phone.rtl ? "ویرایش صفحهٔ اصلی" : "Edit Home Screen"
			}),
			!DOCK.includes(id) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "danger",
				onClick: () => {
					phone.uninstall(id);
					onClose();
				},
				children: core ? phone.rtl ? "حذف از صفحهٔ اصلی" : "Remove from Home" : phone.rtl ? "حذف اپ" : "Delete App"
			})
		]
	})] });
}
function Lock({ ink, onUnlock }) {
	const phone = usePhone();
	const d = phone.now ?? new Date(2026, 9, 23, 9, 41);
	const y0 = (0, import_react.useRef)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `lock ${ink === "dark" ? "dark-ink" : ""}`,
		onPointerDown: (e) => {
			y0.current = e.clientY;
		},
		onPointerUp: (e) => {
			if (y0.current - e.clientY > 50) onUnlock();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lock-date",
				children: formatLockDate(d, phone.lang)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "lock-time",
				children: formatClock(d, phone.lang)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lock-shortcuts",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: phone.data.flashlight ? "on" : "",
					"aria-label": "flashlight",
					onClick: (e) => {
						e.stopPropagation();
						phone.update({ flashlight: !phone.data.flashlight });
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flash, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "camera",
					onClick: (e) => {
						e.stopPropagation();
						phone.openApp("camera");
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cam, {})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "unlock",
				"aria-label": phone.rtl ? "باز کردن" : "Unlock",
				onClick: onUnlock,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "chevron" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("small", { children: phone.rtl ? "برای باز کردن به بالا بکشید" : "Swipe up to open" })]
			})
		]
	});
}
function Control({ onClose, onLock }) {
	const phone = usePhone();
	const d = phone.data;
	const t = (fa, en) => phone.rtl ? fa : en;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "sheet",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "cc-grid",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "cc-card",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "conn",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: `bubble ${d.airplane ? "orange on" : ""}`,
									"aria-label": "airplane",
									onClick: () => phone.update({
										airplane: !d.airplane,
										wifi: d.airplane ? d.wifi : false
									}),
									children: "✈"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: `bubble blue ${d.cellular && !d.airplane ? "on" : ""}`,
									"aria-label": "cellular",
									onClick: () => phone.update({
										cellular: !d.cellular,
										airplane: false
									}),
									children: "▮"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: `bubble blue ${d.wifi && !d.airplane ? "on" : ""}`,
									"aria-label": "wifi",
									onClick: () => phone.update({
										wifi: !d.wifi,
										airplane: false
									}),
									children: "⌂"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: `bubble blue ${d.bluetooth ? "on" : ""}`,
									"aria-label": "bluetooth",
									onClick: () => phone.update({ bluetooth: !d.bluetooth }),
									children: "✦"
								})
							]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NowCard, {})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sliders",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VSlider, {
						value: d.brightness,
						label: "☼",
						onChange: (v) => phone.update({ brightness: Math.max(.25, v) })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VSlider, {
						value: d.volume,
						label: "♪",
						onChange: (v) => phone.update({ volume: v })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "cc-round",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: `bubble ${d.flashlight ? "on" : ""}`,
							"aria-label": "flashlight",
							onClick: () => phone.update({ flashlight: !d.flashlight }),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flash, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "bubble",
							"aria-label": "timer",
							onClick: () => {
								onClose();
								phone.openApp("clock");
							},
							children: "◷"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "bubble",
							"aria-label": "calculator",
							onClick: () => {
								onClose();
								phone.openApp("calculator");
							},
							children: "＝"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "bubble",
							"aria-label": "camera",
							onClick: () => {
								onClose();
								phone.openApp("camera");
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cam, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: `bubble ${d.lowPower ? "on" : ""}`,
							"aria-label": "low power",
							onClick: () => phone.update({ lowPower: !d.lowPower }),
							children: "⌁"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: `bubble ${d.silent ? "red on" : ""}`,
							"aria-label": "silent",
							onClick: () => phone.update({ silent: !d.silent }),
							children: "☾"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "bubble",
							"aria-label": "lock",
							onClick: onLock,
							children: "🔒"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "bubble",
							onClick: () => {
								onClose();
								phone.openApp("settings");
							},
							children: "⚙"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					style: {
						textAlign: "center",
						color: "#ddd",
						fontSize: 13
					},
					children: t("برای بستن ضربه بزنید", "Tap outside to close")
				})
			]
		})
	});
}
function useMusicTick() {
	const [n, setN] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => music.subscribe(() => setN((x) => x + 1)), []);
	return n;
}
function NowCard() {
	useMusicTick();
	const tr = music.track;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "cc-card np-mini",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: tr.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { children: tr.artist }) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "bubble on",
			"aria-label": "play",
			onClick: () => void music.toggle(),
			children: music.playing ? "❚❚" : "▶"
		})]
	});
}
function VSlider({ value, onChange, label }) {
	const ref = (0, import_react.useRef)(null);
	function setFrom(clientY) {
		const r = ref.current.getBoundingClientRect();
		const p = 1 - (clientY - r.top) / r.height;
		onChange(Math.min(1, Math.max(0, p)));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "vsl",
		ref,
		onPointerDown: (e) => {
			e.currentTarget.setPointerCapture(e.pointerId);
			setFrom(e.clientY);
		},
		onPointerMove: (e) => {
			if (e.currentTarget.hasPointerCapture(e.pointerId)) setFrom(e.clientY);
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "vsl-fill",
			style: { height: `${value * 100}%` }
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
	});
}
function Notifications({ onClose }) {
	const phone = usePhone();
	const items = [
		{
			app: "messages",
			title: phone.rtl ? "سارا نادری" : "Sara",
			body: phone.rtl ? "فردا ساعت ۱۰ همون کافه؟" : "Same café at 10?"
		},
		{
			app: "calendar",
			title: phone.rtl ? "تقویم" : "Calendar",
			body: phone.rtl ? "قرار کافه · ۱۰:۰۰" : "Café · 10:00"
		},
		{
			app: "mail",
			title: "ALI Phone",
			body: phone.rtl ? "به آیفون مجازی خوش آمدی" : "Welcome to your virtual iPhone"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "sheet notes-panel",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			onClick: (e) => e.stopPropagation(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "large",
				style: { color: "#fff" },
				children: phone.rtl ? "اعلان‌ها" : "Notifications"
			}), items.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "note-card",
				onClick: () => {
					phone.openApp(n.app);
					onClose();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: n.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: n.body })]
			}, n.title))]
		})
	});
}
function Spotlight({ onClose }) {
	const phone = usePhone();
	const [q, setQ] = (0, import_react.useState)("");
	const apps = [...Object.keys(APPS).filter((id) => available(phone.data, id)), ...phone.data.webApps.map((w) => w.id)].filter((id) => phone.nameOf(id).toLowerCase().includes(q.trim().toLowerCase()));
	const notes = phone.data.notes.filter((n) => (n.title + n.body).includes(q.trim()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "spot",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				className: "search",
				autoFocus: true,
				placeholder: phone.rtl ? "جستجو" : "Search",
				value: q,
				onChange: (e) => setQ(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "app-scroll",
				children: [apps.slice(0, 8).map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "spot-hit",
					onClick: () => {
						phone.openApp(id);
						onClose();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IosIcon, {
						id,
						now: phone.now,
						web: phone.web(id)
					}), phone.nameOf(id)]
				}, id)), q && notes.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "spot-hit",
					onClick: () => {
						phone.openApp("notes");
						onClose();
					},
					children: n.title
				}, n.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "text-btn",
				onClick: onClose,
				children: phone.rtl ? "بستن" : "Cancel"
			})
		]
	});
}
function Flash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: "20",
		height: "20",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M13 2L4 14h7l-1 8 9-12h-7l1-8z" })
	});
}
function Cam() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		width: "20",
		height: "20",
		viewBox: "0 0 24 24",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M4 8h3l2-3h6l2 3h3v11H4z" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: "12",
			cy: "13",
			r: "3.2"
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, {});
}
//#endregion
export { Home as component };
