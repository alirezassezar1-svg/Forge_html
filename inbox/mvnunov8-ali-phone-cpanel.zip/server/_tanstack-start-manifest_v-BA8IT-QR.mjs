//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BA8IT-QR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/claude/o/ocean-wolf-mist-breeze-main/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-ZAGci9Ez.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ZAGci9Ez.js"
		} }]
	},
	"/": {
		filePath: "/home/claude/o/ocean-wolf-mist-breeze-main/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CnwhVAev.js"]
	}
} });
//#endregion
export { tsrStartManifest };
