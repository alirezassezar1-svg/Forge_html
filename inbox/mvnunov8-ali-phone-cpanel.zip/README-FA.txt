نصب روی cPanel (Node.js Selector)
1) محتویات این زیپ رو توی یه پوشه مثل /home/USER/ali-phone اکسترکت کن (نه داخل public_html).
2) cPanel > Setup Node.js App > Create Application
   - Node.js version: 20 یا بالاتر (22 بهتره)
   - Application mode: Production
   - Application root: ali-phone
   - Application URL: دامنه یا ساب‌دامین
   - Application startup file: app.cjs
3) Create بزن، بعد Restart.
نیازی به npm install و دیتابیس نیست.
