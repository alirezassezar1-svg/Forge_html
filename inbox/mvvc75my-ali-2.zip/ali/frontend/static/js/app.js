const API = "/api/v1";
let currentLang = localStorage.getItem("ali_lang") || "en";

const titles = {
  en: {
    dashboard: "Dashboard", import: "Import", library: "Library",
    search: "Search", answer: "Ask", tools: "Tools", settings: "Settings"
  },
  fa: {
    dashboard: "داشبورد", import: "ورود اطلاعات", library: "کتابخانه",
    search: "جستجو", answer: "پرسش", tools: "ابزارها", settings: "تنظیمات"
  }
};

function $(sel) { return document.querySelector(sel); }
function $$(sel) { return document.querySelectorAll(sel); }

function toast(msg, type = "") {
  const el = $("#toast");
  el.textContent = msg;
  el.className = "toast " + type;
  el.classList.remove("hidden");
  setTimeout(() => el.classList.add("hidden"), 3500);
}

async function api(path, opts = {}) {
  const res = await fetch(API + path, {
    headers: { "Content-Type": "application/json", ...(opts.headers || {}) },
    ...opts,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || data.message || res.statusText);
  return data;
}

function setView(name) {
  $$(".view").forEach(v => v.classList.remove("active"));
  $$(".nav-item").forEach(n => n.classList.remove("active"));
  const view = $(`#view-${name}`);
  if (view) view.classList.add("active");
  const nav = $(`.nav-item[data-view="${name}"]`);
  if (nav) nav.classList.add("active");
  $("#view-title").textContent = titles[currentLang][name] || name;
  $("#sidebar").classList.remove("open");
  if (name === "dashboard") loadDashboard();
  if (name === "library") loadLibrary();
  if (name === "tools") loadTools();
}

function applyLang() {
  document.documentElement.lang = currentLang;
  document.documentElement.dir = currentLang === "fa" ? "rtl" : "ltr";
  localStorage.setItem("ali_lang", currentLang);
  const active = $(".nav-item.active");
  if (active) setView(active.dataset.view);
}

async function loadDashboard() {
  try {
    const health = await api("/health");
    const pill = $("#health-pill");
    pill.textContent = health.status === "ok" ? "Healthy" : "Degraded";
    pill.className = "status-pill " + (health.status === "ok" ? "ok" : "err");

    const diag = await api("/diagnostics");
    $("#m-docs").textContent = diag.counts.documents;
    $("#m-chunks").textContent = diag.counts.chunks;
    $("#m-scores").textContent = diag.counts.scores;
    $("#m-imports").textContent = diag.counts.import_history;
    $("#diag-out").textContent = JSON.stringify(diag, null, 2);
  } catch (e) {
    $("#health-pill").textContent = "Error";
    $("#health-pill").className = "status-pill err";
    $("#diag-out").textContent = String(e);
  }
}

async function loadLibrary() {
  const el = $("#lib-list");
  el.innerHTML = "<p class='meta'>Loading…</p>";
  try {
    const data = await api("/documents?limit=100");
    if (!data.documents.length) {
      el.innerHTML = "<p class='meta'>No documents yet. Import something.</p>";
      return;
    }
    el.innerHTML = data.documents.map(d => `
      <div class="list-item" data-id="${d.id}">
        <h4>${escapeHtml(d.title || "Untitled")}</h4>
        <div class="meta">
          #${d.id} · ${d.source_type} · ${d.language || "?"} · ${d.status}
          ${d.domain ? " · " + escapeHtml(d.domain) : ""}
        </div>
        <div class="actions">
          <button class="ghost btn-score" data-id="${d.id}">Score</button>
          <button class="ghost btn-del" data-id="${d.id}">Delete</button>
        </div>
        <pre class="code-block hidden score-out" id="score-${d.id}"></pre>
      </div>
    `).join("");

    el.querySelectorAll(".btn-score").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        const out = $(`#score-${id}`);
        out.classList.remove("hidden");
        out.textContent = "Scoring…";
        try {
          const s = await api(`/documents/${id}/score`);
          out.textContent = JSON.stringify(s, null, 2);
        } catch (e) { out.textContent = String(e); }
      });
    });
    el.querySelectorAll(".btn-del").forEach(btn => {
      btn.addEventListener("click", async () => {
        if (!confirm("Delete this document?")) return;
        try {
          await api(`/documents/${btn.dataset.id}`, { method: "DELETE" });
          toast("Deleted", "success");
          loadLibrary();
        } catch (e) { toast(String(e), "error"); }
      });
    });
  } catch (e) {
    el.innerHTML = `<p class="meta">${escapeHtml(String(e))}</p>`;
  }
}

async function loadTools() {
  const el = $("#tools-list");
  try {
    const data = await api("/tools");
    el.innerHTML = (data.tools || []).map(t => `
      <div class="list-item">
        <h4>${escapeHtml(t.name)} <span class="meta">(${t.tool_id} v${t.version})</span></h4>
        <div class="meta">${escapeHtml(t.description || "")} · ${t.origin} · ${t.status}</div>
      </div>
    `).join("") || "<p class='meta'>No tools registered</p>";
  } catch (e) {
    el.innerHTML = `<p class="meta">${escapeHtml(String(e))}</p>`;
  }
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Navigation
$$(".nav-item").forEach(btn => {
  btn.addEventListener("click", () => setView(btn.dataset.view));
});
$("#menu-toggle").addEventListener("click", () => {
  $("#sidebar").classList.toggle("open");
});
$("#lang-toggle").addEventListener("click", () => {
  currentLang = currentLang === "en" ? "fa" : "en";
  applyLang();
});
$("#theme-toggle").addEventListener("click", () => {
  const html = document.documentElement;
  html.dataset.theme = html.dataset.theme === "dark" ? "light" : "dark";
});

// Tabs
$$(".tab").forEach(t => {
  t.addEventListener("click", () => {
    $$(".tab").forEach(x => x.classList.remove("active"));
    $$(".tab-panel").forEach(x => x.classList.remove("active"));
    t.classList.add("active");
    $(`#tab-${t.dataset.tab}`).classList.add("active");
  });
});

// Import forms
$("#form-file").addEventListener("submit", async (e) => {
  e.preventDefault();
  const file = $("#file-input").files[0];
  if (!file) return toast("Choose a file", "error");
  const fd = new FormData();
  fd.append("file", file);
  const title = $("#file-title").value;
  if (title) fd.append("title", title);
  try {
    const res = await fetch(API + "/ingest/file", { method: "POST", body: fd });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Failed");
    showImportResult(data);
    toast("Ingested", "success");
  } catch (err) { toast(String(err), "error"); }
});

$("#form-url").addEventListener("submit", async (e) => {
  e.preventDefault();
  try {
    const data = await api("/ingest/url", {
      method: "POST",
      body: JSON.stringify({
        url: $("#url-input").value,
        title: $("#url-title").value || null,
      }),
    });
    showImportResult(data);
    toast("URL ingested", "success");
  } catch (err) { toast(String(err), "error"); }
});

$("#form-text").addEventListener("submit", async (e) => {
  e.preventDefault();
  try {
    const data = await api("/ingest/text", {
      method: "POST",
      body: JSON.stringify({
        text: $("#text-input").value,
        title: $("#text-title").value || null,
      }),
    });
    showImportResult(data);
    toast("Text ingested", "success");
  } catch (err) { toast(String(err), "error"); }
});

function showImportResult(data) {
  const el = $("#import-result");
  el.classList.remove("hidden");
  el.innerHTML = `<h2>Result</h2><pre class="code-block">${escapeHtml(JSON.stringify(data, null, 2))}</pre>`;
}

// Search
$("#form-search").addEventListener("submit", async (e) => {
  e.preventDefault();
  const q = $("#search-q").value;
  const lang = $("#search-lang").value || null;
  const el = $("#search-results");
  el.innerHTML = "<p class='meta'>Searching…</p>";
  try {
    const data = await api("/search", {
      method: "POST",
      body: JSON.stringify({ query: q, limit: 30, language: lang }),
    });
    if (!data.results.length) {
      el.innerHTML = `<p class="meta">No results for “${escapeHtml(q)}”</p>`;
      return;
    }
    el.innerHTML = `<p class="meta">${data.total} hit(s) · method: ${data.retrieval_method}</p>` +
      data.results.map(r => `
        <div class="list-item">
          <h4>${escapeHtml(r.title)}</h4>
          <div class="meta">doc #${r.document_id} · chunk #${r.chunk_id} · ${r.language || "?"} ${r.domain ? "· " + escapeHtml(r.domain) : ""}</div>
          <div class="snippet">${escapeHtml(r.snippet)}</div>
        </div>
      `).join("");
  } catch (err) {
    el.innerHTML = `<p class="meta">${escapeHtml(String(err))}</p>`;
  }
});

// Answer
$("#form-answer").addEventListener("submit", async (e) => {
  e.preventDefault();
  const q = $("#answer-q").value;
  const el = $("#answer-out");
  el.classList.remove("hidden");
  el.innerHTML = "<p class='meta'>Retrieving evidence…</p>";
  try {
    const data = await api("/answer", {
      method: "POST",
      body: JSON.stringify({ question: q, max_evidence: 8 }),
    });
    let html = `<h2>Answer</h2>
      <p><strong>Confidence:</strong> ${escapeHtml(data.confidence)}</p>
      <div class="snippet" style="white-space:pre-wrap;margin:0.75rem 0">${escapeHtml(data.answer)}</div>`;
    if (data.evidence && data.evidence.length) {
      html += "<h3>Evidence</h3>";
      data.evidence.forEach(ev => {
        html += `<div class="evidence-block">
          <div class="meta">[${ev.rank}] ${escapeHtml(ev.title)}
            ${ev.source_quality_score != null ? " · quality " + Number(ev.source_quality_score).toFixed(2) : ""}
          </div>
          <div class="snippet">${escapeHtml(ev.snippet)}</div>
        </div>`;
      });
    }
    if (data.notes && data.notes.length) {
      html += "<h3>Notes</h3><ul>" + data.notes.map(n => `<li class="meta">${escapeHtml(n)}</li>`).join("") + "</ul>";
    }
    el.innerHTML = html;
  } catch (err) {
    el.innerHTML = `<p class="meta">${escapeHtml(String(err))}</p>`;
  }
});

$("#refresh-lib").addEventListener("click", loadLibrary);
$("#btn-backup").addEventListener("click", async () => {
  try {
    const data = await api("/maintenance/backup", { method: "POST" });
    $("#settings-out").textContent = JSON.stringify(data, null, 2);
    toast("Backup created", "success");
  } catch (e) {
    toast(String(e), "error");
  }
});

// Init
applyLang();
setView("dashboard");
