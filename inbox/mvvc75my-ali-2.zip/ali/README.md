# ALI — Adaptive Learning & Intelligence

**Personal, evidence-centered knowledge engine.**

ALI ingests documents and public URLs, preserves originals, extracts and indexes text, performs full-text search, evaluates sources with explainable scores, and produces answers grounded in retrieved passages with citations.

Core workflow: **Import → Extract → Preserve → Normalize → Index → Analyze → Retrieve → Rank → Answer → Cite**

## Features implemented

- **Ingestion**: TXT, Markdown, CSV, JSON, text-based PDF, HTML, pasted text, public HTTP(S) URLs
- **Security**: SSRF protection (blocks private/loopback), size/timeout limits, safe filenames, path sanitization
- **Storage**: SQLite + FTS5, document versioning, content hashing, duplicate detection, soft delete, backup/restore
- **Search**: Keyword & phrase full-text search (Unicode / Persian-aware), filters, snippets, BM25 ranking
- **Answers**: Evidence-based retrieval with citations and explicit uncertainty when knowledge is missing
- **Source scoring**: Explainable multi-feature quality scores (author, domain type, references, length, spam heuristics, etc.)
- **UI**: Dark/light theme, English LTR + Persian RTL, responsive layout, dashboard, import, library, search, ask, tools, settings
- **Tool registry**: Built-in tools registered and queryable
- **Tests**: Automated pytest suite covering ingestion, search, Persian/English, SSRF, scoring, backup

## Not enabled by default (environment constraints)

- OCR for scanned PDFs (requires additional heavy dependencies and CPU)
- Semantic / embedding search (memory constrained; FTS5 is the primary retrieval method)
- External LLM providers (answers are retrieval-grounded without requiring paid APIs)
- Full graph relationship explorer (schema supports entities; advanced graph UI not implemented)
- Production authentication (optional token can be configured; disabled by default for local use)

## Requirements

- Python 3.10+
- ~100 MB disk for application + database growth with your documents
- Works on Linux / Windows / macOS for local use

## Quick start

```bash
cd ali
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

export PYTHONPATH=$PWD/backend
python3 -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --app-dir backend
```

Open http://127.0.0.1:8000

API docs: http://127.0.0.1:8000/api/docs

## Configuration

Copy `.env.example` to `.env` and adjust if needed. Important variables:

- `SECRET_KEY` — change in any non-local deployment
- `MAX_UPLOAD_SIZE_MB`
- `ENABLE_EMBEDDINGS` / `ENABLE_OCR` (default false)

Data lives under `data/` (uploads, originals, SQLite DB, backups, logs).

## Tests

```bash
export PYTHONPATH=$PWD/backend
python3 -m pytest tests/ -v
```

## Backup & recovery

- UI: Settings → Create Database Backup
- API: `POST /api/v1/maintenance/backup`
- Programmatic: `Database.backup()` / `Database.restore(path)`

## Architecture (high level)

```
frontend/          Responsive SPA (HTML/CSS/JS)
backend/app/
  api/             FastAPI routes
  core/            Config
  db/              SQLite + FTS5 schema & access
  ingestion/       Extractors + pipeline
  search/          Retriever
  evaluation/      Source scorer
  services/        Answer engine
  utils/           Text & security helpers
```

## Security notes

- Treat all imported content as untrusted.
- URL fetcher blocks private IP ranges and localhost.
- Original files are stored under `data/originals/` with UUID prefixes.
- Do not expose the service publicly without authentication, TLS, and hardened host configuration.
- Prompt injection in documents is treated as data, never as instructions.

## License

MIT (see LICENSE). Third-party packages retain their own licenses.

## Limitations & honesty

This is a functional local knowledge system implementing the core ALI specification. Advanced capabilities (OCR, vector embeddings, multi-user auth, full relationship graphs, CI deployment pipelines) are designed for but not fully activated in constrained environments. See the Final Delivery Report for exact coverage.
