# ALI Architecture

## Layers

1. **Frontend** (`frontend/`) — Single-page responsive UI, talks to REST API. Supports EN/FA and dark/light themes.
2. **API** (`backend/app/api/`) — FastAPI routes for health, ingest, documents, search, answer, scoring, maintenance.
3. **Services** — Answer engine composes retriever + scorer into cited responses.
4. **Search** — SQLite FTS5 with BM25 ranking and Unicode tokenizer.
5. **Ingestion** — Format extractors + pipeline (hash, version, chunk, index, score).
6. **Evaluation** — Feature-based source quality scoring with preserved weights and explanations.
7. **Database** — SQLite (WAL), schema versioning, triggers keeping FTS in sync, backup API.
8. **Security utilities** — SSRF checks, path sanitization, size/timeout limits.

## Data flow

```
Client → FastAPI → IngestionPipeline → extractors → documents + originals
                              ↓
                         chunks + FTS5 triggers
                              ↓
                    source_scores (on demand / after ingest)
Client → Search/Answer → Retriever (FTS) → AnswerEngine → citations
```

## Extensibility

- New formats: add extractor branch + supported extension.
- Alternative DB: `Database` class is the isolation boundary.
- Semantic search: set `ENABLE_EMBEDDINGS` and add embedding generation + vector store behind the same Retriever interface (not activated by default).
- Tool registry: insert rows into `tool_registry`; health checks can be extended.

## Deployment notes

- Local: `uvicorn app.main:app --app-dir backend`
- Process manager / systemd / Windows service for persistence
- GitHub Pages is **not** suitable for the Python backend or SQLite DB
- Reverse proxy (Caddy/nginx) recommended if exposing beyond localhost
