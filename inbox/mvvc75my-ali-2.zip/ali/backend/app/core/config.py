"""Application configuration with environment variable support."""

from __future__ import annotations

import os
from pathlib import Path
from typing import List, Optional

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # Application
    app_name: str = "ALI"
    app_version: str = "1.0.0"
    debug: bool = False
    secret_key: str = Field(default="change-me-in-production-use-openssl-rand-hex-32")
    api_prefix: str = "/api/v1"

    # Paths
    base_dir: Path = Path(__file__).resolve().parents[3]
    data_dir: Path = base_dir / "data"
    upload_dir: Path = data_dir / "uploads"
    original_dir: Path = data_dir / "originals"
    db_path: Path = data_dir / "ali.db"
    backup_dir: Path = data_dir / "backups"
    log_dir: Path = data_dir / "logs"

    # Limits
    max_upload_size_mb: int = 25
    max_url_content_mb: int = 10
    request_timeout_seconds: int = 30
    max_batch_files: int = 50
    fts_result_limit: int = 50
    snippet_length: int = 280

    # Security
    allowed_hosts: List[str] = ["localhost", "127.0.0.1"]
    cors_origins: List[str] = ["http://localhost:8000", "http://127.0.0.1:8000"]
    enable_auth: bool = False  # Simple token auth optional
    admin_token: Optional[str] = None

    # Ingestion
    enable_ocr: bool = False  # Disabled by default (resource heavy)
    enable_embeddings: bool = False  # Disabled by default (memory constrained)
    supported_extensions: List[str] = [
        ".txt", ".md", ".markdown", ".csv", ".json",
        ".pdf", ".html", ".htm", ".xml"
    ]

    # Source scoring weights (versioned)
    scoring_version: str = "1.0"
    scoring_weights: dict = {
        "author_identified": 0.15,
        "has_date": 0.10,
        "primary_source_signal": 0.15,
        "has_references": 0.10,
        "institutional": 0.10,
        "content_length_adequate": 0.05,
        "language_consistent": 0.05,
        "no_obvious_spam": 0.10,
        "provenance_clear": 0.10,
        "recent_or_timeless": 0.10,
    }

    def ensure_directories(self) -> None:
        for d in (self.data_dir, self.upload_dir, self.original_dir,
                  self.backup_dir, self.log_dir):
            d.mkdir(parents=True, exist_ok=True)


settings = Settings()
settings.ensure_directories()