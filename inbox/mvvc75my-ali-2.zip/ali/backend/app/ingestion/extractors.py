"""Content extractors for supported formats."""

from __future__ import annotations

import csv
import io
import json
import logging
from pathlib import Path
from typing import Optional, Tuple

from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)


def extract_text_from_bytes(
    data: bytes,
    filename: str = "",
    mime_hint: str = "",
) -> Tuple[Optional[str], Optional[str], dict]:
    """
    Extract plain text from various formats.
    Returns (text, detected_mime_or_type, metadata_dict).
    """
    ext = Path(filename).suffix.lower() if filename else ""
    meta: dict = {"filename": filename, "size": len(data)}

    # Encoding detection for text-like
    try:
        import chardet
        detected = chardet.detect(data[:10000])
        encoding = detected.get("encoding") or "utf-8"
        confidence = detected.get("confidence") or 0
        meta["encoding"] = encoding
        meta["encoding_confidence"] = confidence
    except Exception:
        encoding = "utf-8"

    # --- TXT / MD ---
    if ext in (".txt", ".md", ".markdown") or mime_hint.startswith("text/plain"):
        try:
            text = data.decode(encoding, errors="replace")
            return text, "text/plain", meta
        except Exception as e:
            return None, None, {**meta, "error": str(e)}

    # --- JSON ---
    if ext == ".json" or mime_hint == "application/json":
        try:
            obj = json.loads(data.decode(encoding, errors="replace"))
            # Pretty flatten for search
            text = json.dumps(obj, ensure_ascii=False, indent=2)
            meta["json_keys"] = list(obj.keys()) if isinstance(obj, dict) else []
            return text, "application/json", meta
        except Exception as e:
            return None, None, {**meta, "error": str(e)}

    # --- CSV ---
    if ext == ".csv" or mime_hint == "text/csv":
        try:
            text_data = data.decode(encoding, errors="replace")
            reader = csv.reader(io.StringIO(text_data))
            rows = []
            for i, row in enumerate(reader):
                rows.append(" | ".join(str(c) for c in row))
                if i > 5000:  # safety
                    rows.append("... (truncated)")
                    break
            text = "\n".join(rows)
            meta["csv_rows_approx"] = min(i + 1, 5001)
            return text, "text/csv", meta
        except Exception as e:
            return None, None, {**meta, "error": str(e)}

    # --- HTML ---
    if ext in (".html", ".htm", ".xml") or "html" in mime_hint:
        try:
            soup = BeautifulSoup(data, "html.parser")
            # Remove scripts/styles
            for tag in soup(["script", "style", "noscript", "iframe"]):
                tag.decompose()
            title = ""
            if soup.title and soup.title.string:
                title = soup.title.string.strip()
            text = soup.get_text(separator="\n", strip=True)
            meta["html_title"] = title
            return text, "text/html", meta
        except Exception as e:
            return None, None, {**meta, "error": str(e)}

    # --- PDF ---
    if ext == ".pdf" or mime_hint == "application/pdf":
        return _extract_pdf(data, meta)

    # Fallback: try decode as text
    try:
        text = data.decode(encoding, errors="replace")
        if len(text.strip()) > 20:
            return text, "text/plain", meta
    except Exception:
        pass

    return None, None, {**meta, "error": f"Unsupported or unreadable format: {ext or mime_hint}"}


def _extract_pdf(data: bytes, meta: dict) -> Tuple[Optional[str], Optional[str], dict]:
    """Extract text from PDF using pypdf (text-based PDFs)."""
    try:
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(data))
        pages = []
        for i, page in enumerate(reader.pages):
            try:
                t = page.extract_text() or ""
                if t.strip():
                    pages.append(t)
            except Exception as e:
                logger.warning("PDF page %s extract failed: %s", i, e)
            if i > 200:  # safety limit
                pages.append("... (truncated)")
                break
        text = "\n\n".join(pages)
        meta["pdf_pages"] = len(reader.pages)
        meta["pdf_encrypted"] = reader.is_encrypted
        if not text.strip():
            meta["error"] = "No extractable text (possibly scanned/image-only PDF). OCR disabled."
            return None, "application/pdf", meta
        return text, "application/pdf", meta
    except Exception as e:
        meta["error"] = f"PDF extraction failed: {e}"
        return None, "application/pdf", meta
