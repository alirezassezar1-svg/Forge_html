"""Ingestion pipeline: validate → extract → store → chunk → index → score."""

from __future__ import annotations

import json
import logging
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

from app.core.config import settings
from app.db.database import get_db
from app.ingestion.extractors import extract_text_from_bytes
from app.utils.security import fetch_url_safely, safe_filename, validate_file_extension
from app.utils.text import (
    chunk_text,
    content_hash,
    content_hash_normalized,
    detect_language_simple,
    extract_title_from_text,
    is_probably_spam_or_low_quality,
    normalize_for_search,
)
from app.evaluation.scorer import score_document

logger = logging.getLogger(__name__)


class IngestionError(Exception):
    pass


class IngestionPipeline:
    def __init__(self):
        self.db = get_db()

    def _log_import(
        self,
        source: str,
        source_type: str,
        status: str,
        document_id: Optional[int] = None,
        error: Optional[str] = None,
        meta: Optional[dict] = None,
    ) -> None:
        self.db.execute(
            """
            INSERT INTO import_history
            (source, source_type, status, document_id, error_message, finished_at, metadata_json)
            VALUES (?, ?, ?, ?, ?, datetime('now'), ?)
            """,
            (
                source[:500],
                source_type,
                status,
                document_id,
                error,
                json.dumps(meta or {}),
            ),
        )

    def ingest_file(
        self,
        file_path: Path,
        original_filename: Optional[str] = None,
        title: Optional[str] = None,
        extra_meta: Optional[dict] = None,
    ) -> Dict[str, Any]:
        """Ingest a local file. Returns result dict."""
        file_path = Path(file_path)
        original_filename = original_filename or file_path.name

        if not file_path.exists():
            raise IngestionError(f"File not found: {file_path}")

        size = file_path.stat().st_size
        if size > settings.max_upload_size_mb * 1024 * 1024:
            raise IngestionError(f"File exceeds size limit ({settings.max_upload_size_mb} MB)")

        if not validate_file_extension(original_filename):
            raise IngestionError(f"Unsupported file type: {Path(original_filename).suffix}")

        data = file_path.read_bytes()
        return self._process_content(
            data=data,
            source_type="file",
            original_filename=original_filename,
            title=title,
            source_url=None,
            extra_meta=extra_meta or {},
        )

    def ingest_bytes(
        self,
        data: bytes,
        filename: str,
        title: Optional[str] = None,
        extra_meta: Optional[dict] = None,
    ) -> Dict[str, Any]:
        if len(data) > settings.max_upload_size_mb * 1024 * 1024:
            raise IngestionError(f"Data exceeds size limit")
        if not validate_file_extension(filename):
            raise IngestionError(f"Unsupported file type")
        return self._process_content(
            data=data,
            source_type="file",
            original_filename=filename,
            title=title,
            source_url=None,
            extra_meta=extra_meta or {},
        )

    async def ingest_url(self, url: str, title: Optional[str] = None) -> Dict[str, Any]:
        data, final_url, err = await fetch_url_safely(url)
        if err or data is None:
            self._log_import(url, "url", "failed", error=err or "No content")
            raise IngestionError(err or "Failed to fetch URL")

        # Guess filename from URL
        path = urlparse(final_url or url).path
        fname = Path(path).name or "webpage.html"
        if not Path(fname).suffix:
            fname += ".html"

        return self._process_content(
            data=data,
            source_type="url",
            original_filename=fname,
            title=title,
            source_url=final_url or url,
            extra_meta={},
        )

    def ingest_text(
        self,
        text: str,
        title: Optional[str] = None,
        source_label: str = "pasted_text",
    ) -> Dict[str, Any]:
        data = text.encode("utf-8")
        return self._process_content(
            data=data,
            source_type="text",
            original_filename=f"{source_label}.txt",
            title=title or extract_title_from_text(text),
            source_url=None,
            extra_meta={"source_label": source_label},
        )

    def _process_content(
        self,
        data: bytes,
        source_type: str,
        original_filename: str,
        title: Optional[str],
        source_url: Optional[str],
        extra_meta: dict,
    ) -> Dict[str, Any]:
        # Extract
        text, mime, extract_meta = extract_text_from_bytes(data, original_filename)
        if not text or not text.strip():
            err = extract_meta.get("error") or "No extractable text"
            self._log_import(original_filename, source_type, "failed", error=err)
            raise IngestionError(err)

        text = text.strip()
        c_hash = content_hash(text)
        n_hash = content_hash_normalized(text)

        # Duplicate check
        existing = self.db.fetchone(
            "SELECT id, uuid, title, version FROM documents WHERE content_hash = ? AND is_deleted = 0",
            (c_hash,),
        )
        if existing:
            self._log_import(
                original_filename or source_url or "text",
                source_type,
                "duplicate",
                document_id=existing["id"],
                meta={"existing_uuid": existing["uuid"]},
            )
            return {
                "status": "duplicate",
                "document_id": existing["id"],
                "uuid": existing["uuid"],
                "title": existing["title"],
                "message": "Document already exists (identical content hash)",
            }

        # Also check normalized hash for near-duplicates (same content after normalize)
        near = self.db.fetchone(
            "SELECT id, uuid, title FROM documents WHERE content_hash_normalized = ? AND is_deleted = 0",
            (n_hash,),
        )
        near_dup_id = near["id"] if near else None

        lang = detect_language_simple(text)
        doc_title = title or extract_meta.get("html_title") or extract_title_from_text(text)
        domain = None
        if source_url:
            domain = urlparse(source_url).hostname

        doc_uuid = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat()

        # Preserve original
        safe_name = safe_filename(original_filename)
        orig_path = settings.original_dir / f"{doc_uuid}_{safe_name}"
        orig_path.write_bytes(data)

        meta = {
            **extract_meta,
            **extra_meta,
            "near_duplicate_of": near_dup_id,
            "char_count": len(text),
        }

        # Insert document
        with self.db.connection() as conn:
            cur = conn.execute(
                """
                INSERT INTO documents (
                    uuid, title, source_type, original_filename, mime_type,
                    language, content_hash, content_hash_normalized, file_size,
                    original_path, source_url, domain, ingested_at, updated_at,
                    version, status, metadata_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'processing', ?)
                """,
                (
                    doc_uuid, doc_title, source_type, original_filename, mime,
                    lang, c_hash, n_hash, len(data),
                    str(orig_path), source_url, domain, now, now,
                    json.dumps(meta),
                ),
            )
            doc_id = cur.lastrowid

            # Store version
            conn.execute(
                """
                INSERT INTO document_versions (document_id, version, content_hash, extracted_text)
                VALUES (?, 1, ?, ?)
                """,
                (doc_id, c_hash, text),
            )

            # Chunk and insert
            chunks = chunk_text(text)
            for idx, (chunk_content, start, end) in enumerate(chunks):
                norm = normalize_for_search(chunk_content)
                conn.execute(
                    """
                    INSERT INTO chunks (document_id, chunk_index, content, content_normalized, char_start, char_end, token_count)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (doc_id, idx, chunk_content, norm, start, end, len(chunk_content.split())),
                )

            # Mark indexed
            conn.execute(
                "UPDATE documents SET status = 'indexed', updated_at = ? WHERE id = ?",
                (datetime.now(timezone.utc).isoformat(), doc_id),
            )

        # Score
        try:
            score_document(doc_id)
        except Exception as e:
            logger.warning("Scoring failed for doc %s: %s", doc_id, e)

        self._log_import(
            original_filename or source_url or "text",
            source_type,
            "success",
            document_id=doc_id,
            meta={"uuid": doc_uuid, "chunks": len(chunks)},
        )

        return {
            "status": "success",
            "document_id": doc_id,
            "uuid": doc_uuid,
            "title": doc_title,
            "language": lang,
            "chunks": len(chunks),
            "char_count": len(text),
            "source_type": source_type,
            "mime_type": mime,
            "near_duplicate_of": near_dup_id,
        }

    def delete_document(self, doc_id: int, hard: bool = False) -> bool:
        """Soft-delete by default. Hard delete removes original file too."""
        doc = self.db.fetchone(
            "SELECT id, original_path, is_deleted FROM documents WHERE id = ?",
            (doc_id,),
        )
        if not doc:
            return False
        if hard:
            # Remove original
            if doc["original_path"]:
                p = Path(doc["original_path"])
                if p.exists():
                    p.unlink()
            self.db.execute("DELETE FROM documents WHERE id = ?", (doc_id,))
        else:
            self.db.execute(
                "UPDATE documents SET is_deleted = 1, updated_at = ? WHERE id = ?",
                (datetime.now(timezone.utc).isoformat(), doc_id),
            )
        return True
