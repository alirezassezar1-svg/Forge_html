"""Database connection, migrations, and integrity helpers."""

from __future__ import annotations

import json
import shutil
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Generator, Optional

from app.core.config import settings
from app.db.schema import SCHEMA_SQL, SCHEMA_VERSION


class Database:
    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = Path(db_path or settings.db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(
            str(self.db_path),
            detect_types=sqlite3.PARSE_DECLTYPES,
            check_same_thread=False,
            timeout=30.0,
        )
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    @contextmanager
    def connection(self) -> Generator[sqlite3.Connection, None, None]:
        conn = self._connect()
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_db(self) -> None:
        with self.connection() as conn:
            current = self._get_schema_version(conn)
            if current < SCHEMA_VERSION:
                conn.executescript(SCHEMA_SQL)
                conn.execute(
                    "INSERT OR REPLACE INTO schema_version(version) VALUES (?)",
                    (SCHEMA_VERSION,),
                )
                conn.commit()

    def _get_schema_version(self, conn: sqlite3.Connection) -> int:
        try:
            row = conn.execute(
                "SELECT version FROM schema_version ORDER BY version DESC LIMIT 1"
            ).fetchone()
            return int(row["version"]) if row else 0
        except sqlite3.OperationalError:
            return 0

    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        with self.connection() as conn:
            return conn.execute(sql, params)

    def executemany(self, sql: str, seq: list) -> None:
        with self.connection() as conn:
            conn.executemany(sql, seq)

    def fetchone(self, sql: str, params: tuple = ()) -> Optional[dict]:
        with self.connection() as conn:
            row = conn.execute(sql, params).fetchone()
            return dict(row) if row else None

    def fetchall(self, sql: str, params: tuple = ()) -> list[dict]:
        with self.connection() as conn:
            rows = conn.execute(sql, params).fetchall()
            return [dict(r) for r in rows]

    def integrity_check(self) -> dict:
        with self.connection() as conn:
            result = conn.execute("PRAGMA integrity_check").fetchone()
            return {"ok": result[0] == "ok", "message": result[0]}

    def backup(self, dest: Optional[Path] = None) -> Path:
        dest = Path(dest or settings.backup_dir / f"ali_backup_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.db")
        dest.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as conn:
            # Use SQLite backup API
            dest_conn = sqlite3.connect(str(dest))
            try:
                conn.backup(dest_conn)
            finally:
                dest_conn.close()
        if not dest.exists() or dest.stat().st_size == 0:
            raise RuntimeError("Backup failed: destination file missing or empty")
        return dest

    def restore(self, backup_path: Path) -> None:
        backup_path = Path(backup_path)
        if not backup_path.exists():
            raise FileNotFoundError(f"Backup not found: {backup_path}")
        # Close any open connections by replacing file
        tmp = self.db_path.with_suffix(".restore_tmp")
        shutil.copy2(backup_path, tmp)
        if self.db_path.exists():
            self.db_path.unlink()
        tmp.rename(self.db_path)
        self._init_db()  # ensure schema triggers etc.

    def vacuum(self) -> None:
        with self.connection() as conn:
            conn.execute("VACUUM")


# Singleton-style access
_db: Optional[Database] = None


def get_db() -> Database:
    global _db
    if _db is None:
        _db = Database()
    return _db
