"""FastAPI routes for ALI."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from app.core.config import settings
from app.db.database import get_db
from app.evaluation.scorer import get_score, score_document
from app.ingestion.pipeline import IngestionError, IngestionPipeline
from app.search.retriever import Retriever
from app.services.answer_engine import AnswerEngine

logger = logging.getLogger(__name__)
router = APIRouter()


# ---------- Request / Response models ----------

class TextIngestRequest(BaseModel):
    text: str = Field(..., min_length=1)
    title: Optional[str] = None


class UrlIngestRequest(BaseModel):
    url: str = Field(..., min_length=8)
    title: Optional[str] = None


class SearchRequest(BaseModel):
    query: str
    limit: int = 20
    offset: int = 0
    language: Optional[str] = None
    source_type: Optional[str] = None


class AnswerRequest(BaseModel):
    question: str
    max_evidence: int = 8
    language: Optional[str] = None


# ---------- Health & diagnostics ----------

@router.get("/health")
def health():
    db = get_db()
    integrity = db.integrity_check()
    return {
        "status": "ok" if integrity["ok"] else "degraded",
        "app": settings.app_name,
        "version": settings.app_version,
        "db_integrity": integrity,
        "embeddings_enabled": settings.enable_embeddings,
        "ocr_enabled": settings.enable_ocr,
    }


@router.get("/diagnostics")
def diagnostics():
    db = get_db()
    counts = {
        "documents": db.fetchone("SELECT COUNT(*) AS c FROM documents WHERE is_deleted=0")["c"],
        "chunks": db.fetchone("SELECT COUNT(*) AS c FROM chunks")["c"],
        "scores": db.fetchone("SELECT COUNT(*) AS c FROM source_scores")["c"],
        "import_history": db.fetchone("SELECT COUNT(*) AS c FROM import_history")["c"],
    }
    return {
        "counts": counts,
        "db_path": str(settings.db_path),
        "data_dir": str(settings.data_dir),
        "settings": {
            "max_upload_mb": settings.max_upload_size_mb,
            "enable_embeddings": settings.enable_embeddings,
            "enable_ocr": settings.enable_ocr,
            "scoring_version": settings.scoring_version,
        },
    }


# ---------- Ingestion ----------

@router.post("/ingest/text")
def ingest_text(body: TextIngestRequest):
    pipe = IngestionPipeline()
    try:
        result = pipe.ingest_text(body.text, title=body.title)
        return result
    except IngestionError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/ingest/url")
async def ingest_url(body: UrlIngestRequest):
    pipe = IngestionPipeline()
    try:
        result = await pipe.ingest_url(body.url, title=body.title)
        return result
    except IngestionError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/ingest/file")
async def ingest_file(
    file: UploadFile = File(...),
    title: Optional[str] = Form(None),
):
    if not file.filename:
        raise HTTPException(400, "Missing filename")
    data = await file.read()
    if len(data) > settings.max_upload_size_mb * 1024 * 1024:
        raise HTTPException(400, f"File too large (max {settings.max_upload_size_mb} MB)")
    pipe = IngestionPipeline()
    try:
        result = pipe.ingest_bytes(data, filename=file.filename, title=title)
        return result
    except IngestionError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/ingest/history")
def ingest_history(limit: int = Query(50, ge=1, le=200)):
    db = get_db()
    rows = db.fetchall(
        "SELECT * FROM import_history ORDER BY started_at DESC LIMIT ?",
        (limit,),
    )
    return {"history": rows}


# ---------- Documents ----------

@router.get("/documents")
def list_documents(
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    language: Optional[str] = None,
    status: Optional[str] = None,
):
    ret = Retriever()
    return ret.list_documents(limit=limit, offset=offset, language=language, status=status)


@router.get("/documents/{doc_id}")
def get_document(doc_id: int):
    ret = Retriever()
    doc = ret.get_document(doc_id)
    if not doc:
        raise HTTPException(404, "Document not found")
    # Hide internal path from response for safety
    doc.pop("original_path", None)
    return doc


@router.delete("/documents/{doc_id}")
def delete_document(doc_id: int, hard: bool = Query(False)):
    pipe = IngestionPipeline()
    ok = pipe.delete_document(doc_id, hard=hard)
    if not ok:
        raise HTTPException(404, "Document not found")
    return {"status": "deleted", "document_id": doc_id, "hard": hard}


# ---------- Search ----------

@router.post("/search")
def search(body: SearchRequest):
    ret = Retriever()
    return ret.search(
        query=body.query,
        limit=body.limit,
        offset=body.offset,
        language=body.language,
        source_type=body.source_type,
    )


@router.get("/search")
def search_get(
    q: str = Query(..., min_length=1),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    language: Optional[str] = None,
    source_type: Optional[str] = None,
):
    ret = Retriever()
    return ret.search(q, limit=limit, offset=offset, language=language, source_type=source_type)


# ---------- Answers ----------

@router.post("/answer")
def answer(body: AnswerRequest):
    engine = AnswerEngine()
    return engine.answer(body.question, max_evidence=body.max_evidence, language=body.language)


# ---------- Source evaluation ----------

@router.get("/documents/{doc_id}/score")
def document_score(doc_id: int, rescore: bool = Query(False)):
    if rescore:
        try:
            return score_document(doc_id)
        except ValueError as e:
            raise HTTPException(404, str(e))
    score = get_score(doc_id)
    if not score:
        # compute on demand
        try:
            return score_document(doc_id)
        except ValueError as e:
            raise HTTPException(404, str(e))
    return score


# ---------- Maintenance ----------

@router.post("/maintenance/backup")
def create_backup():
    db = get_db()
    path = db.backup()
    return {"status": "ok", "backup_path": str(path)}


@router.get("/maintenance/integrity")
def check_integrity():
    return get_db().integrity_check()


@router.get("/tools")
def list_tools():
    db = get_db()
    rows = db.fetchall("SELECT tool_id, version, name, description, origin, status FROM tool_registry ORDER BY tool_id")
    return {"tools": rows}
