"""Text normalization, hashing, language heuristics, chunking."""

from __future__ import annotations

import hashlib
import re
import unicodedata
from typing import List, Optional, Tuple


# Persian / Arabic character normalization map (common variants)
PERSIAN_ARABIC_MAP = str.maketrans({
    "ك": "ک",
    "ي": "ی",
    "ى": "ی",
    "ة": "ه",
    "ؤ": "و",
    "إ": "ا",
    "أ": "ا",
    "آ": "ا",
    "ۀ": "ه",
    "‌": " ",  # ZWNJ -> space for search
})


def normalize_for_search(text: str) -> str:
    """Produce a searchable normalized form without destroying original."""
    if not text:
        return ""
    # Unicode normalize
    t = unicodedata.normalize("NFKC", text)
    # Persian/Arabic variants
    t = t.translate(PERSIAN_ARABIC_MAP)
    # Collapse whitespace
    t = re.sub(r"\s+", " ", t).strip().lower()
    return t


def content_hash(text: str) -> str:
    """SHA-256 of original text (utf-8)."""
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()


def content_hash_normalized(text: str) -> str:
    return content_hash(normalize_for_search(text))


def detect_language_simple(text: str) -> str:
    """Very lightweight heuristic. Returns 'fa', 'en', or 'unknown'."""
    if not text or len(text.strip()) < 20:
        return "unknown"
    sample = text[:2000]
    # Count Persian/Arabic letters vs Latin
    persian_re = re.compile(r"[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]")
    latin_re = re.compile(r"[a-zA-Z]")
    p_count = len(persian_re.findall(sample))
    l_count = len(latin_re.findall(sample))
    total = p_count + l_count
    if total == 0:
        return "unknown"
    if p_count / total > 0.4:
        return "fa"
    if l_count / total > 0.5:
        return "en"
    return "unknown"


def chunk_text(
    text: str,
    max_chars: int = 1200,
    overlap: int = 150,
) -> List[Tuple[str, int, int]]:
    """
    Split text into overlapping chunks.
    Returns list of (chunk_text, char_start, char_end).
    """
    if not text:
        return []
    text = text.strip()
    if len(text) <= max_chars:
        return [(text, 0, len(text))]

    chunks: List[Tuple[str, int, int]] = []
    start = 0
    length = len(text)
    while start < length:
        end = min(start + max_chars, length)
        # Prefer break at paragraph or sentence
        if end < length:
            for sep in ("\n\n", "\n", ". ", "؟ ", "! ", " "):
                pos = text.rfind(sep, start + max_chars // 2, end)
                if pos != -1:
                    end = pos + len(sep)
                    break
        chunk = text[start:end].strip()
        if chunk:
            chunks.append((chunk, start, end))
        if end >= length:
            break
        start = max(start + 1, end - overlap)
    return chunks


def extract_title_from_text(text: str, fallback: str = "Untitled") -> str:
    """Take first non-empty line as title candidate."""
    for line in text.splitlines()[:10]:
        line = line.strip()
        if 5 < len(line) < 200:
            return line[:180]
    return fallback


def is_probably_spam_or_low_quality(text: str) -> bool:
    """Simple heuristics for low-quality content."""
    if not text or len(text.strip()) < 40:
        return True
    # Too many repeated characters
    if re.search(r"(.)\1{8,}", text):
        return True
    # Excessive URLs relative to length
    urls = re.findall(r"https?://\S+", text)
    if len(urls) > 15 and len(text) < 2000:
        return True
    return False
