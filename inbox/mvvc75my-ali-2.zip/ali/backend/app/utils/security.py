"""Security helpers: SSRF protection, path safety, sanitization."""

from __future__ import annotations

import ipaddress
import re
import socket
from pathlib import Path
from typing import Optional, Tuple
from urllib.parse import urlparse, urljoin

import httpx

from app.core.config import settings


# Blocked networks
PRIVATE_NETWORKS = [
    ipaddress.ip_network("0.0.0.0/8"),
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
]


def is_safe_url(url: str) -> Tuple[bool, str]:
    """
    Validate URL for ingestion. Blocks private/loopback, non-http(s), etc.
    Returns (ok, reason).
    """
    try:
        parsed = urlparse(url)
    except Exception as e:
        return False, f"Invalid URL: {e}"

    if parsed.scheme not in ("http", "https"):
        return False, "Only http and https schemes are allowed"

    if not parsed.hostname:
        return False, "Missing hostname"

    hostname = parsed.hostname.lower()

    # Block obvious local names
    if hostname in ("localhost", "localhost.localdomain", "ip6-localhost"):
        return False, "Localhost is not allowed"

    # Resolve and check IP
    try:
        infos = socket.getaddrinfo(hostname, None)
        for info in infos:
            ip_str = info[4][0]
            try:
                ip = ipaddress.ip_address(ip_str)
                for net in PRIVATE_NETWORKS:
                    if ip in net:
                        return False, f"Private or reserved IP not allowed: {ip}"
            except ValueError:
                continue
    except socket.gaierror:
        return False, "DNS resolution failed"
    except Exception as e:
        return False, f"Host resolution error: {e}"

    return True, "ok"


def safe_filename(name: str) -> str:
    """Sanitize a filename for storage."""
    name = Path(name).name  # drop any path components
    name = re.sub(r"[^\w\s\-\.\(\)\[\]\u0600-\u06FF]", "_", name)
    name = re.sub(r"\s+", "_", name).strip("._")
    if not name:
        name = "unnamed"
    return name[:200]


def validate_file_extension(filename: str) -> bool:
    ext = Path(filename).suffix.lower()
    return ext in settings.supported_extensions


async def fetch_url_safely(
    url: str,
    timeout: float = None,
    max_bytes: int = None,
) -> Tuple[Optional[bytes], Optional[str], Optional[str]]:
    """
    Fetch URL with SSRF protection, size limit, timeout.
    Returns (content_bytes, final_url, error_message).
    """
    timeout = timeout or settings.request_timeout_seconds
    max_bytes = max_bytes or (settings.max_url_content_mb * 1024 * 1024)

    ok, reason = is_safe_url(url)
    if not ok:
        return None, None, reason

    headers = {
        "User-Agent": "ALI-KnowledgeEngine/1.0 (personal research; +local)",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,text/plain;q=0.8,*/*;q=0.7",
    }

    try:
        async with httpx.AsyncClient(
            follow_redirects=True,
            max_redirects=5,
            timeout=timeout,
            headers=headers,
        ) as client:
            # Re-validate after redirects would be ideal; we do basic check
            resp = await client.get(url)
            final_url = str(resp.url)

            # Re-check final destination
            ok2, reason2 = is_safe_url(final_url)
            if not ok2:
                return None, final_url, f"Redirect target blocked: {reason2}"

            content = resp.content
            if len(content) > max_bytes:
                return None, final_url, f"Content exceeds size limit ({max_bytes} bytes)"

            if resp.status_code >= 400:
                return None, final_url, f"HTTP {resp.status_code}"

            return content, final_url, None
    except httpx.TimeoutException:
        return None, None, "Request timed out"
    except httpx.RequestError as e:
        return None, None, f"Request error: {e}"
    except Exception as e:
        return None, None, f"Unexpected fetch error: {e}"


def escape_html(text: str) -> str:
    """Minimal HTML escaping for safe display."""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )
