"""ALI - Adaptive Learning & Intelligence Core Package."""

__version__ = "1.0.0"
__description__ = "Personal Evidence-Centered Knowledge Engine"