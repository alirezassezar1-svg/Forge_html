"""Explainable source quality scoring (feature-based, no trained ML)."""

from __future__ import annotations

import json
import re
from datetime import datetime
from typing import Any, Dict, Optional
from urllib.parse import urlparse

from app.core.config import settings
from app.db.database import get_db
from app.utils.text import is_probably_spam_or_low_quality


# Feature definitions (compact, auditable)
FEATURE_DEFS = {
    "author_identified": "Author or responsible organization name present in metadata or content signals",
    "has_date": "Publication or last-modified date is present",
    "primary_source_signal": "Signals of primary source (official domain, original research language, data tables)",
    "has_references": "Contains citations, footnotes, or reference lists",
    "institutional": "Domain or metadata indicates known institution, university, government, or publisher",
    "content_length_adequate": "Extracted text length is sufficient for meaningful analysis (>300 chars)",
    "language_consistent": "Detected language is consistent and supported (en/fa)",
    "no_obvious_spam": "Does not match simple spam / low-quality heuristics",
    "provenance_clear": "Clear source URL or file origin is recorded",
    "recent_or_timeless": "Either has a recent date or content appears timeless (no date required)",
}


def _bool_score(val: bool) -> float:
    return 1.0 if val else 0.0


def compute_features(doc: dict, text: Optional[str] = None) -> Dict[str, Any]:
    """Compute measurable features from available data. Unknowns stay None."""
    meta = {}
    if doc.get("metadata_json"):
        try:
            meta = json.loads(doc["metadata_json"])
        except Exception:
            pass

    features: Dict[str, Any] = {k: None for k in FEATURE_DEFS}

    # author_identified
    author = doc.get("author") or meta.get("author")
    features["author_identified"] = bool(author and len(str(author).strip()) > 1)

    # has_date
    features["has_date"] = bool(doc.get("published_at") or meta.get("date") or meta.get("published_at"))

    # primary_source_signal (heuristic)
    domain = (doc.get("domain") or "").lower()
    primary_hints = (
        domain.endswith(".gov") or domain.endswith(".edu") or domain.endswith(".ac.ir")
        or domain.endswith(".gov.ir") or "wikipedia.org" in domain
        or bool(re.search(r"\b(official|primary|original research|dataset)\b", (text or "")[:2000], re.I))
    )
    features["primary_source_signal"] = primary_hints

    # has_references
    if text:
        ref_patterns = [
            r"\[\d+\]", r"\(\d{4}\)", r"et al\.", r"doi:", r"https?://doi\.org",
            r"references?\s*\n", r"bibliography", r"منابع", r"مراجع",
        ]
        features["has_references"] = any(re.search(p, text[:15000], re.I) for p in ref_patterns)
    else:
        features["has_references"] = None

    # institutional
    inst_tlds = (".edu", ".gov", ".ac.ir", ".gov.ir", ".org", ".int")
    features["institutional"] = any(domain.endswith(t) for t in inst_tlds) if domain else False

    # content_length_adequate
    char_count = meta.get("char_count") or (len(text) if text else 0)
    features["content_length_adequate"] = char_count >= 300

    # language_consistent
    lang = doc.get("language")
    features["language_consistent"] = lang in ("en", "fa")

    # no_obvious_spam
    if text:
        features["no_obvious_spam"] = not is_probably_spam_or_low_quality(text)
    else:
        features["no_obvious_spam"] = None

    # provenance_clear
    features["provenance_clear"] = bool(doc.get("source_url") or doc.get("original_path") or doc.get("source_type") == "text")

    # recent_or_timeless
    if features["has_date"]:
        features["recent_or_timeless"] = True  # we don't parse dates strictly here
    else:
        # Treat undated content as potentially timeless
        features["recent_or_timeless"] = True

    return features


def score_from_features(features: Dict[str, Any]) -> tuple[float, str]:
    """Weighted average of known features. Returns (score 0-1, explanation)."""
    weights = settings.scoring_weights
    total_w = 0.0
    weighted = 0.0
    parts = []

    for name, weight in weights.items():
        val = features.get(name)
        if val is None:
            parts.append(f"{name}: unknown")
            continue
        score = _bool_score(bool(val))
        weighted += score * weight
        total_w += weight
        parts.append(f"{name}: {score:.0f} (w={weight})")

    overall = (weighted / total_w) if total_w > 0 else 0.0
    explanation = (
        f"Scoring version {settings.scoring_version}. "
        f"Overall {overall:.2f} from {len([p for p in parts if 'unknown' not in p])} known features. "
        + "; ".join(parts)
    )
    return overall, explanation


def score_document(document_id: int) -> Dict[str, Any]:
    """Compute and store source score for a document."""
    db = get_db()
    doc = db.fetchone(
        "SELECT * FROM documents WHERE id = ? AND is_deleted = 0",
        (document_id,),
    )
    if not doc:
        raise ValueError(f"Document {document_id} not found")

    # Get text from first version or chunks
    ver = db.fetchone(
        "SELECT extracted_text FROM document_versions WHERE document_id = ? ORDER BY version DESC LIMIT 1",
        (document_id,),
    )
    text = ver["extracted_text"] if ver else None
    if not text:
        chunks = db.fetchall(
            "SELECT content FROM chunks WHERE document_id = ? ORDER BY chunk_index LIMIT 5",
            (document_id,),
        )
        text = "\n".join(c["content"] for c in chunks)

    features = compute_features(doc, text)
    overall, explanation = score_from_features(features)

    # Store
    db.execute(
        """
        INSERT INTO source_scores (document_id, scoring_version, overall_score, feature_values_json, feature_weights_json, explanation)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(document_id) DO UPDATE SET
            scoring_version = excluded.scoring_version,
            overall_score = excluded.overall_score,
            feature_values_json = excluded.feature_values_json,
            feature_weights_json = excluded.feature_weights_json,
            explanation = excluded.explanation,
            scored_at = datetime('now')
        """,
        (
            document_id,
            settings.scoring_version,
            overall,
            json.dumps(features),
            json.dumps(settings.scoring_weights),
            explanation,
        ),
    )

    return {
        "document_id": document_id,
        "overall_score": overall,
        "features": features,
        "explanation": explanation,
        "scoring_version": settings.scoring_version,
    }


def get_score(document_id: int) -> Optional[Dict[str, Any]]:
    db = get_db()
    row = db.fetchone(
        "SELECT * FROM source_scores WHERE document_id = ?",
        (document_id,),
    )
    if not row:
        return None
    return {
        "document_id": document_id,
        "overall_score": row["overall_score"],
        "features": json.loads(row["feature_values_json"]),
        "weights": json.loads(row["feature_weights_json"]),
        "explanation": row["explanation"],
        "scoring_version": row["scoring_version"],
        "scored_at": row["scored_at"],
        "feature_definitions": FEATURE_DEFS,
    }
