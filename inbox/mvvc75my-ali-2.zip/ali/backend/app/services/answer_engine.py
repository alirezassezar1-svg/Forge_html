"""Evidence-based answer engine. Retrieval + structured response. No invented citations."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from app.search.retriever import Retriever
from app.evaluation.scorer import get_score


class AnswerEngine:
    def __init__(self):
        self.retriever = Retriever()

    def answer(
        self,
        question: str,
        max_evidence: int = 8,
        language: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Produce a concise answer grounded in retrieved evidence.
        Distinguishes sourced facts from absence of evidence.
        """
        if not question or not question.strip():
            return {
                "question": question,
                "answer": "Please provide a question.",
                "confidence": "none",
                "evidence": [],
                "citations": [],
                "notes": [],
            }

        search = self.retriever.search(question, limit=max_evidence, language=language)
        results = search.get("results") or []

        if not results:
            return {
                "question": question,
                "answer": "No relevant information was found in the current knowledge base for this query.",
                "confidence": "none",
                "evidence": [],
                "citations": [],
                "notes": [
                    "This does not mean the statement is false; it means the knowledge base currently lacks supporting passages.",
                    "Try different keywords, import additional sources, or broaden the query.",
                ],
                "retrieval": {
                    "method": search.get("retrieval_method"),
                    "total_hits": 0,
                },
            }

        # Build evidence list with scores
        evidence = []
        citations = []
        for i, r in enumerate(results, 1):
            score_info = get_score(r["document_id"])
            overall = score_info["overall_score"] if score_info else None
            evidence.append({
                "rank": i,
                "chunk_id": r["chunk_id"],
                "document_id": r["document_id"],
                "title": r["title"],
                "snippet": r["snippet"],
                "source_url": r.get("source_url"),
                "domain": r.get("domain"),
                "language": r.get("language"),
                "source_quality_score": overall,
            })
            citations.append({
                "id": i,
                "document_id": r["document_id"],
                "title": r["title"],
                "chunk_id": r["chunk_id"],
                "url": r.get("source_url"),
            })

        # Simple synthesis: present top evidence clearly (no LLM required for basic mode)
        answer_parts = [
            f"Based on {len(evidence)} relevant passage(s) in the knowledge base:"
        ]
        for e in evidence[:5]:
            cite = f"[{e['rank']}]"
            answer_parts.append(f"\n{cite} {e['snippet']}")

        notes = [
            "Answers are derived solely from indexed content. The system does not independently verify real-world truth.",
            "Source quality scores reflect measurable features (author, domain type, references, etc.), not ground truth.",
        ]
        if any(e.get("source_quality_score") is not None and e["source_quality_score"] < 0.4 for e in evidence):
            notes.append("Some supporting sources have relatively low quality scores; treat them with caution.")

        # Detect possible contradiction heuristic (very light)
        # (Full contradiction detection would require deeper NLP)
        notes.append("If sources appear to conflict, examine the original passages and publication dates.")

        return {
            "question": question,
            "answer": "\n".join(answer_parts),
            "confidence": "low_to_medium" if len(evidence) < 3 else "medium",
            "evidence": evidence,
            "citations": citations,
            "notes": notes,
            "retrieval": {
                "method": search.get("retrieval_method"),
                "total_hits": search.get("total"),
                "semantic_enabled": search.get("semantic_enabled", False),
            },
        }
