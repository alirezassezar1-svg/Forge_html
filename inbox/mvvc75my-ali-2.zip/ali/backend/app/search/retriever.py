"""Full-text search and evidence retrieval using SQLite FTS5."""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from app.core.config import settings
from app.db.database import get_db
from app.utils.text import normalize_for_search


class Retriever:
    def __init__(self):
        self.db = get_db()

    def search(
        self,
        query: str,
        limit: int = None,
        offset: int = 0,
        language: Optional[str] = None,
        source_type: Optional[str] = None,
        document_id: Optional[int] = None,
    ) -> Dict[str, Any]:
        limit = limit or settings.fts_result_limit
        if not query or not query.strip():
            return {"query": query, "total": 0, "results": [], "message": "Empty query"}

        # Prepare FTS query: simple phrase + keyword support
        fts_query = self._prepare_fts_query(query)

        params: list = []
        filters = ["d.is_deleted = 0"]
        if language:
            filters.append("d.language = ?")
            params.append(language)
        if source_type:
            filters.append("d.source_type = ?")
            params.append(source_type)
        if document_id:
            filters.append("d.id = ?")
            params.append(document_id)

        filter_sql = " AND ".join(filters)

        # Count
        count_sql = f"""
            SELECT COUNT(*) AS cnt
            FROM chunks_fts f
            JOIN documents d ON d.id = f.document_id
            WHERE chunks_fts MATCH ? AND {filter_sql}
        """
        count_row = self.db.fetchone(count_sql, (fts_query, *params))
        total = count_row["cnt"] if count_row else 0

        # Results with ranking (bm25)
        sql = f"""
            SELECT
                f.chunk_id,
                f.document_id,
                f.content,
                f.title,
                f.language AS chunk_lang,
                d.uuid AS doc_uuid,
                d.title AS doc_title,
                d.source_type,
                d.source_url,
                d.domain,
                d.language AS doc_lang,
                d.ingested_at,
                bm25(chunks_fts) AS rank
            FROM chunks_fts f
            JOIN documents d ON d.id = f.document_id
            WHERE chunks_fts MATCH ? AND {filter_sql}
            ORDER BY rank
            LIMIT ? OFFSET ?
        """
        rows = self.db.fetchall(sql, (fts_query, *params, limit, offset))

        results = []
        seen_content = set()
        for r in rows:
            # Simple dedup by normalized snippet start
            snip_key = normalize_for_search(r["content"][:120])
            if snip_key in seen_content:
                continue
            seen_content.add(snip_key)

            snippet = self._make_snippet(r["content"], query)
            results.append({
                "chunk_id": r["chunk_id"],
                "document_id": r["document_id"],
                "doc_uuid": r["doc_uuid"],
                "title": r["doc_title"] or r["title"] or "Untitled",
                "snippet": snippet,
                "source_type": r["source_type"],
                "source_url": r["source_url"],
                "domain": r["domain"],
                "language": r["doc_lang"] or r["chunk_lang"],
                "ingested_at": r["ingested_at"],
                "rank": r["rank"],
            })

        return {
            "query": query,
            "fts_query": fts_query,
            "total": total,
            "offset": offset,
            "limit": limit,
            "results": results,
            "retrieval_method": "fts5_bm25",
            "semantic_enabled": settings.enable_embeddings,
        }

    def get_document(self, doc_id: int) -> Optional[Dict[str, Any]]:
        doc = self.db.fetchone(
            "SELECT * FROM documents WHERE id = ? AND is_deleted = 0",
            (doc_id,),
        )
        if not doc:
            return None
        chunks = self.db.fetchall(
            "SELECT id, chunk_index, content, char_start, char_end FROM chunks WHERE document_id = ? ORDER BY chunk_index",
            (doc_id,),
        )
        score = self.db.fetchone(
            "SELECT overall_score, explanation, scoring_version FROM source_scores WHERE document_id = ?",
            (doc_id,),
        )
        return {
            **doc,
            "chunks": chunks,
            "score": dict(score) if score else None,
        }

    def get_chunk(self, chunk_id: int) -> Optional[Dict[str, Any]]:
        return self.db.fetchone(
            """
            SELECT c.*, d.uuid AS doc_uuid, d.title AS doc_title, d.source_url, d.source_type
            FROM chunks c
            JOIN documents d ON d.id = c.document_id
            WHERE c.id = ? AND d.is_deleted = 0
            """,
            (chunk_id,),
        )

    def list_documents(
        self,
        limit: int = 50,
        offset: int = 0,
        status: Optional[str] = None,
        language: Optional[str] = None,
    ) -> Dict[str, Any]:
        filters = ["is_deleted = 0"]
        params: list = []
        if status:
            filters.append("status = ?")
            params.append(status)
        if language:
            filters.append("language = ?")
            params.append(language)
        where = " AND ".join(filters)
        total_row = self.db.fetchone(f"SELECT COUNT(*) AS cnt FROM documents WHERE {where}", tuple(params))
        rows = self.db.fetchall(
            f"""
            SELECT id, uuid, title, source_type, language, domain, source_url,
                   status, ingested_at, version, file_size
            FROM documents WHERE {where}
            ORDER BY ingested_at DESC
            LIMIT ? OFFSET ?
            """,
            (*params, limit, offset),
        )
        return {"total": total_row["cnt"] if total_row else 0, "documents": rows}

    def _prepare_fts_query(self, query: str) -> str:
        """Convert user query to FTS5 syntax. Supports phrases in quotes."""
        query = query.strip()
        # Strip characters that break FTS5 MATCH (e.g. ? ! ; etc.)
        cleaned = re.sub(r"[^\w\s\u0600-\u06FF\"\*]", " ", query)
        cleaned = re.sub(r"\s+", " ", cleaned).strip()
        if not cleaned:
            return '""'

        terms = []
        phrases = re.findall(r'"([^"]+)"', cleaned)
        remainder = re.sub(r'"[^"]+"', " ", cleaned)
        for p in phrases:
            p = p.strip()
            if p:
                terms.append(f'"{p}"')
        for t in remainder.split():
            t = re.sub(r'["*]', "", t.strip())
            if t:
                terms.append(t)
        if not terms:
            return '""'
        return " AND ".join(terms)

    def _make_snippet(self, content: str, query: str, max_len: int = None) -> str:
        max_len = max_len or settings.snippet_length
        content = content.strip()
        if len(content) <= max_len:
            return content
        # Try to center on first query term
        terms = re.findall(r"\w+", query.lower())
        lower = content.lower()
        pos = 0
        for t in terms:
            idx = lower.find(t)
            if idx != -1:
                pos = max(0, idx - max_len // 3)
                break
        snippet = content[pos : pos + max_len]
        if pos > 0:
            snippet = "…" + snippet
        if pos + max_len < len(content):
            snippet = snippet + "…"
        return snippet
