"""ALI FastAPI application entrypoint."""

from __future__ import annotations

import logging
import sys
from pathlib import Path

# Ensure package root is importable
ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from app.api.routes import router
from app.core.config import settings
from app.db.database import get_db

logging.basicConfig(
    level=logging.DEBUG if settings.debug else logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("ali")

app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="Adaptive Learning & Intelligence — Personal Evidence-Centered Knowledge Engine",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins + ["*"] if settings.debug else settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router, prefix=settings.api_prefix)

# Frontend static
FRONTEND_DIR = settings.base_dir / "frontend"
STATIC_DIR = FRONTEND_DIR / "static"
if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.on_event("startup")
def on_startup():
    settings.ensure_directories()
    db = get_db()
    integrity = db.integrity_check()
    logger.info("ALI started. DB integrity: %s", integrity)
    # Register core tools
    _register_builtin_tools(db)


def _register_builtin_tools(db):
    tools = [
        ("ingest.file", "1.0", "File Ingestion", "Ingest local files (txt,md,csv,json,pdf,html)", "internal"),
        ("ingest.url", "1.0", "URL Ingestion", "Fetch and ingest public HTTP(S) pages with SSRF protection", "internal"),
        ("search.fts", "1.0", "Full-Text Search", "SQLite FTS5 keyword and phrase search", "internal"),
        ("answer.evidence", "1.0", "Evidence Answer Engine", "Retrieve passages and produce cited answers", "internal"),
        ("eval.source_score", "1.0", "Source Quality Scorer", "Explainable multi-feature source scoring", "internal"),
    ]
    for tid, ver, name, desc, origin in tools:
        db.execute(
            """
            INSERT INTO tool_registry (tool_id, version, name, description, capability, origin, status)
            VALUES (?, ?, ?, ?, ?, ?, 'active')
            ON CONFLICT(tool_id) DO UPDATE SET version=excluded.version, name=excluded.name
            """,
            (tid, ver, name, desc, desc, origin),
        )


@app.get("/", response_class=HTMLResponse)
async def index():
    index_path = FRONTEND_DIR / "index.html"
    if index_path.exists():
        return FileResponse(index_path)
    return HTMLResponse("<h1>ALI backend is running</h1><p>Frontend not found. API docs at /api/docs</p>")


@app.get("/manifest.json")
async def manifest():
    m = FRONTEND_DIR / "manifest.json"
    if m.exists():
        return FileResponse(m)
    return JSONResponse({"name": "ALI", "short_name": "ALI", "start_url": "/", "display": "standalone"})


# Fallback for SPA-style navigation
@app.get("/{path:path}")
async def spa_fallback(path: str):
    if path.startswith("api/") or path.startswith("static/"):
        raise HTTPException(404)
    index_path = FRONTEND_DIR / "index.html"
    if index_path.exists():
        return FileResponse(index_path)
    raise HTTPException(404)
