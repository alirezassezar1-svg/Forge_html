"""Core integration tests for ALI."""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

import pytest

# Make backend importable
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

# Use a temporary DB for tests
os.environ["DB_PATH"] = ""  # will be overridden

from app.core.config import settings
from app.db.database import Database
from app.ingestion.pipeline import IngestionPipeline, IngestionError
from app.search.retriever import Retriever
from app.services.answer_engine import AnswerEngine
from app.utils.text import normalize_for_search, content_hash, detect_language_simple, chunk_text
from app.utils.security import is_safe_url, safe_filename


@pytest.fixture
def tmp_db(tmp_path):
    db_file = tmp_path / "test_ali.db"
    # Override settings paths
    settings.db_path = db_file
    settings.data_dir = tmp_path / "data"
    settings.upload_dir = settings.data_dir / "uploads"
    settings.original_dir = settings.data_dir / "originals"
    settings.backup_dir = settings.data_dir / "backups"
    settings.ensure_directories()
    db = Database(db_file)
    yield db
    # cleanup handled by tmp_path


def test_normalize_persian():
    text = "سلام كي و ي"
    norm = normalize_for_search(text)
    assert "ک" in norm or "کي" in norm or "ی" in norm
    assert norm == normalize_for_search(norm)


def test_language_detect():
    assert detect_language_simple("This is a simple English sentence for testing language detection heuristics.") == "en"
    fa = "این یک متن فارسی برای آزمایش تشخیص زبان است و باید به درستی کار کند."
    assert detect_language_simple(fa) == "fa"


def test_chunking():
    text = "Paragraph one.\n\n" + ("word " * 400)
    chunks = chunk_text(text, max_chars=200, overlap=20)
    assert len(chunks) >= 2
    assert all(c[0] for c in chunks)


def test_ssrf_block():
    ok, reason = is_safe_url("http://127.0.0.1/")
    assert not ok
    ok, reason = is_safe_url("http://localhost/admin")
    assert not ok
    ok, reason = is_safe_url("ftp://example.com")
    assert not ok


def test_safe_filename():
    assert ".." not in safe_filename("../../etc/passwd")
    assert safe_filename("my file (1).txt").endswith(".txt")


def test_ingest_and_search(tmp_db):
    pipe = IngestionPipeline()
    sample = """
    The ALI system is a personal knowledge engine.
    It supports Persian and English full-text search.
    Evidence-based answers require retrieved passages.
    """
    result = pipe.ingest_text(sample, title="ALI Overview")
    assert result["status"] == "success"
    assert result["chunks"] >= 1
    doc_id = result["document_id"]

    ret = Retriever()
    search = ret.search("knowledge engine")
    assert search["total"] >= 1
    assert any("ALI" in (r["title"] or "") or "knowledge" in r["snippet"].lower() for r in search["results"])

    # Persian text
    fa_text = "سیستم علی یک موتور دانش شخصی است که از جستجوی تمام‌متن پشتیبانی می‌کند."
    r2 = pipe.ingest_text(fa_text, title="متن فارسی")
    assert r2["status"] == "success"
    assert r2["language"] == "fa"

    search_fa = ret.search("موتور دانش", language="fa")
    assert search_fa["total"] >= 1

    # Answer engine
    eng = AnswerEngine()
    ans = eng.answer("What is ALI?")
    assert "evidence" in ans
    assert ans["confidence"] != "none" or len(ans["evidence"]) == 0

    # Duplicate detection
    dup = pipe.ingest_text(sample, title="Dup")
    assert dup["status"] == "duplicate"

    # Document list
    listing = ret.list_documents()
    assert listing["total"] >= 2

    # Score
    from app.evaluation.scorer import score_document, get_score
    sc = score_document(doc_id)
    assert 0 <= sc["overall_score"] <= 1
    assert get_score(doc_id) is not None

    # Backup
    backup_path = tmp_db.backup()
    assert backup_path.exists()
    assert backup_path.stat().st_size > 0


def test_empty_and_invalid(tmp_db):
    pipe = IngestionPipeline()
    with pytest.raises(IngestionError):
        pipe.ingest_text("   ")
    with pytest.raises(IngestionError):
        pipe.ingest_bytes(b"not a real pdf content xyz", filename="x.pdf")
