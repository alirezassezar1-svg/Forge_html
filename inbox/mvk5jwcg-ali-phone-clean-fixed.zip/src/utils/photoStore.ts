import { PhotoItem } from '../types/phone';

/** Photos are stored in IndexedDB – localStorage (5 MB) silently drops camera photos. */
const DB = 'aliphone_photos';
const STORE = 'photos';
type Row = PhotoItem & { ts: number };

function open(): Promise<IDBDatabase> {
  return new Promise((res, rej) => {
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(STORE, { keyPath: 'id' });
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
}
async function run<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await open();
  return new Promise((res, rej) => {
    const t = db.transaction(STORE, mode);
    const q = fn(t.objectStore(STORE));
    t.oncomplete = () => res(q.result);
    t.onerror = () => rej(t.error);
  });
}

export const photoStore = {
  async all(): Promise<PhotoItem[]> {
    const rows = await run<Row[]>('readonly', (s) => s.getAll() as IDBRequest<Row[]>);
    return rows.sort((a, b) => b.ts - a.ts);
  },
  put: (p: PhotoItem, ts = Date.now()) => run('readwrite', (s) => s.put({ ...p, ts })),
  remove: (id: string) => run('readwrite', (s) => s.delete(id)),
  clear: () => run('readwrite', (s) => s.clear()),
};

export function fileToDataUrl(file: Blob): Promise<string> {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result as string);
    r.onerror = () => rej(r.error);
    r.readAsDataURL(file);
  });
}
