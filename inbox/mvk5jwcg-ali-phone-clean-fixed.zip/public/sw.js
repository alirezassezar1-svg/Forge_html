/* ALI phone Service Worker — offline-first shell + smart runtime caching */
const VERSION = 'aliphone-v2';
const SHELL = [
  '/',
  '/manifest.webmanifest',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/icons/icon-maskable-512.png',
  '/icons/apple-touch-icon.png',
  '/icons/favicon-32.png',
];

// Pre-cache key wallpapers for instant offline theme switching
const WALLPAPERS = [
  '/wallpapers/iphone16_titanium_desert_1792636480310.jpg',
  '/wallpapers/iphone16_titanium_dark_1792636480816.jpg',
  '/wallpapers/iphone16_titanium_natural_1792636481964.jpg',
  '/wallpapers/iphone16_titanium_white.jpg',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches
      .open(VERSION)
      .then(async (cache) => {
        await cache.addAll([...SHELL, ...WALLPAPERS]);
        // Precache the hashed JS/CSS/font bundles referenced by index.html → offline works right after first visit
        try {
          const html = await (await fetch('/', { cache: 'no-store' })).text();
          const assets = [...new Set(html.match(/\/assets\/[^"'\s)]+/g) || [])];
          await Promise.all(assets.map((a) => cache.add(a).catch(() => {})));
        } catch {}
      })
      .then(() => self.skipWaiting())
      .catch((err) => console.warn('[SW] install cache failed', err))
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', (e) => {
  if (e.data === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  // Only same-origin GET; skip API and non-GET
  if (req.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/api/')) {
    return;
  }

  // HTML navigations → network-first, offline fallback to shell
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(VERSION).then((c) => c.put('/', copy));
          return res;
        })
        .catch(() => caches.match('/').then((r) => r || caches.match('/index.html')))
    );
    return;
  }

  // Images & fonts → cache-first (stale-while-revalidate)
  const isAsset =
    url.pathname.startsWith('/wallpapers/') ||
    url.pathname.startsWith('/icons/') ||
    url.pathname.match(/\.(png|jpe?g|webp|svg|woff2?|ttf|css|js)$/i);

  if (isAsset) {
    event.respondWith(
      caches.open(VERSION).then(async (cache) => {
        const cached = await cache.match(req);
        const networkPromise = fetch(req)
          .then((res) => {
            if (res.ok && res.status === 200) cache.put(req, res.clone());
            return res;
          })
          .catch(() => cached);
        return cached || networkPromise;
      })
    );
    return;
  }

  // Everything else → stale-while-revalidate
  event.respondWith(
    caches.open(VERSION).then(async (cache) => {
      const cached = await cache.match(req);
      const network = fetch(req)
        .then((res) => {
          if (res.ok && res.status === 200) cache.put(req, res.clone());
          return res;
        })
        .catch(() => cached);
      return cached || network;
    })
  );
});
