/* NONOS service worker — offline-first app shell */
const CACHE = 'nonos-v3';
const CORE = [
  './', './index.html', './manifest.webmanifest', './favicon.svg',
  'icons/icon-192.png', 'icons/icon-512.png', 'icons/icon-maskable-512.png',
  'modules/nono-ai.html', 'modules/content-studio.html', 'modules/text-studio.html',
  'modules/database-os.html', 'modules/api-forge.html', 'modules/nonomail.html',
  'modules/global-voice.html', 'modules/admin-os.html'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(CORE).catch(() => null))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return; // let CDN requests hit network/browser cache

  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then(hit => {
      if (hit) return hit;
      return fetch(req).then(res => {
        if (res && res.ok) {
          const copy = res.clone();
          caches.open(CACHE).then(c => c.put(req, copy)).catch(() => null);
        }
        return res;
      }).catch(() => {
        // offline fallback for navigations
        if (req.mode === 'navigate') return caches.match('./index.html');
        return new Response('offline', { status: 503 });
      });
    })
  );
});
