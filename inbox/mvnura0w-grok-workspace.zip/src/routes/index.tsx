import { createFileRoute } from "@tanstack/react-router";
import { Phone } from "@/phone/Phone";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <Phone />;
}
