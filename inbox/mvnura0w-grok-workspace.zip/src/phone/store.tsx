import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { beepAlarm, music } from "./audio";
import {
  APPS,
  DEFAULT_DATA,
  DOCK,
  type Alarm,
  type Lang,
  type PhoneData,
  type WebApp,
  available,
  mergeSaved,
  uid,
  webOf,
} from "./model";

const KEY = "aliphone.v1";

export interface VoiceMemo {
  id: string;
  url: string;
  seconds: number;
  at: number;
}
export interface LiveCall {
  name: string;
  number: string;
  started: number;
}

interface PhoneApi {
  data: PhoneData;
  now: Date | null;
  rtl: boolean;
  lang: Lang;
  locked: boolean;
  setLocked: (v: boolean) => void;
  app: string | null;
  openApp: (id: string) => void;
  closeApp: () => void;
  recents: string[];
  closeRecent: (id: string) => void;
  update: (patch: Partial<PhoneData> | ((d: PhoneData) => PhoneData)) => void;
  install: (id: string) => void;
  uninstall: (id: string) => void;
  addWeb: (w: Omit<WebApp, "id">) => string;
  moveHome: (from: number, to: number) => void;
  nameOf: (id: string) => string;
  isAvail: (id: string) => boolean;
  web: (id: string) => WebApp | undefined;
  memos: VoiceMemo[];
  addMemo: (m: VoiceMemo) => void;
  call: LiveCall | null;
  startCall: (name: string, number: string) => void;
  endCall: () => void;
  timer: { endsAt: number; total: number } | null;
  setTimer: (t: { endsAt: number; total: number } | null) => void;
  ringing: Alarm | null;
  dismissAlarm: () => void;
  battery: number;
  unread: number;
}

const Ctx = createContext<PhoneApi | null>(null);

export function PhoneProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<PhoneData>(DEFAULT_DATA);
  const [ready, setReady] = useState(false);
  const [now, setNow] = useState<Date | null>(null);
  const [locked, setLocked] = useState(false);
  const [app, setApp] = useState<string | null>(null);
  const [recents, setRecents] = useState<string[]>([]);
  const [memos, setMemos] = useState<VoiceMemo[]>([]);
  const [call, setCall] = useState<LiveCall | null>(null);
  const [timer, setTimer] = useState<{ endsAt: number; total: number } | null>(null);
  const [ringing, setRinging] = useState<Alarm | null>(null);
  const [battery, setBattery] = useState(86);
  const fired = useMemo(() => ({ key: "" }), []);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) setData(mergeSaved(JSON.parse(raw)));
    } catch {
      /* keep default */
    }
    setReady(true);
    setNow(new Date());
    const t = window.setInterval(() => setNow(new Date()), 1000);
    const bat = navigator as Navigator & { getBattery?: () => Promise<{ level: number }> };
    if (bat.getBattery) {
      void bat.getBattery().then((b) => setBattery(Math.round(b.level * 100))).catch(() => {});
    }
    return () => window.clearInterval(t);
  }, []);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(KEY, JSON.stringify(data));
    } catch {
      const slim = { ...data, photos: data.photos.filter((p) => !p.url.startsWith("data:")).slice(0, 6) };
      try {
        localStorage.setItem(KEY, JSON.stringify(slim));
      } catch {
        /* ignore quota */
      }
    }
  }, [data, ready]);

  useEffect(() => {
    music.setVolume(data.silent ? 0 : data.volume);
  }, [data.volume, data.silent]);

  useEffect(() => {
    if (!now) return;
    const key = `${now.getFullYear()}-${now.getMonth()}-${now.getDate()}-${now.getHours()}-${now.getMinutes()}`;
    if (now.getSeconds() > 1) return;
    const hit = data.alarms.find((a) => a.on && a.hour === now.getHours() && a.minute === now.getMinutes());
    if (hit && fired.key !== key) {
      fired.key = key;
      setRinging(hit);
      if (!data.silent) beepAlarm();
    }
  }, [now, data.alarms, data.silent, fired]);

  useEffect(() => {
    if (!timer || !now) return;
    if (now.getTime() >= timer.endsAt) {
      setTimer(null);
      if (!data.silent) beepAlarm();
      setRinging({ id: "timer", hour: 0, minute: 0, on: true, label: data.lang === "fa" ? "زمان‌سنج" : "Timer" });
    }
  }, [now, timer, data.silent, data.lang]);

  const update: PhoneApi["update"] = (patch) => {
    setData((d) => (typeof patch === "function" ? patch(d) : { ...d, ...patch }));
  };

  const lang = data.lang;

  const api = useMemo<PhoneApi>(() => {
    const unread = Object.values(data.threads).reduce((n, t) => n + (t.unread || 0), 0);
    return {
      data,
      now,
      rtl: lang === "fa",
      lang,
      locked,
      setLocked,
      app,
      openApp: (id: string) => {
        if (!available(data, id) && id !== "camera") return;
        setLocked(false);
        setApp(id);
        setRecents((r) => [id, ...r.filter((x) => x !== id)].slice(0, 8));
      },
      closeApp: () => setApp(null),
      recents,
      closeRecent: (id: string) => {
        setRecents((r) => r.filter((x) => x !== id));
        setApp((cur) => (cur === id ? null : cur));
      },
      update,
      install: (id: string) => {
        update((d) => {
          if (d.installed.includes(id) || APPS[id]?.core) {
            if (d.home.includes(id) || (DOCK as readonly string[]).includes(id)) return d;
            return { ...d, home: [...d.home, id] };
          }
          return { ...d, installed: [...d.installed, id], home: [...d.home, id] };
        });
      },
      uninstall: (id: string) => {
        update((d) => {
          if (APPS[id]?.core) return { ...d, home: d.home.filter((x) => x !== id) };
          return {
            ...d,
            installed: d.installed.filter((x) => x !== id),
            home: d.home.filter((x) => x !== id),
            webApps: d.webApps.filter((w) => w.id !== id),
          };
        });
        setRecents((r) => r.filter((x) => x !== id));
        setApp((cur) => (cur === id ? null : cur));
      },
      addWeb: (w) => {
        const id = `web:${uid("w")}`;
        update((d) => ({ ...d, webApps: [...d.webApps, { ...w, id }], home: [...d.home, id] }));
        return id;
      },
      moveHome: (from, to) => {
        update((d) => {
          const h = d.home.slice();
          if (from < 0 || from >= h.length || to < 0 || to >= h.length) return d;
          const [it] = h.splice(from, 1);
          if (!it) return d;
          h.splice(to, 0, it);
          return { ...d, home: h };
        });
      },
      nameOf: (id: string) => {
        const w = webOf(data, id);
        if (w) return w.name;
        const m = APPS[id];
        return m ? (lang === "fa" ? m.fa : m.en) : id;
      },
      isAvail: (id: string) => available(data, id),
      web: (id: string) => webOf(data, id),
      memos,
      addMemo: (m) => setMemos((xs) => [m, ...xs]),
      call,
      startCall: (name, number) => {
        setCall({ name, number, started: Date.now() });
        setLocked(false);
        update((d) => ({
          ...d,
          recents: [{ id: uid("rc"), name, number, at: Date.now() }, ...d.recents].slice(0, 20),
        }));
      },
      endCall: () => setCall(null),
      timer,
      setTimer,
      ringing,
      dismissAlarm: () => setRinging(null),
      battery,
      unread,
    };
  }, [data, now, lang, locked, app, recents, memos, call, timer, ringing, battery]);

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}

export function usePhone() {
  const v = useContext(Ctx);
  if (!v) throw new Error("phone");
  return v;
}
