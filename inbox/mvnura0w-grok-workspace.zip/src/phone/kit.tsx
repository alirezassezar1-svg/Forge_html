import type { ReactNode } from "react";
import { usePhone } from "./store";

export function Screen({
  title,
  back,
  right,
  children,
  scroll = true,
  padTop = true,
}: {
  title?: string;
  back?: () => void;
  right?: ReactNode;
  children: ReactNode;
  scroll?: boolean;
  padTop?: boolean;
}) {
  return (
    <div className="app" style={padTop ? undefined : { paddingTop: 0 }}>
      <div className="nav">
        {back ? (
          <button className="nav-back" onClick={back} aria-label="back">
            ‹
          </button>
        ) : (
          <span />
        )}
        {back ? <div className="nav-title">{title}</div> : <span />}
        <div>{right}</div>
      </div>
      {title && !back ? <h1 className="large">{title}</h1> : null}
      <div className={scroll ? "app-scroll" : "app-fill"}>{children}</div>
    </div>
  );
}

export function Group({ children }: { children: ReactNode }) {
  return <div className="group">{children}</div>;
}

export function Row({
  label,
  value,
  onClick,
  icon,
}: {
  label: string;
  value?: ReactNode;
  onClick?: () => void;
  icon?: ReactNode;
}) {
  return (
    <button className="row" onClick={onClick} type="button">
      {icon}
      <span>{label}</span>
      {value != null && <span className="value">{value}</span>}
    </button>
  );
}

export function Toggle({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <button className={`switch ${on ? "on" : ""}`} onClick={onClick} aria-pressed={on} type="button">
      <i />
    </button>
  );
}

export function useT() {
  const { rtl } = usePhone();
  return (fa: string, en: string) => (rtl ? fa : en);
}
