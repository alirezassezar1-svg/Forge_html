import { useEffect, useRef, useState } from "react";
import { music, padHit } from "./audio";
import { Group, Row, Screen, Toggle, useT } from "./kit";
import { IosIcon } from "./icons";
import {
  APPS,
  CALC0,
  CITIES,
  DOCK,
  WALLPAPERS,
  calcKey,
  faNum,
  formatClock,
  initialView,
  monthGrid,
  monthTitle,
  shiftMonth,
  todayKey,
  uid,
  type CalcState,
} from "./model";
import { usePhone } from "./store";
import { ExtraApps } from "./extra";

export function AppView({ id }: { id: string }) {
  const phone = usePhone();
  const web = phone.web(id);
  if (web?.html) return <HtmlApp name={web.name} html={web.html} />;
  if (web?.url) return <WebFrame title={web.name} url={web.url} />;
  switch (id) {
    case "phone":
      return <PhoneApp />;
    case "messages":
      return <MessagesApp />;
    case "safari":
      return <SafariApp />;
    case "music":
      return <MusicApp />;
    case "camera":
      return <CameraApp />;
    case "photos":
      return <PhotosApp />;
    case "weather":
      return <WeatherApp />;
    case "clock":
      return <ClockApp />;
    case "maps":
      return <MapsApp />;
    case "notes":
      return <NotesApp />;
    case "calendar":
      return <CalendarApp />;
    case "reminders":
      return <RemindersApp />;
    case "calculator":
      return <CalculatorApp />;
    case "settings":
      return <SettingsApp />;
    case "appstore":
      return <StoreApp />;
    case "files":
      return <FilesApp />;
    default:
      return <ExtraApps id={id} />;
  }
}

function PhoneApp() {
  const phone = usePhone();
  const t = useT();
  const [tab, setTab] = useState<"fav" | "recents" | "contacts" | "key">("key");
  const [digits, setDigits] = useState("");
  const [sec, setSec] = useState(0);
  useEffect(() => {
    if (!phone.call) return;
    const id = window.setInterval(() => setSec(Math.floor((Date.now() - phone.call!.started) / 1000)), 500);
    return () => window.clearInterval(id);
  }, [phone.call]);
  if (phone.call) {
    const c = phone.call;
    return (
      <Screen title={t("تماس", "Call")} scroll={false}>
        <div className="call-screen">
          <div className="who">{c.name || faNum(c.number, phone.lang)}</div>
          <div className="num">{faNum(`${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`, phone.lang)}</div>
          <button className="call-btn end-btn" aria-label="end" onClick={phone.endCall}>
            ⌁
          </button>
        </div>
      </Screen>
    );
  }
  const keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#"];
  const sub: Record<string, string> = { "2": "ABC", "3": "DEF", "4": "GHI", "5": "JKL", "6": "MNO", "7": "PQRS", "8": "TUV", "9": "WXYZ" };
  return (
    <Screen title={t("تلفن", "Phone")} scroll={false}>
      <div className="app-fill">
        {tab === "key" && (
          <>
            <div style={{ textAlign: "center", fontSize: 34, minHeight: 48, letterSpacing: 1 }}>{faNum(digits || "", phone.lang)}</div>
            <div className="keypad">
              {keys.map((k) => (
                <button key={k} className="key" onClick={() => setDigits((d) => (d + k).slice(0, 16))}>
                  {faNum(k, phone.lang)}
                  {sub[k] && <small>{sub[k]}</small>}
                </button>
              ))}
            </div>
            <button
              className="call-btn"
              aria-label="call"
              onClick={() => {
                if (!digits) return;
                const hit = phone.data.contacts.find((c) => c.phone === digits);
                phone.startCall(hit?.name || "", digits);
              }}
            >
              ☎
            </button>
            {digits && (
              <button className="text-btn" onClick={() => setDigits((d) => d.slice(0, -1))}>
                ⌫
              </button>
            )}
          </>
        )}
        {tab === "recents" && (
          <div className="app-scroll">
            {phone.data.recents.map((r) => (
              <Row key={r.id} label={r.name || faNum(r.number, phone.lang)} value={faNum(r.number, phone.lang)} onClick={() => phone.startCall(r.name, r.number)} />
            ))}
          </div>
        )}
        {(tab === "contacts" || tab === "fav") && (
          <div className="app-scroll">
            {phone.data.contacts.map((c) => (
              <Row key={c.id} label={c.name} value={faNum(c.phone, phone.lang)} onClick={() => phone.startCall(c.name, c.phone)} />
            ))}
          </div>
        )}
        <div className="tabs">
          <button className={tab === "fav" ? "on" : ""} onClick={() => setTab("fav")}>{t("علاقه‌مندی", "Favorites")}</button>
          <button className={tab === "recents" ? "on" : ""} onClick={() => setTab("recents")}>{t("اخیر", "Recents")}</button>
          <button className={tab === "contacts" ? "on" : ""} onClick={() => setTab("contacts")}>{t("مخاطبان", "Contacts")}</button>
          <button className={tab === "key" ? "on" : ""} onClick={() => setTab("key")}>{t("صفحه کلید", "Keypad")}</button>
        </div>
      </div>
    </Screen>
  );
}

function MessagesApp() {
  const phone = usePhone();
  const t = useT();
  const [open, setOpen] = useState<string | null>(null);
  const [text, setText] = useState("");
  const contact = phone.data.contacts.find((c) => c.id === open);
  function send() {
    if (!open || !text.trim()) return;
    const body = text.trim();
    setText("");
    phone.update((d) => {
      const th = d.threads[open] ?? { messages: [], unread: 0 };
      return {
        ...d,
        threads: {
          ...d.threads,
          [open]: { unread: 0, messages: [...th.messages, { id: uid("m"), from: "me", text: body, at: Date.now() }] },
        },
      };
    });
    window.setTimeout(() => {
      const reply = t("باشه، دیدمت.", "Got it.");
      phone.update((d) => {
        const th = d.threads[open] ?? { messages: [], unread: 0 };
        return {
          ...d,
          threads: {
            ...d.threads,
            [open]: { ...th, messages: [...th.messages, { id: uid("m"), from: "them", text: reply, at: Date.now() }] },
          },
        };
      });
    }, 700);
  }
  if (open && contact) {
    const msgs = phone.data.threads[open]?.messages ?? [];
    return (
      <Screen title={contact.name} back={() => setOpen(null)} scroll={false}>
        <div className="app-scroll">
          {msgs.map((m) => (
            <div key={m.id} className={`bubble-row ${m.from}`}>
              <div className="msg">{m.text}</div>
            </div>
          ))}
        </div>
        <div className="composer">
          <input value={text} placeholder={t("پیام", "Message")} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} />
          <button className="text-btn" onClick={send}>{t("بفرست", "Send")}</button>
        </div>
      </Screen>
    );
  }
  return (
    <Screen title={t("پیام‌ها", "Messages")}>
      {phone.data.contacts.map((c) => {
        const th = phone.data.threads[c.id];
        const last = th?.messages[th.messages.length - 1];
        return (
          <Row
            key={c.id}
            label={c.name}
            value={th?.unread ? faNum(th.unread, phone.lang) : ""}
            onClick={() => {
              setOpen(c.id);
              phone.update((d) => ({ ...d, threads: { ...d.threads, [c.id]: { ...(d.threads[c.id] ?? { messages: [] }), unread: 0, messages: d.threads[c.id]?.messages ?? [] } } }));
            }}
            icon={<span style={{ color: "#8e8e93", fontSize: 13 }}>{last?.text.slice(0, 18)}</span>}
          />
        );
      })}
    </Screen>
  );
}

const BOOKMARKS = [
  { fa: "ویکی‌پدیا", en: "Wikipedia", url: "https://fa.wikipedia.org" },
  { fa: "نقشه", en: "Map", url: "https://www.openstreetmap.org" },
  { fa: "هوا", en: "Weather", url: "https://open-meteo.com" },
];

function SafariApp() {
  const phone = usePhone();
  const t = useT();
  const [url, setUrl] = useState("");
  const [current, setCurrent] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [name, setName] = useState("");
  function go(raw: string) {
    const u = /^https?:\/\//.test(raw) ? raw : `https://${raw}`;
    setCurrent(u);
    setUrl(u);
  }
  return (
    <Screen
      title={t("سافاری", "Safari")}
      scroll={false}
      right={
        <button className="text-btn" onClick={() => { setName(t("وب", "Web")); setAdding(true); }}>
          +
        </button>
      }
    >
      <div className="composer">
        <input value={url} placeholder="example.com" onChange={(e) => setUrl(e.target.value)} onKeyDown={(e) => e.key === "Enter" && go(url)} />
        <button className="text-btn" onClick={() => go(url)}>{t("برو", "Go")}</button>
      </div>
      {!current && (
        <div className="app-scroll">
          <p className="section-label">{t("نشان‌شده‌ها", "Bookmarks")}</p>
          {BOOKMARKS.map((b) => (
            <Row key={b.url} label={phone.rtl ? b.fa : b.en} value={b.url.replace("https://", "")} onClick={() => go(b.url)} />
          ))}
        </div>
      )}
      {current && <iframe className="map-frame" title="safari" src={current} sandbox="allow-scripts allow-forms allow-popups" />}
      {adding && (
        <div className="sheet" style={{ zIndex: 40 }}>
          <h2 className="large">{t("افزودن به صفحهٔ اصلی", "Add to Home Screen")}</h2>
          <input className="field" value={name} onChange={(e) => setName(e.target.value)} placeholder={t("نام", "Name")} />
          <button
            className="get open"
            onClick={() => {
              if (!name.trim() || !current) return;
              phone.addWeb({ name: name.trim(), url: current, color: "#0A84FF" });
              setAdding(false);
            }}
          >
            {t("افزودن", "Add")}
          </button>
          <button className="text-btn" onClick={() => setAdding(false)}>{t("لغو", "Cancel")}</button>
        </div>
      )}
    </Screen>
  );
}

function WebFrame({ title, url }: { title: string; url: string }) {
  const phone = usePhone();
  return (
    <Screen title={title} back={phone.closeApp} scroll={false}>
      <iframe className="map-frame" title={title} src={url} sandbox="allow-scripts allow-forms allow-popups" />
    </Screen>
  );
}

function HtmlApp({ name, html }: { name: string; html: string }) {
  const phone = usePhone();
  return (
    <Screen title={name} back={phone.closeApp} scroll={false}>
      <iframe className="map-frame" title={name} sandbox="allow-scripts" srcDoc={html} />
    </Screen>
  );
}

function MusicApp() {
  const phone = usePhone();
  const t = useT();
  const [, setN] = useState(0);
  useEffect(() => music.subscribe(() => setN((n) => n + 1)), []);
  const tr = music.track;
  return (
    <Screen title={t("موسیقی", "Music")} scroll={false}>
      <div className="app-fill" style={{ alignItems: "center", padding: 16 }}>
        <div style={{ width: 220, height: 220, borderRadius: 24, background: tr.hue, margin: "12px auto" }} />
        <b style={{ fontSize: 22 }}>{tr.title}</b>
        <div style={{ color: "#8e8e93" }}>{tr.artist}</div>
        <div style={{ display: "flex", gap: 18, marginTop: 18 }}>
          <button className="bubble" onClick={() => music.prev()}>⏮</button>
          <button className="bubble on" onClick={() => void music.toggle()}>{music.playing ? "❚❚" : "▶"}</button>
          <button className="bubble" onClick={() => music.next()}>⏭</button>
        </div>
        <div className="app-scroll" style={{ width: "100%", marginTop: 16 }}>
          {music.tracks.map((track, i) => (
            <Row key={track.id} label={track.title} value={track.artist} onClick={() => void music.playIndex(i)} />
          ))}
        </div>
      </div>
    </Screen>
  );
}

function CameraApp() {
  const phone = usePhone();
  const t = useT();
  const video = useRef<HTMLVideoElement>(null);
  const [err, setErr] = useState("");
  const [zoom, setZoom] = useState(1);
  useEffect(() => {
    let stream: MediaStream | null = null;
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" }, audio: false });
        if (video.current) video.current.srcObject = stream;
      } catch {
        setErr(t("دوربین در این پیش‌نمایش در دسترس نیست. شاتر یک عکس نمونه می‌سازد.", "Camera is blocked here. The shutter saves a sample photo."));
      }
    })();
    return () => stream?.getTracks().forEach((tr) => tr.stop());
  }, []);
  function shoot() {
    const v = video.current;
    let url = phone.data.wallpaper;
    if (v && v.videoWidth) {
      const c = document.createElement("canvas");
      c.width = 480;
      c.height = Math.round(480 * (v.videoHeight / v.videoWidth));
      c.getContext("2d")!.drawImage(v, 0, 0, c.width, c.height);
      url = c.toDataURL("image/jpeg", 0.62);
    }
    phone.update((d) => ({ ...d, photos: [{ id: uid("ph"), url, at: Date.now() }, ...d.photos].slice(0, 16) }));
    phone.openApp("photos");
  }
  return (
    <div className="app" style={{ paddingTop: 54 }}>
      <div className="cam-view">
        <video ref={video} autoPlay playsInline muted style={{ transform: `scale(${zoom})` }} />
        {err && <p className="warn">{err}</p>}
        <button className="shutter" aria-label="shutter" onClick={shoot}><i /></button>
      </div>
      <input type="range" min={1} max={3} step={0.1} value={zoom} onChange={(e) => setZoom(Number(e.target.value))} style={{ margin: 8 }} />
    </div>
  );
}

function PhotosApp() {
  const phone = usePhone();
  const t = useT();
  const [open, setOpen] = useState<string | null>(null);
  const photo = phone.data.photos.find((p) => p.id === open);
  return (
    <Screen title={t("عکس‌ها", "Photos")}>
      <div className="photo-grid">
        {phone.data.photos.map((p) => (
          <button key={p.id} onClick={() => setOpen(p.id)}>
            <img src={p.url} alt="" />
          </button>
        ))}
      </div>
      {photo && (
        <div className="viewer">
          <div className="nav">
            <button className="text-btn" onClick={() => setOpen(null)}>{t("بستن", "Close")}</button>
            <button
              className="text-btn"
              onClick={() => phone.update((d) => ({ ...d, photos: d.photos.map((p) => (p.id === photo.id ? { ...p, fav: !p.fav } : p)) }))}
            >
              {photo.fav ? "★" : "☆"}
            </button>
            <button
              className="text-btn"
              onClick={() => {
                phone.update((d) => ({ ...d, photos: d.photos.filter((p) => p.id !== photo.id) }));
                setOpen(null);
              }}
            >
              {t("حذف", "Delete")}
            </button>
          </div>
          <img src={photo.url} alt="" />
        </div>
      )}
    </Screen>
  );
}

function WeatherApp() {
  const phone = usePhone();
  const t = useT();
  const [city, setCity] = useState(CITIES[5]!);
  const [wx, setWx] = useState<{ temp: number; code: number; hours: { t: string; c: number }[]; days: { max: number; min: number; code: number }[] } | null>(null);
  const [err, setErr] = useState("");
  useEffect(() => {
    let stop = false;
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}&current=temperature_2m,weather_code&hourly=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=6`;
    fetch(url)
      .then((r) => r.json())
      .then((j) => {
        if (stop) return;
        const hours = (j.hourly.time as string[]).slice(0, 12).map((time: string, i: number) => ({
          t: time.slice(11, 16),
          c: Math.round(j.hourly.temperature_2m[i]),
        }));
        const days = (j.daily.time as string[]).map((_: string, i: number) => ({
          max: Math.round(j.daily.temperature_2m_max[i]),
          min: Math.round(j.daily.temperature_2m_min[i]),
          code: j.daily.weather_code[i],
        }));
        setWx({ temp: Math.round(j.current.temperature_2m), code: j.current.weather_code, hours, days });
      })
      .catch(() => setErr(t("هوا این لحظه نرسید", "Forecast unavailable")));
    return () => {
      stop = true;
    };
  }, [city]);
  const label = (code: number) => {
    if (code === 0) return t("آفتابی", "Clear");
    if (code < 3) return t("نیمه‌ابری", "Partly cloudy");
    if (code < 50) return t("ابری", "Cloudy");
    if (code < 70) return t("باران", "Rain");
    if (code < 80) return t("برف", "Snow");
    return t("رگبار", "Showers");
  };
  return (
    <Screen title={phone.rtl ? city.fa : city.en}>
      <div className="chips">
        {CITIES.map((c) => (
          <button key={c.en} className={c.en === city.en ? "on" : ""} onClick={() => setCity(c)}>
            {phone.rtl ? c.fa : c.en}
          </button>
        ))}
      </div>
      {err && <p className="warn">{err}</p>}
      {wx && (
        <>
          <div className="wx-hero">
            <div className="temp">{faNum(wx.temp, phone.lang)}°</div>
            <div>{label(wx.code)}</div>
          </div>
          <div className="hour-row">
            {wx.hours.map((h) => (
              <div key={h.t}>
                <div>{faNum(h.t, phone.lang)}</div>
                <b>{faNum(h.c, phone.lang)}°</b>
              </div>
            ))}
          </div>
          <Group>
            {wx.days.map((d, i) => (
              <Row key={i} label={i === 0 ? t("امروز", "Today") : t(`روز ${i + 1}`, `Day ${i + 1}`)} value={`${faNum(d.min, phone.lang)}°  ${faNum(d.max, phone.lang)}°`} />
            ))}
          </Group>
        </>
      )}
    </Screen>
  );
}

function ClockApp() {
  const phone = usePhone();
  const t = useT();
  const [tab, setTab] = useState<"world" | "alarm" | "stop" | "timer">("world");
  const [sw, setSw] = useState({ run: false, base: 0, since: 0 });
  const [laps, setLaps] = useState<number[]>([]);
  const [, bump] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => bump((n) => n + 1), 200);
    return () => window.clearInterval(id);
  }, []);
  const elapsed = sw.base + (sw.run ? Date.now() - sw.since : 0);
  const [mins, setMins] = useState(1);
  function fmt(ms: number) {
    const s = Math.floor(ms / 1000);
    return faNum(`${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}.${String(Math.floor((ms % 1000) / 10)).padStart(2, "0")}`, phone.lang);
  }
  return (
    <Screen title={t("ساعت", "Clock")} scroll={tab !== "stop"}>
      {tab === "world" && (
        <Group>
          {CITIES.filter((_, i) => [0, 5, 6, 8, 9].includes(i)).map((c) => (
            <Row
              key={c.en}
              label={phone.rtl ? c.fa : c.en}
              value={
                phone.now
                  ? faNum(
                      new Intl.DateTimeFormat("en-GB", { timeZone: c.tz, hour: "2-digit", minute: "2-digit", hour12: false }).format(phone.now),
                      phone.lang,
                    )
                  : "—"
              }
            />
          ))}
        </Group>
      )}
      {tab === "alarm" && (
        <>
          {phone.data.alarms.map((a) => (
            <Group key={a.id}>
              <Row
                label={a.label}
                value={
                  <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    {faNum(`${String(a.hour).padStart(2, "0")}:${String(a.minute).padStart(2, "0")}`, phone.lang)}
                    <Toggle on={a.on} onClick={() => phone.update((d) => ({ ...d, alarms: d.alarms.map((x) => (x.id === a.id ? { ...x, on: !x.on } : x)) }))} />
                  </span>
                }
              />
            </Group>
          ))}
          <button
            className="text-btn"
            onClick={() => {
              const n = phone.now ?? new Date();
              phone.update((d) => ({
                ...d,
                alarms: [...d.alarms, { id: uid("a"), hour: n.getHours(), minute: (n.getMinutes() + 1) % 60, on: true, label: t("زنگ", "Alarm") }],
              }));
            }}
          >
            {t("زنگ جدید", "Add alarm")}
          </button>
        </>
      )}
      {tab === "stop" && (
        <div style={{ textAlign: "center" }}>
          <div className="lock-time" style={{ fontSize: 56 }}>{fmt(elapsed)}</div>
          <div style={{ display: "flex", justifyContent: "center", gap: 12 }}>
            <button className="get" onClick={() => setLaps((l) => [elapsed, ...l].slice(0, 8))}>{t("دور", "Lap")}</button>
            <button
              className="get open"
              onClick={() => setSw((s) => (s.run ? { run: false, base: s.base + Date.now() - s.since, since: 0 } : { run: true, base: s.base, since: Date.now() }))}
            >
              {sw.run ? t("توقف", "Stop") : t("شروع", "Start")}
            </button>
            <button className="get" onClick={() => { setSw({ run: false, base: 0, since: 0 }); setLaps([]); }}>{t("صفر", "Reset")}</button>
          </div>
          {laps.map((l, i) => (
            <Row key={i} label={t(`دور ${laps.length - i}`, `Lap ${laps.length - i}`)} value={fmt(l)} />
          ))}
        </div>
      )}
      {tab === "timer" && (
        <div style={{ textAlign: "center", padding: 16 }}>
          <div className="lock-time" style={{ fontSize: 64 }}>{faNum(mins, phone.lang)} {t("دقیقه", "min")}</div>
          <input type="range" min={1} max={60} value={mins} onChange={(e) => setMins(Number(e.target.value))} />
          <button
            className="get open"
            onClick={() => phone.setTimer({ endsAt: Date.now() + mins * 60000, total: mins * 60000 })}
          >
            {t("شروع زمان‌سنج", "Start timer")}
          </button>
          {phone.timer && <p>{t("در حال اجرا — روی جزیره پویا هم هست", "Running — also on the Dynamic Island")}</p>}
          {phone.timer && <button className="text-btn" onClick={() => phone.setTimer(null)}>{t("لغو", "Cancel")}</button>}
        </div>
      )}
      <div className="tabs">
        <button className={tab === "world" ? "on" : ""} onClick={() => setTab("world")}>{t("جهان", "World")}</button>
        <button className={tab === "alarm" ? "on" : ""} onClick={() => setTab("alarm")}>{t("زنگ", "Alarm")}</button>
        <button className={tab === "stop" ? "on" : ""} onClick={() => setTab("stop")}>{t("کرونومتر", "Stopwatch")}</button>
        <button className={tab === "timer" ? "on" : ""} onClick={() => setTab("timer")}>{t("زمان‌سنج", "Timer")}</button>
      </div>
    </Screen>
  );
}

function MapsApp() {
  const phone = usePhone();
  const [city, setCity] = useState(CITIES[0]!);
  const [me, setMe] = useState<string>("");
  const box = `${city.lon - 0.08},${city.lat - 0.05},${city.lon + 0.08},${city.lat + 0.05}`;
  const src = `https://www.openstreetmap.org/export/embed.html?bbox=${encodeURIComponent(box)}&layer=mapnik&marker=${city.lat}%2C${city.lon}`;
  return (
    <Screen title={phone.rtl ? "نقشه" : "Maps"} scroll={false}>
      <div className="chips">
        <button
          onClick={() => {
            navigator.geolocation?.getCurrentPosition(
              (p) => {
                setCity({ fa: "من", en: "Me", lat: p.coords.latitude, lon: p.coords.longitude, tz: "UTC" });
                setMe(`${p.coords.latitude.toFixed(3)}, ${p.coords.longitude.toFixed(3)}`);
              },
              () => setMe(phone.rtl ? "موقعیت رد شد" : "Location denied"),
            );
          }}
        >
          {phone.rtl ? "موقعیت من" : "My location"}
        </button>
        {CITIES.slice(0, 8).map((c) => (
          <button key={c.en} className={c.en === city.en ? "on" : ""} onClick={() => setCity(c)}>
            {phone.rtl ? c.fa : c.en}
          </button>
        ))}
      </div>
      {me && <p className="warn">{me}</p>}
      <iframe className="map-frame" title="map" src={src} />
    </Screen>
  );
}

function NotesApp() {
  const phone = usePhone();
  const t = useT();
  const [id, setId] = useState<string | null>(null);
  const note = phone.data.notes.find((n) => n.id === id);
  if (note) {
    return (
      <Screen
        title={note.title || t("یادداشت", "Note")}
        back={() => setId(null)}
        right={
          <button className="text-btn" onClick={() => { phone.update((d) => ({ ...d, notes: d.notes.filter((n) => n.id !== note.id) })); setId(null); }}>
            {t("حذف", "Delete")}
          </button>
        }
      >
        <input
          className="field"
          value={note.title}
          onChange={(e) => phone.update((d) => ({ ...d, notes: d.notes.map((n) => (n.id === note.id ? { ...n, title: e.target.value, updated: Date.now() } : n)) }))}
        />
        <textarea
          className="area"
          value={note.body}
          onChange={(e) => phone.update((d) => ({ ...d, notes: d.notes.map((n) => (n.id === note.id ? { ...n, body: e.target.value, updated: Date.now() } : n)) }))}
        />
      </Screen>
    );
  }
  return (
    <Screen
      title={t("یادداشت", "Notes")}
      right={<button className="text-btn" onClick={() => { const n = { id: uid("n"), title: "", body: "", updated: Date.now() }; phone.update((d) => ({ ...d, notes: [n, ...d.notes] })); setId(n.id); }}>+</button>}
    >
      <Group>
        {phone.data.notes.map((n) => (
          <Row key={n.id} label={n.title || t("بدون عنوان", "New note")} value={n.body.slice(0, 16)} onClick={() => setId(n.id)} />
        ))}
      </Group>
    </Screen>
  );
}

function CalendarApp() {
  const phone = usePhone();
  const t = useT();
  const [view, setView] = useState(() => initialView(new Date(), phone.lang));
  const [sel, setSel] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const cells = monthGrid(view, phone.lang);
  const today = phone.now ? todayKey(phone.now) : "";
  const dayEvents = phone.data.events.filter((e) => e.day === sel);
  return (
    <Screen title={t("تقویم", "Calendar")}>
      <div className="nav">
        <button className="text-btn" onClick={() => setView((v) => shiftMonth(v, -1, phone.lang))}>‹</button>
        <b>{monthTitle(view, phone.lang)}</b>
        <button className="text-btn" onClick={() => setView((v) => shiftMonth(v, 1, phone.lang))}>›</button>
      </div>
      <div className="cal-grid">
        {(phone.rtl ? ["ی", "د", "س", "چ", "پ", "ج", "ش"] : ["S", "M", "T", "W", "T", "F", "S"]).map((d, i) => (
          <i key={i} className="wd">{d}</i>
        ))}
        {cells.map((c) => (
          <button key={c.key} className={`${c.key === sel ? "on" : ""} ${c.key === today ? "today" : ""}`} disabled={!c.inMonth} onClick={() => setSel(c.key)}>
            {c.label}
          </button>
        ))}
      </div>
      {sel && (
        <>
          <p className="section-label">{faNum(sel, phone.lang)}</p>
          <Group>
            {dayEvents.map((e) => (
              <Row key={e.id} label={e.title} value={e.time || ""} />
            ))}
          </Group>
          <input className="field" value={title} placeholder={t("رویداد تازه", "New event")} onChange={(e) => setTitle(e.target.value)} />
          <button
            className="get open"
            style={{ marginInlineStart: 16 }}
            onClick={() => {
              if (!title.trim()) return;
              phone.update((d) => ({ ...d, events: [...d.events, { id: uid("e"), title: title.trim(), day: sel, color: "#0A84FF" }] }));
              setTitle("");
            }}
          >
            {t("افزودن", "Add")}
          </button>
        </>
      )}
    </Screen>
  );
}

function RemindersApp() {
  const phone = usePhone();
  const t = useT();
  const [text, setText] = useState("");
  return (
    <Screen title={t("یادآورها", "Reminders")}>
      <div className="composer">
        <input value={text} placeholder={t("کار تازه", "New reminder")} onChange={(e) => setText(e.target.value)} />
        <button
          className="text-btn"
          onClick={() => {
            if (!text.trim()) return;
            phone.update((d) => ({ ...d, reminders: [{ id: uid("r"), title: text.trim(), done: false }, ...d.reminders] }));
            setText("");
          }}
        >
          +
        </button>
      </div>
      <Group>
        {phone.data.reminders.map((r) => (
          <Row
            key={r.id}
            label={r.done ? `✓ ${r.title}` : r.title}
            onClick={() => phone.update((d) => ({ ...d, reminders: d.reminders.map((x) => (x.id === r.id ? { ...x, done: !x.done } : x)) }))}
          />
        ))}
      </Group>
    </Screen>
  );
}

function CalculatorApp() {
  const phone = usePhone();
  const [st, setSt] = useState<CalcState>(CALC0);
  const keys = ["AC", "±", "%", "÷", "7", "8", "9", "×", "4", "5", "6", "−", "1", "2", "3", "+", "0", ".", "="];
  const clear = st.fresh || st.disp === "0" ? "AC" : "C";
  return (
    <div className="app">
      <div className="calc">
        <div className="calc-disp">{faNum(st.disp, phone.lang)}</div>
        <div className="calc-grid">
          {keys.map((k) => {
            const label = k === "AC" ? clear : k;
            const cls = k === "0" ? "ck zero" : "÷×−+= ".includes(k) || k === "÷" || k === "×" || k === "−" || k === "+" || k === "=" ? "ck op" : k === "AC" || k === "±" || k === "%" ? "ck fn" : "ck";
            return (
              <button key={k} className={cls} onClick={() => setSt((s) => calcKey(s, label === "C" ? "C" : k))}>
                {label === "AC" || label === "C" ? label : faNum(label, phone.lang)}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function SettingsApp() {
  const phone = usePhone();
  const t = useT();
  const d = phone.data;
  return (
    <Screen title={t("تنظیمات", "Settings")}>
      <p className="section-label">{t("ظاهر", "Appearance")}</p>
      <div className="wall-pick">
        {WALLPAPERS.map((w) => (
          <button key={w.id} className={d.wallpaper === w.url ? "on" : ""} onClick={() => phone.update({ wallpaper: w.url })}>
            <img src={w.url} alt={phone.rtl ? w.fa : w.en} />
          </button>
        ))}
      </div>
      <Group>
        {(["black", "natural", "desert", "white"] as const).map((f) => (
          <Row key={f} label={f === "black" ? t("تیتانیوم مشکی", "Black Titanium") : f === "natural" ? t("تیتانیوم طبیعی", "Natural") : f === "desert" ? t("تیتانیوم صحرایی", "Desert") : t("سفید", "White")} value={d.finish === f ? "✓" : ""} onClick={() => phone.update({ finish: f })} />
        ))}
      </Group>
      <p className="section-label">{t("عمومی", "General")}</p>
      <Group>
        <Row label={t("زبان", "Language")} value={d.lang === "fa" ? "فارسی" : "English"} onClick={() => phone.update({ lang: d.lang === "fa" ? "en" : "fa" })} />
        <Row label={t("صدا", "Sounds")} value={<Toggle on={!d.silent} onClick={() => phone.update({ silent: !d.silent })} />} />
        <Row label={t("کم‌مصرف", "Low Power")} value={<Toggle on={d.lowPower} onClick={() => phone.update({ lowPower: !d.lowPower })} />} />
        <Row label={t("روشنایی", "Brightness")} value={faNum(Math.round(d.brightness * 100), phone.lang)} onClick={() => phone.update({ brightness: d.brightness > 0.6 ? 0.45 : 1 })} />
      </Group>
      <p className="section-label">{t("درباره", "About")}</p>
      <Group>
        <Row label={t("نام", "Name")} value="ALI Phone" />
        <Row label={t("مدل", "Model")} value="iPhone 16 Pro Max" />
        <Row label={t("نسخه", "Version")} value="iOS 18" />
        <Row
          label={t("پاک کردن دادهٔ دستگاه", "Erase device data")}
          onClick={() => {
            localStorage.removeItem("aliphone.v1");
            window.location.reload();
          }}
        />
      </Group>
    </Screen>
  );
}

function StoreApp() {
  const phone = usePhone();
  const t = useT();
  const [q, setQ] = useState("");
  const [make, setMake] = useState(false);
  const [form, setForm] = useState({ name: "", url: "", html: "", color: "#5E5CE6" });
  const list = Object.entries(APPS).filter(([id, m]) => {
    if ((DOCK as readonly string[]).includes(id)) return false;
    const name = phone.rtl ? m.fa : m.en;
    return name.toLowerCase().includes(q.trim().toLowerCase());
  });
  return (
    <Screen title={t("اپ استور", "App Store")} right={<button className="text-btn" onClick={() => setMake(true)}>{t("ساخت", "Create")}</button>}>
      <input className="field" placeholder={t("جستجو", "Search")} value={q} onChange={(e) => setQ(e.target.value)} />
      {list.map(([id, m]) => {
        const onHome = phone.data.home.includes(id);
        const have = m.core || phone.data.installed.includes(id);
        return (
          <div className="store-card" key={id}>
            <IosIcon id={id} now={phone.now} />
            <div className="meta">
              <b>{phone.rtl ? m.fa : m.en}</b>
              <span>{phone.rtl ? m.blurbFa : m.blurbEn}</span>
            </div>
            {have && onHome ? (
              <button className="get open" onClick={() => phone.openApp(id)}>{t("باز", "Open")}</button>
            ) : (
              <button className="get" onClick={() => phone.install(id)}>{t("گرفتن", "Get")}</button>
            )}
          </div>
        );
      })}
      {phone.data.webApps.map((w) => (
        <div className="store-card" key={w.id}>
          <IosIcon id={w.id} now={phone.now} web={w} />
          <div className="meta">
            <b>{w.name}</b>
            <span>{w.url || "HTML"}</span>
          </div>
          <button className="get open" onClick={() => phone.openApp(w.id)}>{t("باز", "Open")}</button>
        </div>
      ))}
      {make && (
        <div className="sheet" style={{ zIndex: 40, overflow: "auto" }}>
          <h2 className="large">{t("اپ تازه", "New app")}</h2>
          <input className="field" placeholder={t("نام", "Name")} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <input className="field" placeholder="https://" value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} />
          <textarea className="area" placeholder={t("یا HTML کوچک", "or a small HTML app")} value={form.html} onChange={(e) => setForm({ ...form, html: e.target.value })} />
          <input className="field" value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} />
          <button
            className="get open"
            onClick={() => {
              if (!form.name.trim()) return;
              const url = form.url.trim() ? (/^https?:/.test(form.url) ? form.url.trim() : `https://${form.url.trim()}`) : undefined;
              phone.addWeb({ name: form.name.trim(), url, html: form.html.trim() || undefined, color: form.color || "#5E5CE6" });
              setMake(false);
            }}
          >
            {t("نصب روی صفحهٔ اصلی", "Install on Home Screen")}
          </button>
          <button className="text-btn" onClick={() => setMake(false)}>{t("بستن", "Close")}</button>
        </div>
      )}
    </Screen>
  );
}

function FilesApp() {
  const phone = usePhone();
  const t = useT();
  const [folder, setFolder] = useState<string | null>(null);
  const [open, setOpen] = useState<string | null>(null);
  const items = phone.data.files.filter((f) => f.parent === folder);
  const cur = phone.data.files.find((f) => f.id === folder);
  const file = phone.data.files.find((f) => f.id === open);
  if (file && file.kind === "text") {
    return (
      <Screen title={file.name} back={() => setOpen(null)}>
        <textarea
          className="area"
          value={file.body || ""}
          onChange={(e) => phone.update((d) => ({ ...d, files: d.files.map((f) => (f.id === file.id ? { ...f, body: e.target.value } : f)) }))}
        />
      </Screen>
    );
  }
  return (
    <Screen
      title={cur?.name || t("فایل‌ها", "Files")}
      back={folder ? () => setFolder(cur?.parent ?? null) : undefined}
      right={
        <button
          className="text-btn"
          onClick={() => {
            const name = t("یادداشت تازه.txt", "Note.txt");
            phone.update((d) => ({ ...d, files: [...d.files, { id: uid("f"), name, kind: "text", parent: folder, body: "" }] }));
          }}
        >
          +
        </button>
      }
    >
      <Group>
        {items.map((f) => (
          <Row key={f.id} label={f.name} value={f.kind === "folder" ? "›" : ""} onClick={() => (f.kind === "folder" ? setFolder(f.id) : setOpen(f.id))} />
        ))}
      </Group>
      <button
        className="text-btn"
        onClick={() => phone.update((d) => ({ ...d, files: [...d.files, { id: uid("f"), name: t("پوشه", "Folder"), kind: "folder", parent: folder }] }))}
      >
        {t("پوشهٔ جدید", "New folder")}
      </button>
    </Screen>
  );
}
