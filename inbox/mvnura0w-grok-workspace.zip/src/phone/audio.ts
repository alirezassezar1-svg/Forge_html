export const TRACKS = [
  { id: "t1", title: "شب تیتانیوم", artist: "ALI", hue: "#5E5CE6" },
  { id: "t2", title: "باران شیشه", artist: "ALI", hue: "#64D2FF" },
  { id: "t3", title: "اتاق روشن", artist: "ALI", hue: "#FF9F0A" },
  { id: "t4", title: "کویر آرام", artist: "ALI", hue: "#C4A484" },
];

type Listener = () => void;
const listeners = new Set<Listener>();

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let timer: number | null = null;
let step = 0;
let playing = false;
let trackIndex = 0;
let volume = 0.7;

function emit() {
  listeners.forEach((fn) => fn());
}

function ensure() {
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = volume * 0.15;
    master.connect(ctx.destination);
  }
  return ctx;
}

const PATTERNS: number[][] = [
  [220, 277, 330, 277, 196, 247, 294, 247],
  [196, 247, 294, 392, 294, 247, 220, 196],
  [262, 330, 392, 330, 294, 349, 440, 349],
  [174, 220, 262, 220, 196, 233, 294, 233],
];

function blip(freq: number, dur: number, type: OscillatorType, gain: number) {
  if (!ctx || !master) return;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = type;
  o.frequency.value = freq;
  g.gain.setValueAtTime(gain, ctx.currentTime);
  g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + dur);
  o.connect(g);
  g.connect(master);
  o.start();
  o.stop(ctx.currentTime + dur + 0.02);
}

function tickMusic() {
  if (!playing || !ctx) return;
  const pat = PATTERNS[trackIndex % PATTERNS.length]!;
  const freq = pat[step % pat.length]!;
  blip(freq, 0.28, "triangle", 0.9);
  if (step % 2 === 0) blip(freq / 2, 0.32, "sine", 0.45);
  step += 1;
}

export const music = {
  tracks: TRACKS,
  get playing() {
    return playing;
  },
  get trackIndex() {
    return trackIndex;
  },
  get track() {
    return TRACKS[trackIndex]!;
  },
  subscribe(fn: Listener) {
    listeners.add(fn);
    return () => {
      listeners.delete(fn);
    };
  },
  setVolume(v: number) {
    volume = v;
    if (master && ctx) master.gain.value = v * 0.15;
  },
  async toggle() {
    const c = ensure();
    if (c.state === "suspended") await c.resume();
    playing = !playing;
    if (playing) {
      if (timer == null) timer = window.setInterval(tickMusic, 320);
      tickMusic();
    } else if (timer != null) {
      window.clearInterval(timer);
      timer = null;
    }
    emit();
  },
  async playIndex(i: number) {
    trackIndex = (i + TRACKS.length) % TRACKS.length;
    step = 0;
    if (!playing) await music.toggle();
    else emit();
  },
  next() {
    trackIndex = (trackIndex + 1) % TRACKS.length;
    step = 0;
    emit();
  },
  prev() {
    trackIndex = (trackIndex - 1 + TRACKS.length) % TRACKS.length;
    step = 0;
    emit();
  },
};

export function tapSound(enabled: boolean) {
  if (!enabled) return;
  try {
    const c = ensure();
    if (c.state === "suspended") void c.resume();
    blip(880, 0.04, "sine", 0.25);
    if (navigator.vibrate) navigator.vibrate(8);
  } catch {
    /* ignore */
  }
}

export function beepAlarm() {
  try {
    const c = ensure();
    if (c.state === "suspended") void c.resume();
    blip(880, 0.18, "sine", 1);
    window.setTimeout(() => blip(1175, 0.22, "sine", 1), 200);
  } catch {
    /* ignore */
  }
}

export function padHit(freq: number) {
  try {
    const c = ensure();
    if (c.state === "suspended") void c.resume();
    blip(freq, 0.18, "square", 0.35);
  } catch {
    /* ignore */
  }
}
