import { useEffect, useRef, useState } from "react";
import { AppView } from "./apps";
import { music, tapSound } from "./audio";
import { IosIcon } from "./icons";
import { APPS, DOCK, faNum, formatClock, formatLockDate, available, type PhoneData } from "./model";
import { PhoneProvider, usePhone } from "./store";

const FINISH: Record<PhoneData["finish"], { bg: string; btn: string }> = {
  black: { bg: "linear-gradient(180deg,#4a4946 0%,#2a2927 18%,#161514 60%,#0c0b0a)", btn: "#3a3937" },
  natural: { bg: "linear-gradient(180deg,#d5cfc7,#9a948c 40%,#6e6860)", btn: "#b7b1a9" },
  desert: { bg: "linear-gradient(180deg,#f0d2b4,#c49a70 38%,#8a5e3c)", btn: "#d7b08a" },
  white: { bg: "linear-gradient(180deg,#ffffff,#e4e4ea 50%,#c8c8d0)", btn: "#f2f2f6" },
};

export function Phone() {
  return (
    <PhoneProvider>
      <Stage />
    </PhoneProvider>
  );
}

function Stage() {
  const phone = usePhone();
  const [fit, setFit] = useState({ mode: "desk" as "desk" | "fill", scale: 0.72 });
  useEffect(() => {
    const measure = () => {
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      if (vw < 560) setFit({ mode: "fill", scale: 1 });
      else setFit({ mode: "desk", scale: Math.max(0.34, Math.min((vw - 36) / 476, (vh - 24) / 992, 1)) });
    };
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  const inner = <ScreenBody />;
  if (fit.mode === "fill") {
    return (
      <div className="ali">
        <div className="screen fill">{inner}</div>
      </div>
    );
  }
  const fin = FINISH[phone.data.finish];
  return (
    <div className="ali">
      <div className="stage" style={{ transform: `scale(${fit.scale})` }}>
        <div className="chassis" style={{ background: fin.bg }}>
          <button className="side-btn action" style={{ background: fin.btn }} aria-label="Action" onClick={() => phone.update({ flashlight: !phone.data.flashlight })} />
          <button className="side-btn silent" style={{ background: fin.btn }} aria-label="Silent" onClick={() => phone.update({ silent: !phone.data.silent })} />
          <button className="side-btn vol-up" style={{ background: fin.btn }} aria-label="Volume up" onClick={() => phone.update({ volume: Math.min(1, phone.data.volume + 0.1) })} />
          <button className="side-btn vol-down" style={{ background: fin.btn }} aria-label="Volume down" onClick={() => phone.update({ volume: Math.max(0, phone.data.volume - 0.1) })} />
          <button className="side-btn power" style={{ background: fin.btn }} aria-label="Lock" onClick={() => phone.setLocked(true)} />
          <button className="side-btn camera" style={{ background: fin.btn }} aria-label="Camera" onClick={() => phone.openApp("camera")} />
          <div className="screen">{inner}</div>
        </div>
      </div>
    </div>
  );
}

function ScreenBody() {
  const phone = usePhone();
  const { data, lang } = phone;
  const paperLight = data.wallpaper.includes("mist");
  const inkOnGlass = paperLight ? "dark" : "light";
  const [cc, setCc] = useState(false);
  const [nc, setNc] = useState(false);
  const [spot, setSpot] = useState(false);
  const [switcher, setSwitcher] = useState(false);
  const [editing, setEditing] = useState(false);
  const [menu, setMenu] = useState<{ id: string; x: number; y: number } | null>(null);
  const [page, setPage] = useState(0);
  const [dragX, setDragX] = useState(0);
  const [dragging, setDragging] = useState(false);
  const [islandOpen, setIslandOpen] = useState(false);
  const hold = useRef<number | null>(null);
  void hold;
  const sound = !data.silent;

  const home = data.home.filter((id) => available(data, id));
  const pages = Math.max(1, Math.ceil(home.length / 24));
  const pageCount = pages + 1;

  useEffect(() => {
    if (page > pageCount - 1) setPage(pageCount - 1);
  }, [page, pageCount]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.key === "Escape") {
        if (cc || nc || spot || menu) {
          setCc(false);
          setNc(false);
          setSpot(false);
          setMenu(null);
        } else if (switcher) setSwitcher(false);
        else if (phone.app) phone.closeApp();
        else if (phone.locked) phone.setLocked(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [cc, nc, spot, menu, switcher, phone]);

  function goHome() {
    setSwitcher(false);
    setCc(false);
    setNc(false);
    setSpot(false);
    setMenu(null);
    setEditing(false);
    if (phone.app) phone.closeApp();
    else setSwitcher(true);
  }

  const rtl = lang === "fa";
  const ccSide = rtl ? "left" : "right";
  const ncSide = rtl ? "right" : "left";

  return (
    <>
      <div className="wall" style={{ backgroundImage: `url(${data.wallpaper})` }} />
      <div className="safe" dir={rtl ? "rtl" : "ltr"}>
        {!phone.locked && !phone.app && (
          <Home
            page={page}
            pages={pages}
            pageCount={pageCount}
            dragX={dragX}
            dragging={dragging}
            editing={editing}
            paperLight={paperLight}
            onDrag={(x, active) => {
              setDragX(x);
              setDragging(active);
            }}
            onPage={(p) => setPage(Math.max(0, Math.min(pageCount - 1, p)))}
            onEdit={setEditing}
            onMenu={setMenu}
            onSpot={() => setSpot(true)}
          />
        )}
        {phone.app && !phone.locked && <AppView id={phone.app} />}
        {switcher && !phone.locked && (
          <div className="switcher" onClick={() => setSwitcher(false)}>
            {phone.recents.length === 0 && <div style={{ margin: "auto", opacity: 0.8 }}>{rtl ? "برنامهٔ بازی نیست" : "No open apps"}</div>}
            {phone.recents.map((id) => (
              <div key={id} style={{ position: "relative" }} onClick={(e) => e.stopPropagation()}>
                <button
                  className="card-app"
                  style={{ backgroundImage: `url(${data.wallpaper})` }}
                  onClick={() => {
                    phone.openApp(id);
                    setSwitcher(false);
                  }}
                >
                  <IosIcon id={id} now={phone.now} web={phone.web(id)} />
                  <b>{phone.nameOf(id)}</b>
                </button>
                <button className="kill" aria-label="close" onClick={() => phone.closeRecent(id)} style={{ position: "absolute" }}>
                  ×
                </button>
              </div>
            ))}
          </div>
        )}
        {phone.locked && (
          <Lock
            ink={inkOnGlass}
            onUnlock={() => {
              tapSound(sound);
              phone.setLocked(false);
            }}
          />
        )}
        <Status ink={phone.app && !phone.locked ? "light" : inkOnGlass} hideTime={phone.locked} />
        <Island open={islandOpen} onToggle={() => setIslandOpen((v) => !v)} />
        <button className={`hot ${ncSide}`} aria-label="notifications" onPointerDown={(e) => startEdge(e, () => setNc(true))} />
        <button className={`hot ${ccSide}`} aria-label="control center" onPointerDown={(e) => startEdge(e, () => setCc(true))} />
        {editing && (
          <button className="done-pill" onClick={() => setEditing(false)}>
            {rtl ? "تمام" : "Done"}
          </button>
        )}
        {nc && <Notifications onClose={() => setNc(false)} />}
        {cc && <Control onClose={() => setCc(false)} onLock={() => { setCc(false); phone.setLocked(true); }} />}
        {spot && <Spotlight onClose={() => setSpot(false)} />}
        {menu && (
          <ContextMenu
            id={menu.id}
            x={menu.x}
            y={menu.y}
            onClose={() => setMenu(null)}
            onEdit={() => {
              setEditing(true);
              setMenu(null);
            }}
          />
        )}
        {phone.ringing && (
          <div className="alarm-banner">
            <b>{phone.ringing.label}</b>
            <div>{rtl ? "زنگ" : "Alarm"}</div>
            <button onClick={phone.dismissAlarm}>{rtl ? "متوقف کن" : "Stop"}</button>
          </div>
        )}
        <div className={`home-ind ${paperLight && !phone.app ? "dark" : ""}`} />
        <button
          className="home-hit"
          aria-label={rtl ? "خانه" : "Home"}
          onClick={() => {
            tapSound(sound);
            goHome();
          }}
          onPointerDown={(e) => {
            const y0 = e.clientY;
            const start = Date.now();
            const move = (ev: PointerEvent) => {
              if (y0 - ev.clientY > 40) {
                cleanup();
                setSwitcher(true);
                if (phone.app) phone.closeApp();
              }
            };
            const up = () => {
              if (Date.now() - start > 450) setSwitcher(true);
              cleanup();
            };
            const cleanup = () => {
              window.removeEventListener("pointermove", move);
              window.removeEventListener("pointerup", up);
            };
            window.addEventListener("pointermove", move);
            window.addEventListener("pointerup", up);
          }}
        />
      </div>
      <div className="dimmer" style={{ opacity: (1 - data.brightness) * 0.72 }} />
      {data.flashlight && <div className="torch" />}
    </>
  );
}

function startEdge(e: React.PointerEvent, open: () => void) {
  const y0 = e.clientY;
  const move = (ev: PointerEvent) => {
    if (ev.clientY - y0 > 24) {
      open();
      cleanup();
    }
  };
  const cleanup = () => {
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", cleanup);
  };
  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", cleanup);
}

function Status({ ink, hideTime }: { ink: "light" | "dark"; hideTime: boolean }) {
  const { data, now, battery, lang } = usePhone();
  const bars = data.airplane ? 0 : data.cellular ? 4 : 1;
  return (
    <div className={`status ${ink}`}>
      <span>{hideTime ? "" : formatClock(now ?? new Date(2026, 9, 23, 9, 41), lang)}</span>
      <span className="status-sys">
        {data.silent && <span aria-hidden>☾</span>}
        {data.airplane ? (
          <span aria-label="airplane">✈</span>
        ) : (
          <>
            <span className="sig" aria-hidden>
              {[4, 6, 8, 11].map((h, i) => (
                <i key={h} className={i < bars ? "" : "off"} style={{ height: h }} />
              ))}
            </span>
            <span aria-hidden style={{ opacity: data.wifi ? 1 : 0.35 }}>
              ⌂
            </span>
          </>
        )}
        <span className={`bat ${data.lowPower ? "low" : ""}`} aria-label="battery">
          <b style={{ width: `${Math.max(8, battery)}%` }} />
        </span>
      </span>
    </div>
  );
}

function Island({ open, onToggle }: { open: boolean; onToggle: () => void }) {
  useMusicTick();
  const phone = usePhone();
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let on = false;
    const id = window.setInterval(() => {
      on = !on;
      setTick((n) => n + (on ? 1 : 0));
    }, 400);
    return () => window.clearInterval(id);
  }, []);
  void tick;
  const { call, timer, now, data, lang } = phone;
  let title = "";
  let sub = "";
  let showEq = false;
  if (call) {
    const sec = Math.max(0, Math.floor((Date.now() - call.started) / 1000));
    title = call.name || call.number;
    sub = faNum(`${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`, lang);
  } else if (data.flashlight) {
    title = lang === "fa" ? "چراغ‌قوه" : "Flashlight";
    sub = lang === "fa" ? "روشن" : "On";
  } else if (timer && now) {
    const left = Math.max(0, Math.ceil((timer.endsAt - now.getTime()) / 1000));
    title = lang === "fa" ? "زمان‌سنج" : "Timer";
    sub = faNum(`${Math.floor(left / 60)}:${String(left % 60).padStart(2, "0")}`, lang);
  }
  const activeCall = Boolean(call || data.flashlight || (timer && now) || music.playing);
  if (music.playing && !call) {
    title = music.track.title;
    sub = music.track.artist;
    showEq = true;
  }
  if (!activeCall && !open) {
    return <button className="island" aria-label="Dynamic Island" onClick={onToggle} />;
  }
  return (
    <button className={`island ${open ? "open" : ""}`} onClick={onToggle} aria-label="Dynamic Island">
      {showEq && (
        <span className="eq">
          <i /><i /><i />
        </span>
      )}
      <span style={{ textAlign: "start" }}>
        <div className="island-title">{title || (lang === "fa" ? "ALI Phone" : "ALI Phone")}</div>
        {open && <div className="island-sub">{sub || (lang === "fa" ? "جزیره پویا" : "Dynamic Island")}</div>}
      </span>
      {!open && <span className="island-sub">{sub}</span>}
    </button>
  );
}

function Home({
  page,
  pages,
  pageCount,
  dragX,
  dragging,
  editing,
  paperLight,
  onDrag,
  onPage,
  onEdit,
  onMenu,
  onSpot,
}: {
  page: number;
  pages: number;
  pageCount: number;
  dragX: number;
  dragging: boolean;
  editing: boolean;
  paperLight: boolean;
  onDrag: (x: number, active: boolean) => void;
  onPage: (p: number) => void;
  onEdit: (v: boolean) => void;
  onMenu: (m: { id: string; x: number; y: number } | null) => void;
  onSpot: () => void;
}) {
  const phone = usePhone();
  const home = phone.data.home.filter((id) => available(phone.data, id));
  const origin = useRef<{ x: number; y: number; page: number } | null>(null);
  const long = useRef<number | null>(null);

  function cells(p: number) {
    const slice = home.slice(p * 24, p * 24 + 24);
    const out = slice.slice();
    while (out.length < 24) out.push("");
    return out;
  }

  return (
    <div
      className={`home ${editing ? "editing" : ""}`}
      onPointerDown={(e) => {
        if ((e.target as HTMLElement).closest("button")) {
          const btn = (e.target as HTMLElement).closest("button");
          const id = btn?.getAttribute("data-app");
          if (id && !editing) {
            long.current = window.setTimeout(() => {
              const r = btn!.getBoundingClientRect();
              onMenu({ id, x: r.left, y: r.bottom + 6 });
            }, 480);
          }
          return;
        }
        origin.current = { x: e.clientX, y: e.clientY, page };
      }}
      onPointerMove={(e) => {
        if (!origin.current) return;
        const dx = e.clientX - origin.current.x;
        const dy = e.clientY - origin.current.y;
        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
          if (long.current) window.clearTimeout(long.current);
        }
        if (Math.abs(dx) > 12 && Math.abs(dx) > Math.abs(dy)) onDrag(dx, true);
      }}
      onPointerUp={(e) => {
        if (long.current) window.clearTimeout(long.current);
        if (!origin.current) return;
        const dx = e.clientX - origin.current.x;
        const dy = e.clientY - origin.current.y;
        if (dragging) {
          if (dx < -50) onPage(origin.current.page + 1);
          else if (dx > 50) onPage(origin.current.page - 1);
          onDrag(0, false);
        } else if (dy > 50 && Math.abs(dy) > Math.abs(dx) && origin.current.y > 70) {
          onSpot();
        }
        origin.current = null;
      }}
      onPointerCancel={() => {
        origin.current = null;
        onDrag(0, false);
      }}
    >
      <div className="pager" dir="ltr">
        <div
          className={`pager-track ${dragging ? "drag" : ""}`}
          style={{ transform: `translateX(calc(${-page * 100}% + ${dragX}px))` }}
        >
          {Array.from({ length: pages }).map((_, p) => (
            <div className="page" key={p} dir={phone.rtl ? "rtl" : "ltr"}>
              <div className="page-grid">
                {cells(p).map((id, i) =>
                  id ? (
                    <AppIcon
                      key={id}
                      id={id}
                      editing={editing}
                      paperLight={paperLight}
                      onOpen={() => {
                        if (editing) return;
                        tapSound(!phone.data.silent);
                        phone.openApp(id);
                      }}
                    />
                  ) : (
                    <div key={`e${p}-${i}`} className="icon-btn" />
                  ),
                )}
              </div>
            </div>
          ))}
          <div className="page" dir={phone.rtl ? "rtl" : "ltr"}>
            <Library paperLight={paperLight} onEdit={() => onEdit(true)} />
          </div>
        </div>
      </div>
      <div className={`dots ${paperLight ? "dark" : ""}`}>
        {Array.from({ length: pageCount }).map((_, i) => (
          <i key={i} className={i === page ? "on" : ""} />
        ))}
      </div>
      <div className="dock-wrap">
        <div className="dock-pill" />
        <div className="dock-grid" dir={phone.rtl ? "rtl" : "ltr"}>
          {DOCK.map((id) => (
            <AppIcon
              key={id}
              id={id}
              labeled={false}
              editing={false}
              paperLight={paperLight}
              onOpen={() => {
                tapSound(!phone.data.silent);
                phone.openApp(id);
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function AppIcon({
  id,
  onOpen,
  editing,
  paperLight,
  labeled = true,
}: {
  id: string;
  onOpen: () => void;
  editing: boolean;
  paperLight: boolean;
  labeled?: boolean;
}) {
  const phone = usePhone();
  const removable = !(DOCK as readonly string[]).includes(id);
  return (
    <button className="icon-btn" data-app={id} aria-label={phone.nameOf(id)} onClick={onOpen}>
      {editing && removable && (
        <span
          className="xbtn"
          onClick={(e) => {
            e.stopPropagation();
            phone.uninstall(id);
          }}
        >
          ×
        </span>
      )}
      <IosIcon id={id} now={phone.now} web={phone.web(id)} />
      {id === "messages" && phone.unread > 0 && <span className="badge">{faNum(phone.unread, phone.lang)}</span>}
      {id === "calendar" ? null : null}
      {labeled && <span className={`label ${paperLight ? "dark" : ""}`}>{phone.nameOf(id)}</span>}
    </button>
  );
}

function Library({ paperLight, onEdit }: { paperLight: boolean; onEdit: () => void }) {
  const phone = usePhone();
  const [q, setQ] = useState("");
  const ids = Object.keys(APPS).filter((id) => available(phone.data, id));
  const webs = phone.data.webApps.map((w) => w.id);
  const all = [...ids, ...webs].filter((id) => phone.nameOf(id).toLowerCase().includes(q.trim().toLowerCase()));
  const cats = [
    { id: "main", fa: "اصلی", en: "Main" },
    { id: "life", fa: "زندگی", en: "Life" },
    { id: "tools", fa: "ابزارها", en: "Tools" },
    { id: "create", fa: "ساختن", en: "Create" },
  ] as const;
  return (
    <div className="lib">
      <input className={`search ${paperLight ? "dark" : ""}`} placeholder={phone.rtl ? "کتابخانه برنامه" : "App Library"} value={q} onChange={(e) => setQ(e.target.value)} />
      {q ? (
        <div className="lib-grid" style={{ marginTop: 16 }}>
          {all.map((id) => (
            <AppIcon key={id} id={id} editing={false} paperLight={paperLight} onOpen={() => phone.openApp(id)} />
          ))}
        </div>
      ) : (
        cats.map((c) => {
          const list = all.filter((id) => APPS[id]?.cat === c.id || (id.startsWith("web:") && c.id === "create"));
          if (!list.length) return null;
          return (
            <section key={c.id}>
              <h3>{phone.rtl ? c.fa : c.en}</h3>
              <div className="lib-grid">
                {list.map((id) => (
                  <AppIcon key={id} id={id} editing={false} paperLight={paperLight} onOpen={() => phone.openApp(id)} />
                ))}
              </div>
            </section>
          );
        })
      )}
      <button className="text-btn" onClick={onEdit} style={{ color: "#fff" }}>
        {phone.rtl ? "ویرایش صفحهٔ اصلی" : "Edit Home Screen"}
      </button>
    </div>
  );
}

function ContextMenu({ id, x, y, onClose, onEdit }: { id: string; x: number; y: number; onClose: () => void; onEdit: () => void }) {
  const phone = usePhone();
  const core = Boolean(APPS[id]?.core);
  return (
    <>
      <div style={{ position: "absolute", inset: 0, zIndex: 35 }} onClick={onClose} />
      <div className="menu" style={{ left: Math.min(x, 220), top: Math.min(y, 520) }}>
        <button
          onClick={() => {
            phone.openApp(id);
            onClose();
          }}
        >
          {phone.rtl ? "باز کردن" : "Open"}
        </button>
        <button onClick={onEdit}>{phone.rtl ? "ویرایش صفحهٔ اصلی" : "Edit Home Screen"}</button>
        {!(DOCK as readonly string[]).includes(id) && (
          <button
            className="danger"
            onClick={() => {
              phone.uninstall(id);
              onClose();
            }}
          >
            {core ? (phone.rtl ? "حذف از صفحهٔ اصلی" : "Remove from Home") : phone.rtl ? "حذف اپ" : "Delete App"}
          </button>
        )}
      </div>
    </>
  );
}

function Lock({ ink, onUnlock }: { ink: "light" | "dark"; onUnlock: () => void }) {
  const phone = usePhone();
  const d = phone.now ?? new Date(2026, 9, 23, 9, 41);
  const y0 = useRef(0);
  return (
    <div
      className={`lock ${ink === "dark" ? "dark-ink" : ""}`}
      onPointerDown={(e) => {
        y0.current = e.clientY;
      }}
      onPointerUp={(e) => {
        if (y0.current - e.clientY > 50) onUnlock();
      }}
    >
      <div className="lock-date">{formatLockDate(d, phone.lang)}</div>
      <div className="lock-time">{formatClock(d, phone.lang)}</div>
      <div className="lock-shortcuts">
        <button
          className={phone.data.flashlight ? "on" : ""}
          aria-label="flashlight"
          onClick={(e) => {
            e.stopPropagation();
            phone.update({ flashlight: !phone.data.flashlight });
          }}
        >
          <Flash />
        </button>
        <button
          aria-label="camera"
          onClick={(e) => {
            e.stopPropagation();
            phone.openApp("camera");
          }}
        >
          <Cam />
        </button>
      </div>
      <button className="unlock" aria-label={phone.rtl ? "باز کردن" : "Unlock"} onClick={onUnlock}>
        <i className="chevron" />
        <small>{phone.rtl ? "برای باز کردن به بالا بکشید" : "Swipe up to open"}</small>
      </button>
    </div>
  );
}

function Control({ onClose, onLock }: { onClose: () => void; onLock: () => void }) {
  const phone = usePhone();
  const d = phone.data;
  const t = (fa: string, en: string) => (phone.rtl ? fa : en);
  return (
    <div className="sheet" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()}>
        <div className="cc-grid">
          <div className="cc-card">
            <div className="conn">
              <button className={`bubble ${d.airplane ? "orange on" : ""}`} aria-label="airplane" onClick={() => phone.update({ airplane: !d.airplane, wifi: d.airplane ? d.wifi : false })}>✈</button>
              <button className={`bubble blue ${d.cellular && !d.airplane ? "on" : ""}`} aria-label="cellular" onClick={() => phone.update({ cellular: !d.cellular, airplane: false })}>▮</button>
              <button className={`bubble blue ${d.wifi && !d.airplane ? "on" : ""}`} aria-label="wifi" onClick={() => phone.update({ wifi: !d.wifi, airplane: false })}>⌂</button>
              <button className={`bubble blue ${d.bluetooth ? "on" : ""}`} aria-label="bluetooth" onClick={() => phone.update({ bluetooth: !d.bluetooth })}>✦</button>
            </div>
          </div>
          <NowCard />
        </div>
        <div className="sliders">
          <VSlider value={d.brightness} label="☼" onChange={(v) => phone.update({ brightness: Math.max(0.25, v) })} />
          <VSlider value={d.volume} label="♪" onChange={(v) => phone.update({ volume: v })} />
        </div>
        <div className="cc-round">
          <button className={`bubble ${d.flashlight ? "on" : ""}`} aria-label="flashlight" onClick={() => phone.update({ flashlight: !d.flashlight })}><Flash /></button>
          <button className="bubble" aria-label="timer" onClick={() => { onClose(); phone.openApp("clock"); }}>◷</button>
          <button className="bubble" aria-label="calculator" onClick={() => { onClose(); phone.openApp("calculator"); }}>＝</button>
          <button className="bubble" aria-label="camera" onClick={() => { onClose(); phone.openApp("camera"); }}><Cam /></button>
          <button className={`bubble ${d.lowPower ? "on" : ""}`} aria-label="low power" onClick={() => phone.update({ lowPower: !d.lowPower })}>⌁</button>
          <button className={`bubble ${d.silent ? "red on" : ""}`} aria-label="silent" onClick={() => phone.update({ silent: !d.silent })}>☾</button>
          <button className="bubble" aria-label="lock" onClick={onLock}>🔒</button>
          <button className="bubble" onClick={() => { onClose(); phone.openApp("settings"); }}>⚙</button>
        </div>
        <p style={{ textAlign: "center", color: "#ddd", fontSize: 13 }}>{t("برای بستن ضربه بزنید", "Tap outside to close")}</p>
      </div>
    </div>
  );
}

function useMusicTick() {
  const [n, setN] = useState(0);
  useEffect(() => music.subscribe(() => setN((x) => x + 1)), []);
  return n;
}

function NowCard() {
  useMusicTick();
  const tr = music.track;
  return (
    <div className="cc-card np-mini">
      <div>
        <b>{tr.title}</b>
        <div>
          <em>{tr.artist}</em>
        </div>
      </div>
      <button className="bubble on" aria-label="play" onClick={() => void music.toggle()}>
        {music.playing ? "❚❚" : "▶"}
      </button>
    </div>
  );
}

function VSlider({ value, onChange, label }: { value: number; onChange: (v: number) => void; label: string }) {
  const ref = useRef<HTMLDivElement>(null);
  function setFrom(clientY: number) {
    const r = ref.current!.getBoundingClientRect();
    const p = 1 - (clientY - r.top) / r.height;
    onChange(Math.min(1, Math.max(0, p)));
  }
  return (
    <div
      className="vsl"
      ref={ref}
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        setFrom(e.clientY);
      }}
      onPointerMove={(e) => {
        if (e.currentTarget.hasPointerCapture(e.pointerId)) setFrom(e.clientY);
      }}
    >
      <div className="vsl-fill" style={{ height: `${value * 100}%` }} />
      <span>{label}</span>
    </div>
  );
}

function Notifications({ onClose }: { onClose: () => void }) {
  const phone = usePhone();
  const items = [
    { app: "messages", title: phone.rtl ? "سارا نادری" : "Sara", body: phone.rtl ? "فردا ساعت ۱۰ همون کافه؟" : "Same café at 10?" },
    { app: "calendar", title: phone.rtl ? "تقویم" : "Calendar", body: phone.rtl ? "قرار کافه · ۱۰:۰۰" : "Café · 10:00" },
    { app: "mail", title: "ALI Phone", body: phone.rtl ? "به آیفون مجازی خوش آمدی" : "Welcome to your virtual iPhone" },
  ];
  return (
    <div className="sheet notes-panel" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()}>
        <h2 className="large" style={{ color: "#fff" }}>{phone.rtl ? "اعلان‌ها" : "Notifications"}</h2>
        {items.map((n) => (
          <button
            key={n.title}
            className="note-card"
            onClick={() => {
              phone.openApp(n.app);
              onClose();
            }}
          >
            <b>{n.title}</b>
            <span>{n.body}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function Spotlight({ onClose }: { onClose: () => void }) {
  const phone = usePhone();
  const [q, setQ] = useState("");
  const apps = [...Object.keys(APPS).filter((id) => available(phone.data, id)), ...phone.data.webApps.map((w) => w.id)].filter((id) =>
    phone.nameOf(id).toLowerCase().includes(q.trim().toLowerCase()),
  );
  const notes = phone.data.notes.filter((n) => (n.title + n.body).includes(q.trim()));
  return (
    <div className="spot">
      <input className="search" autoFocus placeholder={phone.rtl ? "جستجو" : "Search"} value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="app-scroll">
        {apps.slice(0, 8).map((id) => (
          <button key={id} className="spot-hit" onClick={() => { phone.openApp(id); onClose(); }}>
            <IosIcon id={id} now={phone.now} web={phone.web(id)} />
            {phone.nameOf(id)}
          </button>
        ))}
        {q && notes.map((n) => (
          <button key={n.id} className="spot-hit" onClick={() => { phone.openApp("notes"); onClose(); }}>
            {n.title}
          </button>
        ))}
      </div>
      <button className="text-btn" onClick={onClose}>{phone.rtl ? "بستن" : "Cancel"}</button>
    </div>
  );
}

function Flash() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z" />
    </svg>
  );
}
function Cam() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
      <path d="M4 8h3l2-3h6l2 3h3v11H4z" />
      <circle cx="12" cy="13" r="3.2" />
    </svg>
  );
}
