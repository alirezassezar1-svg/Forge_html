import { useId } from "react";
import type { WebApp } from "./model";

function hands(now: Date | null) {
  const d = now ?? new Date(2026, 9, 23, 9, 41, 0);
  const h = (d.getHours() % 12) + d.getMinutes() / 60;
  const m = d.getMinutes() + d.getSeconds() / 60;
  const s = d.getSeconds();
  return { h: h * 30, m: m * 6, s: s * 6 };
}

export function IosIcon({
  id,
  now,
  web,
}: {
  id: string;
  now: Date | null;
  web?: WebApp;
}) {
  const uid = useId().replace(/:/g, "");
  if (web || id.startsWith("web:")) {
    const color = web?.color ?? "#0A84FF";
    const letter = (web?.name || "W").slice(0, 1);
    return (
      <span className="ios-glyph" aria-hidden>
        <svg viewBox="0 0 60 60">
          <rect width="60" height="60" fill={color} />
          <text x="30" y="39" textAnchor="middle" fontSize="28" fontWeight="700" fill="#fff" fontFamily="system-ui">
            {letter}
          </text>
        </svg>
      </span>
    );
  }

  const { h, m, s } = hands(now);
  const day = now ? now.getDate() : 23;

  return (
    <span className="ios-glyph" aria-hidden>
      <svg viewBox="0 0 60 60">
        {id === "phone" && (
          <>
            <defs>
              <linearGradient id={`${uid}g`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor="#5BF675" />
                <stop offset="1" stopColor="#1EBE45" />
              </linearGradient>
            </defs>
            <rect width="60" height="60" fill={`url(#${uid}g)`} />
            <path
              fill="#fff"
              d="M18.2 14.6c1.2-1.2 3.1-1.3 4.4-.2l3.4 2.9c1.1.9 1.3 2.5.5 3.7l-1.8 2.6a2 2 0 0 0-.1 1.9c1.2 2.4 3.1 4.6 5.4 6.4 1.6 1.2 3.4 2.1 5.4 2.7.6.2 1.3 0 1.7-.5l2-2.6c.8-1.1 2.4-1.3 3.6-.6l3.6 2.4c1.4 1 1.7 2.9.8 4.3l-1.6 2.4c-1.2 1.8-3.2 2.9-5.4 3-6.2.2-12.2-3.4-17.1-8.6-4.6-4.9-7.6-10.8-7-16.4.2-2 .1-3.4 1.2-4.4z"
            />
          </>
        )}
        {id === "messages" && (
          <>
            <defs>
              <linearGradient id={`${uid}g`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor="#5BF675" />
                <stop offset="1" stopColor="#1EBE45" />
              </linearGradient>
            </defs>
            <rect width="60" height="60" fill={`url(#${uid}g)`} />
            <path fill="#fff" d="M30 12c10.5 0 19 7.4 19 16.5S40.5 45 30 45c-1.6 0-3.2-.2-4.7-.5L15 50l2.4-7.2C14.2 40.2 11 35.6 11 28.5 11 19.4 19.5 12 30 12z" />
          </>
        )}
        {id === "safari" && (
          <>
            <rect width="60" height="60" fill="#fff" />
            <circle cx="30" cy="30" r="20" fill="none" stroke="#d0e8ff" strokeWidth="4" />
            <g stroke="#8e8e93" strokeWidth="1">
              {Array.from({ length: 12 }).map((_, i) => (
                <line key={i} x1="30" y1="12" x2="30" y2={i % 3 === 0 ? 16 : 14.5} transform={`rotate(${i * 30} 30 30)`} />
              ))}
            </g>
            <polygon points="30,14 33.2,30 30,33" fill="#ff3b30" />
            <polygon points="30,46 26.8,30 30,27" fill="#e8eef5" stroke="#c5ced8" strokeWidth="0.4" />
            <circle cx="30" cy="30" r="2.3" fill="#fff" stroke="#bfc6ce" />
          </>
        )}
        {id === "music" && (
          <>
            <defs>
              <linearGradient id={`${uid}g`} x1="0" y1="1" x2="1" y2="0">
                <stop offset="0" stopColor="#FB2C4B" />
                <stop offset="1" stopColor="#FF5A7A" />
              </linearGradient>
            </defs>
            <rect width="60" height="60" fill={`url(#${uid}g)`} />
            <path fill="#fff" d="M26 16h4v18.2a6.2 6.2 0 1 1-2.6-5V20l12-2.4V32a6.2 6.2 0 1 1-2.6-5V16.2L26 18.6V16z" />
          </>
        )}
        {id === "camera" && (
          <>
            <rect width="60" height="60" fill="#1c1c1e" />
            <circle cx="30" cy="32" r="12" fill="none" stroke="#8e8e93" strokeWidth="3" />
            <circle cx="30" cy="32" r="7" fill="#2c2c2e" stroke="#0A84FF" strokeWidth="2" />
            <circle cx="27.5" cy="29.5" r="2" fill="#9ad" opacity="0.8" />
            <rect x="18" y="14" width="10" height="5" rx="1.5" fill="#3a3a3c" />
            <circle cx="44" cy="18" r="2" fill="#FFD60A" />
          </>
        )}
        {id === "photos" && (
          <>
            <rect width="60" height="60" fill="#fff" />
            {["#FFD60A", "#FF9F0A", "#FF375F", "#BF5AF2", "#0A84FF", "#64D2FF", "#30D158", "#FF453A"].map((c, i) => (
              <ellipse key={c} cx="30" cy="16" rx="5.2" ry="9" fill={c} transform={`rotate(${i * 45} 30 30)`} />
            ))}
            <circle cx="30" cy="30" r="5" fill="#fff" />
          </>
        )}
        {id === "weather" && (
          <>
            <defs>
              <linearGradient id={`${uid}g`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor="#4DA3FF" />
                <stop offset="1" stopColor="#0A62E0" />
              </linearGradient>
            </defs>
            <rect width="60" height="60" fill={`url(#${uid}g)`} />
            <circle cx="24" cy="24" r="8" fill="#FFD60A" />
            <path fill="#fff" d="M18 36h22a7 7 0 0 0 1.2-13.9 9 9 0 0 0-17.4 2.2A6.5 6.5 0 0 0 18 36z" />
          </>
        )}
        {id === "clock" && (
          <>
            <rect width="60" height="60" fill="#000" />
            <circle cx="30" cy="30" r="20" fill="#fff" />
            <circle cx="30" cy="30" r="1.6" fill="#000" />
            <line x1="30" y1="30" x2="30" y2="16" stroke="#111" strokeWidth="2.2" strokeLinecap="round" transform={`rotate(${h} 30 30)`} />
            <line x1="30" y1="30" x2="30" y2="13" stroke="#111" strokeWidth="1.6" strokeLinecap="round" transform={`rotate(${m} 30 30)`} />
            <line x1="30" y1="32" x2="30" y2="13" stroke="#FF3B30" strokeWidth="1" strokeLinecap="round" transform={`rotate(${s} 30 30)`} />
          </>
        )}
        {id === "maps" && (
          <>
            <rect width="60" height="60" fill="#C8E6A0" />
            <path d="M0 38c10-8 18-4 28-8s16-2 32 6v24H0z" fill="#6EC8F0" />
            <path d="M8 10h18l6 14H14z" fill="#F4E3A0" />
            <rect x="26" y="0" width="7" height="42" fill="#fff" />
            <rect x="28.2" y="0" width="2.6" height="42" fill="#FFD60A" />
            <path d="M40 14c-4 0-6 3.2-6 6.4 0 4.6 6 10.6 6 10.6s6-6 6-10.6c0-3.2-2-6.4-6-6.4z" fill="#FF3B30" />
            <circle cx="40" cy="20.2" r="2.2" fill="#fff" />
          </>
        )}
        {id === "notes" && (
          <>
            <rect width="60" height="60" fill="#FFCC00" />
            <rect x="14" y="12" width="32" height="36" rx="2" fill="#fff" />
            <path d="M14 18h32" stroke="#FFCC00" strokeWidth="4" />
            <path d="M18 26h24M18 32h24M18 38h16" stroke="#E5E5EA" strokeWidth="2" strokeLinecap="round" />
          </>
        )}
        {id === "calendar" && (
          <>
            <rect width="60" height="60" fill="#fff" />
            <rect width="60" height="16" fill="#FF3B30" />
            <text x="30" y="46" textAnchor="middle" fontSize="26" fontWeight="700" fill="#1c1c1e" fontFamily="-apple-system, system-ui">
              {day}
            </text>
          </>
        )}
        {id === "reminders" && (
          <>
            <rect width="60" height="60" fill="#fff" />
            <circle cx="18" cy="20" r="5" fill="#0A84FF" />
            <path d="M16 20.2l1.4 1.4 3-3.2" stroke="#fff" strokeWidth="1.4" fill="none" />
            <rect x="27" y="17" width="20" height="3" rx="1.5" fill="#d1d1d6" />
            <circle cx="18" cy="32" r="5" fill="#FF9F0A" />
            <rect x="27" y="30" width="16" height="3" rx="1.5" fill="#d1d1d6" />
            <circle cx="18" cy="44" r="5" fill="#30D158" />
            <rect x="27" y="42" width="18" height="3" rx="1.5" fill="#d1d1d6" />
          </>
        )}
        {id === "appstore" && (
          <>
            <defs>
              <linearGradient id={`${uid}g`} x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stopColor="#1AA1FF" />
                <stop offset="1" stopColor="#0070F0" />
              </linearGradient>
            </defs>
            <rect width="60" height="60" fill={`url(#${uid}g)`} />
            <path d="M30 12l6 16h-5l4 14-16-18h6z" fill="#fff" />
          </>
        )}
        {id === "settings" && (
          <>
            <rect width="60" height="60" fill="#8E8E93" />
            <g fill="#fff">
              {Array.from({ length: 8 }).map((_, i) => (
                <rect key={i} x="27" y="10" width="6" height="8" rx="1.5" transform={`rotate(${i * 45} 30 30)`} />
              ))}
              <circle cx="30" cy="30" r="10" />
            </g>
            <circle cx="30" cy="30" r="5.5" fill="#8E8E93" />
          </>
        )}
        {id === "calculator" && (
          <>
            <rect width="60" height="60" fill="#1c1c1e" />
            <circle cx="18" cy="18" r="7" fill="#FF9F0A" />
            <path d="M18 14.5v7M14.5 18h7" stroke="#fff" strokeWidth="1.6" />
            <circle cx="42" cy="18" r="7" fill="#505055" />
            <path d="M39 18h6" stroke="#fff" strokeWidth="1.6" />
            <circle cx="18" cy="42" r="7" fill="#505055" />
            <path d="M15.2 42h5.6M18 39.2v5.6" stroke="#fff" strokeWidth="1.5" />
            <circle cx="42" cy="42" r="7" fill="#505055" />
            <path d="M39 42h6M42 39v6" stroke="#fff" strokeWidth="1.5" />
          </>
        )}
        {id === "files" && (
          <>
            <defs>
              <linearGradient id={`${uid}g`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor="#5AC8FA" />
                <stop offset="1" stopColor="#007AFF" />
              </linearGradient>
            </defs>
            <rect width="60" height="60" fill="#fff" />
            <path fill={`url(#${uid}g)`} d="M10 22a4 4 0 0 1 4-4h10l4 4h18a4 4 0 0 1 4 4v16a4 4 0 0 1-4 4H14a4 4 0 0 1-4-4V22z" />
          </>
        )}
        {id === "mail" && (
          <>
            <defs>
              <linearGradient id={`${uid}g`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor="#4DA3FF" />
                <stop offset="1" stopColor="#0A62E0" />
              </linearGradient>
            </defs>
            <rect width="60" height="60" fill={`url(#${uid}g)`} />
            <rect x="12" y="18" width="36" height="24" rx="3" fill="#fff" />
            <path d="M14 20l16 12L46 20" fill="none" stroke="#0A62E0" strokeWidth="2" />
          </>
        )}
        {id === "health" && (
          <>
            <rect width="60" height="60" fill="#fff" />
            <path fill="#FF2D55" d="M30 46s-14-8.6-14-16a8 8 0 0 1 14-4 8 8 0 0 1 14 4c0 7.4-14 16-14 16z" />
          </>
        )}
        {id === "wallet" && (
          <>
            <rect width="60" height="60" fill="#1c1c1e" />
            <rect x="12" y="28" width="36" height="18" rx="3" fill="#30D158" transform="rotate(-8 30 36)" />
            <rect x="12" y="22" width="36" height="18" rx="3" fill="#0A84FF" />
            <rect x="12" y="16" width="36" height="18" rx="3" fill="#fff" />
            <rect x="16" y="22" width="12" height="3" rx="1" fill="#e5e5ea" />
          </>
        )}
        {id === "stocks" && (
          <>
            <rect width="60" height="60" fill="#000" />
            <path d="M10 42l10-8 8 5 14-18 8 6" fill="none" stroke="#fff" strokeWidth="2.4" strokeLinejoin="round" strokeLinecap="round" />
            <path d="M40 16h10v10" fill="none" stroke="#30D158" strokeWidth="2.2" />
          </>
        )}
        {id === "translate" && (
          <>
            <rect width="60" height="60" fill="#1c1c1e" />
            <rect x="10" y="14" width="26" height="22" rx="6" fill="#0A84FF" />
            <text x="23" y="30" textAnchor="middle" fontSize="14" fontWeight="700" fill="#fff">
              A
            </text>
            <rect x="24" y="26" width="26" height="22" rx="6" fill="#FF9F0A" />
            <text x="37" y="42" textAnchor="middle" fontSize="13" fontWeight="700" fill="#fff">
              文
            </text>
          </>
        )}
        {id === "compass" && (
          <>
            <rect width="60" height="60" fill="#000" />
            <circle cx="30" cy="30" r="20" fill="#1c1c1e" stroke="#fff" strokeWidth="2" />
            <polygon points="30,14 33,30 30,32" fill="#FF3B30" />
            <polygon points="30,46 27,30 30,28" fill="#fff" />
            <circle cx="30" cy="30" r="2" fill="#000" stroke="#fff" />
          </>
        )}
        {id === "voicememo" && (
          <>
            <rect width="60" height="60" fill="#000" />
            <path
              d="M12 32h3l2-6 3 14 3-18 3 16 3-12 3 8 2-4h3"
              fill="none"
              stroke="#fff"
              strokeWidth="2"
              strokeLinejoin="round"
              strokeLinecap="round"
            />
            <circle cx="46" cy="20" r="4" fill="#FF3B30" />
          </>
        )}
        {id === "contacts" && (
          <>
            <rect width="60" height="60" fill="#8E8E93" />
            <circle cx="30" cy="24" r="8" fill="#fff" />
            <path fill="#fff" d="M14 48c2-8 8-12 16-12s14 4 16 12z" />
          </>
        )}
        {id === "books" && (
          <>
            <rect width="60" height="60" fill="#FF9500" />
            <path fill="#fff" d="M12 16h16c3 0 5 2 5 5v24c-2-2-4-3-7-3H12V16z" />
            <path fill="#fff5e6" d="M48 16H32c-3 0-5 2-5 5v24c2-2 4-3 7-3h14V16z" />
          </>
        )}
        {id === "podcasts" && (
          <>
            <defs>
              <linearGradient id={`${uid}g`} x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stopColor="#D07CFF" />
                <stop offset="1" stopColor="#7D2AE8" />
              </linearGradient>
            </defs>
            <rect width="60" height="60" fill={`url(#${uid}g)`} />
            <circle cx="30" cy="24" r="6" fill="#fff" />
            <path fill="#fff" d="M18 46c1.5-7 6-10 12-10s10.5 3 12 10z" />
            <path d="M14 28a16 16 0 0 1 32 0" fill="none" stroke="#fff" strokeWidth="2" opacity="0.85" />
          </>
        )}
        {id === "shortcuts" && (
          <>
            <defs>
              <linearGradient id={`${uid}g`} x1="0" y1="1" x2="1" y2="0">
                <stop offset="0" stopColor="#2E5BFF" />
                <stop offset="1" stopColor="#64D2FF" />
              </linearGradient>
            </defs>
            <rect width="60" height="60" fill={`url(#${uid}g)`} />
            <rect x="14" y="14" width="14" height="14" rx="4" fill="#fff" />
            <rect x="32" y="14" width="14" height="14" rx="4" fill="#FFD60A" />
            <rect x="14" y="32" width="14" height="14" rx="4" fill="#FF375F" />
            <rect x="32" y="32" width="14" height="14" rx="4" fill="#30D158" />
          </>
        )}
        {id === "fitness" && (
          <>
            <rect width="60" height="60" fill="#000" />
            <circle cx="30" cy="30" r="16" fill="none" stroke="#FF2D55" strokeWidth="4" strokeDasharray="70 40" strokeLinecap="round" transform="rotate(-80 30 30)" />
            <circle cx="30" cy="30" r="11" fill="none" stroke="#30D158" strokeWidth="4" strokeDasharray="48 30" strokeLinecap="round" transform="rotate(40 30 30)" />
            <circle cx="30" cy="30" r="6" fill="none" stroke="#64D2FF" strokeWidth="4" strokeDasharray="24 20" strokeLinecap="round" />
          </>
        )}
        {id === "news" && (
          <>
            <rect width="60" height="60" fill="#fff" />
            <text x="30" y="42" textAnchor="middle" fontSize="34" fontWeight="800" fill="#FF2D55" fontFamily="Georgia, serif">
              N
            </text>
          </>
        )}
        {id === "tv" && (
          <>
            <rect width="60" height="60" fill="#000" />
            <rect x="12" y="16" width="36" height="26" rx="4" fill="#1c1c1e" stroke="#fff" strokeWidth="1.4" />
            <polygon points="27,23 27,35 38,29" fill="#fff" />
          </>
        )}
        {id === "homeapp" && (
          <>
            <rect width="60" height="60" fill="#fff" />
            <path fill="#FF9F0A" d="M30 14l16 14h-4v14H18V28h-4z" />
            <rect x="26" y="32" width="8" height="10" fill="#fff" />
          </>
        )}
        {id === "find" && (
          <>
            <defs>
              <linearGradient id={`${uid}g`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor="#5BF675" />
                <stop offset="1" stopColor="#1EBE45" />
              </linearGradient>
            </defs>
            <rect width="60" height="60" fill={`url(#${uid}g)`} />
            <circle cx="30" cy="30" r="14" fill="none" stroke="#fff" strokeWidth="2" opacity="0.85" />
            <circle cx="30" cy="30" r="8" fill="none" stroke="#fff" strokeWidth="2" />
            <circle cx="30" cy="30" r="3" fill="#fff" />
          </>
        )}
        {id === "journal" && (
          <>
            <rect width="60" height="60" fill="#FFD6E8" />
            <rect x="16" y="12" width="28" height="36" rx="3" fill="#fff" />
            <path d="M22 22h16M22 28h16M22 34h10" stroke="#FF2D55" strokeWidth="1.6" strokeLinecap="round" />
          </>
        )}
        {id === "passwords" && (
          <>
            <rect width="60" height="60" fill="#1c1c1e" />
            <circle cx="30" cy="26" r="8" fill="none" stroke="#FFD60A" strokeWidth="3" />
            <rect x="27" y="32" width="6" height="12" rx="1" fill="#FFD60A" />
            <rect x="27" y="38" width="10" height="3" rx="1" fill="#FFD60A" />
          </>
        )}
        {id === "measure" && (
          <>
            <rect width="60" height="60" fill="#fff" />
            <rect x="14" y="16" width="32" height="28" rx="3" fill="none" stroke="#111" strokeWidth="2" />
            {Array.from({ length: 7 }).map((_, i) => (
              <line key={i} x1={18 + i * 4} y1="16" x2={18 + i * 4} y2={i % 2 ? 22 : 26} stroke="#111" strokeWidth="1.4" />
            ))}
          </>
        )}
        {id === "tips" && (
          <>
            <rect width="60" height="60" fill="#fff" />
            <circle cx="30" cy="26" r="10" fill="#FFD60A" />
            <rect x="27" y="36" width="6" height="8" rx="2" fill="#FFD60A" />
            <rect x="25" y="44" width="10" height="3" rx="1.5" fill="#d1d1d6" />
          </>
        )}
        {id === "studio" && (
          <>
            <rect width="60" height="60" fill="#2c1a4a" />
            <circle cx="22" cy="32" r="8" fill="#FF375F" />
            <circle cx="38" cy="26" r="7" fill="#FFD60A" />
            <circle cx="40" cy="40" r="5" fill="#64D2FF" />
          </>
        )}
        {id === "sheets" && (
          <>
            <rect width="60" height="60" fill="#30D158" />
            <rect x="12" y="14" width="36" height="32" rx="2" fill="#fff" />
            <path d="M12 24h36M12 34h36M24 14v32M36 14v32" stroke="#30D158" strokeWidth="1.4" />
          </>
        )}
        {id === "writer" && (
          <>
            <rect width="60" height="60" fill="#FF9500" />
            <rect x="16" y="12" width="24" height="32" rx="2" fill="#fff" />
            <path d="M34 38l8 8-4 1-5-7z" fill="#FFD60A" />
            <path d="M20 20h14M20 26h14M20 32h8" stroke="#FF9500" strokeWidth="1.6" strokeLinecap="round" />
          </>
        )}
        {id === "board" && (
          <>
            <rect width="60" height="60" fill="#1c1c1e" />
            <rect x="10" y="12" width="22" height="18" rx="3" fill="#FFE066" transform="rotate(-6 21 21)" />
            <rect x="28" y="18" width="22" height="18" rx="3" fill="#FFD6E0" transform="rotate(5 39 27)" />
            <rect x="16" y="32" width="24" height="16" rx="3" fill="#C8F7C5" />
          </>
        )}
        {id === "magnifier" && (
          <>
            <rect width="60" height="60" fill="#8E8E93" />
            <circle cx="26" cy="26" r="12" fill="none" stroke="#fff" strokeWidth="4" />
            <path d="M35 35l10 10" stroke="#fff" strokeWidth="4" strokeLinecap="round" />
          </>
        )}
        {!APPS_KNOWN.has(id) && !id.startsWith("web:") && <rect width="60" height="60" fill="#3a3a3c" />}
      </svg>
    </span>
  );
}

const APPS_KNOWN = new Set([
  "phone",
  "messages",
  "safari",
  "music",
  "camera",
  "photos",
  "weather",
  "clock",
  "maps",
  "notes",
  "calendar",
  "reminders",
  "appstore",
  "settings",
  "calculator",
  "files",
  "mail",
  "health",
  "wallet",
  "stocks",
  "translate",
  "compass",
  "voicememo",
  "contacts",
  "books",
  "podcasts",
  "shortcuts",
  "fitness",
  "news",
  "tv",
  "homeapp",
  "find",
  "journal",
  "passwords",
  "measure",
  "tips",
  "studio",
  "sheets",
  "writer",
  "board",
  "magnifier",
]);
