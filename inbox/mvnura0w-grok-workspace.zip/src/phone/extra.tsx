import { useEffect, useRef, useState } from "react";
import { padHit } from "./audio";
import { Group, Row, Screen, useT } from "./kit";
import { blankSheet, DICT, faNum, uid } from "./model";
import { usePhone } from "./store";

const STORY_FA = `شب روی شیشهٔ تیتانیوم، شهر مثل یک جزیرهٔ روشن بود.\n\nعلی گوشی را برداشت. نه برای اینکه گم شود، برای اینکه همهٔ ابزارهایش را همان‌جا، اندازهٔ واقعی، کنار هم داشته باشد: نقشه، یادداشت، زنگ ساعت، و یک آهنگ که مال خودش بود.\n\nفردا قرار کافه است. امشب فقط صفحهٔ اصلی را مرتب می‌کند. چهار ستون. داک پایین. یک اپ تازه از اپ استور.\n\nوقتی چراغ‌قوه را خاموش کرد، کویر والپیپر هنوز گرم بود.`;

const STORY_EN = `The city sat on the glass like a bright island.\n\nThis phone is a place to keep the day: a map, a note, an alarm, a song that belongs to nobody else.\n\nTomorrow is the café. Tonight the home screen is enough. Four columns. A dock. One new app from the store.`;

export function ExtraApps({ id }: { id: string }) {
  switch (id) {
    case "mail":
      return <MailApp />;
    case "health":
      return <HealthApp />;
    case "wallet":
      return <WalletApp />;
    case "stocks":
      return <StocksApp />;
    case "translate":
      return <TranslateApp />;
    case "compass":
      return <CompassApp />;
    case "voicememo":
      return <MemoApp />;
    case "contacts":
      return <ContactsApp />;
    case "books":
      return <BooksApp />;
    case "podcasts":
      return <PodcastsApp />;
    case "shortcuts":
      return <ShortcutsApp />;
    case "fitness":
      return <FitnessApp />;
    case "news":
      return <NewsApp />;
    case "tv":
      return <TvApp />;
    case "homeapp":
      return <HomeApp />;
    case "find":
      return <FindApp />;
    case "journal":
      return <JournalApp />;
    case "passwords":
      return <PassApp />;
    case "measure":
      return <MeasureApp />;
    case "tips":
      return <TipsApp />;
    case "studio":
      return <StudioApp />;
    case "sheets":
      return <SheetsApp />;
    case "writer":
      return <WriterApp />;
    case "board":
      return <BoardApp />;
    case "magnifier":
      return <MagApp />;
    default:
      return (
        <Screen title={id}>
          <p className="warn">…</p>
        </Screen>
      );
  }
}

function MailApp() {
  const phone = usePhone();
  const t = useT();
  const [id, setId] = useState<string | null>(null);
  const [draft, setDraft] = useState(false);
  const [form, setForm] = useState({ to: "", subject: "", body: "" });
  const mail = phone.data.mails.find((m) => m.id === id);
  if (draft) {
    return (
      <Screen title={t("نامهٔ تازه", "New Message")} back={() => setDraft(false)}>
        <input className="field" placeholder={t("به", "To")} value={form.to} onChange={(e) => setForm({ ...form, to: e.target.value })} />
        <input className="field" placeholder={t("موضوع", "Subject")} value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} />
        <textarea className="area" value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} />
        <button
          className="get open"
          style={{ marginInlineStart: 16 }}
          onClick={() => {
            phone.update((d) => ({
              ...d,
              mails: [{ id: uid("ml"), from: t("من", "Me"), subject: form.subject || t("بدون موضوع", "No subject"), body: form.body, read: true, at: Date.now() }, ...d.mails],
            }));
            setDraft(false);
          }}
        >
          {t("بفرست", "Send")}
        </button>
      </Screen>
    );
  }
  if (mail) {
    return (
      <Screen title={mail.subject} back={() => setId(null)}>
        <p className="section-label">{mail.from}</p>
        <p className="reader">{mail.body}</p>
      </Screen>
    );
  }
  return (
    <Screen title={t("ایمیل", "Mail")} right={<button className="text-btn" onClick={() => setDraft(true)}>✎</button>}>
      <Group>
        {phone.data.mails.map((m) => (
          <Row
            key={m.id}
            label={m.subject}
            value={m.read ? "" : "●"}
            onClick={() => {
              setId(m.id);
              phone.update((d) => ({ ...d, mails: d.mails.map((x) => (x.id === m.id ? { ...x, read: true } : x)) }));
            }}
          />
        ))}
      </Group>
    </Screen>
  );
}

function HealthApp() {
  const phone = usePhone();
  const t = useT();
  const move = Math.min(1, phone.data.workouts.reduce((n, w) => n + w.seconds, 0) / 1800);
  const exercise = Math.min(1, phone.data.workouts.length / 3);
  const stand = Math.min(1, phone.data.water / 8);
  return (
    <Screen title={t("سلامت", "Health")}>
      <svg className="rings" viewBox="0 0 120 120">
        <circle cx="60" cy="60" r="48" fill="none" stroke="#3a2030" strokeWidth="10" />
        <circle cx="60" cy="60" r="48" fill="none" stroke="#ff2d55" strokeWidth="10" strokeDasharray={`${move * 300} 400`} strokeLinecap="round" transform="rotate(-90 60 60)" />
        <circle cx="60" cy="60" r="34" fill="none" stroke="#14321c" strokeWidth="10" />
        <circle cx="60" cy="60" r="34" fill="none" stroke="#30d158" strokeWidth="10" strokeDasharray={`${exercise * 214} 300`} strokeLinecap="round" transform="rotate(-90 60 60)" />
        <circle cx="60" cy="60" r="20" fill="none" stroke="#12323a" strokeWidth="10" />
        <circle cx="60" cy="60" r="20" fill="none" stroke="#64d2ff" strokeWidth="10" strokeDasharray={`${stand * 126} 200`} strokeLinecap="round" transform="rotate(-90 60 60)" />
      </svg>
      <Group>
        <Row label={t("لیوان آب", "Water")} value={faNum(phone.data.water, phone.lang)} onClick={() => phone.update({ water: Math.min(12, phone.data.water + 1) })} />
        <Row label={t("کم کن", "Less")} onClick={() => phone.update({ water: Math.max(0, phone.data.water - 1) })} />
      </Group>
    </Screen>
  );
}

function WalletApp() {
  const phone = usePhone();
  const t = useT();
  const [form, setForm] = useState({ label: "", last4: "", holder: "" });
  return (
    <Screen title={t("کیف پول", "Wallet")}>
      <p className="warn">{t("کارت‌ها فقط نمایشی‌اند و پرداخت واقعی نیستند.", "Cards are visual only. No real payments.")}</p>
      {phone.data.cards.map((c, i) => (
        <div key={c.id} style={{ margin: "10px 16px", background: c.color, borderRadius: 16, padding: 16, minHeight: 90, transform: `translateY(${-i * 4}px)` }}>
          <b>{c.label}</b>
          <div style={{ fontSize: 22, letterSpacing: 2, marginTop: 12 }}>•••• {faNum(c.last4, phone.lang)}</div>
          <div style={{ opacity: 0.8 }}>{c.holder}</div>
        </div>
      ))}
      <input className="field" placeholder={t("نام کارت", "Card name")} value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} />
      <input className="field" placeholder="1234" value={form.last4} onChange={(e) => setForm({ ...form, last4: e.target.value.slice(0, 4) })} />
      <button
        className="get open"
        style={{ marginInlineStart: 16 }}
        onClick={() => {
          if (!form.label || form.last4.length < 4) return;
          phone.update((d) => ({ ...d, cards: [...d.cards, { id: uid("cd"), label: form.label, last4: form.last4, holder: form.holder || "ALI", color: "#5E5CE6" }] }));
          setForm({ label: "", last4: "", holder: "" });
        }}
      >
        {t("افزودن کارت", "Add card")}
      </button>
    </Screen>
  );
}

const STOCKS = [
  { s: "ALI", p: 128.4, d: 1.8, line: [20, 22, 21, 24, 28, 26, 30, 34] },
  { s: "GLASS", p: 54.1, d: -0.6, line: [30, 28, 29, 27, 26, 24, 25, 22] },
  { s: "DUNE", p: 76.0, d: 0.4, line: [14, 16, 15, 18, 17, 19, 21, 20] },
];

function StocksApp() {
  const phone = usePhone();
  const t = useT();
  const [i, setI] = useState<number | null>(null);
  if (i != null) {
    const st = STOCKS[i]!;
    const max = Math.max(...st.line);
    return (
      <Screen title={st.s} back={() => setI(null)}>
        <div className="wx-hero">
          <div className="temp" style={{ fontSize: 56 }}>{faNum(st.p.toFixed(2), phone.lang)}</div>
          <div style={{ color: st.d >= 0 ? "#30d158" : "#ff453a" }}>{st.d > 0 ? "+" : ""}{faNum(st.d.toFixed(2), phone.lang)}</div>
        </div>
        <svg viewBox="0 0 100 40" style={{ width: "100%", height: 140 }}>
          <polyline fill="none" stroke="#30d158" strokeWidth="2" points={st.line.map((n, idx) => `${idx * 14},${40 - (n / max) * 34}`).join(" ")} />
        </svg>
        <p className="warn">{t("نمودار نمونه است، نه قیمت بازار.", "Sample chart, not a live market.")}</p>
      </Screen>
    );
  }
  return (
    <Screen title={t("سهام", "Stocks")}>
      <Group>
        {STOCKS.map((st, idx) => (
          <Row key={st.s} label={st.s} value={`${faNum(st.p.toFixed(1), phone.lang)}`} onClick={() => setI(idx)} />
        ))}
      </Group>
    </Screen>
  );
}

function TranslateApp() {
  const phone = usePhone();
  const t = useT();
  const [q, setQ] = useState("");
  const [faFirst, setFaFirst] = useState(true);
  const query = q.trim().toLowerCase();
  const hits = DICT.filter((d) => d.fa.includes(query) || d.en.includes(query));
  return (
    <Screen title={t("ترجمه", "Translate")}>
      <div className="nav">
        <b>{faFirst ? "فارسی" : "English"}</b>
        <button className="text-btn" onClick={() => setFaFirst((v) => !v)}>⇄</button>
        <b>{faFirst ? "English" : "فارسی"}</b>
      </div>
      <input className="field" value={q} placeholder={t("کلمه", "Word")} onChange={(e) => setQ(e.target.value)} />
      <Group>
        {(query ? hits : DICT.slice(0, 8)).map((d) => (
          <Row key={d.en} label={faFirst ? d.fa : d.en} value={faFirst ? d.en : d.fa} />
        ))}
      </Group>
      {query && hits.length === 0 && <p className="warn">{t("در واژه‌نامهٔ آفلاین نیست.", "Not in the offline dictionary.")}</p>}
    </Screen>
  );
}

function CompassApp() {
  const phone = usePhone();
  const t = useT();
  const [heading, setHeading] = useState<number | null>(null);
  const [need, setNeed] = useState(false);
  useEffect(() => {
    const DOE = DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> };
    if (typeof DOE.requestPermission === "function") setNeed(true);
    const on = (e: DeviceOrientationEvent) => {
      const extra = e as DeviceOrientationEvent & { webkitCompassHeading?: number };
      if (typeof extra.webkitCompassHeading === "number") setHeading(extra.webkitCompassHeading);
      else if (e.alpha != null) setHeading(360 - e.alpha);
    };
    window.addEventListener("deviceorientation", on);
    return () => window.removeEventListener("deviceorientation", on);
  }, []);
  return (
    <Screen title={t("قطب‌نما", "Compass")}>
      {need && (
        <button
          className="get open"
          style={{ margin: 16 }}
          onClick={() => {
            const DOE = DeviceOrientationEvent as unknown as { requestPermission?: () => Promise<string> };
            void DOE.requestPermission?.();
          }}
        >
          {t("اجازه بده", "Allow")}
        </button>
      )}
      <div style={{ width: 220, height: 220, margin: "30px auto", borderRadius: "50%", border: "2px solid #fff", position: "relative", transform: `rotate(${-(heading ?? 0)}deg)` }}>
        <b style={{ position: "absolute", top: 8, left: "50%", transform: "translateX(-50%)", color: "#ff453a" }}>N</b>
        <b style={{ position: "absolute", bottom: 8, left: "50%" }}>S</b>
      </div>
      <p style={{ textAlign: "center", fontSize: 28 }}>{heading == null ? "—" : faNum(`${Math.round(heading)}°`, phone.lang)}</p>
    </Screen>
  );
}

function MemoApp() {
  const phone = usePhone();
  const t = useT();
  const rec = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const [on, setOn] = useState(false);
  const [sec, setSec] = useState(0);
  const [err, setErr] = useState("");
  useEffect(() => {
    if (!on) return;
    const id = window.setInterval(() => setSec((s) => s + 1), 1000);
    return () => window.clearInterval(id);
  }, [on]);
  async function toggle() {
    if (on && rec.current) {
      rec.current.stop();
      setOn(false);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      chunks.current = [];
      mr.ondataavailable = (e) => {
        if (e.data.size) chunks.current.push(e.data);
      };
      mr.onstop = () => {
        const blob = new Blob(chunks.current, { type: mr.mimeType || "audio/webm" });
        const url = URL.createObjectURL(blob);
        phone.addMemo({ id: uid("vm"), url, seconds: sec, at: Date.now() });
        stream.getTracks().forEach((tr) => tr.stop());
        setSec(0);
      };
      mr.start();
      rec.current = mr;
      setSec(0);
      setOn(true);
    } catch {
      setErr(t("میکروفون اجازه نداد.", "Microphone permission denied."));
    }
  }
  return (
    <Screen title={t("یادداشت صوتی", "Voice Memos")}>
      {err && <p className="warn">{err}</p>}
      <div style={{ textAlign: "center", padding: 16 }}>
        <div className="lock-time" style={{ fontSize: 48 }}>{faNum(sec, phone.lang)}</div>
        <button className="call-btn" style={{ background: on ? "#ff453a" : "#ff375f" }} onClick={() => void toggle()}>
          {on ? "■" : "●"}
        </button>
      </div>
      <Group>
        {phone.memos.map((m) => (
          <div key={m.id} className="row" style={{ display: "flex", gap: 8 }}>
            <span>{faNum(m.seconds, phone.lang)}s</span>
            <audio controls src={m.url} style={{ flex: 1, height: 32 }} />
          </div>
        ))}
      </Group>
      <p className="warn">{t("ضبط‌ها تا وقتی این صفحه باز است می‌مانند.", "Recordings stay for this visit.")}</p>
    </Screen>
  );
}

function ContactsApp() {
  const phone = usePhone();
  const t = useT();
  const [form, setForm] = useState({ name: "", phone: "" });
  return (
    <Screen title={t("مخاطبان", "Contacts")}>
      <input className="field" placeholder={t("نام", "Name")} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
      <input className="field" placeholder="09…" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
      <button
        className="get open"
        style={{ marginInlineStart: 16 }}
        onClick={() => {
          if (!form.name.trim()) return;
          phone.update((d) => ({ ...d, contacts: [...d.contacts, { id: uid("c"), name: form.name.trim(), phone: form.phone, color: "#0A84FF" }] }));
          setForm({ name: "", phone: "" });
        }}
      >
        {t("افزودن", "Add")}
      </button>
      <Group>
        {phone.data.contacts.map((c) => (
          <Row key={c.id} label={c.name} value={faNum(c.phone, phone.lang)} onClick={() => phone.startCall(c.name, c.phone)} />
        ))}
      </Group>
    </Screen>
  );
}

function BooksApp() {
  const phone = usePhone();
  const t = useT();
  const text = phone.rtl ? STORY_FA : STORY_EN;
  return (
    <Screen title={t("کتاب", "Books")} right={<button className="text-btn" onClick={() => speechSynthesis.speak(new SpeechSynthesisUtterance(text))}>▶</button>}>
      <article className="reader book-text">{text}</article>
    </Screen>
  );
}

const SHOWS = [
  { fa: "شب تیتانیوم", en: "Titanium Night", bodyFa: "دربارهٔ ساختن یک گوشی که واقعاً دستت باشد.", bodyEn: "On making a phone that feels like it is yours." },
  { fa: "چهار ستون", en: "Four Columns", bodyFa: "چرا آیکون آیفون ۶۰ نقطه است و شلوغ نمی‌شود.", bodyEn: "Why a 60-point icon keeps the grid calm." },
];

function PodcastsApp() {
  const phone = usePhone();
  const t = useT();
  const [play, setPlay] = useState<number | null>(null);
  return (
    <Screen title={t("پادکست", "Podcasts")}>
      {SHOWS.map((s, i) => (
        <div key={s.en} className="store-card">
          <div className="meta">
            <b>{phone.rtl ? s.fa : s.en}</b>
            <span>{phone.rtl ? s.bodyFa : s.bodyEn}</span>
          </div>
          <button
            className="get open"
            onClick={() => {
              setPlay(i);
              const u = new SpeechSynthesisUtterance(phone.rtl ? s.bodyFa : s.bodyEn);
              u.lang = phone.rtl ? "fa-IR" : "en-US";
              speechSynthesis.cancel();
              speechSynthesis.speak(u);
            }}
          >
            {play === i ? "●" : "▶"}
          </button>
        </div>
      ))}
    </Screen>
  );
}

function ShortcutsApp() {
  const phone = usePhone();
  const t = useT();
  const items = [
    { fa: "چراغ‌قوه", en: "Flashlight", run: () => phone.update({ flashlight: !phone.data.flashlight }) },
    { fa: "دوربین", en: "Camera", run: () => phone.openApp("camera") },
    { fa: "یادداشت تازه", en: "New note", run: () => phone.update((d) => ({ ...d, notes: [{ id: uid("n"), title: t("سریع", "Quick"), body: "", updated: Date.now() }, ...d.notes] })) },
    { fa: "وای‌فای", en: "Wi-Fi", run: () => phone.update({ wifi: !phone.data.wifi }) },
    { fa: "قفل", en: "Lock", run: () => phone.setLocked(true) },
    { fa: "زنگ یک دقیقه", en: "Alarm +1 min", run: () => {
      const n = new Date();
      const minute = (n.getMinutes() + 1) % 60;
      const hour = minute === 0 ? (n.getHours() + 1) % 24 : n.getHours();
      phone.update((d) => ({ ...d, alarms: [...d.alarms, { id: uid("a"), hour, minute, on: true, label: t("میانبر", "Shortcut") }] }));
    } },
  ];
  return (
    <Screen title={t("میانبرها", "Shortcuts")}>
      <div className="pad-grid">
        {items.map((it) => (
          <button key={it.en} className="pad" style={{ background: "#0A84FF" }} onClick={it.run}>
            {phone.rtl ? it.fa : it.en}
          </button>
        ))}
      </div>
    </Screen>
  );
}

function FitnessApp() {
  const phone = usePhone();
  const t = useT();
  const [run, setRun] = useState<{ kind: string; start: number } | null>(null);
  const [sec, setSec] = useState(0);
  useEffect(() => {
    if (!run) return;
    const id = window.setInterval(() => setSec(Math.floor((Date.now() - run.start) / 1000)), 500);
    return () => window.clearInterval(id);
  }, [run]);
  const kinds = [
    { fa: "پیاده‌روی", en: "Walk" },
    { fa: "دو", en: "Run" },
    { fa: "دوچرخه", en: "Cycle" },
  ];
  return (
    <Screen title={t("تناسب", "Fitness")}>
      <div style={{ textAlign: "center", fontSize: 48 }}>{faNum(`${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`, phone.lang)}</div>
      {!run ? (
        <div className="pad-grid">
          {kinds.map((k) => (
            <button key={k.en} className="pad" style={{ background: "#30d158", color: "#042" }} onClick={() => { setRun({ kind: phone.rtl ? k.fa : k.en, start: Date.now() }); setSec(0); }}>
              {phone.rtl ? k.fa : k.en}
            </button>
          ))}
        </div>
      ) : (
        <button
          className="get open"
          style={{ margin: 16 }}
          onClick={() => {
            phone.update((d) => ({ ...d, workouts: [{ id: uid("w"), kind: run.kind, seconds: sec, at: Date.now() }, ...d.workouts] }));
            setRun(null);
            setSec(0);
          }}
        >
          {t("پایان تمرین", "End workout")}
        </button>
      )}
      <Group>
        {phone.data.workouts.map((w) => (
          <Row key={w.id} label={w.kind} value={faNum(`${Math.floor(w.seconds / 60)}m`, phone.lang)} />
        ))}
      </Group>
    </Screen>
  );
}

function NewsApp() {
  const phone = usePhone();
  const t = useT();
  const items = [
    { fa: "صفحهٔ اصلی خلوت‌تر شد", en: "A calmer home screen", body: t("چهار ستون، آیکون ۶۰ نقطه‌ای، داک بدون برچسب.", "Four columns, 60-point icons, a dock without labels.") },
    { fa: "هوای شهر", en: "City weather", body: t("هواشناسی از Open-Meteo می‌خواند.", "Weather reads Open-Meteo.") },
    { fa: "اپ خودت را بساز", en: "Build your own app", body: t("در اپ استور دکمهٔ ساخت، یک صفحهٔ HTML نصب می‌کند.", "App Store → Create installs a small HTML app.") },
  ];
  const [i, setI] = useState<number | null>(null);
  if (i != null) {
    const it = items[i]!;
    return (
      <Screen title={phone.rtl ? it.fa : it.en} back={() => setI(null)}>
        <p className="reader">{it.body}</p>
      </Screen>
    );
  }
  return (
    <Screen title={t("اخبار", "News")}>
      <Group>
        {items.map((it, idx) => (
          <Row key={it.en} label={phone.rtl ? it.fa : it.en} onClick={() => setI(idx)} />
        ))}
      </Group>
    </Screen>
  );
}

function TvApp() {
  const phone = usePhone();
  const t = useT();
  const shows = [
    { fa: "کویر", en: "Dune", color: "#C4A484" },
    { fa: "شفق", en: "Aurora", color: "#5E5CE6" },
    { fa: "اقیانوس", en: "Ocean", color: "#0A84FF" },
  ];
  const [play, setPlay] = useState<number | null>(null);
  if (play != null) {
    const s = shows[play]!;
    return (
      <Screen title={phone.rtl ? s.fa : s.en} back={() => setPlay(null)} scroll={false}>
        <div className="app-fill" style={{ background: s.color, alignItems: "center", justifyContent: "center", fontSize: 42 }}>▶</div>
      </Screen>
    );
  }
  return (
    <Screen title={t("تماشا", "TV")}>
      <div className="wall-pick">
        {shows.map((s, i) => (
          <button key={s.en} style={{ background: s.color, color: "#fff", font: "inherit", fontSize: 18 }} onClick={() => setPlay(i)}>
            {phone.rtl ? s.fa : s.en}
          </button>
        ))}
      </div>
    </Screen>
  );
}

function HomeApp() {
  const phone = usePhone();
  const t = useT();
  return (
    <Screen title={t("خانه", "Home")}>
      <Group>
        {Object.entries(phone.data.lights).map(([room, on]) => (
          <Row key={room} label={room} value={on ? t("روشن", "On") : t("خاموش", "Off")} onClick={() => phone.update((d) => ({ ...d, lights: { ...d.lights, [room]: !on } }))} />
        ))}
      </Group>
    </Screen>
  );
}

function FindApp() {
  const phone = usePhone();
  const t = useT();
  const [where, setWhere] = useState(t("در حال جستجو…", "Searching…"));
  useEffect(() => {
    navigator.geolocation?.getCurrentPosition(
      (p) => setWhere(`${p.coords.latitude.toFixed(4)}, ${p.coords.longitude.toFixed(4)}`),
      () => setWhere("near you"),
    );
  }, []);
  return (
    <Screen title={t("پیدا کن", "Find")}>
      <div className="finder"><i /></div>
      <p style={{ textAlign: "center" }}>ALI Phone</p>
      <p style={{ textAlign: "center", color: "#8e8e93" }}>{where}</p>
    </Screen>
  );
}

function JournalApp() {
  const phone = usePhone();
  const t = useT();
  const [text, setText] = useState("");
  return (
    <Screen title={t("دفتر روزانه", "Journal")}>
      <textarea className="area" value={text} placeholder={t("امروز…", "Today…")} onChange={(e) => setText(e.target.value)} />
      <button
        className="get open"
        style={{ marginInlineStart: 16 }}
        onClick={() => {
          if (!text.trim()) return;
          phone.update((d) => ({ ...d, journal: [{ id: uid("j"), body: text.trim(), at: Date.now() }, ...d.journal] }));
          setText("");
        }}
      >
        {t("ذخیره", "Save")}
      </button>
      {phone.data.journal.map((j) => (
        <p key={j.id} className="reader">{j.body}</p>
      ))}
    </Screen>
  );
}

function PassApp() {
  const phone = usePhone();
  const t = useT();
  const [form, setForm] = useState({ site: "", user: "", pass: "" });
  const [show, setShow] = useState<string | null>(null);
  return (
    <Screen title={t("رمزها", "Passwords")}>
      <p className="warn">{t("فقط روی همین دستگاه ذخیره می‌شود و رمزنگاری بانکی نیست. رمز واقعی نگذار.", "Stored only on this device, not a secure vault. Do not save real passwords.")}</p>
      <input className="field" placeholder={t("سایت", "Site")} value={form.site} onChange={(e) => setForm({ ...form, site: e.target.value })} />
      <input className="field" placeholder={t("نام کاربری", "User")} value={form.user} onChange={(e) => setForm({ ...form, user: e.target.value })} />
      <input className="field" placeholder={t("رمز", "Password")} value={form.pass} onChange={(e) => setForm({ ...form, pass: e.target.value })} />
      <button
        className="get open"
        style={{ marginInlineStart: 16 }}
        onClick={() => {
          if (!form.site) return;
          phone.update((d) => ({ ...d, secrets: [...d.secrets, { id: uid("pw"), ...form }] }));
          setForm({ site: "", user: "", pass: "" });
        }}
      >
        {t("ذخیره", "Save")}
      </button>
      <Group>
        {phone.data.secrets.map((s) => (
          <Row key={s.id} label={s.site} value={show === s.id ? s.pass : "••••"} onClick={() => setShow(show === s.id ? null : s.id)} />
        ))}
      </Group>
    </Screen>
  );
}

function MeasureApp() {
  const phone = usePhone();
  const t = useT();
  const [tilt, setTilt] = useState(0);
  useEffect(() => {
    const on = (e: DeviceOrientationEvent) => setTilt(Math.round(e.gamma || 0));
    window.addEventListener("deviceorientation", on);
    return () => window.removeEventListener("deviceorientation", on);
  }, []);
  return (
    <Screen title={t("اندازه", "Measure")}>
      <p className="section-label">{t("خط‌کش تقریبی (پیکسل به سانتی)", "Approximate ruler")}</p>
      <div style={{ margin: 16, height: 80, background: "repeating-linear-gradient(90deg,#fff 0 1px,transparent 1px 37.8px)", borderRadius: 8 }} />
      <p style={{ textAlign: "center" }}>{t("هر خانه حدود ۱ سانتی‌متر روی نمایشگر ۹۶dpi.", "Each mark is about 1 cm at 96dpi.")}</p>
      <p className="section-label">{t("تراز", "Level")}</p>
      <div className="level">
        <b style={{ left: `calc(50% + ${Math.max(-140, Math.min(140, tilt * 3))}px)` }} />
      </div>
      <p style={{ textAlign: "center" }}>{faNum(`${tilt}°`, phone.lang)}</p>
    </Screen>
  );
}

function TipsApp() {
  const t = useT();
  const tips = [
    t("برای باز کردن قفل، به بالا بکش یا دکمهٔ پایین را بزن.", "Swipe up on the lock screen, or tap the hint."),
    t("مرکز کنترل: از بالا سمت باتری به پایین بکش.", "Control Center: swipe down from the battery side."),
    t("اعلان‌ها: از بالا سمت ساعت به پایین بکش.", "Notifications: swipe down from the clock side."),
    t("نوار خانه را بزن تا از اپ برگردی. دوباره بزن تا اپ‌های باز را ببینی.", "Tap the home bar to leave an app. Tap again for the app switcher."),
    t("در اپ استور «گرفتن» اپ را روی صفحه می‌گذارد. «ساخت» یک وب‌اپ یا HTML نصب می‌کند.", "App Store Get puts an app on the home screen. Create installs a web or HTML app."),
    t("نگه‌داشتن آیکون: حذف یا ویرایش صفحه.", "Hold an icon to remove it or edit the home screen."),
    t("آیکون‌ها ۶۰ نقطه هستند، چهار ستون، مثل آیفون واقعی.", "Icons are 60 points, four columns, like a real iPhone."),
  ];
  return (
    <Screen title={t("نکته‌ها", "Tips")}>
      <Group>
        {tips.map((tip) => (
          <Row key={tip} label={tip} />
        ))}
      </Group>
    </Screen>
  );
}

function StudioApp() {
  const t = useT();
  const pads = [
    { n: "Kick", f: 80, c: "#FF375F" },
    { n: "Snare", f: 180, c: "#FF9F0A" },
    { n: "Hat", f: 640, c: "#FFD60A" },
    { n: "Tom", f: 140, c: "#30D158" },
    { n: "Clap", f: 420, c: "#64D2FF" },
    { n: "Bass", f: 55, c: "#0A84FF" },
    { n: "Bell", f: 880, c: "#BF5AF2" },
    { n: "Chord", f: 262, c: "#FF6482" },
  ];
  return (
    <Screen title={t("استودیو", "Studio")}>
      <div className="pad-grid">
        {pads.map((p) => (
          <button key={p.n} className="pad" style={{ background: p.c, color: "#111" }} onClick={() => padHit(p.f)}>
            {p.n}
          </button>
        ))}
      </div>
    </Screen>
  );
}

function SheetsApp() {
  const phone = usePhone();
  const t = useT();
  const sheet = phone.data.sheets[0];
  if (!sheet) return null;
  return (
    <Screen title={t("جدول", "Sheets")}>
      <table className="sheet-grid">
        <tbody>
          {sheet.cells.map((row, r) => (
            <tr key={r}>
              {row.map((cell, c) => (
                <td key={c}>
                  <input
                    value={cell}
                    onChange={(e) => {
                      const value = e.target.value;
                      phone.update((d) => ({
                        ...d,
                        sheets: d.sheets.map((s) =>
                          s.id !== sheet.id
                            ? s
                            : { ...s, cells: s.cells.map((rr, ri) => (ri === r ? rr.map((cc, ci) => (ci === c ? value : cc)) : rr)) },
                        ),
                      }));
                    }}
                  />
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      <button
        className="text-btn"
        onClick={() => phone.update((d) => ({ ...d, sheets: [...d.sheets, { id: uid("s"), name: t("برگ", "Sheet"), cells: blankSheet() }] }))}
      >
        {t("برگ تازه", "New sheet")}
      </button>
    </Screen>
  );
}

function WriterApp() {
  const phone = usePhone();
  const t = useT();
  const doc = phone.data.docs[0];
  if (!doc) return null;
  return (
    <Screen title={t("نوشته", "Writer")}>
      <input
        className="field"
        value={doc.title}
        onChange={(e) => phone.update((d) => ({ ...d, docs: d.docs.map((x) => (x.id === doc.id ? { ...x, title: e.target.value } : x)) }))}
      />
      <textarea
        className="area"
        style={{ minHeight: 280 }}
        value={doc.body}
        onChange={(e) => phone.update((d) => ({ ...d, docs: d.docs.map((x) => (x.id === doc.id ? { ...x, body: e.target.value } : x)) }))}
      />
    </Screen>
  );
}

function BoardApp() {
  const phone = usePhone();
  const t = useT();
  return (
    <Screen title={t("تخته", "Board")} scroll={false}>
      <button
        className="text-btn"
        onClick={() =>
          phone.update((d) => ({
            ...d,
            stickies: [...d.stickies, { id: uid("st"), text: t("جدید", "New"), x: 20 + d.stickies.length * 12, y: 20, color: "#C8F7C5" }],
          }))
        }
      >
        +
      </button>
      <div className="board">
        {phone.data.stickies.map((s) => (
          <textarea
            key={s.id}
            className="sticky"
            style={{ left: s.x, top: s.y, background: s.color }}
            value={s.text}
            onChange={(e) => phone.update((d) => ({ ...d, stickies: d.stickies.map((x) => (x.id === s.id ? { ...x, text: e.target.value } : x)) }))}
            onPointerDown={(e) => {
              const sx = e.clientX;
              const sy = e.clientY;
              const ox = s.x;
              const oy = s.y;
              const move = (ev: PointerEvent) => {
                phone.update((d) => ({
                  ...d,
                  stickies: d.stickies.map((x) => (x.id === s.id ? { ...x, x: ox + ev.clientX - sx, y: oy + ev.clientY - sy } : x)),
                }));
              };
              const up = () => {
                window.removeEventListener("pointermove", move);
                window.removeEventListener("pointerup", up);
              };
              window.addEventListener("pointermove", move);
              window.addEventListener("pointerup", up);
            }}
          />
        ))}
      </div>
    </Screen>
  );
}

function MagApp() {
  const phone = usePhone();
  const t = useT();
  const video = useRef<HTMLVideoElement>(null);
  const [zoom, setZoom] = useState(1.5);
  const [err, setErr] = useState("");
  useEffect(() => {
    let stream: MediaStream | null = null;
    navigator.mediaDevices
      ?.getUserMedia({ video: true })
      .then((s) => {
        stream = s;
        if (video.current) video.current.srcObject = s;
      })
      .catch(() => setErr(t("دوربین نیست", "No camera")));
    return () => stream?.getTracks().forEach((tr) => tr.stop());
  }, []);
  return (
    <Screen title={t("ذره‌بین", "Magnifier")} scroll={false}>
      <div className="cam-view">
        <video ref={video} autoPlay playsInline muted style={{ transform: `scale(${zoom})` }} />
        {err && <p className="warn">{err}</p>}
      </div>
      <input type="range" min={1} max={4} step={0.1} value={zoom} onChange={(e) => setZoom(Number(e.target.value))} />
    </Screen>
  );
}
