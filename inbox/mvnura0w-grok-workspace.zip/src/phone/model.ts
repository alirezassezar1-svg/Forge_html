import { jalaaliMonthLength, toGregorian, toJalaali } from "jalaali-js";

export type Lang = "fa" | "en";
export type Finish = "black" | "natural" | "desert" | "white";

export interface Note {
  id: string;
  title: string;
  body: string;
  updated: number;
}
export interface Contact {
  id: string;
  name: string;
  phone: string;
  color: string;
}
export interface Msg {
  id: string;
  from: "me" | "them";
  text: string;
  at: number;
}
export interface Thread {
  messages: Msg[];
  unread: number;
}
export interface CalEvent {
  id: string;
  title: string;
  day: string;
  time?: string;
  color: string;
}
export interface Reminder {
  id: string;
  title: string;
  done: boolean;
}
export interface VFile {
  id: string;
  name: string;
  kind: "folder" | "text";
  parent: string | null;
  body?: string;
}
export interface Photo {
  id: string;
  url: string;
  at: number;
  fav?: boolean;
}
export interface Alarm {
  id: string;
  hour: number;
  minute: number;
  on: boolean;
  label: string;
}
export interface WebApp {
  id: string;
  name: string;
  url?: string;
  html?: string;
  color: string;
}
export interface Mail {
  id: string;
  from: string;
  subject: string;
  body: string;
  read: boolean;
  at: number;
}
export interface JournalEntry {
  id: string;
  body: string;
  at: number;
}
export interface Secret {
  id: string;
  site: string;
  user: string;
  pass: string;
}
export interface Card {
  id: string;
  label: string;
  last4: string;
  color: string;
  holder: string;
}
export interface Doc {
  id: string;
  title: string;
  body: string;
}
export interface SheetDoc {
  id: string;
  name: string;
  cells: string[][];
}
export interface Sticky {
  id: string;
  text: string;
  x: number;
  y: number;
  color: string;
}
export interface RecentCall {
  id: string;
  name: string;
  number: string;
  at: number;
}
export interface Workout {
  id: string;
  kind: string;
  seconds: number;
  at: number;
}

export interface PhoneData {
  lang: Lang;
  wallpaper: string;
  brightness: number;
  volume: number;
  wifi: boolean;
  bluetooth: boolean;
  airplane: boolean;
  cellular: boolean;
  lowPower: boolean;
  silent: boolean;
  flashlight: boolean;
  finish: Finish;
  home: string[];
  installed: string[];
  notes: Note[];
  contacts: Contact[];
  threads: Record<string, Thread>;
  events: CalEvent[];
  reminders: Reminder[];
  files: VFile[];
  photos: Photo[];
  alarms: Alarm[];
  webApps: WebApp[];
  mails: Mail[];
  journal: JournalEntry[];
  secrets: Secret[];
  cards: Card[];
  docs: Doc[];
  sheets: SheetDoc[];
  stickies: Sticky[];
  water: number;
  workouts: Workout[];
  recents: RecentCall[];
  lights: Record<string, boolean>;
}

export interface AppMeta {
  fa: string;
  en: string;
  cat: "main" | "tools" | "create" | "life";
  core: boolean;
  blurbFa: string;
  blurbEn: string;
}

export const DOCK = ["phone", "safari", "messages", "music"] as const;

export const DEFAULT_HOME = [
  "camera",
  "photos",
  "weather",
  "clock",
  "maps",
  "notes",
  "calendar",
  "reminders",
  "appstore",
  "settings",
  "calculator",
  "files",
  "mail",
  "health",
  "wallet",
  "stocks",
  "translate",
  "compass",
  "voicememo",
  "contacts",
  "books",
  "podcasts",
  "shortcuts",
  "fitness",
];

export const APPS: Record<string, AppMeta> = {
  phone: { fa: "تلفن", en: "Phone", cat: "main", core: true, blurbFa: "شماره‌گیری، مخاطبان و تماس", blurbEn: "Keypad, contacts and calls" },
  safari: { fa: "سافاری", en: "Safari", cat: "main", core: true, blurbFa: "وب و افزودن به صفحه اصلی", blurbEn: "Web and Add to Home Screen" },
  messages: { fa: "پیام‌ها", en: "Messages", cat: "main", core: true, blurbFa: "گفتگوهای روی دستگاه", blurbEn: "On-device conversations" },
  music: { fa: "موسیقی", en: "Music", cat: "main", core: true, blurbFa: "پخش آهنگ‌های اصلی", blurbEn: "Original tracks" },
  camera: { fa: "دوربین", en: "Camera", cat: "main", core: true, blurbFa: "عکس با دوربین دستگاه", blurbEn: "Shoot with the device camera" },
  photos: { fa: "عکس‌ها", en: "Photos", cat: "main", core: true, blurbFa: "گالری و علاقه‌مندی", blurbEn: "Library and favorites" },
  weather: { fa: "هواشناسی", en: "Weather", cat: "life", core: true, blurbFa: "دمای واقعی همین‌جا", blurbEn: "Live local forecast" },
  clock: { fa: "ساعت", en: "Clock", cat: "tools", core: true, blurbFa: "زنگ، زمان‌سنج، کرونومتر", blurbEn: "Alarms, timer, stopwatch" },
  maps: { fa: "نقشه", en: "Maps", cat: "life", core: true, blurbFa: "نقشه و موقعیت", blurbEn: "Map and location" },
  notes: { fa: "یادداشت", en: "Notes", cat: "create", core: true, blurbFa: "یادداشت سریع", blurbEn: "Quick notes" },
  calendar: { fa: "تقویم", en: "Calendar", cat: "life", core: true, blurbFa: "تقویم شمسی و رویداد", blurbEn: "Month and events" },
  reminders: { fa: "یادآورها", en: "Reminders", cat: "life", core: true, blurbFa: "فهرست کارها", blurbEn: "To-dos" },
  appstore: { fa: "اپ استور", en: "App Store", cat: "main", core: true, blurbFa: "نصب اپ و وب‌اپ", blurbEn: "Install apps and web apps" },
  settings: { fa: "تنظیمات", en: "Settings", cat: "tools", core: true, blurbFa: "ظاهر، صدا، زبان", blurbEn: "Look, sound, language" },
  calculator: { fa: "ماشین‌حساب", en: "Calculator", cat: "tools", core: true, blurbFa: "حساب چهارعمل", blurbEn: "Arithmetic" },
  files: { fa: "فایل‌ها", en: "Files", cat: "tools", core: true, blurbFa: "پوشه و فایل متنی", blurbEn: "Folders and text files" },
  mail: { fa: "ایمیل", en: "Mail", cat: "main", core: true, blurbFa: "صندوق روی دستگاه", blurbEn: "On-device inbox" },
  health: { fa: "سلامت", en: "Health", cat: "life", core: true, blurbFa: "حلقه‌ها و آب", blurbEn: "Rings and water" },
  wallet: { fa: "کیف پول", en: "Wallet", cat: "life", core: true, blurbFa: "کارت‌های نمایشی", blurbEn: "Visual cards" },
  stocks: { fa: "سهام", en: "Stocks", cat: "life", core: true, blurbFa: "نمودار بازار نمونه", blurbEn: "Sample market charts" },
  translate: { fa: "ترجمه", en: "Translate", cat: "tools", core: true, blurbFa: "واژه‌نامه آفلاین", blurbEn: "Offline dictionary" },
  compass: { fa: "قطب‌نما", en: "Compass", cat: "tools", core: true, blurbFa: "جهت دستگاه", blurbEn: "Device heading" },
  voicememo: { fa: "یادداشت صوتی", en: "Voice Memos", cat: "create", core: true, blurbFa: "ضبط صدا", blurbEn: "Record audio" },
  contacts: { fa: "مخاطبان", en: "Contacts", cat: "main", core: true, blurbFa: "دفترچه تلفن", blurbEn: "Address book" },
  books: { fa: "کتاب", en: "Books", cat: "create", core: true, blurbFa: "داستان کوتاه", blurbEn: "Short stories" },
  podcasts: { fa: "پادکست", en: "Podcasts", cat: "create", core: true, blurbFa: "اپیزود و پخش", blurbEn: "Episodes" },
  shortcuts: { fa: "میانبرها", en: "Shortcuts", cat: "tools", core: true, blurbFa: "کارهای یک‌ضربه", blurbEn: "One-tap actions" },
  fitness: { fa: "تناسب", en: "Fitness", cat: "life", core: true, blurbFa: "تمرین با زمان", blurbEn: "Timed workouts" },
  news: { fa: "اخبار", en: "News", cat: "life", core: false, blurbFa: "تیترهای نمونه", blurbEn: "Sample headlines" },
  tv: { fa: "تماشا", en: "TV", cat: "create", core: false, blurbFa: "پوستر و پخش", blurbEn: "Posters and player" },
  homeapp: { fa: "خانه", en: "Home", cat: "life", core: false, blurbFa: "چراغ اتاق‌ها", blurbEn: "Room lights" },
  find: { fa: "پیدا کن", en: "Find", cat: "life", core: false, blurbFa: "رادار این دستگاه", blurbEn: "This device" },
  journal: { fa: "دفتر روزانه", en: "Journal", cat: "create", core: false, blurbFa: "خاطره روزانه", blurbEn: "Daily journal" },
  passwords: { fa: "رمزها", en: "Passwords", cat: "tools", core: false, blurbFa: "یادداشت رمز، فقط همین دستگاه", blurbEn: "Local-only secrets" },
  measure: { fa: "اندازه", en: "Measure", cat: "tools", core: false, blurbFa: "خط‌کش و تراز", blurbEn: "Ruler and level" },
  tips: { fa: "نکته‌ها", en: "Tips", cat: "tools", core: false, blurbFa: "کار با این آیفون", blurbEn: "How to use this iPhone" },
  studio: { fa: "استودیو", en: "Studio", cat: "create", core: false, blurbFa: "پد ریتم", blurbEn: "Drum pads" },
  sheets: { fa: "جدول", en: "Sheets", cat: "create", core: false, blurbFa: "جدول کوچک", blurbEn: "Tiny spreadsheet" },
  writer: { fa: "نوشته", en: "Writer", cat: "create", core: false, blurbFa: "متن بلند", blurbEn: "Long-form writing" },
  board: { fa: "تخته", en: "Board", cat: "create", core: false, blurbFa: "یادداشت چسبان", blurbEn: "Sticky notes" },
  magnifier: { fa: "ذره‌بین", en: "Magnifier", cat: "tools", core: false, blurbFa: "زوم دوربین", blurbEn: "Camera zoom" },
};

export const WALLPAPERS = [
  { id: "aurora", url: "/wallpapers/aurora.jpg", fa: "شفق", en: "Aurora" },
  { id: "dune", url: "/wallpapers/dune.jpg", fa: "کویر", en: "Dune" },
  { id: "ocean", url: "/wallpapers/ocean.jpg", fa: "اقیانوس", en: "Ocean" },
  { id: "mist", url: "/wallpapers/mist.jpg", fa: "مه", en: "Mist" },
];

export const CITIES = [
  { fa: "تهران", en: "Tehran", lat: 35.6892, lon: 51.389, tz: "Asia/Tehran" },
  { fa: "شیراز", en: "Shiraz", lat: 29.5918, lon: 52.5837, tz: "Asia/Tehran" },
  { fa: "اصفهان", en: "Isfahan", lat: 32.6539, lon: 51.666, tz: "Asia/Tehran" },
  { fa: "مشهد", en: "Mashhad", lat: 36.2605, lon: 59.6168, tz: "Asia/Tehran" },
  { fa: "کیش", en: "Kish", lat: 26.532, lon: 53.98, tz: "Asia/Tehran" },
  { fa: "شیکاگو", en: "Chicago", lat: 41.8781, lon: -87.6298, tz: "America/Chicago" },
  { fa: "دبی", en: "Dubai", lat: 25.2048, lon: 55.2708, tz: "Asia/Dubai" },
  { fa: "استانبول", en: "Istanbul", lat: 41.0082, lon: 28.9784, tz: "Europe/Istanbul" },
  { fa: "پاریس", en: "Paris", lat: 48.8566, lon: 2.3522, tz: "Europe/Paris" },
  { fa: "توکیو", en: "Tokyo", lat: 35.6762, lon: 139.6503, tz: "Asia/Tokyo" },
];

const JM = ["فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];
const GM = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const WD_FA = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
const WD_EN = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export function faNum(input: string | number, lang: Lang): string {
  const s = String(input);
  if (lang !== "fa") return s;
  return s.replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)] ?? d);
}

export function uid(prefix = "id"): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 9)}`;
}

export function appName(id: string, lang: Lang, web?: WebApp): string {
  if (web) return web.name;
  const m = APPS[id];
  if (!m) return id;
  return lang === "fa" ? m.fa : m.en;
}

export function formatClock(d: Date, lang: Lang): string {
  const h = lang === "en" ? d.getHours() % 12 || 12 : d.getHours();
  const m = d.getMinutes().toString().padStart(2, "0");
  return faNum(`${h}:${m}`, lang);
}

export function formatLockDate(d: Date, lang: Lang): string {
  if (lang === "en") {
    return `${WD_EN[d.getDay()]}, ${GM[d.getMonth()]} ${d.getDate()}`;
  }
  const j = toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
  return `${WD_FA[d.getDay()]} ${faNum(j.jd, "fa")} ${JM[j.jm - 1]}`;
}

export function jalaliParts(d: Date) {
  return toJalaali(d.getFullYear(), d.getMonth() + 1, d.getDate());
}

export function monthTitle(view: { y: number; m: number }, lang: Lang): string {
  if (lang === "en") return `${GM[view.m - 1]} ${view.y}`;
  return `${JM[view.m - 1]} ${faNum(view.y, "fa")}`;
}

export function monthGrid(view: { y: number; m: number }, lang: Lang) {
  if (lang === "en") {
    const first = new Date(view.y, view.m - 1, 1);
    const start = first.getDay();
    const days = new Date(view.y, view.m, 0).getDate();
    const cells: { key: string; label: string; inMonth: boolean }[] = [];
    for (let i = 0; i < start; i++) cells.push({ key: `e${i}`, label: "", inMonth: false });
    for (let d = 1; d <= days; d++) {
      const dt = new Date(view.y, view.m - 1, d);
      const key = `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
      cells.push({ key, label: String(d), inMonth: true });
    }
    return cells;
  }
  const len = jalaaliMonthLength(view.y, view.m);
  const g = toGregorian(view.y, view.m, 1);
  const first = new Date(g.gy, g.gm - 1, g.gd);
  const start = first.getDay();
  const cells: { key: string; label: string; inMonth: boolean }[] = [];
  for (let i = 0; i < start; i++) cells.push({ key: `e${i}`, label: "", inMonth: false });
  for (let d = 1; d <= len; d++) {
    const gg = toGregorian(view.y, view.m, d);
    const key = `${gg.gy}-${String(gg.gm).padStart(2, "0")}-${String(gg.gd).padStart(2, "0")}`;
    cells.push({ key, label: faNum(d, "fa"), inMonth: true });
  }
  return cells;
}

export function todayKey(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function shiftMonth(view: { y: number; m: number }, dir: number, lang: Lang) {
  let m = view.m + dir;
  let y = view.y;
  if (m > 12) {
    m = 1;
    y += 1;
  } else if (m < 1) {
    m = 12;
    y -= 1;
  }
  if (lang === "fa" && m === 12) {
    /* keep */
  }
  return { y, m };
}

export function initialView(d: Date, lang: Lang) {
  if (lang === "en") return { y: d.getFullYear(), m: d.getMonth() + 1 };
  const j = jalaliParts(d);
  return { y: j.jy, m: j.jm };
}

export const DICT: { fa: string; en: string }[] = [
  { fa: "سلام", en: "hello" },
  { fa: "خداحافظ", en: "goodbye" },
  { fa: "ممنون", en: "thank you" },
  { fa: "لطفاً", en: "please" },
  { fa: "بله", en: "yes" },
  { fa: "نه", en: "no" },
  { fa: "آب", en: "water" },
  { fa: "نان", en: "bread" },
  { fa: "خانه", en: "home" },
  { fa: "تلفن", en: "phone" },
  { fa: "کتاب", en: "book" },
  { fa: "عشق", en: "love" },
  { fa: "دوست", en: "friend" },
  { fa: "زمان", en: "time" },
  { fa: "روز", en: "day" },
  { fa: "شب", en: "night" },
  { fa: "شهر", en: "city" },
  { fa: "ماشین", en: "car" },
  { fa: "غذا", en: "food" },
  { fa: "قهوه", en: "coffee" },
  { fa: "کار", en: "work" },
  { fa: "مدرسه", en: "school" },
  { fa: "موسیقی", en: "music" },
  { fa: "عکس", en: "photo" },
  { fa: "باران", en: "rain" },
  { fa: "آفتاب", en: "sun" },
  { fa: "دریا", en: "sea" },
  { fa: "کوه", en: "mountain" },
  { fa: "امروز", en: "today" },
  { fa: "فردا", en: "tomorrow" },
  { fa: "دیروز", en: "yesterday" },
  { fa: "خانواده", en: "family" },
  { fa: "نام", en: "name" },
  { fa: "آدرس", en: "address" },
  { fa: "کمک", en: "help" },
  { fa: "زیبا", en: "beautiful" },
  { fa: "بزرگ", en: "big" },
  { fa: "کوچک", en: "small" },
  { fa: "سریع", en: "fast" },
  { fa: "آرام", en: "slow" },
];

export function blankSheet(): string[][] {
  return Array.from({ length: 8 }, () => Array.from({ length: 4 }, () => ""));
}

export const DEFAULT_DATA: PhoneData = {
  lang: "fa",
  wallpaper: WALLPAPERS[0]!.url,
  brightness: 1,
  volume: 0.7,
  wifi: true,
  bluetooth: true,
  airplane: false,
  cellular: true,
  lowPower: false,
  silent: false,
  flashlight: false,
  finish: "black",
  home: DEFAULT_HOME,
  installed: [],
  notes: [
    {
      id: "n1",
      title: "ایده آیفون",
      body: "آیکون‌ها ۶۰ نقطه هستند. چهار ستون. داک بدون اسم. برای نصب اپ برو به اپ استور.",
      updated: 1761180000000,
    },
    {
      id: "n2",
      title: "خرید",
      body: "قهوه، نان، باتری ساعت.",
      updated: 1761100000000,
    },
  ],
  contacts: [
    { id: "c1", name: "سارا نادری", phone: "09120001111", color: "#34C759" },
    { id: "c2", name: "امیر حسینی", phone: "09123334455", color: "#0A84FF" },
    { id: "c3", name: "نیکا", phone: "09351112233", color: "#FF9F0A" },
    { id: "c4", name: "دفتر", phone: "02188001234", color: "#8E8E93" },
  ],
  threads: {
    c1: {
      unread: 1,
      messages: [
        { id: "m1", from: "them", text: "فردا ساعت ۱۰ همون کافه؟", at: 1761182000000 },
        { id: "m2", from: "me", text: "آره، میز کنار پنجره.", at: 1761182300000 },
        { id: "m3", from: "them", text: "عالی. عکس منو رو هم بفرست.", at: 1761184000000 },
      ],
    },
    c2: {
      unread: 0,
      messages: [{ id: "m4", from: "them", text: "فایل پروژه رو گذاشتم توی فایل‌ها.", at: 1761000000000 }],
    },
  },
  events: [
    { id: "e1", title: "قرار کافه", day: "2026-10-24", time: "10:00", color: "#0A84FF" },
    { id: "e2", title: "تمرین", day: "2026-10-25", time: "18:30", color: "#30D158" },
  ],
  reminders: [
    { id: "r1", title: "شارژ ساعت", done: false },
    { id: "r2", title: "پاسخ ایمیل دفتر", done: false },
    { id: "r3", title: "والپیپر جدید", done: true },
  ],
  files: [
    { id: "f-doc", name: "Documents", kind: "folder", parent: null },
    { id: "f-dl", name: "Downloads", kind: "folder", parent: null },
    { id: "f1", name: "یادداشت.txt", kind: "text", parent: "f-doc", body: "این یک فایل متنی روی همین دستگاه است." },
  ],
  photos: [
    { id: "ph1", url: "/wallpapers/dune.jpg", at: 1761000000000 },
    { id: "ph2", url: "/wallpapers/ocean.jpg", at: 1760900000000 },
    { id: "ph3", url: "/wallpapers/mist.jpg", at: 1760800000000, fav: true },
  ],
  alarms: [
    { id: "a1", hour: 7, minute: 0, on: false, label: "بیدارباش" },
    { id: "a2", hour: 22, minute: 30, on: false, label: "خاموشی" },
  ],
  webApps: [],
  mails: [
    {
      id: "ml1",
      from: "ALI Phone",
      subject: "به آیفون مجازی خوش آمدی",
      body: "از اپ استور هر برنامه‌ای را نصب کن. در سافاری هم می‌توانی سایت را به صفحهٔ اصلی اضافه کنی. همه چیز روی همین دستگاه می‌ماند.",
      read: false,
      at: 1761180000000,
    },
    {
      id: "ml2",
      from: "سارا",
      subject: "منوی کافه",
      body: "اسپرسو و چیزکیک. اگر دیر کردم شروع کن.",
      read: true,
      at: 1761000000000,
    },
  ],
  journal: [{ id: "j1", body: "اولین روز با این آیفون. صفحهٔ اصلی دقیقاً چهار ستون است.", at: 1761180000000 }],
  secrets: [],
  cards: [
    { id: "cd1", label: "ALI", last4: "1616", color: "#1c1c1e", holder: "ALI PHONE" },
    { id: "cd2", label: "Cash", last4: "0420", color: "#0A84FF", holder: "EVERYDAY" },
  ],
  docs: [{ id: "d1", title: "بدون عنوان", body: "" }],
  sheets: [{ id: "s1", name: "بودجه", cells: blankSheet() }],
  stickies: [
    { id: "st1", text: "ایده", x: 24, y: 24, color: "#FFE066" },
    { id: "st2", text: "بعداً", x: 150, y: 90, color: "#FFD6E0" },
  ],
  water: 2,
  workouts: [],
  recents: [{ id: "rc1", name: "سارا نادری", number: "09120001111", at: 1761180000000 }],
  lights: { "اتاق": true, "آشپزخانه": false, "کار": true },
};

export function available(data: PhoneData, id: string): boolean {
  if (id.startsWith("web:")) return data.webApps.some((w) => w.id === id);
  const meta = APPS[id];
  if (!meta) return false;
  return meta.core || data.installed.includes(id);
}

export function webOf(data: PhoneData, id: string): WebApp | undefined {
  return data.webApps.find((w) => w.id === id);
}

export type Op = "+" | "−" | "×" | "÷";
export interface CalcState {
  disp: string;
  acc: number | null;
  op: Op | null;
  fresh: boolean;
  error: boolean;
}

export const CALC0: CalcState = { disp: "0", acc: null, op: null, fresh: true, error: false };

function parseDisp(s: string): number {
  const n = Number(s.replace("−", "-"));
  return Number.isFinite(n) ? n : NaN;
}

function formatNum(n: number): string {
  if (!Number.isFinite(n)) return "خطا";
  const abs = Math.abs(n);
  if (abs !== 0 && (abs >= 1e9 || abs < 1e-9)) {
    return n.toExponential(4).replace("+", "").replace("-", "−");
  }
  let s = String(Number(n.toPrecision(10)));
  if (s.replace("-", "").replace(".", "").length > 9) s = n.toExponential(4).replace("+", "");
  return s.replace("-", "−");
}

function compute(a: number, op: Op, b: number): number {
  if (op === "+") return a + b;
  if (op === "−") return a - b;
  if (op === "×") return a * b;
  if (b === 0) return NaN;
  return a / b;
}

export function calcKey(state: CalcState, key: string): CalcState {
  if (key === "AC" || (key === "C" && state.error)) return { ...CALC0 };
  if (state.error && key !== "AC") return { ...CALC0 };
  if (key === "C") return { ...state, disp: "0", fresh: true };

  if (key === "±") {
    if (state.disp === "0") return state;
    const neg = state.disp.startsWith("−");
    return { ...state, disp: neg ? state.disp.slice(1) : `−${state.disp}` };
  }

  if (key === "%") {
    const cur = parseDisp(state.disp);
    if (state.op && state.acc != null && (state.op === "+" || state.op === "−")) {
      return { ...state, disp: formatNum(state.acc * (cur / 100)), fresh: true };
    }
    return { ...state, disp: formatNum(cur / 100), fresh: true };
  }

  if (key === "+" || key === "−" || key === "×" || key === "÷") {
    const cur = parseDisp(state.disp);
    if (state.acc != null && state.op && !state.fresh) {
      const r = compute(state.acc, state.op, cur);
      if (!Number.isFinite(r)) return { ...CALC0, disp: "خطا", error: true };
      return { disp: formatNum(r), acc: r, op: key, fresh: true, error: false };
    }
    return { ...state, acc: cur, op: key, fresh: true, error: false };
  }

  if (key === "=") {
    if (state.acc == null || !state.op) return state;
    const r = compute(state.acc, state.op, parseDisp(state.disp));
    if (!Number.isFinite(r)) return { ...CALC0, disp: "خطا", error: true };
    return { disp: formatNum(r), acc: null, op: null, fresh: true, error: false };
  }

  if (/^[0-9.]$/.test(key)) {
    if (state.fresh) {
      return { ...state, disp: key === "." ? "0." : key, fresh: false, error: false };
    }
    if (key === "." && state.disp.includes(".")) return state;
    if (state.disp.replace("−", "").replace(".", "").length >= 9) return state;
    const next = state.disp === "0" && key !== "." ? key : state.disp + key;
    return { ...state, disp: next };
  }
  return state;
}

export function mergeSaved(raw: unknown): PhoneData {
  if (!raw || typeof raw !== "object") return DEFAULT_DATA;
  const s = raw as Partial<PhoneData>;
  const home = Array.isArray(s.home) ? s.home.filter((id) => typeof id === "string") : DEFAULT_DATA.home;
  return {
    ...DEFAULT_DATA,
    ...s,
    home,
    installed: Array.isArray(s.installed) ? s.installed.filter((id) => typeof id === "string") : [],
    webApps: Array.isArray(s.webApps) ? s.webApps : [],
    notes: Array.isArray(s.notes) ? s.notes : DEFAULT_DATA.notes,
    contacts: Array.isArray(s.contacts) ? s.contacts : DEFAULT_DATA.contacts,
    threads: s.threads && typeof s.threads === "object" ? s.threads : DEFAULT_DATA.threads,
    events: Array.isArray(s.events) ? s.events : DEFAULT_DATA.events,
    reminders: Array.isArray(s.reminders) ? s.reminders : DEFAULT_DATA.reminders,
    files: Array.isArray(s.files) ? s.files : DEFAULT_DATA.files,
    photos: Array.isArray(s.photos) ? s.photos : DEFAULT_DATA.photos,
    alarms: Array.isArray(s.alarms) ? s.alarms : DEFAULT_DATA.alarms,
    mails: Array.isArray(s.mails) ? s.mails : DEFAULT_DATA.mails,
    journal: Array.isArray(s.journal) ? s.journal : DEFAULT_DATA.journal,
    secrets: Array.isArray(s.secrets) ? s.secrets : [],
    cards: Array.isArray(s.cards) ? s.cards : DEFAULT_DATA.cards,
    docs: Array.isArray(s.docs) ? s.docs : DEFAULT_DATA.docs,
    sheets: Array.isArray(s.sheets) ? s.sheets : DEFAULT_DATA.sheets,
    stickies: Array.isArray(s.stickies) ? s.stickies : DEFAULT_DATA.stickies,
    recents: Array.isArray(s.recents) ? s.recents : DEFAULT_DATA.recents,
    lights: s.lights && typeof s.lights === "object" ? s.lights : DEFAULT_DATA.lights,
    workouts: Array.isArray(s.workouts) ? s.workouts : [],
    lang: s.lang === "en" ? "en" : "fa",
    wallpaper: typeof s.wallpaper === "string" ? s.wallpaper : DEFAULT_DATA.wallpaper,
    finish: s.finish === "natural" || s.finish === "desert" || s.finish === "white" || s.finish === "black" ? s.finish : "black",
  };
}
