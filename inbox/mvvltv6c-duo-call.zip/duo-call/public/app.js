'use strict';
/* دونفره — کلاینت: جفت‌سازی با کد، چت E2EE (ECDH P-256 + AES-GCM)، تماس WebRTC */
const $ = (s) => document.querySelector(s);
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
  del(k) { try { localStorage.removeItem(k); } catch {} },
};
const hex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
const b64 = (buf) => {
  const u = new Uint8Array(buf); let s = '';
  for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
  return btoa(s);
};
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
const normDigits = (s) => s.replace(/[۰-۹]/g, (d) => d.charCodeAt(0) - 0x6f0).replace(/[٠-٩]/g, (d) => d.charCodeAt(0) - 0x660).replace(/\D/g, '');
const ECDH = { name: 'ECDH', namedCurve: 'P-256' };

let st = store.get('duo', null);          // { deviceId, code, paired, jwkPriv, pubB64 }
let privKey = null, aesKey = null, peerPub = null;
let ws = null, wsOpen = false, peerOnline = false, backoff = 1000, pendingAction = null, stopReconnect = false;
let msgs = store.get('msgs', []);

function toast(t, ms = 2800) {
  const el = $('#toast'); el.textContent = t; el.hidden = false;
  clearTimeout(toast.t); toast.t = setTimeout(() => (el.hidden = true), ms);
}
function save() { store.set('duo', { deviceId: st.deviceId, code: st.code, paired: st.paired, jwkPriv: st.jwkPriv, pubB64: st.pubB64 }); }

/* ---------- کلیدها ---------- */
async function initKeys() {
  if (!st) st = { deviceId: hex(crypto.getRandomValues(new Uint8Array(16))) };
  if (st.jwkPriv && st.pubB64) {
    privKey = await crypto.subtle.importKey('jwk', st.jwkPriv, ECDH, false, ['deriveKey']);
  } else {
    const kp = await crypto.subtle.generateKey(ECDH, true, ['deriveKey']);
    st.jwkPriv = await crypto.subtle.exportKey('jwk', kp.privateKey);
    st.pubB64 = b64(await crypto.subtle.exportKey('raw', kp.publicKey));
    privKey = await crypto.subtle.importKey('jwk', st.jwkPriv, ECDH, false, ['deriveKey']);
  }
  save();
}
async function setPeerPub(p) {
  if (!p || p === peerPub) return;
  peerPub = p;
  const pk = await crypto.subtle.importKey('raw', unb64(p), ECDH, false, []);
  aesKey = await crypto.subtle.deriveKey({ name: 'ECDH', public: pk }, privKey, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  updateFingerprint();
}
async function encrypt(text) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, aesKey, new TextEncoder().encode(JSON.stringify({ t: text })));
  const out = new Uint8Array(12 + ct.byteLength); out.set(iv); out.set(new Uint8Array(ct), 12);
  return b64(out);
}
async function decrypt(c) {
  const u = unb64(c);
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: u.slice(0, 12) }, aesKey, u.slice(12));
  return JSON.parse(new TextDecoder().decode(pt)).t;
}
async function updateFingerprint() {
  if (!peerPub) { $('#fp').textContent = '—'; return; }
  const [a, b] = [st.pubB64, peerPub].sort();
  const h = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(a + b)));
  const g = []; for (let i = 0; i < 8; i += 2) g.push(String(((h[i] << 8) | h[i + 1]) % 100000).padStart(5, '0'));
  $('#fp').textContent = g.join(' ');
}

/* ---------- اتصال ---------- */
function wsSend(o) { if (ws && ws.readyState === 1) ws.send(JSON.stringify(o)); }
function connect() {
  stopReconnect = false;
  ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`);
  ws.onopen = () => { wsOpen = true; backoff = 1000; handshake(); render(); };
  ws.onmessage = (e) => { try { onMsg(JSON.parse(e.data)); } catch (err) { console.error(err); } };
  ws.onclose = (e) => {
    wsOpen = false; peerOnline = false; render();
    if (call) endCall('اتصال قطع شد', false);
    if (e.code === 4000) { stopReconnect = true; toast('برنامه در جای دیگری باز شد'); return; }
    setTimeout(() => { if (!stopReconnect) connect(); }, backoff);
    backoff = Math.min(backoff * 2, 15000);
  };
}
function handshake() {
  if (pendingAction) { wsSend({ ...pendingAction, deviceId: st.deviceId, pub: st.pubB64 }); pendingAction = null; }
  else if (st.code) wsSend({ type: 'resume', code: st.code, deviceId: st.deviceId, pub: st.pubB64 });
}
const ERR = {
  not_found: 'این کد پیدا نشد.', room_full: 'این کد قبلاً برای دو نفر استفاده شده.', expired: 'این کد منقضی شده؛ کد جدید بسازید.',
  too_many: 'تلاش‌های زیاد. چند دقیقه بعد دوباره امتحان کنید.', not_member: 'این دستگاه عضو این گفتگو نیست.', bad_device: 'خطای دستگاه.',
};
async function onMsg(m) {
  switch (m.type) {
    case 'joined':
      st.code = m.code; st.paired = m.paired; save();
      peerOnline = m.peerOnline; await setPeerPub(m.peerPub); render(); break;
    case 'peer':
      peerOnline = m.online;
      if (m.paired) { st.paired = true; save(); }
      await setPeerPub(m.peerPub);
      if (!m.online && call) endCall('همسرت قطع شد', false);
      render(); break;
    case 'error':
      if (m.error === 'not_found' || m.error === 'not_member') {
        if (st.code) { resetPairing(); }
      }
      $('#welcomeErr').textContent = ERR[m.error] || 'خطا';
      break;
    case 'chat': {
      let t; try { t = await decrypt(m.c); } catch { t = '⚠️ پیام قابل رمزگشایی نبود'; }
      addMsg({ id: m.id, me: false, t, ts: m.ts });
      wsSend({ type: 'ack', id: m.id });
      if (document.hidden) notify('پیام جدید', 'یک پیام دریافت کردی');
      break;
    }
    case 'sent': setMsgState(m.id, 'sent'); break;
    case 'ack': setMsgState(m.id, 'read'); break;
    case 'call': onCall(m.d); break;
    case 'signal': onSignal(m.d); break;
  }
}
function resetPairing() {
  const keep = { deviceId: st.deviceId, jwkPriv: st.jwkPriv, pubB64: st.pubB64 };
  st = keep; peerPub = null; aesKey = null; msgs = []; store.del('msgs'); save(); render();
}

/* ---------- رابط ---------- */
function show(id) { for (const s of ['welcome', 'waiting', 'chat']) $('#' + s).hidden = s !== id; }
function render() {
  if (!st || !st.code) show('welcome');
  else if (!st.paired) { show('waiting'); $('#bigCode').textContent = st.code; }
  else show('chat');
  const s = $('#status');
  s.textContent = !wsOpen ? 'در حال اتصال…' : peerOnline ? 'آنلاین' : 'آفلاین';
  s.className = wsOpen && peerOnline ? 'on' : '';
}
const fmtTime = (ts) => new Date(ts).toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' });
const MARK = { pending: '⏳', sent: '✓', read: '✓✓' };
function renderMsgs() {
  const list = $('#list'); list.textContent = '';
  for (const m of msgs) {
    const d = document.createElement('div');
    if (m.sys) { d.className = 'sys'; d.textContent = m.t; }
    else {
      d.className = 'msg ' + (m.me ? 'me' : 'peer'); d.dataset.id = m.id;
      const b = document.createElement('span'); b.dir = 'auto'; b.textContent = m.t;
      const t = document.createElement('span'); t.className = 't'; t.textContent = fmtTime(m.ts) + (m.me ? ' ' + (MARK[m.st] || '') : '');
      d.append(b, t);
    }
    list.append(d);
  }
  list.scrollTop = list.scrollHeight;
}
function addMsg(m) { msgs.push(m); if (msgs.length > 500) msgs.shift(); store.set('msgs', msgs); renderMsgs(); }
function setMsgState(id, s) {
  const m = msgs.find((x) => x.id === id); if (!m || (m.st === 'read' && s === 'sent')) return;
  m.st = s; store.set('msgs', msgs); renderMsgs();
}
async function sendText(text) {
  text = text.trim(); if (!text) return;
  if (!aesKey) return toast('کلید رمزنگاری هنوز آماده نیست');
  if (!wsOpen) return toast('اتصال برقرار نیست');
  const id = hex(crypto.getRandomValues(new Uint8Array(8))), ts = Date.now();
  addMsg({ id, me: true, t: text, ts, st: 'pending' });
  wsSend({ type: 'chat', id, ts, c: await encrypt(text) });
}

/* ---------- اعلان محلی (وقتی برنامه باز ولی در پس‌زمینه است) ---------- */
async function notify(title, body, opts = {}) {
  try {
    if (Notification.permission !== 'granted') return;
    const reg = await navigator.serviceWorker.ready;
    reg.showNotification(title, { body, icon: '/icon-192.png', tag: opts.tag || 'duo', renotify: true, vibrate: [200, 100, 200], ...opts });
  } catch {}
}

/* ---------- تماس ---------- */
let call = null; let ring = null; let actx = null; let wake = null;
function ringStart(kind) {
  ringStop();
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const beep = () => {
      for (const [f, off] of [[440, 0], [480, 0.0]]) {
        const o = actx.createOscillator(), g = actx.createGain();
        o.frequency.value = f; o.connect(g); g.connect(actx.destination);
        g.gain.setValueAtTime(0.0001, actx.currentTime + off);
        g.gain.exponentialRampToValueAtTime(0.15, actx.currentTime + off + 0.05);
        g.gain.exponentialRampToValueAtTime(0.0001, actx.currentTime + off + 0.9);
        o.start(actx.currentTime + off); o.stop(actx.currentTime + off + 1);
      }
      if (kind === 'in' && navigator.vibrate) navigator.vibrate([500, 300, 500]);
    };
    beep(); ring = setInterval(beep, 2500);
  } catch {}
}
function ringStop() { clearInterval(ring); ring = null; if (navigator.vibrate) navigator.vibrate(0); }
document.addEventListener('click', () => { try { actx = actx || new (window.AudioContext || window.webkitAudioContext)(); actx.resume(); } catch {} }, { once: true });

const getMedia = (video) => navigator.mediaDevices.getUserMedia({
  audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
  video: video ? { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } } : false,
});
const sendCall = (d) => wsSend({ type: 'call', d });
const sendSignal = (d) => wsSend({ type: 'signal', d });

function showCallUI(video) {
  const c = $('#call'); c.hidden = false; c.className = 'overlay call' + (video ? ' video' : '');
  $('#local').srcObject = call.stream || null;
  $('#btnMute').classList.remove('off'); $('#btnCam').classList.remove('off');
}
async function startCall(video) {
  if (call) return;
  if (!wsOpen || !peerOnline) return toast('همسرت الان آنلاین نیست');
  if (!navigator.mediaDevices) return toast('برای تماس باید از https استفاده شود');
  let stream;
  try { stream = await getMedia(video); } catch { return toast('اجازه‌ی میکروفون/دوربین داده نشد'); }
  call = { role: 'caller', video, stream, state: 'ringing', t0: 0, queue: Promise.resolve(), ice: [] };
  showCallUI(video); $('#callState').textContent = 'در حال زنگ زدن…';
  sendCall({ k: 'invite', video }); ringStart('out');
  call.timeout = setTimeout(() => endCall('پاسخی نداد', true), 45000);
}
function onCall(d) {
  if (!d) return;
  if (d.k === 'invite') {
    if (call) return sendCall({ k: 'busy' });
    call = { role: 'callee', video: !!d.video, state: 'incoming', queue: Promise.resolve(), ice: [] };
    $('#incomingKind').textContent = d.video ? 'تماس تصویری ورودی…' : 'تماس صوتی ورودی…';
    $('#incoming').hidden = false; ringStart('in');
    if (document.hidden) notify('تماس ورودی از همسر', d.video ? 'تماس تصویری' : 'تماس صوتی', { tag: 'call', requireInteraction: true });
    call.timeout = setTimeout(() => { if (call && call.state === 'incoming') endCall('تماس از دست رفته', false); }, 46000);
  } else if (d.k === 'accept' && call && call.role === 'caller') {
    clearTimeout(call.timeout); ringStop(); call.state = 'connecting'; $('#callState').textContent = 'در حال اتصال…';
    setupPC().catch((e) => { console.error(e); endCall('خطا در برقراری تماس', true); });
  } else if (d.k === 'reject' && call) { endCall('تماس رد شد', false); }
  else if (d.k === 'busy' && call) { endCall('همسرت در تماس است', false); }
  else if (d.k === 'end' && call) { endCall('تماس پایان یافت', false); }
}
async function acceptCall() {
  if (!call || call.state !== 'incoming') return;
  clearTimeout(call.timeout); ringStop(); $('#incoming').hidden = true;
  try { call.stream = await getMedia(call.video); } catch { sendCall({ k: 'reject' }); call = null; return toast('اجازه‌ی میکروفون/دوربین داده نشد'); }
  call.state = 'connecting'; showCallUI(call.video); $('#callState').textContent = 'در حال اتصال…';
  try { await setupPC(); sendCall({ k: 'accept' }); } catch (e) { console.error(e); endCall('خطا در برقراری تماس', true); }
}
async function setupPC() {
  let iceServers = [{ urls: 'stun:stun.l.google.com:19302' }];
  try { iceServers = (await (await fetch('/ice', { cache: 'no-store' })).json()).iceServers; } catch {}
  const pc = new RTCPeerConnection({ iceServers });
  call.pc = pc;
  call.stream.getTracks().forEach((t) => pc.addTrack(t, call.stream));
  pc.ontrack = (e) => { $('#remote').srcObject = e.streams[0]; };
  pc.onicecandidate = (e) => { if (e.candidate) sendSignal({ c: e.candidate }); };
  pc.onconnectionstatechange = () => {
    if (!call || call.pc !== pc) return;
    if (pc.connectionState === 'connected') {
      if (!call.t0) { call.t0 = Date.now(); call.tick = setInterval(tickTimer, 1000); $('#call').classList.add('live'); lockWake(); }
      tickTimer();
    } else if (pc.connectionState === 'failed') endCall('اتصال برقرار نشد', true);
    else if (pc.connectionState === 'disconnected') $('#callState').textContent = 'اتصال ضعیف…';
  };
  // سیگنال‌هایی که قبل از آماده شدن pc رسیده‌اند
  if (call.role === 'caller') {
    const offer = await pc.createOffer(); await pc.setLocalDescription(offer); sendSignal({ s: pc.localDescription });
  }
}
function onSignal(d) {
  if (!call || !d) return;
  call.queue = call.queue.then(async () => {
    // منتظر آماده شدن pc (حداکثر ~۵ ثانیه)
    for (let i = 0; i < 100 && call && !call.pc; i++) await new Promise((r) => setTimeout(r, 50));
    if (!call || !call.pc) return;
    const pc = call.pc;
    if (d.s) {
      await pc.setRemoteDescription(d.s);
      if (d.s.type === 'offer') { const a = await pc.createAnswer(); await pc.setLocalDescription(a); sendSignal({ s: pc.localDescription }); }
      for (const c of call.ice.splice(0)) await pc.addIceCandidate(c).catch(() => {});
    } else if (d.c) {
      if (pc.remoteDescription) await pc.addIceCandidate(d.c).catch(() => {}); else call.ice.push(d.c);
    }
  }).catch((e) => console.error('signal', e));
}
function tickTimer() {
  if (!call || !call.t0) return;
  const s = Math.floor((Date.now() - call.t0) / 1000);
  $('#callState').textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
}
async function lockWake() { try { wake = await navigator.wakeLock.request('screen'); } catch {} }
function endCall(reason, notifyPeer) {
  if (!call) return;
  const c = call; call = null;
  if (notifyPeer) sendCall({ k: c.state === 'incoming' ? 'reject' : 'end' });
  clearTimeout(c.timeout); clearInterval(c.tick); ringStop();
  try { c.pc && c.pc.close(); } catch {}
  try { c.stream && c.stream.getTracks().forEach((t) => t.stop()); } catch {}
  try { wake && wake.release(); } catch {} wake = null;
  $('#call').hidden = true; $('#incoming').hidden = true; $('#remote').srcObject = null; $('#local').srcObject = null;
  let line = reason;
  if (c.t0) { const s = Math.floor((Date.now() - c.t0) / 1000); line = `${c.video ? 'تماس تصویری' : 'تماس صوتی'} — ${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; }
  else if (c.role === 'callee' && reason === 'تماس از دست رفته') line = 'تماس از دست رفته';
  addMsg({ id: 's' + Date.now(), sys: true, t: line, ts: Date.now() });
  toast(reason);
}

/* ---------- رویدادها ---------- */
$('#btnCreate').onclick = () => { $('#welcomeErr').textContent = ''; pendingAction = { type: 'create' }; if (wsOpen) handshake(); };
$('#joinForm').onsubmit = (e) => {
  e.preventDefault();
  const code = normDigits($('#codeIn').value);
  if (code.length !== 6) { $('#welcomeErr').textContent = 'کد باید ۶ رقم باشد.'; return; }
  $('#welcomeErr').textContent = ''; pendingAction = { type: 'join', code }; if (wsOpen) handshake();
};
$('#btnCopy').onclick = async () => { try { await navigator.clipboard.writeText(st.code); toast('کپی شد'); } catch { toast('کد را دستی بنویسید'); } };
$('#btnCancel').onclick = () => { resetPairing(); location.reload(); };
$('#sendForm').onsubmit = (e) => { e.preventDefault(); const i = $('#msgIn'); const v = i.value; i.value = ''; i.style.height = ''; sendText(v); i.focus(); };
$('#msgIn').addEventListener('input', (e) => { e.target.style.height = 'auto'; e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px'; });
$('#msgIn').addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !/Mobi|Android|iPhone/i.test(navigator.userAgent)) { e.preventDefault(); $('#sendForm').requestSubmit(); } });
$('#btnAudio').onclick = () => startCall(false);
$('#btnVideo').onclick = () => startCall(true);
$('#btnAccept').onclick = acceptCall;
$('#btnReject').onclick = () => endCall('تماس رد شد', true);
$('#btnHang').onclick = () => endCall('تماس پایان یافت', true);
$('#btnMute').onclick = (e) => {
  const t = call && call.stream && call.stream.getAudioTracks()[0]; if (!t) return;
  t.enabled = !t.enabled; e.currentTarget.classList.toggle('off', !t.enabled); e.currentTarget.textContent = t.enabled ? '🎤' : '🔇';
};
$('#btnCam').onclick = (e) => {
  const t = call && call.stream && call.stream.getVideoTracks()[0]; if (!t) return;
  t.enabled = !t.enabled; e.currentTarget.classList.toggle('off', !t.enabled);
};
$('#btnFlip').onclick = async () => {
  if (!call || !call.pc) return;
  const old = call.stream.getVideoTracks()[0]; if (!old) return;
  const cur = (old.getSettings().facingMode) === 'environment' ? 'user' : 'environment';
  try {
    const ns = await navigator.mediaDevices.getUserMedia({ video: { facingMode: cur } });
    const nt = ns.getVideoTracks()[0];
    const sender = call.pc.getSenders().find((s) => s.track && s.track.kind === 'video');
    if (sender) await sender.replaceTrack(nt);
    old.stop(); call.stream.removeTrack(old); call.stream.addTrack(nt);
    $('#local').srcObject = call.stream; $('#local').style.transform = cur === 'user' ? 'scaleX(-1)' : 'none';
  } catch { toast('چرخاندن دوربین ممکن نشد'); }
};
$('#btnMenu').onclick = () => { $('#sheet').hidden = false; updateFingerprint(); };
$('#btnCloseSheet').onclick = () => ($('#sheet').hidden = true);
$('#sheet').onclick = (e) => { if (e.target.id === 'sheet') $('#sheet').hidden = true; };
$('#btnNotif').onclick = async () => {
  if (!('Notification' in window)) return toast('این مرورگر اعلان را پشتیبانی نمی‌کند');
  const r = await Notification.requestPermission(); toast(r === 'granted' ? 'اعلان فعال شد' : 'اعلان فعال نشد');
};
$('#btnUnpair').onclick = () => { if (confirm('گفتگو از این گوشی پاک و اتصال قطع می‌شود. مطمئنی؟')) { resetPairing(); location.reload(); } };
document.addEventListener('visibilitychange', () => { if (!document.hidden && !wsOpen && ws && ws.readyState > 1) connect(); });

/* نصب */
let deferredInstall = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault(); deferredInstall = e;
  const h = $('#installHint'); h.hidden = false; h.innerHTML = ''; const b = document.createElement('button');
  b.className = 'secondary'; b.textContent = 'نصب برنامه روی گوشی'; b.onclick = () => deferredInstall.prompt(); h.append(b);
});
(function iosHint() {
  const ios = /iPhone|iPad|iPod/i.test(navigator.userAgent), standalone = navigator.standalone || matchMedia('(display-mode: standalone)').matches;
  if (ios && !standalone) { const h = $('#installHint'); h.hidden = false; h.textContent = 'برای نصب در آیفون: دکمه‌ی Share را بزن و «Add to Home Screen» را انتخاب کن (در Safari).'; }
})();

/* شروع */
(async function main() {
  if (!(window.crypto && crypto.subtle)) { $('#welcomeErr').textContent = 'این صفحه باید با https باز شود.'; return; }
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
  await initKeys();
  renderMsgs(); render(); connect();
})();
