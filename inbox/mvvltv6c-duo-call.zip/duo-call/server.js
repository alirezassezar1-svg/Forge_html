'use strict';
/**
 * Duo Call server — جفت‌سازی با کد، سیگنالینگ WebRTC، و رله‌ی پیام‌های رمزشده.
 * تنها وابستگی: ws (پیاده‌سازی WebSocket در خانه غیرایمن و بی‌دلیل است).
 * سرور هیچ‌وقت متن پیام‌ها را نمی‌بیند (E2EE سمت کلاینت).
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

const PORT = +process.env.PORT || 3000;
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data', 'rooms.json');
const PUBLIC = path.join(__dirname, 'public');
const STUN_URLS = (process.env.STUN_URLS || 'stun:stun.l.google.com:19302').split(',').filter(Boolean);
const TURN_URL = process.env.TURN_URL || '';          // مثل turn:turn.example.com:3478
const TURN_SECRET = process.env.TURN_SECRET || '';    // همان static-auth-secret در coturn
const PENDING_TTL = 10 * 60 * 1000;                   // کد جفت‌نشده ۱۰ دقیقه اعتبار دارد
const QUEUE_MAX = 200;

// rooms: code -> { code, members:[deviceId,deviceId?], created, queue:{deviceId:[msg]} }
let rooms = new Map();
try {
  const raw = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  for (const r of raw) rooms.set(r.code, r);
} catch { /* first run */ }

let saveTimer = null;
function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try {
      fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
      const tmp = DATA_FILE + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify([...rooms.values()]), { mode: 0o600 });
      fs.renameSync(tmp, DATA_FILE);
    } catch (e) { console.error('save failed', e.message); }
  }, 200);
}

const online = new Map(); // `${code}:${deviceId}` -> ws

function newCode() {
  for (let i = 0; i < 20; i++) {
    const c = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    if (!rooms.has(c)) return c;
  }
  throw new Error('no code');
}

// محدودیت تلاش برای جلوگیری از حدس زدن کد
const attempts = new Map(); // ip -> {n, t}
function tooMany(ip) {
  const now = Date.now();
  const a = attempts.get(ip) || { n: 0, t: now };
  if (now - a.t > 10 * 60 * 1000) { a.n = 0; a.t = now; }
  a.n++;
  attempts.set(ip, a);
  return a.n > 10;
}

function iceServers() {
  const list = [{ urls: STUN_URLS }];
  if (TURN_URL && TURN_SECRET) {
    const user = String(Math.floor(Date.now() / 1000) + 24 * 3600);
    const cred = crypto.createHmac('sha1', TURN_SECRET).update(user).digest('base64');
    list.push({ urls: TURN_URL.split(','), username: user, credential: cred });
  }
  return list;
}

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json',
  '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.svg': 'image/svg+xml',
};

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  const headers = {
    'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer',
    'Permissions-Policy': 'camera=(self), microphone=(self)',
  };
  if (url.pathname === '/ice') {
    res.writeHead(200, { ...headers, 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    return res.end(JSON.stringify({ iceServers: iceServers() }));
  }
  if (url.pathname === '/health') { res.writeHead(200, headers); return res.end('ok'); }
  let p = url.pathname === '/' ? '/index.html' : decodeURIComponent(url.pathname);
  const file = path.normalize(path.join(PUBLIC, p));
  if (!file.startsWith(PUBLIC + path.sep)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404, headers); return res.end('not found'); }
    const ext = path.extname(file);
    res.writeHead(200, {
      ...headers,
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': file.endsWith('sw.js') ? 'no-cache' : 'public, max-age=300',
    });
    res.end(buf);
  });
});

const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 256 * 1024 });

function send(ws, obj) { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); }

wss.on('connection', (ws, req) => {
  const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });
  ws.ctx = null; // {code, deviceId}
  let msgCount = 0, windowStart = Date.now();

  ws.on('message', (data) => {
    // محدودیت نرخ پیام
    const now = Date.now();
    if (now - windowStart > 10000) { windowStart = now; msgCount = 0; }
    if (++msgCount > 200) return ws.close(1008, 'rate');

    let m; try { m = JSON.parse(data); } catch { return; }
    if (!m || typeof m.type !== 'string') return;

    if (m.type === 'create' || m.type === 'join' || m.type === 'resume') {
      if (ws.ctx) return;
      const deviceId = String(m.deviceId || '');
      if (!/^[a-f0-9]{32}$/.test(deviceId)) return send(ws, { type: 'error', error: 'bad_device' });
      let room;
      if (m.type === 'create') {
        const code = newCode();
        room = { code, members: [deviceId], pub: {}, created: Date.now(), queue: {} };
        rooms.set(code, room);
      } else {
        if (tooMany(ip)) return send(ws, { type: 'error', error: 'too_many' });
        room = rooms.get(String(m.code || ''));
        if (!room) return send(ws, { type: 'error', error: 'not_found' });
        const isMember = room.members.includes(deviceId);
        if (m.type === 'resume' && !isMember) return send(ws, { type: 'error', error: 'not_member' });
        if (m.type === 'join' && !isMember) {
          if (room.members.length >= 2) return send(ws, { type: 'error', error: 'room_full' });
          if (Date.now() - room.created > PENDING_TTL) { rooms.delete(room.code); save(); return send(ws, { type: 'error', error: 'expired' }); }
          room.members.push(deviceId);
        }
      }
      if (typeof m.pub === 'string' && m.pub.length < 400) room.pub[deviceId] = m.pub;
      ws.ctx = { code: room.code, deviceId };
      const key = room.code + ':' + deviceId;
      const old = online.get(key);
      if (old && old !== ws) { try { old.close(4000, 'replaced'); } catch {} }
      online.set(key, ws);
      save();
      const peerId = room.members.find((d) => d !== deviceId);
      send(ws, {
        type: 'joined', code: room.code, paired: room.members.length === 2,
        peerPub: peerId ? room.pub[peerId] || null : null,
        peerOnline: !!(peerId && online.has(room.code + ':' + peerId)),
      });
      // تحویل پیام‌های صف‌شده
      const q = room.queue[deviceId];
      if (q && q.length) { for (const item of q) send(ws, item); room.queue[deviceId] = []; save(); }
      if (peerId) {
        const pws = online.get(room.code + ':' + peerId);
        if (pws) send(pws, { type: 'peer', online: true, paired: true, peerPub: room.pub[deviceId] || null });
      }
      return;
    }

    if (!ws.ctx) return;
    const room = rooms.get(ws.ctx.code);
    if (!room) return;
    const peerId = room.members.find((d) => d !== ws.ctx.deviceId);
    if (!peerId) return;
    const pws = online.get(room.code + ':' + peerId);

    if (m.type === 'chat') {
      // m.c = ciphertext (base64)، m.id = شناسه‌ی پیام، m.ts
      if (typeof m.c !== 'string' || m.c.length > 100000) return;
      const item = { type: 'chat', id: String(m.id).slice(0, 40), c: m.c, ts: +m.ts || Date.now() };
      if (pws) send(pws, item);
      else {
        const q = (room.queue[peerId] ||= []);
        q.push(item); if (q.length > QUEUE_MAX) q.shift();
        save();
      }
      return send(ws, { type: 'sent', id: item.id, delivered: !!pws });
    }
    if (m.type === 'signal' || m.type === 'call') {
      // رله‌ی بی‌ادعا؛ فقط وقتی مقابل آنلاین است
      if (!pws) return send(ws, { type: 'peer', online: false });
      return send(pws, { type: m.type, d: m.d });
    }
    if (m.type === 'ack') { if (pws) send(pws, { type: 'ack', id: String(m.id) }); }
  });

  ws.on('close', () => {
    if (!ws.ctx) return;
    const key = ws.ctx.code + ':' + ws.ctx.deviceId;
    if (online.get(key) === ws) {
      online.delete(key);
      const room = rooms.get(ws.ctx.code);
      const peerId = room && room.members.find((d) => d !== ws.ctx.deviceId);
      const pws = peerId && online.get(room.code + ':' + peerId);
      if (pws) send(pws, { type: 'peer', online: false });
    }
  });
});

// قلب تپنده + پاکسازی
setInterval(() => {
  for (const ws of wss.clients) {
    if (!ws.isAlive) { ws.terminate(); continue; }
    ws.isAlive = false; ws.ping();
  }
  const now = Date.now();
  let changed = false;
  for (const [code, r] of rooms) {
    if (r.members.length < 2 && now - r.created > PENDING_TTL && !online.has(code + ':' + r.members[0])) {
      rooms.delete(code); changed = true;
    }
  }
  if (changed) save();
}, 25000).unref();

if (require.main === module) {
  server.listen(PORT, () => console.log(`Duo Call on :${PORT}`));
}
module.exports = { server, rooms };
