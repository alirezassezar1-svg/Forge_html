'use strict';
// تست سرتاسری با دو مرورگر واقعی (Chromium + دوربین/میکروفون جعلی)
const { chromium } = require('playwright');
const assert = require('assert');
const os = require('os'), path = require('path'), fs = require('fs');

process.env.PORT = '3199';
process.env.DATA_FILE = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'duo-')), 'rooms.json');
const { server } = require('../server');
const URL = 'http://localhost:3199/';
const ok = (m) => console.log('  ✔', m);

(async () => {
  await new Promise((r) => server.listen(3199, r));
  const browser = await chromium.launch({
    args: ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream', '--autoplay-policy=no-user-gesture-required'],
  });
  const mk = async () => {
    const ctx = await browser.newContext({ permissions: ['camera', 'microphone'] });
    const p = await ctx.newPage(); p.on('pageerror', (e) => console.log('PAGEERR', e.message));
    await p.goto(URL); return { ctx, p };
  };
  const A = await mk(), B = await mk();

  // جفت‌سازی
  await A.p.click('#btnCreate');
  await A.p.waitForSelector('#waiting:not([hidden])');
  const code = (await A.p.textContent('#bigCode')).trim();
  assert(/^\d{6}$/.test(code)); ok('کد ساخته شد: ' + code);
  await B.p.fill('#codeIn', code.split('').map((d) => String.fromCharCode(0x6f0 + +d)).join('')); // ارقام فارسی
  await B.p.click('#joinForm button');
  await A.p.waitForSelector('#chat:not([hidden])'); await B.p.waitForSelector('#chat:not([hidden])');
  ok('جفت‌سازی انجام شد (ورود با ارقام فارسی هم کار کرد)');

  // نفر سوم نباید وارد شود
  const C = await mk(); await C.p.fill('#codeIn', code); await C.p.click('#joinForm button');
  await C.p.waitForFunction(() => document.querySelector('#welcomeErr').textContent.includes('دو نفر'));
  ok('نفر سوم رد شد'); await C.ctx.close();

  // اثر انگشت یکسان
  const fp = async (X) => { await X.p.click('#btnMenu'); await X.p.waitForFunction(() => /\d{5}/.test(document.querySelector('#fp').textContent)); const t = await X.p.textContent('#fp'); await X.p.click('#btnCloseSheet'); return t; };
  assert.strictEqual(await fp(A), await fp(B)); ok('اثر انگشت امنیتی هر دو گوشی یکی است');

  // چت
  await A.p.waitForFunction(() => document.querySelector('#status').textContent === 'آنلاین');
  await A.p.fill('#msgIn', 'سلام عزیزم <b>x</b>'); await A.p.click('.send');
  await B.p.waitForSelector('.msg.peer');
  assert.strictEqual(await B.p.textContent('.msg.peer span'), 'سلام عزیزم <b>x</b>');
  assert.strictEqual(await B.p.locator('.msg.peer b').count(), 0);
  await A.p.waitForFunction(() => document.querySelector('.msg.me .t').textContent.includes('✓✓'));
  ok('چت دوطرفه، رمزگشایی، XSS-safe، تیک تحویل');

  // سرور متن را نمی‌بیند
  const raw = fs.readFileSync(process.env.DATA_FILE, 'utf8');
  assert(!raw.includes('سلام')); ok('متن پیام در دیتای سرور نیست');

  // پیام آفلاین
  await B.p.close();
  await A.p.fill('#msgIn', 'پیام آفلاین'); await A.p.click('.send');
  await new Promise((r) => setTimeout(r, 400));
  const B2p = await B.ctx.newPage(); await B2p.goto(URL);
  await B2p.waitForFunction(() => [...document.querySelectorAll('.msg.peer span:first-child')].some((e) => e.textContent === 'پیام آفلاین'));
  ok('پیام صف‌شده پس از آنلاین شدن رسید (و بازگشت خودکار به گفتگو بعد از بستن برنامه)');
  B.p = B2p;

  // تماس صوتی
  await A.p.waitForFunction(() => document.querySelector('#status').textContent === 'آنلاین');
  await A.p.click('#btnAudio');
  await B.p.waitForSelector('#incoming:not([hidden])');
  await B.p.click('#btnAccept');
  const live = (X) => X.p.waitForFunction(() => /^\d\d:\d\d$/.test(document.querySelector('#callState').textContent), null, { timeout: 20000 });
  await live(A); await live(B); ok('تماس صوتی برقرار شد');
  // آیا صدا واقعاً جریان دارد؟
  const bytes = await B.p.evaluate(async () => {
    await new Promise((r) => setTimeout(r, 1500));
    const v = document.querySelector('#remote'); return v.srcObject ? v.srcObject.getAudioTracks().length : 0;
  });
  assert.strictEqual(bytes, 1); ok('ترک صدای مقابل دریافت می‌شود');
  await A.p.click('#btnHang');
  await B.p.waitForSelector('#call', { state: 'hidden' }); ok('قطع تماس از یک طرف، طرف دیگر هم قطع شد');
  await B.p.waitForSelector('.sys');

  // تماس تصویری
  await B.p.click('#btnVideo');
  await A.p.waitForSelector('#incoming:not([hidden])'); await A.p.click('#btnAccept');
  await live(A); await live(B);
  await B.p.waitForFunction(() => document.querySelector('#remote').videoWidth > 0, null, { timeout: 15000 });
  await A.p.waitForFunction(() => document.querySelector('#remote').videoWidth > 0, null, { timeout: 15000 });
  ok('تماس تصویری برقرار شد و ویدیوی دو طرف نمایش داده می‌شود');
  await B.p.click('#btnHang'); await A.p.waitForSelector('#call', { state: 'hidden' });

  // رد تماس
  await A.p.click('#btnAudio'); await B.p.waitForSelector('#incoming:not([hidden])'); await B.p.click('#btnReject');
  await A.p.waitForSelector('#call', { state: 'hidden' }); ok('رد تماس');

  console.log('\nهمه‌ی تست‌ها موفق بود');
  await browser.close(); server.close(); process.exit(0);
})().catch((e) => { console.error('FAIL', e); process.exit(1); });
