import { ChangeDetectionStrategy, Component, inject, signal, effect } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StorageService } from '../../services/storage.service';

@Component({
  selector: 'app-notes-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    @if (item(); as target) {
      <div 
        role="presentation"
        (click)="close()"
        class="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
        
        <div 
          role="dialog"
          aria-modal="true"
          tabindex="-1"
          (click)="$event.stopPropagation()"
          (keydown.stop)="$event.stopPropagation()"
          class="w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col animate-in fade-in zoom-in-95 duration-150">
          
          <!-- Header -->
          <div class="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <div class="flex items-center gap-2.5">
              <div class="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                <mat-icon class="!text-[20px]">edit_note</mat-icon>
              </div>
              <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white leading-tight">
                  یادداشت شخصی علیرضا
                </h3>
                <p class="text-xs text-slate-500 dark:text-slate-400 truncate max-w-xs sm:max-w-sm">
                  {{ target.title }}
                </p>
              </div>
            </div>

            <button
              (click)="close()"
              class="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
              <mat-icon class="!text-[20px]">close</mat-icon>
            </button>
          </div>

          <!-- Body -->
          <div class="p-6 space-y-3">
            <label for="note-textarea" class="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              متن یادداشت، پیش‌نیازها، پیگیری ایمیل یا نکات کلیدی:
            </label>
            <textarea
              #noteInput
              id="note-textarea"
              [value]="noteText()"
              (input)="noteText.set(noteInput.value)"
              rows="6"
              placeholder="مثال: ایمیل زدم به دکتر ربیعی برای پاییز ۱۴۰۶، منتظر پاسخ در مورد ظرفیت پذیرش هستم. مقاله این آزمایشگاه را در زمینه ترنسفورمر مطالعه کردم..."
              class="w-full p-3.5 rounded-xl text-sm bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 dark:text-slate-100 placeholder-slate-400 leading-relaxed resize-none"></textarea>
            
            <p class="text-[11px] text-slate-500 dark:text-slate-400">
              * یادداشت‌های شما به صورت خودکار و امن در مرورگر ذخیره می‌شوند و همیشه در کنار این آیتم در دسترس خواهند بود.
            </p>
          </div>

          <!-- Footer -->
          <div class="px-6 py-3.5 bg-slate-50 dark:bg-slate-950/40 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
            @if (noteText().trim().length > 0) {
              <button
                (click)="deleteNote(target.id)"
                class="px-3 py-2 rounded-xl text-xs font-medium text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors flex items-center gap-1.5">
                <mat-icon class="!text-[16px]">delete</mat-icon>
                <span>حذف یادداشت</span>
              </button>
            } @else {
              <div></div>
            }

            <div class="flex items-center gap-2">
              <button
                (click)="close()"
                class="px-4 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors">
                انصراف
              </button>
              <button
                (click)="save(target.id)"
                class="px-5 py-2 rounded-xl text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 shadow-sm shadow-indigo-600/20 transition-all flex items-center gap-1.5">
                <mat-icon class="!text-[16px]">check</mat-icon>
                <span>ذخیره یادداشت</span>
              </button>
            </div>
          </div>

        </div>
      </div>
    }
  `
})
export class NotesModal {
  readonly storage = inject(StorageService);
  readonly item = this.storage.activeNoteItem;
  readonly noteText = signal<string>('');

  constructor() {
    effect(() => {
      const active = this.item();
      if (active) {
        this.noteText.set(this.storage.getNote(active.id));
      } else {
        this.noteText.set('');
      }
    });
  }

  save(id: string) {
    this.storage.saveNote(id, this.noteText());
    this.close();
  }

  deleteNote(id: string) {
    this.storage.saveNote(id, '');
    this.close();
  }

  close() {
    this.storage.closeNoteModal();
  }
}
