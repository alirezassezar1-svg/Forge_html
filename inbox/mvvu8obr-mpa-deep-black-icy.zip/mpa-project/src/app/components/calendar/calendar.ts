import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StorageService } from '../../services/storage.service';
import { CalendarEvent } from '../../models/academic.models';

@Component({
  selector: 'app-calendar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6 pb-12">
      
      <!-- Top Title -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <mat-icon class="text-indigo-600 dark:text-indigo-400 !text-[26px]">event</mat-icon>
            <span>تقویم جامع ددلاین‌های علمی و پذیرش دکتری</span>
          </h1>
          <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">
            زمان‌بندی اپلای دکتری دانشگاه‌های جهان، ثبت‌نام کنکور سراسری و آزاد، کنفرانس‌های AI و آزمون‌های زبان
          </p>
        </div>

        <button
          (click)="toggleAddEvent()"
          class="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all shadow-sm flex items-center gap-1.5 self-start sm:self-auto">
          <mat-icon class="!text-[18px]">{{ showAddEvent() ? 'close' : 'add' }}</mat-icon>
          <span>{{ showAddEvent() ? 'بستن فرم' : 'افزودن ددلاین شخصی علیرضا' }}</span>
        </button>
      </div>

      <!-- Add Custom Event Form (Collapsible) -->
      @if (showAddEvent()) {
        <div class="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-indigo-200 dark:border-indigo-900/60 shadow-md space-y-4 animate-in fade-in duration-200">
          <div class="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-bold text-xs">
            <mat-icon class="!text-[18px]">calendar_today</mat-icon>
            <span>ثبت ددلاین یا رویداد شخصی جدید</span>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            <div class="sm:col-span-2">
              <label for="event-title-input" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">عنوان رویداد یا ددلاین:</label>
              <input
                #titleInput
                id="event-title-input"
                type="text"
                placeholder="مثال: ددلاین ارسال فرم پیشینه به دانشگاه دزفول یا آزمون ماک آیلتس"
                class="w-full px-3.5 py-2.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>

            <div>
              <label for="event-type-select" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">دسته‌بندی:</label>
              <select
                #typeSelect
                id="event-type-select"
                class="w-full px-3.5 py-2.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                <option value="personal">شخصی / دانشگاه دزفول</option>
                <option value="phd_admission">پذیرش دکتری</option>
                <option value="conference">کنفرانس و مقاله</option>
                <option value="exam">آزمون (زبان / کنکور)</option>
                <option value="term">ترم تحصیلی</option>
              </select>
            </div>

            <div>
              <label for="event-date-input" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">تاریخ میلادی (YYYY-MM-DD):</label>
              <input
                #dateInput
                id="event-date-input"
                type="date"
                dir="ltr"
                class="w-full px-3.5 py-2.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>

            <div>
              <label for="event-shamsi-input" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">تاریخ شمسی (جهت نمایش):</label>
              <input
                #shamsiInput
                id="event-shamsi-input"
                type="text"
                placeholder="مثال: ۲۵ آبان"
                class="w-full px-3.5 py-2.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>

            <div>
              <label for="event-org-input" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">مرکز / سازمان مرتبط:</label>
              <input
                #orgInput
                id="event-org-input"
                type="text"
                placeholder="مثال: دانشگاه آزاد دزفول / سازمان سنجش"
                class="w-full px-3.5 py-2.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>

            <div class="sm:col-span-2">
              <label for="event-notes-input" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">یادداشت تکمیلی یا لینک:</label>
              <input
                #notesInput
                id="event-notes-input"
                type="text"
                placeholder="توضیحات لازم برای پیگیری"
                class="w-full px-3.5 py-2.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>

            <div class="flex items-end">
              <button
                (click)="submitEvent(titleInput, typeSelect, dateInput, shamsiInput, orgInput, notesInput)"
                class="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all flex items-center justify-center gap-1.5 shadow-sm">
                <mat-icon class="!text-[16px]">save</mat-icon>
                <span>ثبت در تقویم</span>
              </button>
            </div>
          </div>
        </div>
      }

      <!-- Filter by Event Category -->
      <div class="flex flex-wrap items-center gap-2 p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
        <span class="text-xs font-bold text-slate-500 dark:text-slate-400 ml-2">فیلتر نوع رویداد:</span>
        @for (f of typeFilters; track f.id) {
          <button
            (click)="selectedType.set(f.id)"
            [class.bg-indigo-600]="selectedType() === f.id"
            [class.text-white]="selectedType() === f.id"
            [class.bg-slate-100]="selectedType() !== f.id"
            [class.dark:bg-slate-800]="selectedType() !== f.id"
            [class.text-slate-700]="selectedType() !== f.id"
            [class.dark:text-slate-300]="selectedType() !== f.id"
            class="px-3 py-1.5 rounded-lg text-xs font-medium transition-colors">
            {{ f.label }}
          </button>
        }
      </div>

      <!-- Timeline List -->
      <div class="space-y-4">
        @for (ev of filteredEvents(); track ev.id) {
          <div class="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            
            <div class="flex items-start gap-4">
              <!-- Countdown Badge / Icon -->
              <div class="flex flex-col items-center justify-center w-14 h-14 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-900/40 shrink-0">
                <span class="text-[10px] font-bold">{{ getCountdown(ev.deadlineDate).label }}</span>
                <span class="text-xs font-extrabold font-mono mt-0.5">{{ getCountdown(ev.deadlineDate).value }}</span>
              </div>

              <div class="space-y-1">
                <div class="flex flex-wrap items-center gap-2">
                  <span class="text-xs font-bold text-slate-900 dark:text-white leading-snug">
                    {{ ev.title }}
                  </span>
                  
                  @if (ev.isCustom) {
                    <span class="text-[10px] px-2 py-0.5 rounded font-bold bg-purple-100 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300">
                      رویداد شخصی علیرضا
                    </span>
                  }
                </div>

                <div class="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <span class="font-bold text-indigo-600 dark:text-indigo-400">{{ ev.deadlineShamsi }}</span>
                  <span>·</span>
                  <span class="font-mono text-[11px]" dir="ltr">{{ ev.deadlineDate }}</span>
                  <span>·</span>
                  <span>{{ ev.institutionOrOrg }}</span>
                </div>

                @if (ev.notes) {
                  <p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed pt-0.5">
                    {{ ev.notes }}
                  </p>
                }
              </div>
            </div>

            <!-- Actions -->
            <div class="flex items-center gap-2 shrink-0 self-end sm:self-auto">
              @if (ev.linkUrl) {
                <a
                  [href]="ev.linkUrl"
                  target="_blank"
                  rel="noopener noreferrer"
                  class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs text-slate-700 dark:text-slate-300 font-medium transition-colors flex items-center gap-1">
                  <span>سامانه رسمی</span>
                  <mat-icon class="!text-[14px]">open_in_new</mat-icon>
                </a>
              }

              @if (ev.isCustom) {
                <button
                  (click)="storage.deleteCustomEvent(ev.id)"
                  class="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                  title="حذف رویداد شخصی">
                  <mat-icon class="!text-[18px]">delete</mat-icon>
                </button>
              }
            </div>

          </div>
        }
      </div>

    </div>
  `
})
export class Calendar {
  readonly storage = inject(StorageService);

  readonly showAddEvent = signal<boolean>(false);
  readonly selectedType = signal<string>('all');

  readonly typeFilters = [
    { id: 'all', label: 'همه رویدادها' },
    { id: 'phd_admission', label: 'پذیرش و ددلاین دکتری' },
    { id: 'conference', label: 'کنفرانس‌ها' },
    { id: 'exam', label: 'آزمون‌ها (زبان / سنجش)' },
    { id: 'personal', label: 'رویدادهای شخصی' }
  ];

  readonly filteredEvents = computed<CalendarEvent[]>(() => {
    const t = this.selectedType();
    return this.storage.allEvents().filter(e => {
      if (t === 'all') return true;
      if (t === 'personal' && e.isCustom) return true;
      return e.type === t;
    });
  });

  toggleAddEvent() {
    this.showAddEvent.update(v => !v);
  }

  getCountdown(dateStr: string): { label: string; value: string } {
    const target = new Date(dateStr).getTime();
    const now = new Date().getTime();
    const diffDays = Math.ceil((target - now) / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
      return { label: 'گذشته', value: `${Math.abs(diffDays)} روز` };
    } else if (diffDays === 0) {
      return { label: 'امروز', value: 'موعد' };
    } else {
      return { label: 'باقی‌مانده', value: `${diffDays} روز` };
    }
  }

  submitEvent(
    titleEl: HTMLInputElement,
    typeEl: HTMLSelectElement,
    dateEl: HTMLInputElement,
    shamsiEl: HTMLInputElement,
    orgEl: HTMLInputElement,
    notesEl: HTMLInputElement
  ) {
    const title = titleEl.value.trim();
    const type = typeEl.value as CalendarEvent['type'];
    const deadlineDate = dateEl.value;
    const deadlineShamsi = shamsiEl.value.trim() || deadlineDate;
    const institutionOrOrg = orgEl.value.trim() || 'شخصی';
    const notes = notesEl.value.trim();

    if (!title || !deadlineDate) return;

    this.storage.addCustomEvent({
      title,
      type,
      deadlineDate,
      deadlineShamsi,
      priority: 'high',
      institutionOrOrg,
      notes
    });

    this.showAddEvent.set(false);
  }
}
