import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StorageService } from '../../services/storage.service';
import { AcademicDataService } from '../../services/academic-data.service';
import { SectionTab } from '../../models/academic.models';

interface SearchResultItem {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  tab: SectionTab;
  url?: string;
}

@Component({
  selector: 'app-search-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    @if (storage.isSearchOpen()) {
      <div 
        role="presentation"
        (click)="close()"
        class="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-start justify-center p-4 sm:p-6 md:p-20">
        
        <div 
          role="dialog"
          aria-modal="true"
          tabindex="-1"
          (click)="$event.stopPropagation()"
          (keydown.stop)="$event.stopPropagation()"
          class="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[85vh] animate-in fade-in zoom-in-95 duration-150">
          
          <!-- Search Header Input -->
          <div class="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-3 bg-slate-50/50 dark:bg-slate-950/40">
            <mat-icon class="text-slate-400 !text-[22px]">search</mat-icon>
            <input
              #searchInput
              type="text"
              [value]="query()"
              (input)="query.set(searchInput.value)"
              placeholder="جستجو در دانشگاه‌ها، اساتید، آزمایشگاه‌ها، کتاب‌ها، کنفرانس‌ها و ابزارها..."
              class="w-full bg-transparent text-sm sm:text-base text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none" />
            
            <button
              (click)="close()"
              class="px-2 py-1 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-800 rounded">
              بستن (Esc)
            </button>
          </div>

          <!-- Quick Suggestions / Categories if no query -->
          @if (!query().trim()) {
            <div class="p-6 text-center space-y-4">
              <p class="text-xs text-slate-500 dark:text-slate-400">
                عبارت مورد نظر خود را تایپ کنید یا روی پیشنهادهای زیر کلیک نمایید:
              </p>
              <div class="flex flex-wrap items-center justify-center gap-2">
                @for (sug of suggestions; track sug) {
                  <button
                    (click)="query.set(sug)"
                    class="px-3 py-1.5 rounded-full text-xs bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-indigo-950/50 dark:hover:text-indigo-400 transition-colors">
                    {{ sug }}
                  </button>
                }
              </div>
            </div>
          } @else {
            <!-- Results List -->
            <div class="overflow-y-auto p-3 space-y-1 divide-y divide-slate-100 dark:divide-slate-800/60 max-h-[60vh]">
              @if (results().length === 0) {
                <div class="py-12 text-center space-y-2">
                  <mat-icon class="text-slate-300 dark:text-slate-600 !text-[36px]">sentiment_dissatisfied</mat-icon>
                  <p class="text-sm font-medium text-slate-600 dark:text-slate-400">
                    موردی برای «{{ query() }}» یافت نشد.
                  </p>
                  <p class="text-xs text-slate-400">
                    کلمات کلیدی کوتاه‌تر یا نام انگلیسی دانشگاه/استاد را امتحان کنید.
                  </p>
                </div>
              } @else {
                <div class="px-3 py-1 text-[11px] font-semibold text-slate-400">
                  {{ results().length }} نتیجه یافت شد:
                </div>
                @for (res of results(); track res.id) {
                  <button
                    (click)="navigateTo(res)"
                    class="w-full text-right p-3 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors flex items-center justify-between gap-3 group focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <div class="space-y-0.5 min-w-0">
                      <div class="flex items-center gap-2">
                        <span class="text-xs font-bold text-slate-900 dark:text-slate-100 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors truncate">
                          {{ res.title }}
                        </span>
                        <span class="text-[10px] px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-medium shrink-0">
                          {{ res.category }}
                        </span>
                      </div>
                      <p class="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {{ res.subtitle }}
                      </p>
                    </div>

                    <div class="flex items-center gap-2 shrink-0">
                      @if (res.url) {
                        <a
                          [href]="res.url"
                          target="_blank"
                          rel="noopener noreferrer"
                          (click)="$event.stopPropagation()"
                          class="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 transition-colors"
                          title="باز کردن لینک مستقیم">
                          <mat-icon class="!text-[18px]">open_in_new</mat-icon>
                        </a>
                      }
                      <mat-icon class="text-slate-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 !text-[18px]">
                        arrow_back_ios
                      </mat-icon>
                    </div>
                  </button>
                }
              }
            </div>
          }

        </div>
      </div>
    }
  `
})
export class SearchModal {
  readonly storage = inject(StorageService);
  readonly academicData = inject(AcademicDataService);
  readonly query = signal<string>('');

  readonly suggestions = [
    'شریف', 'تهران', 'استنفورد', 'MIT', 'ETH', 'NeurIPS', 
    'DeepMind', 'OpenAI', 'Overleaf', 'PyTorch', 'ایران‌داک', 'Google Scholar'
  ];

  readonly results = computed<SearchResultItem[]>(() => {
    const q = this.query().trim().toLowerCase();
    if (!q) return [];

    const items: SearchResultItem[] = [];

    // Search universities
    for (const u of this.academicData.universities) {
      const matchFaculty = u.facultyMembers.some(f => f.name.toLowerCase().includes(q) || f.specialty.toLowerCase().includes(q));
      if (
        u.name.toLowerCase().includes(q) ||
        u.englishName.toLowerCase().includes(q) ||
        u.city.toLowerCase().includes(q) ||
        u.specializations.some(s => s.toLowerCase().includes(q)) ||
        matchFaculty
      ) {
        items.push({
          id: u.id,
          title: u.name,
          subtitle: `${u.rankingText} · ${u.city} · ${u.specializations.slice(0, 2).join('، ')}`,
          category: u.region === 'iran' ? 'دانشگاه ایران' : 'دانشگاه جهان',
          tab: 'universities',
          url: u.admissionUrl
        });
      }
    }

    // Search resources & books
    for (const r of this.academicData.resources) {
      if (
        r.title.toLowerCase().includes(q) ||
        r.englishTitle.toLowerCase().includes(q) ||
        r.description.toLowerCase().includes(q) ||
        r.authorOrProvider.toLowerCase().includes(q)
      ) {
        items.push({
          id: r.id,
          title: r.title,
          subtitle: `${r.authorOrProvider} · ${r.recommendedFor}`,
          category: r.type === 'textbook' ? 'کتاب مرجع' : 'پایگاه علمی',
          tab: 'resources',
          url: r.url
        });
      }
    }

    // Search labs
    for (const l of this.academicData.labs) {
      if (
        l.name.toLowerCase().includes(q) ||
        l.englishName.toLowerCase().includes(q) ||
        l.organization.toLowerCase().includes(q) ||
        l.focusAreas.some(fa => fa.toLowerCase().includes(q))
      ) {
        items.push({
          id: l.id,
          title: l.name,
          subtitle: `${l.organization} · ${l.location} · ${l.focusAreas.slice(0, 2).join('، ')}`,
          category: 'مرکز تحقیقاتی',
          tab: 'labs',
          url: l.careersOrFellowshipUrl || l.websiteUrl
        });
      }
    }

    // Search conferences
    for (const c of this.academicData.conferences) {
      if (
        c.name.toLowerCase().includes(q) ||
        c.acronym.toLowerCase().includes(q) ||
        c.field.toLowerCase().includes(q)
      ) {
        items.push({
          id: c.id,
          title: `${c.acronym} - ${c.name}`,
          subtitle: `${c.ranking} · ${c.field} · ددلاین: ${c.submissionDeadline}`,
          category: 'کنفرانس',
          tab: 'conferences',
          url: c.websiteUrl
        });
      }
    }

    // Search tools
    for (const t of this.academicData.tools) {
      if (
        t.name.toLowerCase().includes(q) ||
        t.tagline.toLowerCase().includes(q) ||
        t.description.toLowerCase().includes(q)
      ) {
        items.push({
          id: t.id,
          title: t.name,
          subtitle: `${t.tagline} · ${t.benefitsForAlireza}`,
          category: 'ابزار پژوهشی',
          tab: 'tools-skills',
          url: t.url
        });
      }
    }

    return items;
  });

  navigateTo(result: SearchResultItem) {
    this.storage.activeTab.set(result.tab);
    this.close();
  }

  close() {
    this.storage.isSearchOpen.set(false);
    this.query.set('');
  }
}
