import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StorageService } from '../../services/storage.service';
import { AcademicDataService } from '../../services/academic-data.service';
import { ConferenceItem } from '../../models/academic.models';

@Component({
  selector: 'app-conferences',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6 pb-12">
      
      <!-- Top Title -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <mat-icon class="text-indigo-600 dark:text-indigo-400 !text-[26px]">groups</mat-icon>
            <span>کنفرانس‌ها، گردهمایی‌ها و مدارس تابستانی AI</span>
          </h1>
          <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">
            کنفرانس‌های تراز اول Core A*، ددلاین‌های ارسال مقاله، درگاه OpenReview و کنفرانس‌های معتبر ایران
          </p>
        </div>

        <!-- Filter Region -->
        <div class="flex items-center p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl shrink-0 border border-slate-200/60 dark:border-slate-700/60">
          <button
            (click)="selectedRegion.set('all')"
            [class.bg-white]="selectedRegion() === 'all'"
            [class.text-indigo-600]="selectedRegion() === 'all'"
            [class.shadow-sm]="selectedRegion() === 'all'"
            [class.dark:bg-slate-900]="selectedRegion() === 'all'"
            [class.dark:text-indigo-400]="selectedRegion() === 'all'"
            [class.text-slate-600]="selectedRegion() !== 'all'"
            [class.dark:text-slate-300]="selectedRegion() !== 'all'"
            class="px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all">
            همه رویدادها
          </button>

          <button
            (click)="selectedRegion.set('world')"
            [class.bg-white]="selectedRegion() === 'world'"
            [class.text-indigo-600]="selectedRegion() === 'world'"
            [class.shadow-sm]="selectedRegion() === 'world'"
            [class.dark:bg-slate-900]="selectedRegion() === 'world'"
            [class.dark:text-indigo-400]="selectedRegion() === 'world'"
            [class.text-slate-600]="selectedRegion() !== 'world'"
            [class.dark:text-slate-300]="selectedRegion() !== 'world'"
            class="px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all">
            کنفرانس‌های جهانی (Core A*)
          </button>

          <button
            (click)="selectedRegion.set('iran')"
            [class.bg-white]="selectedRegion() === 'iran'"
            [class.text-indigo-600]="selectedRegion() === 'iran'"
            [class.shadow-sm]="selectedRegion() === 'iran'"
            [class.dark:bg-slate-900]="selectedRegion() === 'iran'"
            [class.dark:text-indigo-400]="selectedRegion() === 'iran'"
            [class.text-slate-600]="selectedRegion() !== 'iran'"
            [class.dark:text-slate-300]="selectedRegion() !== 'iran'"
            class="px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all">
            کنفرانس‌های معتبر ایران
          </button>
        </div>
      </div>

      <!-- Field Filter Pills -->
      <div class="flex flex-wrap items-center gap-2 p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
        <span class="text-xs font-bold text-slate-500 dark:text-slate-400 ml-2">حوزه تخصصی:</span>
        @for (f of fields; track f.id) {
          <button
            (click)="selectedField.set(f.id)"
            [class.bg-indigo-600]="selectedField() === f.id"
            [class.text-white]="selectedField() === f.id"
            [class.bg-slate-100]="selectedField() !== f.id"
            [class.dark:bg-slate-800]="selectedField() !== f.id"
            [class.text-slate-700]="selectedField() !== f.id"
            [class.dark:text-slate-300]="selectedField() !== f.id"
            class="px-3 py-1.5 rounded-lg text-xs font-medium transition-colors">
            {{ f.label }}
          </button>
        }
      </div>

      <!-- Conferences Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
        @for (conf of filteredConferences(); track conf.id) {
          <div class="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4">
            
            <div class="space-y-3">
              <!-- Top Header -->
              <div class="flex items-start justify-between gap-3">
                <div>
                  <div class="flex items-center gap-2">
                    <span class="text-sm font-black font-sans tracking-wide text-indigo-600 dark:text-indigo-400">
                      {{ conf.acronym }}
                    </span>
                    <span class="text-[10px] px-2 py-0.5 rounded font-bold bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300">
                      {{ conf.ranking }}
                    </span>
                  </div>

                  <h3 class="text-xs sm:text-sm font-bold text-slate-900 dark:text-white mt-1 leading-snug">
                    {{ conf.name }}
                  </h3>
                </div>

                <div class="flex items-center gap-1 shrink-0">
                  <button
                    (click)="storage.toggleBookmark(conf.id)"
                    [class.text-amber-500]="storage.isBookmarked(conf.id)"
                    [class.text-slate-400]="!storage.isBookmarked(conf.id)"
                    class="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    title="نشان کردن کنفرانس">
                    <mat-icon class="!text-[20px]">{{ storage.isBookmarked(conf.id) ? 'bookmark' : 'bookmark_border' }}</mat-icon>
                  </button>

                  <button
                    (click)="openNote(conf)"
                    [class.text-indigo-600]="storage.hasNote(conf.id)"
                    [class.text-slate-400]="!storage.hasNote(conf.id)"
                    class="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    title="یادداشت شخصی">
                    <mat-icon class="!text-[20px]">edit_note</mat-icon>
                  </button>
                </div>
              </div>

              <!-- Description -->
              <p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {{ conf.description }}
              </p>

              <!-- Personal Note Snippet -->
              @if (storage.hasNote(conf.id)) {
                <div class="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-800/40 text-[11px] text-amber-900 dark:text-amber-200">
                  <span class="font-bold block mb-0.5">یادداشت من:</span>
                  <p>{{ storage.getNote(conf.id) }}</p>
                </div>
              }

              <!-- Deadlines and Logistics Strip -->
              <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 text-xs">
                <div class="p-2.5 rounded-xl bg-rose-50/70 dark:bg-rose-950/30 border border-rose-100 dark:border-rose-900/40">
                  <span class="text-[10px] font-bold text-rose-600 dark:text-rose-400 block mb-0.5">ددلاین ارسال مقاله:</span>
                  <span class="font-bold text-slate-800 dark:text-slate-200">{{ conf.submissionDeadline }}</span>
                </div>

                <div class="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/50 border border-slate-100 dark:border-slate-800">
                  <span class="text-[10px] font-bold text-slate-500 block mb-0.5">زمان و محل برگزاری:</span>
                  <span class="font-medium text-slate-700 dark:text-slate-300">{{ conf.conferenceDate }} · {{ conf.location }}</span>
                </div>
              </div>
            </div>

            <!-- Footer Action Links -->
            <div class="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
              <a
                [href]="conf.websiteUrl"
                target="_blank"
                rel="noopener noreferrer"
                class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs text-slate-700 dark:text-slate-300 font-medium transition-colors flex items-center gap-1">
                <span>پایگاه رسمی کنفرانس</span>
                <mat-icon class="!text-[14px]">public</mat-icon>
              </a>

              @if (conf.submissionUrl) {
                <a
                  [href]="conf.submissionUrl"
                  target="_blank"
                  rel="noopener noreferrer"
                  class="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-colors shadow-sm flex items-center gap-1">
                  <span>سامانه ارسال (OpenReview)</span>
                  <mat-icon class="!text-[14px]">open_in_new</mat-icon>
                </a>
              }
            </div>

          </div>
        }
      </div>

      <!-- Summer Schools & Top AI Workshops Section -->
      <div class="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div class="flex items-center gap-2">
          <div class="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
            <mat-icon class="!text-[20px]">school</mat-icon>
          </div>
          <div>
            <h2 class="text-sm font-bold text-slate-900 dark:text-white">
              کارگاه‌ها، مدارس تابستانی و دوره‌های تخصصی بین‌المللی
            </h2>
            <p class="text-xs text-slate-500">
              تقویت فوق‌العاده رزومه و تسلط بر مباحث عمیق با تدریس اساتید مطرح استنفورد و MIT
            </p>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          @for (course of workshops; track course.title) {
            <div class="p-4 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/40 space-y-2 flex flex-col justify-between">
              <div class="space-y-1.5">
                <span class="text-[10px] font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider block">
                  {{ course.provider }}
                </span>
                <h3 class="text-xs font-bold text-slate-900 dark:text-white">
                  {{ course.title }}
                </h3>
                <p class="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  {{ course.desc }}
                </p>
              </div>

              <div class="pt-2">
                <a
                  [href]="course.url"
                  target="_blank"
                  rel="noopener noreferrer"
                  class="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1">
                  <span>ورود به دوره و اسلایدها</span>
                  <mat-icon class="!text-[14px]">arrow_back</mat-icon>
                </a>
              </div>
            </div>
          }
        </div>
      </div>

    </div>
  `
})
export class Conferences {
  readonly storage = inject(StorageService);
  readonly academicData = inject(AcademicDataService);

  readonly selectedRegion = signal<'all' | 'world' | 'iran'>('all');
  readonly selectedField = signal<string>('all');

  readonly fields = [
    { id: 'all', label: 'همه حوزه‌ها' },
    { id: 'ml', label: 'یادگیری ماشین و تئوری' },
    { id: 'nlp', label: 'پردازش متن و زبان (NLP)' },
    { id: 'cv', label: 'بینایی کامپیوتر و تصویر' }
  ];

  readonly workshops = [
    {
      title: 'استنفورد CS231n: یادگیری عمیق برای بینایی کامپیوتر',
      provider: 'Stanford University (Fei-Fei Li / Andrej Karpathy legacy)',
      desc: 'کامل‌ترین و استانداردترین دوره تصویری جهان شامل یادداشت‌های عالی پایتورچ، CNNs، بک‌پراپاگیشن و معماری‌های نوین.',
      url: 'https://cs231n.stanford.edu'
    },
    {
      title: 'استنفورد CS224n: پردازش زبان طبیعی با یادگیری عمیق',
      provider: 'Stanford University (Christopher Manning)',
      desc: 'مرجع یادگیری ترنسفورمرها، مکانیزم Self-Attention، مدلسازی زبانی، پرامپتینگ و مبانی مدل‌های بزرگ زبانی.',
      url: 'https://web.stanford.edu/class/cs224n/'
    },
    {
      title: 'مدرسه تابستانی یادگیری ماشین اروپای شرقی (EEML)',
      provider: 'Google DeepMind & University Partners',
      desc: 'مدرسه تابستانی فشرده سالانه همراه با گرنت‌های سفر و اسکان برای دانشجویان ممتاز با حضور پژوهشگران مطرح دیپ‌مایند.',
      url: 'https://www.eeml.eu'
    }
  ];

  readonly filteredConferences = computed<ConferenceItem[]>(() => {
    const reg = this.selectedRegion();
    const f = this.selectedField();
    const bookmarksOnly = this.storage.filterBookmarksOnly();

    return this.academicData.conferences.filter(c => {
      if (bookmarksOnly && !this.storage.isBookmarked(c.id)) return false;
      if (reg === 'world' && c.region !== 'world') return false;
      if (reg === 'iran' && c.region !== 'iran') return false;

      if (f === 'ml' && !c.field.includes('یادگیری')) return false;
      if (f === 'nlp' && !c.field.includes('زبان')) return false;
      if (f === 'cv' && !c.field.includes('بینایی') && !c.field.includes('تصویر')) return false;

      return true;
    });
  });

  openNote(conf: ConferenceItem) {
    this.storage.openNoteModal(conf.id, `${conf.acronym} - ${conf.name}`, 'کنفرانس');
  }
}
