import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StorageService } from '../../services/storage.service';
import { AcademicDataService } from '../../services/academic-data.service';
import { University } from '../../models/academic.models';

@Component({
  selector: 'app-universities',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6 pb-12">
      
      <!-- Top Title & Navigation between Iran vs World -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <mat-icon class="text-indigo-600 dark:text-indigo-400 !text-[26px]">account_balance</mat-icon>
            <span>دانشگاه‌های هدف برای مقطع دکتری هوش مصنوعی</span>
          </h1>
          <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">
            اطلاعات کامل، لینک‌های مستقیم پذیرش، شرایط آزمون، ظرفیت‌ها و اعضای هیئت علمی فعال در AI
          </p>
        </div>

        <!-- Segmented Region Selector -->
        <div class="flex items-center p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl shrink-0 self-start sm:self-auto border border-slate-200/60 dark:border-slate-700/60">
          <button
            (click)="region.set('iran')"
            [class.bg-white]="region() === 'iran'"
            [class.text-indigo-600]="region() === 'iran'"
            [class.shadow-sm]="region() === 'iran'"
            [class.dark:bg-slate-900]="region() === 'iran'"
            [class.dark:text-indigo-400]="region() === 'iran'"
            [class.text-slate-600]="region() !== 'iran'"
            [class.dark:text-slate-300]="region() !== 'iran'"
            class="px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap">
            <mat-icon class="!text-[18px]">domain</mat-icon>
            <span>دانشگاه‌های برتر ایران ({{ iranCount() }})</span>
          </button>

          <button
            (click)="region.set('world')"
            [class.bg-white]="region() === 'world'"
            [class.text-indigo-600]="region() === 'world'"
            [class.shadow-sm]="region() === 'world'"
            [class.dark:bg-slate-900]="region() === 'world'"
            [class.dark:text-indigo-400]="region() === 'world'"
            [class.text-slate-600]="region() !== 'world'"
            [class.dark:text-slate-300]="region() !== 'world'"
            class="px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 whitespace-nowrap">
            <mat-icon class="!text-[18px]">public</mat-icon>
            <span>دانشگاه‌های برتر جهان ({{ worldCount() }})</span>
          </button>
        </div>
      </div>

      <!-- Filter and Search Bar -->
      <div class="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
        <div class="flex flex-col md:flex-row md:items-center gap-3">
          <!-- Local Search -->
          <div class="relative flex-1">
            <mat-icon class="absolute right-3.5 top-3 text-slate-400 !text-[20px]">search</mat-icon>
            <input
              #filterInput
              type="text"
              [value]="searchTerm()"
              (input)="searchTerm.set(filterInput.value)"
              placeholder="جستجو بر اساس نام دانشگاه، شهر، نام استاد (مثال: ربیعی، Manning، زوریخ، علم و صنعت)..."
              class="w-full pl-4 pr-10 py-2.5 rounded-xl text-xs sm:text-sm bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            
            @if (searchTerm()) {
              <button
                (click)="searchTerm.set(''); filterInput.value = ''"
                class="absolute left-3 top-2.5 text-slate-400 hover:text-slate-600">
                <mat-icon class="!text-[18px]">close</mat-icon>
              </button>
            }
          </div>

          <!-- Secondary Filters based on Region -->
          @if (region() === 'world') {
            <div class="flex flex-wrap items-center gap-1.5">
              <span class="text-xs text-slate-400 ml-1">کشور:</span>
              @for (c of worldCountries; track c) {
                <button
                  (click)="toggleCountry(c)"
                  [class.bg-indigo-600]="selectedCountry() === c"
                  [class.text-white]="selectedCountry() === c"
                  [class.bg-slate-100]="selectedCountry() !== c"
                  [class.dark:bg-slate-800]="selectedCountry() !== c"
                  [class.text-slate-700]="selectedCountry() !== c"
                  [class.dark:text-slate-300]="selectedCountry() !== c"
                  class="px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors">
                  {{ c }}
                </button>
              }
            </div>
          } @else {
            <div class="flex flex-wrap items-center gap-1.5">
              <span class="text-xs text-slate-400 ml-1">شهر / نوع:</span>
              @for (f of iranFilters; track f) {
                <button
                  (click)="toggleIranFilter(f)"
                  [class.bg-indigo-600]="selectedIranFilter() === f"
                  [class.text-white]="selectedIranFilter() === f"
                  [class.bg-slate-100]="selectedIranFilter() !== f"
                  [class.dark:bg-slate-800]="selectedIranFilter() !== f"
                  [class.text-slate-700]="selectedIranFilter() !== f"
                  [class.dark:text-slate-300]="selectedIranFilter() !== f"
                  class="px-2.5 py-1.5 rounded-lg text-xs font-medium transition-colors">
                  {{ f }}
                </button>
              }
            </div>
          }
        </div>

        @if (storage.filterBookmarksOnly()) {
          <div class="flex items-center gap-2 p-2 rounded-xl bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-300 text-xs">
            <mat-icon class="!text-[18px]">bookmark</mat-icon>
            <span>نمایش فقط دانشگاه‌های نشان‌شده شما</span>
            <button (click)="storage.filterBookmarksOnly.set(false)" class="underline mr-auto">نمایش همه</button>
          </div>
        }
      </div>

      <!-- Universities List -->
      <div class="space-y-5">
        @if (filteredUniversities().length === 0) {
          <div class="py-16 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
            <mat-icon class="text-slate-400 !text-[36px]">search_off</mat-icon>
            <p class="text-sm font-semibold text-slate-700 dark:text-slate-300">هیچ دانشگاهی با این مشخصات یافت نشد.</p>
            <p class="text-xs text-slate-400">فیلترها را ریست کنید یا کلمه دیگری جستجو نمایید.</p>
          </div>
        } @else {
          @for (uni of filteredUniversities(); track uni.id) {
            <div class="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all space-y-4">
              
              <!-- Card Header -->
              <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div class="space-y-1">
                  <div class="flex flex-wrap items-center gap-2">
                    <h2 class="text-base sm:text-lg font-black text-slate-900 dark:text-white leading-tight">
                      {{ uni.name }}
                    </h2>
                    <span class="text-xs text-slate-500 font-sans tracking-wide" dir="ltr">
                      {{ uni.englishName }}
                    </span>
                  </div>

                  <div class="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                    <span class="font-semibold text-indigo-600 dark:text-indigo-400">{{ uni.rankingText }}</span>
                    <span>·</span>
                    <span>{{ uni.city }}، {{ uni.country }}</span>
                    @if (uni.capacityInfo) {
                      <span>·</span>
                      <span class="text-slate-600 dark:text-slate-300">{{ uni.capacityInfo }}</span>
                    }
                  </div>
                </div>

                <!-- Action Buttons: Direct Admission Link & Web -->
                <div class="flex items-center gap-2 shrink-0">
                  <!-- Bookmark Button -->
                  <button
                    (click)="storage.toggleBookmark(uni.id)"
                    [class.text-amber-500]="storage.isBookmarked(uni.id)"
                    [class.text-slate-400]="!storage.isBookmarked(uni.id)"
                    class="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                    [title]="storage.isBookmarked(uni.id) ? 'حذف از نشان‌شده‌ها' : 'نشان کردن دانشگاه'">
                    <mat-icon class="!text-[20px]">{{ storage.isBookmarked(uni.id) ? 'bookmark' : 'bookmark_border' }}</mat-icon>
                  </button>

                  <!-- Personal Note Button -->
                  <button
                    (click)="openNote(uni)"
                    [class.text-indigo-600]="storage.hasNote(uni.id)"
                    [class.bg-indigo-50]="storage.hasNote(uni.id)"
                    [class.dark:bg-indigo-950/60]="storage.hasNote(uni.id)"
                    [class.text-slate-500]="!storage.hasNote(uni.id)"
                    class="p-2 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors flex items-center gap-1 text-xs"
                    title="یادداشت شخصی">
                    <mat-icon class="!text-[20px]">{{ storage.hasNote(uni.id) ? 'speaker_notes' : 'note_add' }}</mat-icon>
                    @if (storage.hasNote(uni.id)) {
                      <span class="hidden sm:inline font-bold">یادداشت</span>
                    }
                  </button>

                  <!-- Direct Admission Page Button -->
                  <a
                    [href]="uni.admissionUrl"
                    target="_blank"
                    rel="noopener noreferrer"
                    class="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-colors shadow-sm shadow-indigo-600/20 flex items-center gap-1.5 whitespace-nowrap">
                    <span>صفحه پذیرش دکتری</span>
                    <mat-icon class="!text-[16px]">open_in_new</mat-icon>
                  </a>

                  <!-- Official Site -->
                  <a
                    [href]="uni.officialUrl"
                    target="_blank"
                    rel="noopener noreferrer"
                    class="p-2 rounded-xl text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 transition-colors"
                    title="وب‌سایت اصلی دانشگاه">
                    <mat-icon class="!text-[18px]">language</mat-icon>
                  </a>
                </div>
              </div>

              <!-- Personal Note Snippet (if Alireza wrote one) -->
              @if (storage.hasNote(uni.id)) {
                <div class="p-3 rounded-xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-800/40 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2">
                  <mat-icon class="text-amber-600 !text-[18px] shrink-0 mt-0.5">sticky_note_2</mat-icon>
                  <div class="flex-1">
                    <span class="font-bold block mb-0.5">یادداشت شخصی علیرضا:</span>
                    <p class="leading-relaxed">{{ storage.getNote(uni.id) }}</p>
                  </div>
                  <button 
                    (click)="openNote(uni)"
                    class="text-[11px] underline font-semibold text-amber-700 dark:text-amber-300">
                    ویرایش
                  </button>
                </div>
              }

              <!-- Admission Conditions & Details Grid -->
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
                
                <!-- Requirements -->
                <div class="p-4 rounded-xl bg-slate-50/80 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800/60 space-y-2">
                  <h3 class="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <mat-icon class="text-indigo-600 !text-[16px]">verified</mat-icon>
                    <span>شرایط پذیرش و آزمون‌ها</span>
                  </h3>
                  <ul class="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                    @for (req of uni.admissionRequirements; track req) {
                      <li class="flex items-start gap-1.5">
                        <span class="text-indigo-500 font-bold mt-0.5">·</span>
                        <span class="leading-relaxed">{{ req }}</span>
                      </li>
                    }
                  </ul>

                  @if (uni.deadlinesSummary) {
                    <div class="pt-2 text-[11px] font-semibold text-amber-700 dark:text-amber-400 border-t border-slate-200/60 dark:border-slate-800 flex items-center gap-1">
                      <mat-icon class="!text-[14px]">event</mat-icon>
                      <span>زمان‌بندی: {{ uni.deadlinesSummary }}</span>
                    </div>
                  }
                </div>

                <!-- Specializations and Departments -->
                <div class="p-4 rounded-xl bg-slate-50/80 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800/60 space-y-2">
                  <h3 class="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <mat-icon class="text-sky-600 !text-[16px]">psychology</mat-icon>
                    <span>حوزه‌ها و گرایش‌های هوش مصنوعی</span>
                  </h3>
                  
                  <div class="flex flex-wrap gap-1.5 pt-1">
                    @for (spec of uni.specializations; track spec) {
                      <span class="px-2.5 py-1 rounded-md text-[11px] font-medium bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200">
                        {{ spec }}
                      </span>
                    }
                  </div>

                  <div class="pt-2 text-xs text-slate-500 dark:text-slate-400">
                    <span class="font-medium">دانشکده‌ها: </span>
                    <span>{{ uni.departments.join(' · ') }}</span>
                  </div>
                </div>

              </div>

              <!-- Active AI Faculty Members -->
              @if (uni.facultyMembers.length > 0) {
                <div class="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
                  <div class="flex items-center justify-between">
                    <h3 class="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                      <mat-icon class="text-emerald-600 !text-[16px]">badge</mat-icon>
                      <span>اساتید سرشناس و فعال هوش مصنوعی</span>
                    </h3>
                    <span class="text-[11px] text-slate-400">جهت بررسی مقالات و مکاتبه (Cold Email)</span>
                  </div>

                  <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                    @for (fac of uni.facultyMembers; track fac.name) {
                      <div class="p-2.5 rounded-xl border border-slate-200/70 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between gap-2">
                        <div class="space-y-0.5 min-w-0">
                          <span class="text-xs font-bold text-slate-900 dark:text-white truncate block">
                            {{ fac.name }}
                          </span>
                          <span class="text-[11px] text-slate-500 dark:text-slate-400 truncate block">
                            {{ fac.specialty }}
                          </span>
                        </div>

                        <div class="flex items-center gap-1 shrink-0">
                          @if (fac.scholarUrl) {
                            <a
                              [href]="fac.scholarUrl"
                              target="_blank"
                              rel="noopener noreferrer"
                              class="p-1 rounded-md text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                              title="پروفایل گوگل اسکالر استاد">
                              <mat-icon class="!text-[16px]">school</mat-icon>
                            </a>
                          }
                          @if (fac.profileUrl) {
                            <a
                              [href]="fac.profileUrl"
                              target="_blank"
                              rel="noopener noreferrer"
                              class="p-1 rounded-md text-slate-400 hover:text-sky-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                              title="صفحه خانگی استاد">
                              <mat-icon class="!text-[16px]">person</mat-icon>
                            </a>
                          }
                        </div>
                      </div>
                    }
                  </div>
                </div>
              }

            </div>
          }
        }
      </div>

    </div>
  `
})
export class Universities {
  readonly storage = inject(StorageService);
  readonly academicData = inject(AcademicDataService);

  readonly region = signal<'iran' | 'world'>('iran');
  readonly searchTerm = signal<string>('');
  readonly selectedCountry = signal<string>('همه');
  readonly selectedIranFilter = signal<string>('همه');

  readonly worldCountries = ['همه', 'آمریکا', 'سوئیس', 'کانادا', 'آلمان', 'انگلستان', 'سنگاپور'];
  readonly iranFilters = ['همه', 'تهران', 'اصفهان', 'شیراز', 'مشهد', 'دانشگاه آزاد (علوم و تحقیقات)'];

  readonly iranCount = computed(() => {
    return this.academicData.universities.filter(u => u.region === 'iran').length;
  });

  readonly worldCount = computed(() => {
    return this.academicData.universities.filter(u => u.region === 'world').length;
  });

  readonly filteredUniversities = computed<University[]>(() => {
    const r = this.region();
    const q = this.searchTerm().trim().toLowerCase();
    const country = this.selectedCountry();
    const iranF = this.selectedIranFilter();
    const bookmarksOnly = this.storage.filterBookmarksOnly();

    return this.academicData.universities.filter(u => {
      if (u.region !== r) return false;

      if (bookmarksOnly && !this.storage.isBookmarked(u.id)) return false;

      if (r === 'world' && country !== 'همه' && u.country !== country) return false;

      if (r === 'iran' && iranF !== 'همه') {
        if (iranF === 'دانشگاه آزاد (علوم و تحقیقات)' && !u.tags.includes('دانشگاه آزاد')) return false;
        if (iranF !== 'دانشگاه آزاد (علوم و تحقیقات)' && u.city !== iranF) return false;
      }

      if (q) {
        const matchName = u.name.toLowerCase().includes(q) || u.englishName.toLowerCase().includes(q);
        const matchCity = u.city.toLowerCase().includes(q) || u.country.toLowerCase().includes(q);
        const matchSpec = u.specializations.some(s => s.toLowerCase().includes(q));
        const matchFaculty = u.facultyMembers.some(f => f.name.toLowerCase().includes(q) || f.specialty.toLowerCase().includes(q));
        if (!matchName && !matchCity && !matchSpec && !matchFaculty) return false;
      }

      return true;
    });
  });

  toggleCountry(c: string) {
    this.selectedCountry.set(c);
  }

  toggleIranFilter(f: string) {
    this.selectedIranFilter.set(f);
  }

  openNote(uni: University) {
    this.storage.openNoteModal(uni.id, uni.name, 'دانشگاه');
  }
}
