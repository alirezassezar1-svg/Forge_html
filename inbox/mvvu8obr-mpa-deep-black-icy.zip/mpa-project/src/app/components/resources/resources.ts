import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StorageService } from '../../services/storage.service';
import { AcademicDataService } from '../../services/academic-data.service';
import { AcademicResource } from '../../models/academic.models';

@Component({
  selector: 'app-resources',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6 pb-12">
      
      <!-- Top Title -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <mat-icon class="text-indigo-600 dark:text-indigo-400 !text-[26px]">menu_book</mat-icon>
            <span>کتابخانه‌ها، مراجع علمی و کتب ضروری</span>
          </h1>
          <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">
            پایگاه‌های بین‌المللی مقالات، کتابخانه‌های دیجیتال دانشگاه‌های برتر، سامانه‌های ملی ایران و مراجع طلایی ارشد تا دکتری
          </p>
        </div>

        <!-- Section Category Switcher -->
        <div class="flex items-center p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl shrink-0 border border-slate-200/60 dark:border-slate-700/60">
          <button
            (click)="currentTab.set('search-portals')"
            [class.bg-white]="currentTab() === 'search-portals'"
            [class.text-indigo-600]="currentTab() === 'search-portals'"
            [class.shadow-sm]="currentTab() === 'search-portals'"
            [class.dark:bg-slate-900]="currentTab() === 'search-portals'"
            [class.dark:text-indigo-400]="currentTab() === 'search-portals'"
            [class.text-slate-600]="currentTab() !== 'search-portals'"
            [class.dark:text-slate-300]="currentTab() !== 'search-portals'"
            class="px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5">
            <mat-icon class="!text-[16px]">library_books</mat-icon>
            <span>پایگاه‌های علمی و ژورنال‌ها</span>
          </button>

          <button
            (click)="currentTab.set('iranian')"
            [class.bg-white]="currentTab() === 'iranian'"
            [class.text-indigo-600]="currentTab() === 'iranian'"
            [class.shadow-sm]="currentTab() === 'iranian'"
            [class.dark:bg-slate-900]="currentTab() === 'iranian'"
            [class.dark:text-indigo-400]="currentTab() === 'iranian'"
            [class.text-slate-600]="currentTab() !== 'iranian'"
            [class.dark:text-slate-300]="currentTab() !== 'iranian'"
            class="px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5">
            <mat-icon class="!text-[16px]">account_balance</mat-icon>
            <span>مراجع و کتابخانه‌های ایران</span>
          </button>

          <button
            (click)="currentTab.set('books')"
            [class.bg-white]="currentTab() === 'books'"
            [class.text-indigo-600]="currentTab() === 'books'"
            [class.shadow-sm]="currentTab() === 'books'"
            [class.dark:bg-slate-900]="currentTab() === 'books'"
            [class.dark:text-indigo-400]="currentTab() === 'books'"
            [class.text-slate-600]="currentTab() !== 'books'"
            [class.dark:text-slate-300]="currentTab() !== 'books'"
            class="px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5">
            <mat-icon class="!text-[16px]">auto_stories</mat-icon>
            <span>کتب مرجع ضروری هوش مصنوعی</span>
          </button>
        </div>
      </div>

      <!-- Book Category Pills (visible only when books tab is active) -->
      @if (currentTab() === 'books') {
        <div class="flex flex-wrap items-center gap-2 p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
          <span class="text-xs font-bold text-slate-500 dark:text-slate-400 ml-2">دسته‌بندی موضوعی:</span>
          @for (c of bookCategories; track c.id) {
            <button
              (click)="selectedBookCategory.set(c.id)"
              [class.bg-indigo-600]="selectedBookCategory() === c.id"
              [class.text-white]="selectedBookCategory() === c.id"
              [class.bg-slate-100]="selectedBookCategory() !== c.id"
              [class.dark:bg-slate-800]="selectedBookCategory() !== c.id"
              [class.text-slate-700]="selectedBookCategory() !== c.id"
              [class.dark:text-slate-300]="selectedBookCategory() !== c.id"
              class="px-3 py-1.5 rounded-lg text-xs font-medium transition-colors">
              {{ c.label }}
            </button>
          }
        </div>
      }

      <!-- Resources Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        @for (item of filteredResources(); track item.id) {
          <div class="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4">
            
            <div class="space-y-2.5">
              <!-- Top Badges -->
              <div class="flex items-center justify-between gap-2">
                <span class="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                  {{ item.authorOrProvider }}
                </span>
                
                <span class="text-[10px] px-2 py-0.5 rounded-md font-bold"
                  [class.bg-emerald-100]="item.accessType === 'open-access' || item.accessType === 'free'"
                  [class.text-emerald-700]="item.accessType === 'open-access' || item.accessType === 'free'"
                  [class.bg-slate-100]="item.accessType === 'institutional'"
                  [class.text-slate-700]="item.accessType === 'institutional'">
                  {{ item.accessType === 'open-access' || item.accessType === 'free' ? 'دسترسی آزاد و رایگان' : 'دسترسی دانشگاهی' }}
                </span>
              </div>

              <!-- Title -->
              <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white leading-snug">
                  {{ item.title }}
                </h3>
                <p class="text-[11px] text-slate-400 font-sans tracking-wide mt-0.5" dir="ltr">
                  {{ item.englishTitle }}
                </p>
              </div>

              <!-- Description -->
              <p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {{ item.description }}
              </p>

              <!-- Recommendation note -->
              <div class="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/50 border border-slate-100 dark:border-slate-800/80 text-[11px] text-slate-500 dark:text-slate-400">
                <span class="font-bold text-indigo-600 dark:text-indigo-400 block mb-0.5">کاربرد در مسیر علیرضا:</span>
                <span>{{ item.recommendedFor }}</span>
              </div>

              <!-- Personal Note if exists -->
              @if (storage.hasNote(item.id)) {
                <div class="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-800/40 text-[11px] text-amber-900 dark:text-amber-200">
                  <span class="font-bold block mb-0.5">یادداشت من:</span>
                  <p>{{ storage.getNote(item.id) }}</p>
                </div>
              }
            </div>

            <!-- Footer Action Buttons -->
            <div class="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
              <div class="flex items-center gap-1.5">
                <!-- Bookmark -->
                <button
                  (click)="storage.toggleBookmark(item.id)"
                  [class.text-amber-500]="storage.isBookmarked(item.id)"
                  [class.text-slate-400]="!storage.isBookmarked(item.id)"
                  class="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  title="نشان کردن منبع">
                  <mat-icon class="!text-[20px]">{{ storage.isBookmarked(item.id) ? 'bookmark' : 'bookmark_border' }}</mat-icon>
                </button>

                <!-- Personal Note -->
                <button
                  (click)="openNote(item)"
                  class="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  title="ثبت یادداشت">
                  <mat-icon class="!text-[20px]">edit_note</mat-icon>
                </button>
              </div>

              <!-- Direct link -->
              <a
                [href]="item.url"
                target="_blank"
                rel="noopener noreferrer"
                class="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center gap-1 shadow-sm transition-colors">
                <span>ورود به پایگاه / دانلود</span>
                <mat-icon class="!text-[16px]">open_in_new</mat-icon>
              </a>
            </div>

          </div>
        }
      </div>

    </div>
  `
})
export class Resources {
  readonly storage = inject(StorageService);
  readonly academicData = inject(AcademicDataService);

  readonly currentTab = signal<'search-portals' | 'iranian' | 'books'>('search-portals');
  readonly selectedBookCategory = signal<string>('all');

  readonly bookCategories = [
    { id: 'all', label: 'همه کتاب‌ها' },
    { id: 'math', label: 'ریاضیات یادگیری ماشین' },
    { id: 'deep-learning', label: 'یادگیری عمیق' },
    { id: 'ml', label: 'یادگیری ماشین آماری' },
    { id: 'nlp', label: 'پردازش زبان طبیعی (NLP)' },
    { id: 'cv', label: 'بینایی کامپیوتر' },
    { id: 'rl', label: 'یادگیری تقویتی' },
    { id: 'writing', label: 'نگارش و روش پژوهش' }
  ];

  readonly filteredResources = computed<AcademicResource[]>(() => {
    const tab = this.currentTab();
    const bookCat = this.selectedBookCategory();
    const bookmarksOnly = this.storage.filterBookmarksOnly();

    return this.academicData.resources.filter(r => {
      if (bookmarksOnly && !this.storage.isBookmarked(r.id)) return false;

      if (tab === 'search-portals') {
        return r.type === 'search-engine' || r.type === 'library' || r.type === 'paper-repo';
      } else if (tab === 'iranian') {
        return r.type === 'iranian-portal';
      } else if (tab === 'books') {
        if (r.type !== 'textbook') return false;
        if (bookCat !== 'all' && r.category !== bookCat) return false;
        return true;
      }
      return true;
    });
  });

  openNote(item: AcademicResource) {
    this.storage.openNoteModal(item.id, item.title, 'منبع علمی');
  }
}
