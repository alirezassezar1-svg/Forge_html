import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StorageService } from '../../services/storage.service';
import { AcademicDataService } from '../../services/academic-data.service';
import { ResearchLab } from '../../models/academic.models';

@Component({
  selector: 'app-labs',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6 pb-12">
      
      <!-- Top Title -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <mat-icon class="text-indigo-600 dark:text-indigo-400 !text-[26px]">biotech</mat-icon>
            <span>مراکز تحقیقاتی و آزمایشگاه‌های پیشرو هوش مصنوعی</span>
          </h1>
          <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">
            آزمایشگاه‌های برتر دانشگاهی ایران و غول‌های پژوهشی جهان به همراه لینک‌های مستقیم بورسیه و دوره‌های دستیاری پژوهشی
          </p>
        </div>

        <!-- Filter Iran vs World -->
        <div class="flex items-center p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl shrink-0 border border-slate-200/60 dark:border-slate-700/60">
          <button
            (click)="labRegion.set('all')"
            [class.bg-white]="labRegion() === 'all'"
            [class.text-indigo-600]="labRegion() === 'all'"
            [class.shadow-sm]="labRegion() === 'all'"
            [class.dark:bg-slate-900]="labRegion() === 'all'"
            [class.dark:text-indigo-400]="labRegion() === 'all'"
            [class.text-slate-600]="labRegion() !== 'all'"
            [class.dark:text-slate-300]="labRegion() !== 'all'"
            class="px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all">
            همه مراکز
          </button>

          <button
            (click)="labRegion.set('iran')"
            [class.bg-white]="labRegion() === 'iran'"
            [class.text-indigo-600]="labRegion() === 'iran'"
            [class.shadow-sm]="labRegion() === 'iran'"
            [class.dark:bg-slate-900]="labRegion() === 'iran'"
            [class.dark:text-indigo-400]="labRegion() === 'iran'"
            [class.text-slate-600]="labRegion() !== 'iran'"
            [class.dark:text-slate-300]="labRegion() !== 'iran'"
            class="px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all">
            مراکز تحقیقاتی ایران
          </button>

          <button
            (click)="labRegion.set('world')"
            [class.bg-white]="labRegion() === 'world'"
            [class.text-indigo-600]="labRegion() === 'world'"
            [class.shadow-sm]="labRegion() === 'world'"
            [class.dark:bg-slate-900]="labRegion() === 'world'"
            [class.dark:text-indigo-400]="labRegion() === 'world'"
            [class.text-slate-600]="labRegion() !== 'world'"
            [class.dark:text-slate-300]="labRegion() !== 'world'"
            class="px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all">
            مراکز جهانی (DeepMind, OpenAI, FAIR)
          </button>
        </div>
      </div>

      <!-- Labs Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        @for (lab of filteredLabs(); track lab.id) {
          <div class="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4">
            
            <div class="space-y-3">
              <!-- Top Row -->
              <div class="flex items-start justify-between gap-3">
                <div>
                  <div class="flex items-center gap-2">
                    <span class="text-[10px] font-bold px-2 py-0.5 rounded-md"
                      [class.bg-indigo-100]="lab.region === 'iran'"
                      [class.text-indigo-700]="lab.region === 'iran'"
                      [class.bg-sky-100]="lab.region === 'world'"
                      [class.text-sky-700]="lab.region === 'world'">
                      {{ lab.region === 'iran' ? 'پژوهشگاه داخل ایران' : 'لابراتوار بین‌المللی' }}
                    </span>
                    <span class="text-xs text-slate-400 font-medium">{{ lab.location }}</span>
                  </div>

                  <h3 class="text-base font-bold text-slate-900 dark:text-white mt-1.5 leading-snug">
                    {{ lab.name }}
                  </h3>
                  <p class="text-xs text-slate-500 font-sans tracking-wide" dir="ltr">
                    {{ lab.englishName }}
                  </p>
                </div>

                <div class="flex items-center gap-1.5 shrink-0">
                  <button
                    (click)="storage.toggleBookmark(lab.id)"
                    [class.text-amber-500]="storage.isBookmarked(lab.id)"
                    [class.text-slate-400]="!storage.isBookmarked(lab.id)"
                    class="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    title="نشان کردن آزمایشگاه">
                    <mat-icon class="!text-[20px]">{{ storage.isBookmarked(lab.id) ? 'bookmark' : 'bookmark_border' }}</mat-icon>
                  </button>

                  <button
                    (click)="openNote(lab)"
                    [class.text-indigo-600]="storage.hasNote(lab.id)"
                    [class.text-slate-400]="!storage.hasNote(lab.id)"
                    class="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    title="یادداشت شخصی">
                    <mat-icon class="!text-[20px]">edit_note</mat-icon>
                  </button>
                </div>
              </div>

              <!-- Description -->
              <p class="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {{ lab.description }}
              </p>

              <!-- Personal Note Snippet -->
              @if (storage.hasNote(lab.id)) {
                <div class="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-800/40 text-[11px] text-amber-900 dark:text-amber-200">
                  <span class="font-bold block mb-0.5">یادداشت من:</span>
                  <p>{{ storage.getNote(lab.id) }}</p>
                </div>
              }

              <!-- Focus Areas -->
              <div class="space-y-1.5">
                <span class="text-[11px] font-semibold text-slate-500 dark:text-slate-400">حوزه‌های پژوهش اصلی:</span>
                <div class="flex flex-wrap gap-1.5">
                  @for (fa of lab.focusAreas; track fa) {
                    <span class="px-2 py-0.5 rounded-md text-[11px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium">
                      {{ fa }}
                    </span>
                  }
                </div>
              </div>

              <!-- Opportunities & Leads -->
              <div class="p-3 rounded-xl bg-slate-50/70 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800/60 space-y-1.5 text-xs">
                <div class="flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400 font-semibold">
                  <mat-icon class="!text-[16px]">work_outline</mat-icon>
                  <span>فرصت‌ها: {{ lab.opportunityTypes.join(' · ') }}</span>
                </div>
                @if (lab.leadPeople && lab.leadPeople.length > 0) {
                  <div class="text-[11px] text-slate-500 dark:text-slate-400">
                    <span class="font-medium">پژوهشگران شاخص: </span>
                    <span>{{ lab.leadPeople.join('، ') }}</span>
                  </div>
                }
              </div>
            </div>

            <!-- Footer Action Links -->
            <div class="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
              <a
                [href]="lab.websiteUrl"
                target="_blank"
                rel="noopener noreferrer"
                class="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs text-slate-700 dark:text-slate-300 font-medium transition-colors flex items-center gap-1">
                <span>وب‌سایت آزمایشگاه</span>
                <mat-icon class="!text-[14px]">public</mat-icon>
              </a>

              @if (lab.careersOrFellowshipUrl) {
                <a
                  [href]="lab.careersOrFellowshipUrl"
                  target="_blank"
                  rel="noopener noreferrer"
                  class="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-colors shadow-sm flex items-center gap-1">
                  <span>فرصت‌های پژوهشی و Fellowship</span>
                  <mat-icon class="!text-[14px]">open_in_new</mat-icon>
                </a>
              }
            </div>

          </div>
        }
      </div>

    </div>
  `
})
export class Labs {
  readonly storage = inject(StorageService);
  readonly academicData = inject(AcademicDataService);

  readonly labRegion = signal<'all' | 'iran' | 'world'>('all');

  readonly filteredLabs = computed<ResearchLab[]>(() => {
    const r = this.labRegion();
    const bookmarksOnly = this.storage.filterBookmarksOnly();

    return this.academicData.labs.filter(l => {
      if (bookmarksOnly && !this.storage.isBookmarked(l.id)) return false;
      if (r === 'iran' && l.region !== 'iran') return false;
      if (r === 'world' && l.region !== 'world') return false;
      return true;
    });
  });

  openNote(lab: ResearchLab) {
    this.storage.openNoteModal(lab.id, lab.name, 'مرکز تحقیقاتی');
  }
}
