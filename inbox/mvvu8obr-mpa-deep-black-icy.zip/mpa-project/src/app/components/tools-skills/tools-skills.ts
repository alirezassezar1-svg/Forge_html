import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StorageService } from '../../services/storage.service';
import { AcademicDataService } from '../../services/academic-data.service';
import { AcademicTool, SkillItem } from '../../models/academic.models';

@Component({
  selector: 'app-tools-skills',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-8 pb-12">
      
      <!-- Top Title -->
      <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 class="text-xl sm:text-2xl font-black text-slate-900 dark:text-white flex items-center gap-2">
            <mat-icon class="text-indigo-600 dark:text-indigo-400 !text-[26px]">handyman</mat-icon>
            <span>ابزارها و چک‌لیست مهارت‌های ضروری تا دکتری</span>
          </h1>
          <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">
            سکوهای استاندارد پژوهشی و مراحل گام‌به‌گام مهارتی از روز اول ارشد در دزفول تا قبولی دکتری
          </p>
        </div>

        <div class="flex items-center gap-3 bg-white dark:bg-slate-900 px-4 py-2 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <div class="text-right">
            <span class="text-[11px] text-slate-400 block">پیشرفت مهارت‌ها</span>
            <span class="text-sm font-black text-indigo-600 dark:text-indigo-400">
              {{ storage.skillsProgressPercent() }}٪ تکمیل
            </span>
          </div>
          <div class="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center font-bold text-xs">
            {{ storage.completedSkillsCount() }}/{{ storage.totalSkillsCount() }}
          </div>
        </div>
      </div>

      <!-- Section 1: Academic Tools Suite -->
      <div class="space-y-4">
        <div class="flex items-center gap-2">
          <div class="w-7 h-7 rounded-lg bg-sky-100 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center">
            <mat-icon class="!text-[18px]">build_circle</mat-icon>
          </div>
          <h2 class="text-base font-bold text-slate-900 dark:text-white">
            مجموعه ابزارهای کلیدی پژوهشگر هوش مصنوعی
          </h2>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          @for (tool of academicData.tools; track tool.id) {
            <div class="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4">
              
              <div class="space-y-2.5">
                <div class="flex items-center justify-between gap-2">
                  <span class="text-xs font-bold text-indigo-600 dark:text-indigo-400">
                    {{ tool.name }}
                  </span>
                  
                  <span class="text-[10px] px-2 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 font-semibold">
                    نسخه رایگان دارد
                  </span>
                </div>

                <h3 class="text-xs font-semibold text-slate-700 dark:text-slate-200 leading-snug">
                  {{ tool.tagline }}
                </h3>

                <p class="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  {{ tool.description }}
                </p>

                <div class="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-100 dark:border-slate-800 text-[11px] text-slate-600 dark:text-slate-300">
                  <span class="font-bold text-slate-900 dark:text-white block mb-0.5">مزیت ویژه برای علیرضا:</span>
                  <span>{{ tool.benefitsForAlireza }}</span>
                </div>

                @if (storage.hasNote(tool.id)) {
                  <div class="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200/60 dark:border-amber-800/40 text-[11px] text-amber-900 dark:text-amber-200">
                    <span class="font-bold block mb-0.5">یادداشت من:</span>
                    <p>{{ storage.getNote(tool.id) }}</p>
                  </div>
                }
              </div>

              <div class="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                <div class="flex items-center gap-1.5">
                  <button
                    (click)="storage.toggleBookmark(tool.id)"
                    [class.text-amber-500]="storage.isBookmarked(tool.id)"
                    [class.text-slate-400]="!storage.isBookmarked(tool.id)"
                    class="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    title="نشان کردن ابزار">
                    <mat-icon class="!text-[20px]">{{ storage.isBookmarked(tool.id) ? 'bookmark' : 'bookmark_border' }}</mat-icon>
                  </button>

                  <button
                    (click)="openNote(tool)"
                    class="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    title="ثبت یادداشت">
                    <mat-icon class="!text-[20px]">edit_note</mat-icon>
                  </button>
                </div>

                <a
                  [href]="tool.url"
                  target="_blank"
                  rel="noopener noreferrer"
                  class="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center gap-1 shadow-sm transition-colors">
                  <span>ورود مستقیم</span>
                  <mat-icon class="!text-[16px]">open_in_new</mat-icon>
                </a>
              </div>

            </div>
          }
        </div>
      </div>

      <!-- Section 2: 5-Phase Skills Progression Checklist -->
      <div class="space-y-6 pt-4 border-t border-slate-200 dark:border-slate-800">
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div class="flex items-center gap-2">
            <div class="w-7 h-7 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <mat-icon class="!text-[18px]">verified_user</mat-icon>
            </div>
            <div>
              <h2 class="text-base font-bold text-slate-900 dark:text-white">
                چک‌لیست مهارت‌های ضروری از روز اول ارشد تا قبولی دکتری
              </h2>
              <p class="text-xs text-slate-500 dark:text-slate-400">
                با انجام هر مهارت روی تیک آن کلیک کنید تا وضعیت به صورت دائمی در پروفایل شما ثبت شود.
              </p>
            </div>
          </div>
        </div>

        <div class="space-y-6">
          @for (phase of phasesMeta; track phase.id) {
            <div class="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
              
              <!-- Phase Header -->
              <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
                <div class="flex items-center gap-2.5">
                  <div class="w-7 h-7 rounded-lg bg-indigo-600 text-white font-mono text-xs font-bold flex items-center justify-center">
                    ۰{{ phase.id }}
                  </div>
                  <div>
                    <h3 class="text-sm font-bold text-slate-900 dark:text-white">
                      {{ phase.title }}
                    </h3>
                    <p class="text-xs text-slate-500 dark:text-slate-400">
                      {{ phase.focus }}
                    </p>
                  </div>
                </div>

                <div class="text-xs font-semibold text-slate-600 dark:text-slate-300">
                  {{ phaseCompletion(phase.id) }}
                </div>
              </div>

              <!-- Phase Skills List -->
              <div class="space-y-2.5">
                @for (skill of getSkillsForPhase(phase.id); track skill.id) {
                  <div 
                    class="p-3.5 rounded-xl border border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-950/30 flex items-start justify-between gap-3 hover:bg-slate-100/60 dark:hover:bg-slate-800/40 transition-colors">
                    
                    <button
                      (click)="storage.toggleSkill(skill.id)"
                      class="flex items-start gap-3 text-right flex-1 min-w-0">
                      <div 
                        [class.bg-emerald-500]="skill.completed"
                        [class.border-emerald-500]="skill.completed"
                        [class.border-slate-300]="!skill.completed"
                        [class.dark:border-slate-600]="!skill.completed"
                        class="w-5 h-5 rounded-md border flex items-center justify-center text-white mt-0.5 shrink-0 transition-colors">
                        @if (skill.completed) {
                          <mat-icon class="!text-[14px]">check</mat-icon>
                        }
                      </div>

                      <div class="space-y-1">
                        <span 
                          [class.line-through]="skill.completed"
                          [class.text-slate-400]="skill.completed"
                          [class.text-slate-900]="!skill.completed"
                          [class.dark:text-slate-100]="!skill.completed"
                          class="text-xs font-bold leading-relaxed block">
                          {{ skill.title }}
                        </span>
                        
                        <p class="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                          {{ skill.description }}
                        </p>
                      </div>
                    </button>

                  </div>
                }
              </div>

            </div>
          }
        </div>
      </div>

    </div>
  `
})
export class ToolsSkills {
  readonly storage = inject(StorageService);
  readonly academicData = inject(AcademicDataService);

  readonly phasesMeta = [
    { id: 1 as const, title: 'فاز اول: پایه‌ریزی ریاضیات و مهارت کدنویسی پیشرفته', focus: 'PyTorch، جبر خطی، سیستم‌عامل لینوکس و کنترل نسخه Git' },
    { id: 2 as const, title: 'فاز دوم: تعیین موضوع پایان‌نامه و تسلط بر ادبیات تحقیق', focus: 'مرور ۴۰ مقاله، ساخت ماتریس مقایسه، بازتولید مقاله شاخص و تصویب پروپوزال' },
    { id: 3 as const, title: 'فاز سوم: اجرای پژوهش و نگارش مقاله بین‌المللی', focus: 'پیاده‌سازی نوآوری، نگارش در لاتک و سابمیت به ژورنال معتبر Q1 یا کنفرانس تراز اول' },
    { id: 4 as const, title: 'فاز چهارم: تقویت زبان انگلیسی و رزومه آکادمیک', focus: 'آزمون‌های زبان (MSRT/IELTS/TOEFL)، نگارش CV استاندارد در LaTeX و تدوین انگیزه‌نامه (SOP)' },
    { id: 5 as const, title: 'فاز پنجم: آمادگی کنکور دکتری و مکاتبه هدفمند با اساتید', focus: 'شناسایی ۳۰ استاد در ایران و جهان، ایمیل‌های شخصی‌سازی‌شده و شبیه‌سازی مصاحبه دکتری' }
  ];

  getSkillsForPhase(phaseId: number): SkillItem[] {
    return this.storage.skills().filter(s => s.phaseId === phaseId);
  }

  phaseCompletion(phaseId: number): string {
    const list = this.getSkillsForPhase(phaseId);
    const done = list.filter(s => s.completed).length;
    return `${done} از ${list.length} انجام شده`;
  }

  openNote(tool: AcademicTool) {
    this.storage.openNoteModal(tool.id, tool.name, 'ابزار پژوهشی');
  }
}
