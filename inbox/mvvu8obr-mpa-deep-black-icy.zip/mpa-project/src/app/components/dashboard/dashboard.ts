import { ChangeDetectionStrategy, Component, inject, computed } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StorageService } from '../../services/storage.service';
import { AcademicDataService } from '../../services/academic-data.service';
import { SectionTab } from '../../models/academic.models';

@Component({
  selector: 'app-dashboard',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6 pb-12">
      
      <!-- Welcome Hero Banner -->
      <div class="rounded-3xl bg-gradient-to-br from-indigo-900 via-slate-900 to-slate-950 text-white p-6 sm:p-8 shadow-xl relative overflow-hidden border border-indigo-950/40">
        <!-- Subtle background glow -->
        <div class="absolute -top-24 -left-24 w-80 h-80 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none"></div>
        <div class="absolute -bottom-24 -right-24 w-80 h-80 bg-sky-500/15 rounded-full blur-3xl pointer-events-none"></div>

        <div class="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div class="space-y-3 max-w-2xl">
            <div class="flex flex-wrap items-center gap-2">
              <span class="px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/30 text-indigo-200 border border-indigo-400/30">
                پروفایل اختصاصی علیرضا · ۳۰ ساله
              </span>
              <span class="text-xs text-slate-300">
                {{ storage.profile().university }}
              </span>
            </div>

            <h1 class="text-2xl sm:text-3xl font-black tracking-tight text-white leading-tight">
              درود علیرضا عزیز؛ راهنمای پیشرفت علمی از ارشد تا دکتری
            </h1>
            
            <p class="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {{ storage.profile().thesisTopic }}
            </p>

            <div class="pt-1 flex flex-wrap items-center gap-4 text-xs text-slate-300">
              <div class="flex items-center gap-1.5">
                <mat-icon class="!text-[18px] text-amber-400">flag</mat-icon>
                <span>هدف: {{ storage.profile().targetDegree }}</span>
              </div>
              <div class="flex items-center gap-1.5">
                <mat-icon class="!text-[18px] text-emerald-400">schedule</mat-icon>
                <span>افق: {{ storage.profile().targetTimeline }}</span>
              </div>
            </div>
          </div>

          <!-- Progress summary circle -->
          <div class="flex sm:flex-row lg:flex-col items-center gap-4 bg-white/10 dark:bg-slate-800/40 backdrop-blur-md p-5 rounded-2xl border border-white/10 shrink-0">
            <div class="relative w-20 h-20 flex items-center justify-center">
              <svg class="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                <!-- Background circle -->
                <path
                  class="text-white/20"
                  stroke-width="3.5"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <!-- Progress circle -->
                <path
                  class="text-indigo-400 transition-all duration-700 ease-out"
                  stroke-dasharray="100, 100"
                  [attr.stroke-dashoffset]="100 - storage.skillsProgressPercent()"
                  stroke-linecap="round"
                  stroke-width="3.5"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <div class="absolute text-center">
                <span class="text-xl font-extrabold text-white">{{ storage.skillsProgressPercent() }}%</span>
              </div>
            </div>

            <div class="text-right sm:text-center">
              <span class="text-xs font-bold text-white block">آمادگی جامع دکتری</span>
              <span class="text-[11px] text-slate-300">
                {{ storage.completedSkillsCount() }} از {{ storage.totalSkillsCount() }} مهارت تکمیل شده
              </span>
            </div>
          </div>
        </div>
      </div>

      <!-- 5-Phase Master to PhD Roadmap Stepper -->
      <div class="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <div class="w-7 h-7 rounded-lg bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <mat-icon class="!text-[18px]">alt_route</mat-icon>
            </div>
            <h2 class="text-sm font-bold text-slate-900 dark:text-white">
              نقشه راه ۵ گانه علیرضا (ارشد تا قبولی دکتری)
            </h2>
          </div>
          <button
            (click)="goToTab('tools-skills')"
            class="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1">
            <span>مشاهده چک‌لیست کامل</span>
            <mat-icon class="!text-[16px]">arrow_back</mat-icon>
          </button>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          @for (phase of phases; track phase.id) {
            <button 
              (click)="goToTab('tools-skills')"
              class="text-right p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 hover:border-indigo-300 dark:hover:border-indigo-800 transition-all space-y-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
              <div class="flex items-center justify-between">
                <span class="text-[10px] font-bold px-2 py-0.5 rounded-md"
                  [class.bg-emerald-100]="phase.status === 'completed'"
                  [class.text-emerald-700]="phase.status === 'completed'"
                  [class.bg-indigo-100]="phase.status === 'in-progress'"
                  [class.text-indigo-700]="phase.status === 'in-progress'"
                  [class.bg-slate-200]="phase.status === 'upcoming'"
                  [class.text-slate-700]="phase.status === 'upcoming'">
                  {{ phase.statusLabel }}
                </span>
                <span class="text-xs font-mono font-bold text-slate-400">فاز ۰{{ phase.id }}</span>
              </div>
              
              <h3 class="text-xs font-bold text-slate-800 dark:text-slate-100 leading-snug">
                {{ phase.title }}
              </h3>
              
              <p class="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2">
                {{ phase.desc }}
              </p>
            </button>
          }
        </div>
      </div>

      <!-- Two-Column Grid: Priorities & Upcoming Deadlines -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        <!-- Left Column: Weekly Priorities (7 cols) -->
        <div class="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <div class="w-7 h-7 rounded-lg bg-sky-100 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 flex items-center justify-center">
                <mat-icon class="!text-[18px]">checklist</mat-icon>
              </div>
              <h2 class="text-sm font-bold text-slate-900 dark:text-white">
                اولویت‌های این هفته علیرضا
              </h2>
            </div>
            <span class="text-xs text-slate-400">
              {{ donePrioritiesCount() }} از {{ storage.weeklyPriorities().length }} انجام شده
            </span>
          </div>

          <!-- Add Priority Input -->
          <div class="flex items-center gap-2">
            <input
              #priInput
              type="text"
              placeholder="تسک یا اولویت جدید هفتگی را بنویسید (مثلاً: ران کردن تست شماره ۴ روی دیتاست)..."
              (keydown.enter)="addPriority(priInput)"
              class="flex-1 px-3.5 py-2.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            
            <button
              (click)="addPriority(priInput)"
              class="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shrink-0 transition-colors flex items-center gap-1 shadow-sm">
              <mat-icon class="!text-[18px]">add</mat-icon>
              <span class="hidden sm:inline">افزودن</span>
            </button>
          </div>

          <!-- Priorities List -->
          <div class="space-y-2">
            @for (pri of storage.weeklyPriorities(); track pri.id) {
              <div 
                class="flex items-start justify-between gap-3 p-3 rounded-xl border border-slate-100 dark:border-slate-800/80 bg-slate-50/40 dark:bg-slate-950/30 hover:bg-slate-100/60 dark:hover:bg-slate-800/40 transition-colors group">
                <button
                  (click)="storage.togglePriority(pri.id)"
                  class="flex items-start gap-2.5 text-right flex-1 min-w-0">
                  <div 
                    [class.bg-emerald-500]="pri.done"
                    [class.border-emerald-500]="pri.done"
                    [class.border-slate-300]="!pri.done"
                    [class.dark:border-slate-600]="!pri.done"
                    class="w-5 h-5 rounded-md border flex items-center justify-center text-white mt-0.5 shrink-0 transition-colors">
                    @if (pri.done) {
                      <mat-icon class="!text-[14px]">check</mat-icon>
                    }
                  </div>
                  <span 
                    [class.line-through]="pri.done"
                    [class.text-slate-400]="pri.done"
                    [class.text-slate-800]="!pri.done"
                    [class.dark:text-slate-200]="!pri.done"
                    class="text-xs leading-relaxed font-medium">
                    {{ pri.text }}
                  </span>
                </button>

                <button
                  (click)="storage.deletePriority(pri.id)"
                  class="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-rose-500 transition-all"
                  title="حذف تسک">
                  <mat-icon class="!text-[16px]">close</mat-icon>
                </button>
              </div>
            }
          </div>
        </div>

        <!-- Right Column: Upcoming Deadlines & Reminders (5 cols) -->
        <div class="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-2">
              <div class="w-7 h-7 rounded-lg bg-amber-100 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center">
                <mat-icon class="!text-[18px]">notification_important</mat-icon>
              </div>
              <h2 class="text-sm font-bold text-slate-900 dark:text-white">
                یادآوری‌ها و ددلاین‌های پیش رو
              </h2>
            </div>
            <button
              (click)="goToTab('calendar')"
              class="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline">
              همه رویدادها
            </button>
          </div>

          <div class="space-y-3">
            @for (ev of storage.upcomingEvents(); track ev.id) {
              <div class="p-3.5 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/40 space-y-2 hover:border-indigo-200 dark:hover:border-indigo-900 transition-colors">
                <div class="flex items-start justify-between gap-2">
                  <span class="text-xs font-bold text-slate-900 dark:text-white leading-tight">
                    {{ ev.title }}
                  </span>
                  <span class="text-[10px] font-mono px-2 py-0.5 rounded-md bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 shrink-0 font-bold">
                    {{ ev.deadlineShamsi }}
                  </span>
                </div>

                <div class="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                  <span>{{ ev.institutionOrOrg }}</span>
                  @if (ev.linkUrl) {
                    <a
                      [href]="ev.linkUrl"
                      target="_blank"
                      rel="noopener noreferrer"
                      class="text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-0.5">
                      <span>مشاهده جزئیات</span>
                      <mat-icon class="!text-[14px]">open_in_new</mat-icon>
                    </a>
                  }
                </div>
              </div>
            }
          </div>
        </div>

      </div>

      <!-- Quick Launchpad: Essential Daily Tools & Links for Alireza -->
      <div class="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2">
            <div class="w-7 h-7 rounded-lg bg-emerald-100 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <mat-icon class="!text-[18px]">rocket_launch</mat-icon>
            </div>
            <h2 class="text-sm font-bold text-slate-900 dark:text-white">
              میز کار علمی علیرضا (دسترسی مستقیم روزانه)
            </h2>
          </div>
          <span class="text-xs text-slate-400">لینک‌های پرتکرار پژوهش</span>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5">
          @for (tool of quickLinks; track tool.name) {
            <a
              [href]="tool.url"
              target="_blank"
              rel="noopener noreferrer"
              class="flex flex-col items-center justify-center p-3 rounded-xl border border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/40 hover:bg-indigo-50 hover:border-indigo-300 dark:hover:bg-indigo-950/40 transition-all text-center group">
              <div class="w-8 h-8 rounded-lg bg-slate-200 dark:bg-slate-800 group-hover:bg-indigo-600 group-hover:text-white transition-colors flex items-center justify-center text-slate-700 dark:text-slate-300 mb-1.5">
                <mat-icon class="!text-[18px]">{{ tool.icon }}</mat-icon>
              </div>
              <span class="text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-indigo-600 dark:group-hover:text-indigo-400">
                {{ tool.name }}
              </span>
              <span class="text-[10px] text-slate-400 mt-0.5">
                {{ tool.desc }}
              </span>
            </a>
          }
        </div>
      </div>

      <!-- Strategy Advice Box for Azad University Dezful to Top PhD -->
      <div class="rounded-2xl bg-gradient-to-r from-slate-900 to-indigo-950 text-white p-5 border border-indigo-900/50 space-y-3">
        <div class="flex items-center gap-2 text-amber-400">
          <mat-icon class="!text-[20px]">lightbulb</mat-icon>
          <span class="text-xs font-extrabold tracking-wide">راهبرد طلایی علیرضا برای قبولی در دکتری شریف / تهران یا خارج از کشور</span>
        </div>

        <p class="text-xs text-slate-300 leading-relaxed">
          علیرضای عزیز، داشتن مدرک ارشد از دانشگاه آزاد دزفول هیچ مانعی برای ورود به دکتری شریف، تهران، امیرکبیر یا برترین دانشگاه‌های جهان (ETH, MIT, Toronto) نیست. کلید تمایز شما در سه چیز است:
          <strong>۱. مقاله پژوهشی ژورنالی ISI Q1 یا کنفرانس معتبر بین‌المللی (حتی یک مقاله باکیفیت شما را از ۹۰٪ رقبا جلو می‌اندازد)</strong>؛ 
          <strong>۲. کدنویسی تمیز و ریپوزیتوری گیت‌هاب معتبر</strong>؛ 
          <strong>۳. نمره زبان انگلیسی عالی (MSRT/IELTS) و ارتباط مکاتبه‌ای پیش از آزمون با اساتید راهنما</strong>.
        </p>
      </div>

    </div>
  `
})
export class Dashboard {
  readonly storage = inject(StorageService);
  readonly academicData = inject(AcademicDataService);

  readonly donePrioritiesCount = computed(() => {
    return this.storage.weeklyPriorities().filter(p => p.done).length;
  });

  readonly phases = [
    { id: 1, title: 'پایه‌ریزی ریاضی و کدنویسی', desc: 'PyTorch، جبر خطی، لینوکس و مبانی شبکه‌های عصبی', status: 'completed', statusLabel: 'تکمیل‌شده' },
    { id: 2, title: 'انتخاب موضوع و مرور مقالات', desc: 'مطالعه ۵۰ مقاله، ماتریس ادبیات و تصویب پروپوزال', status: 'in-progress', statusLabel: 'در حال انجام' },
    { id: 3, title: 'پژوهش و نگارش مقاله ارشد', desc: 'پیاده‌سازی نوآوری، مقایسه با SOTA و چاپ در ژورنال Q1', status: 'upcoming', statusLabel: 'برنامه بعدی' },
    { id: 4, title: 'تقویت زبان و رزومه آکادمیک', desc: 'کسب نمره آیلتس/تافل/MSRT، تدوین CV در LaTeX و SOP', status: 'upcoming', statusLabel: 'پیش رو' },
    { id: 5, title: 'کنکور، مکاتبه و مصاحبه دکتری', desc: 'تماس با اساتید، پروپوزال دکتری و مصاحبه‌های دانشگاه‌ها', status: 'upcoming', statusLabel: 'هدف نهایی' }
  ];

  readonly quickLinks = [
    { name: 'Google Scholar', desc: 'جستجوی مقالات', icon: 'school', url: 'https://scholar.google.com' },
    { name: 'arXiv cs.AI', desc: 'تازه‌های یادگیری', icon: 'article', url: 'https://arxiv.org/list/cs.AI/recent' },
    { name: 'Overleaf', desc: 'ویرایشگر LaTeX', icon: 'edit_document', url: 'https://www.overleaf.com' },
    { name: 'GitHub', desc: 'کد و ریپوزیتوری', icon: 'code', url: 'https://github.com' },
    { name: 'ایران‌داک (گنج)', desc: 'پیشینه و پروپوزال', icon: 'find_in_page', url: 'https://ganj.irandoc.ac.ir' },
    { name: 'Papers With Code', desc: 'معیارهای SOTA', icon: 'leaderboard', url: 'https://paperswithcode.com' },
    { name: 'Hugging Face', desc: 'مدل‌ها و وزن‌ها', icon: 'smart_toy', url: 'https://huggingface.co' }
  ];

  goToTab(tab: SectionTab) {
    this.storage.activeTab.set(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  addPriority(inputEl: HTMLInputElement) {
    const val = inputEl.value.trim();
    if (!val) return;
    this.storage.addPriority(val, 'high');
    inputEl.value = '';
  }
}
