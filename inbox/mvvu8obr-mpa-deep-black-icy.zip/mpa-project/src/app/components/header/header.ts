import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StorageService } from '../../services/storage.service';
import { ThemeService } from '../../services/theme.service';
import { SectionTab } from '../../models/academic.models';

@Component({
  selector: 'app-header',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <header class="sticky top-0 z-30 bg-black transition-colors">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        
        <!-- Brand Wordmark -->
        <div class="flex items-center gap-3 shrink-0">
          <button 
            (click)="setTab('dashboard')"
            class="flex items-center gap-2.5 text-right group focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 rounded-lg p-1"
            title="رفتن به داشبورد">
            <div class="w-10 h-10 rounded-xl icy-glow flex items-center justify-center text-white group-hover:scale-105 transition-transform">
              <mat-icon class="!text-[22px]">ac_unit</mat-icon>
            </div>
            <div>
              <span class="text-lg font-extrabold tracking-tight text-slate-900 dark:text-white block leading-none">
                راه علیرضا
              </span>
              <span class="text-[11px] font-medium text-slate-500 dark:text-slate-400 mt-1 block">
                مسیر ارشد تا دکتری هوش مصنوعی
              </span>
            </div>
          </button>
        </div>

        <!-- Desktop Navigation Links -->
        <nav class="hidden lg:flex items-center gap-1 xl:gap-2">
          @for (item of navItems; track item.tab) {
            <button
              (click)="setTab(item.tab)"
              [class.bg-indigo-50]="storage.activeTab() === item.tab"
              [class.text-indigo-600]="storage.activeTab() === item.tab"
              [class.dark:bg-indigo-950/60]="storage.activeTab() === item.tab"
              [class.dark:text-indigo-400]="storage.activeTab() === item.tab"
              [class.text-slate-600]="storage.activeTab() !== item.tab"
              [class.dark:text-slate-300]="storage.activeTab() !== item.tab"
              class="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 transition-all whitespace-nowrap">
              <mat-icon class="!text-[18px]">{{ item.icon }}</mat-icon>
              <span>{{ item.label }}</span>
            </button>
          }
        </nav>

        <!-- Action Controls -->
        <div class="flex items-center gap-2 shrink-0">
          <!-- Search Trigger -->
          <button
            (click)="openSearch()"
            class="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            title="جستجوی سریع (Ctrl+K)">
            <mat-icon class="!text-[18px]">search</mat-icon>
            <span class="hidden sm:inline">جستجو...</span>
            <kbd class="hidden md:inline-block px-1.5 py-0.5 text-[10px] bg-white dark:bg-slate-900 rounded border border-slate-300 dark:border-slate-700 text-slate-400 font-mono">⌘K</kbd>
          </button>

          <!-- Bookmarks Filter Toggle -->
          <button
            (click)="toggleBookmarksOnly()"
            [class.bg-amber-100]="storage.filterBookmarksOnly()"
            [class.text-amber-800]="storage.filterBookmarksOnly()"
            [class.dark:bg-amber-950/50]="storage.filterBookmarksOnly()"
            [class.dark:text-amber-300]="storage.filterBookmarksOnly()"
            [class.text-slate-600]="!storage.filterBookmarksOnly()"
            [class.dark:text-slate-300]="!storage.filterBookmarksOnly()"
            class="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors relative"
            title="فقط نشان‌شده‌ها">
            <mat-icon class="!text-[20px]">{{ storage.filterBookmarksOnly() ? 'bookmark' : 'bookmark_border' }}</mat-icon>
            @if (storage.bookmarks().length > 0) {
              <span class="absolute top-1 right-1 w-4 h-4 bg-amber-500 text-white rounded-full text-[9px] font-bold flex items-center justify-center">
                {{ storage.bookmarks().length }}
              </span>
            }
          </button>

          <!-- Admin / Link Manager & Backup -->
          <button
            (click)="openAdmin()"
            class="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="مدیریت لینک‌ها و پشتیبان‌گیری">
            <mat-icon class="!text-[20px]">tune</mat-icon>
          </button>

          <!-- Dark/Light Theme Toggle -->
          <button
            (click)="theme.toggleTheme()"
            class="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="تغییر تم">
            <mat-icon class="!text-[20px]">{{ theme.isDarkMode() ? 'light_mode' : 'dark_mode' }}</mat-icon>
          </button>
        </div>

      </div>
    </header>
  `
})
export class Header {
  readonly storage = inject(StorageService);
  readonly theme = inject(ThemeService);

  readonly navItems: { tab: SectionTab; label: string; icon: string }[] = [
    { tab: 'dashboard', label: 'داشبورد علیرضا', icon: 'dashboard' },
    { tab: 'universities', label: 'دانشگاه‌ها', icon: 'account_balance' },
    { tab: 'resources', label: 'کتابخانه‌ها و منابع', icon: 'menu_book' },
    { tab: 'labs', label: 'مراکز تحقیقاتی', icon: 'biotech' },
    { tab: 'conferences', label: 'کنفرانس‌ها', icon: 'groups' },
    { tab: 'tools-skills', label: 'ابزارها و مهارت', icon: 'handyman' },
    { tab: 'calendar', label: 'تقویم ددلاین‌ها', icon: 'event' }
  ];

  setTab(tab: SectionTab) {
    this.storage.activeTab.set(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  openSearch() {
    this.storage.isSearchOpen.set(true);
  }

  openAdmin() {
    this.storage.isAdminOpen.set(true);
  }

  toggleBookmarksOnly() {
    this.storage.filterBookmarksOnly.update(v => !v);
  }
}
