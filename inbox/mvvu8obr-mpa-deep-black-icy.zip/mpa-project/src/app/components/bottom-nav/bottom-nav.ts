import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StorageService } from '../../services/storage.service';
import { SectionTab } from '../../models/academic.models';

@Component({
  selector: 'app-bottom-nav',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <!-- Mobile Bottom Navigation Bar -->
    <nav class="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-black">
      <div class="grid grid-cols-5 items-center h-16 max-w-md mx-auto px-2">
        
        <button
          (click)="setTab('dashboard')"
          [class.text-indigo-600]="storage.activeTab() === 'dashboard'"
          [class.dark:text-indigo-400]="storage.activeTab() === 'dashboard'"
          [class.text-slate-500]="storage.activeTab() !== 'dashboard'"
          [class.dark:text-slate-400]="storage.activeTab() !== 'dashboard'"
          class="flex flex-col items-center justify-center h-full min-h-[44px] min-w-[44px] transition-colors">
          <mat-icon class="!text-[22px]">dashboard</mat-icon>
          <span class="text-[10px] font-medium mt-0.5">داشبورد</span>
        </button>

        <button
          (click)="setTab('universities')"
          [class.text-indigo-600]="storage.activeTab() === 'universities'"
          [class.dark:text-indigo-400]="storage.activeTab() === 'universities'"
          [class.text-slate-500]="storage.activeTab() !== 'universities'"
          [class.dark:text-slate-400]="storage.activeTab() !== 'universities'"
          class="flex flex-col items-center justify-center h-full min-h-[44px] min-w-[44px] transition-colors">
          <mat-icon class="!text-[22px]">account_balance</mat-icon>
          <span class="text-[10px] font-medium mt-0.5">دانشگاه‌ها</span>
        </button>

        <button
          (click)="setTab('resources')"
          [class.text-indigo-600]="storage.activeTab() === 'resources'"
          [class.dark:text-indigo-400]="storage.activeTab() === 'resources'"
          [class.text-slate-500]="storage.activeTab() !== 'resources'"
          [class.dark:text-slate-400]="storage.activeTab() !== 'resources'"
          class="flex flex-col items-center justify-center h-full min-h-[44px] min-w-[44px] transition-colors">
          <mat-icon class="!text-[22px]">menu_book</mat-icon>
          <span class="text-[10px] font-medium mt-0.5">منابع علمی</span>
        </button>

        <button
          (click)="setTab('labs')"
          [class.text-indigo-600]="storage.activeTab() === 'labs'"
          [class.dark:text-indigo-400]="storage.activeTab() === 'labs'"
          [class.text-slate-500]="storage.activeTab() !== 'labs'"
          [class.dark:text-slate-400]="storage.activeTab() !== 'labs'"
          class="flex flex-col items-center justify-center h-full min-h-[44px] min-w-[44px] transition-colors">
          <mat-icon class="!text-[22px]">biotech</mat-icon>
          <span class="text-[10px] font-medium mt-0.5">آزمایشگاه</span>
        </button>

        <!-- More Menu Sheet Toggle -->
        <button
          (click)="toggleMoreMenu()"
          [class.text-indigo-600]="isMoreActive()"
          [class.dark:text-indigo-400]="isMoreActive()"
          [class.text-slate-500]="!isMoreActive()"
          [class.dark:text-slate-400]="!isMoreActive()"
          class="flex flex-col items-center justify-center h-full min-h-[44px] min-w-[44px] transition-colors relative">
          <mat-icon class="!text-[22px]">apps</mat-icon>
          <span class="text-[10px] font-medium mt-0.5">بیشتر</span>
        </button>

      </div>
    </nav>

    <!-- Mobile More Drawer -->
    @if (showMoreMenu()) {
      <div 
        role="presentation"
        (click)="closeMoreMenu()"
        class="lg:hidden fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end">
        <div 
          role="dialog"
          aria-modal="true"
          tabindex="-1"
          (click)="$event.stopPropagation()"
          (keydown.stop)="$event.stopPropagation()"
          class="w-full bg-white dark:bg-slate-900 rounded-t-3xl p-5 border-t border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
          
          <div class="w-12 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mb-2"></div>
          
          <div class="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
            <span class="text-sm font-bold text-slate-800 dark:text-slate-200">سایر بخش‌های همراه علمی</span>
            <button 
              (click)="closeMoreMenu()" 
              class="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
              <mat-icon class="!text-[20px]">close</mat-icon>
            </button>
          </div>

          <div class="grid grid-cols-3 gap-3 py-2">
            <button
              (click)="setTab('conferences'); closeMoreMenu()"
              class="flex flex-col items-center p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 border border-slate-200/60 dark:border-slate-700/60 transition-colors">
              <div class="w-10 h-10 rounded-lg bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mb-1.5">
                <mat-icon class="!text-[20px]">groups</mat-icon>
              </div>
              <span class="text-xs font-semibold text-slate-700 dark:text-slate-200 text-center">کنفرانس‌ها</span>
            </button>

            <button
              (click)="setTab('tools-skills'); closeMoreMenu()"
              class="flex flex-col items-center p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 border border-slate-200/60 dark:border-slate-700/60 transition-colors">
              <div class="w-10 h-10 rounded-lg bg-sky-100 dark:bg-sky-900/50 text-sky-600 dark:text-sky-400 flex items-center justify-center mb-1.5">
                <mat-icon class="!text-[20px]">handyman</mat-icon>
              </div>
              <span class="text-xs font-semibold text-slate-700 dark:text-slate-200 text-center">ابزار و مهارت</span>
            </button>

            <button
              (click)="setTab('calendar'); closeMoreMenu()"
              class="flex flex-col items-center p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 border border-slate-200/60 dark:border-slate-700/60 transition-colors">
              <div class="w-10 h-10 rounded-lg bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-1.5">
                <mat-icon class="!text-[20px]">event</mat-icon>
              </div>
              <span class="text-xs font-semibold text-slate-700 dark:text-slate-200 text-center">تقویم ددلاین</span>
            </button>
          </div>

          <div class="pt-2">
            <button
              (click)="storage.isAdminOpen.set(true); closeMoreMenu()"
              class="w-full py-2.5 px-4 rounded-xl text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 flex items-center justify-center gap-2">
              <mat-icon class="!text-[18px]">tune</mat-icon>
              <span>پشتیبان‌گیری و افزودن لینک سفارشی</span>
            </button>
          </div>

        </div>
      </div>
    }
  `
})
export class BottomNav {
  readonly storage = inject(StorageService);
  readonly showMoreMenu = signal<boolean>(false);

  isMoreActive(): boolean {
    const tab = this.storage.activeTab();
    return tab === 'conferences' || tab === 'tools-skills' || tab === 'calendar';
  }

  setTab(tab: SectionTab) {
    this.storage.activeTab.set(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  toggleMoreMenu() {
    this.showMoreMenu.update(v => !v);
  }

  closeMoreMenu() {
    this.showMoreMenu.set(false);
  }
}
