import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StorageService } from '../../services/storage.service';
import { CustomLink } from '../../models/academic.models';

@Component({
  selector: 'app-admin-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    @if (storage.isAdminOpen()) {
      <div 
        role="presentation"
        (click)="close()"
        class="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
        
        <div 
          role="dialog"
          aria-modal="true"
          (click)="$event.stopPropagation()"
          (keydown.stop)="$event.stopPropagation()"
          tabindex="-1"
          class="w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-150">
          
          <!-- Header -->
          <div class="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div class="flex items-center gap-2.5">
              <div class="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
                <mat-icon class="!text-[20px]">tune</mat-icon>
              </div>
              <div>
                <h3 class="text-sm font-bold text-slate-900 dark:text-white leading-tight">
                  مدیریت لینک‌ها و پشتیبان‌گیری
                </h3>
                <p class="text-xs text-slate-500 dark:text-slate-400">
                  به‌روزرسانی سریع، افزودن لینک‌های دلخواه و خروجی داده‌ها
                </p>
              </div>
            </div>

            <button
              (click)="close()"
              class="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
              <mat-icon class="!text-[20px]">close</mat-icon>
            </button>
          </div>

          <!-- Tabs inside Modal -->
          <div class="flex items-center gap-2 px-6 pt-3 border-b border-slate-100 dark:border-slate-800">
            <button
              (click)="subTab.set('add-link')"
              [class.border-indigo-600]="subTab() === 'add-link'"
              [class.text-indigo-600]="subTab() === 'add-link'"
              [class.dark:text-indigo-400]="subTab() === 'add-link'"
              [class.border-transparent]="subTab() !== 'add-link'"
              [class.text-slate-600]="subTab() !== 'add-link'"
              class="pb-2.5 px-2 text-xs font-bold border-b-2 transition-all">
              افزودن لینک سفارشی
            </button>
            <button
              (click)="subTab.set('custom-list')"
              [class.border-indigo-600]="subTab() === 'custom-list'"
              [class.text-indigo-600]="subTab() === 'custom-list'"
              [class.dark:text-indigo-400]="subTab() === 'custom-list'"
              [class.border-transparent]="subTab() !== 'custom-list'"
              [class.text-slate-600]="subTab() !== 'custom-list'"
              class="pb-2.5 px-2 text-xs font-bold border-b-2 transition-all">
              لینک‌های اختصاصی من ({{ storage.customLinks().length }})
            </button>
            <button
              (click)="subTab.set('backup')"
              [class.border-indigo-600]="subTab() === 'backup'"
              [class.text-indigo-600]="subTab() === 'backup'"
              [class.dark:text-indigo-400]="subTab() === 'backup'"
              [class.border-transparent]="subTab() !== 'backup'"
              [class.text-slate-600]="subTab() !== 'backup'"
              class="pb-2.5 px-2 text-xs font-bold border-b-2 transition-all">
              پشتیبان‌گیری (Export / Import)
            </button>
            <button
              (click)="subTab.set('profile')"
              [class.border-indigo-600]="subTab() === 'profile'"
              [class.text-indigo-600]="subTab() === 'profile'"
              [class.dark:text-indigo-400]="subTab() === 'profile'"
              [class.border-transparent]="subTab() !== 'profile'"
              [class.text-slate-600]="subTab() !== 'profile'"
              class="pb-2.5 px-2 text-xs font-bold border-b-2 transition-all">
              تنظیمات پروفایل
            </button>
          </div>

          <!-- Body -->
          <div class="p-6 overflow-y-auto space-y-4 max-h-[60vh]">
            
            <!-- SubTab: Add Link -->
            @if (subTab() === 'add-link') {
              <div class="space-y-3.5">
                <div>
                  <label for="admin-link-title" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    عنوان لینک یا دانشگاه / مرکز:
                  </label>
                  <input
                    #titleInput
                    id="admin-link-title"
                    type="text"
                    placeholder="مثال: پرتال پژوهش دانشگاه آزاد دزفول یا آزمایشگاه دکتر فلانی"
                    class="w-full px-3.5 py-2.5 rounded-xl text-xs sm:text-sm bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>

                <div>
                  <label for="admin-link-url" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    آدرس مستقیم (URL):
                  </label>
                  <input
                    #urlInput
                    id="admin-link-url"
                    type="url"
                    dir="ltr"
                    placeholder="https://..."
                    class="w-full px-3.5 py-2.5 rounded-xl text-xs sm:text-sm bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label for="admin-link-category" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      دسته‌بندی:
                    </label>
                    <select
                      #categorySelect
                      id="admin-link-category"
                      class="w-full px-3.5 py-2.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                      <option value="university">دانشگاه و پذیرش</option>
                      <option value="resource">کتابخانه و منبع علمی</option>
                      <option value="lab">آزمایشگاه پژوهشی</option>
                      <option value="conference">کنفرانس و کارگاه</option>
                      <option value="tool">ابزار کاربردی</option>
                      <option value="other">متفرقه</option>
                    </select>
                  </div>

                  <div>
                    <label for="admin-link-desc" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      توضیح کوتاه یا یادداشت:
                    </label>
                    <input
                      #descInput
                      id="admin-link-desc"
                      type="text"
                      placeholder="دلیل ذخیره یا کارایی برای علیرضا"
                      class="w-full px-3.5 py-2.5 rounded-xl text-xs bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                  </div>
                </div>

                @if (actionSuccess()) {
                  <div class="p-3 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs rounded-xl flex items-center gap-2">
                    <mat-icon class="!text-[18px]">check_circle</mat-icon>
                    <span>لینک با موفقیت ذخیره شد.</span>
                  </div>
                }

                <div class="pt-2">
                  <button
                    (click)="submitAddLink(titleInput, urlInput, categorySelect, descInput)"
                    class="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all shadow-md shadow-indigo-600/20 flex items-center justify-center gap-2">
                    <mat-icon class="!text-[18px]">add_link</mat-icon>
                    <span>افزودن به پایگاه لینک‌های علیرضا</span>
                  </button>
                </div>
              </div>
            }

            <!-- SubTab: Custom Links List -->
            @if (subTab() === 'custom-list') {
              @if (storage.customLinks().length === 0) {
                <div class="py-10 text-center space-y-2">
                  <mat-icon class="text-slate-400 !text-[32px]">link_off</mat-icon>
                  <p class="text-xs text-slate-500">هنوز لینک سفارشی اضافه نکرده‌اید.</p>
                  <button 
                    (click)="subTab.set('add-link')"
                    class="text-xs font-bold text-indigo-600 hover:underline">
                    اولین لینک خود را ثبت کنید
                  </button>
                </div>
              } @else {
                <div class="space-y-2">
                  @for (lnk of storage.customLinks(); track lnk.id) {
                    <div class="p-3 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 bg-slate-50/50 dark:bg-slate-950/40">
                      <div class="space-y-0.5">
                        <div class="flex items-center gap-2">
                          <span class="text-xs font-bold text-slate-900 dark:text-white">{{ lnk.title }}</span>
                          <span class="text-[10px] px-2 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                            {{ lnk.category }}
                          </span>
                        </div>
                        <p class="text-xs text-slate-500 dark:text-slate-400">{{ lnk.description || lnk.url }}</p>
                      </div>

                      <div class="flex items-center gap-2 shrink-0">
                        <a
                          [href]="lnk.url"
                          target="_blank"
                          rel="noopener noreferrer"
                          class="p-1.5 rounded-lg text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/40"
                          title="باز کردن">
                          <mat-icon class="!text-[18px]">open_in_new</mat-icon>
                        </a>
                        <button
                          (click)="storage.deleteCustomLink(lnk.id)"
                          class="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                          title="حذف">
                          <mat-icon class="!text-[18px]">delete</mat-icon>
                        </button>
                      </div>
                    </div>
                  }
                </div>
              }
            }

            <!-- SubTab: Backup Export/Import -->
            @if (subTab() === 'backup') {
              <div class="space-y-4">
                <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/50 border border-slate-200 dark:border-slate-800 space-y-2">
                  <h4 class="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <mat-icon class="!text-[18px] text-indigo-600">download</mat-icon>
                    <span>تهیه نسخه پشتیبان (Export)</span>
                  </h4>
                  <p class="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    یک خروجی استاندارد JSON از تمام بوکمارک‌ها، یادداشت‌های کنار لینک‌ها، تسک‌های هفتگی، درصد پیشرفت مهارت‌ها و رویدادهای تقویم علیرضا تهیه می‌کند.
                  </p>
                  <button
                    (click)="downloadBackup()"
                    class="px-4 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 transition-colors flex items-center gap-1.5">
                    <mat-icon class="!text-[16px]">file_download</mat-icon>
                    <span>دانلود فایل پشتیبان (backup-alireza.json)</span>
                  </button>
                </div>

                <div class="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/50 border border-slate-200 dark:border-slate-800 space-y-2">
                  <h4 class="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <mat-icon class="!text-[18px] text-sky-600">upload</mat-icon>
                    <span>بازیابی نسخه پشتیبان (Import)</span>
                  </h4>
                  <p class="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    متن فایل پشتیبان قبلی خود را در کادر زیر قرار دهید و دکمه بازیابی را بزنید:
                  </p>
                  <textarea
                    #importTextarea
                    rows="3"
                    placeholder="کد JSON پشتیبان را اینجا جای‌گذاری کنید..."
                    class="w-full p-2.5 rounded-xl text-xs font-mono bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200"></textarea>
                  
                  @if (importStatus()) {
                    <p [class.text-emerald-600]="importStatus()?.success" [class.text-rose-600]="!importStatus()?.success" class="text-xs font-medium">
                      {{ importStatus()?.message }}
                    </p>
                  }

                  <button
                    (click)="performImport(importTextarea.value)"
                    class="px-4 py-2 rounded-xl text-xs font-bold text-slate-700 dark:text-slate-200 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors flex items-center gap-1.5">
                    <mat-icon class="!text-[16px]">restore</mat-icon>
                    <span>بازیابی داده‌ها</span>
                  </button>
                </div>
              </div>
            }

            <!-- SubTab: Profile Settings -->
            @if (subTab() === 'profile') {
              <div class="space-y-3">
                <div>
                  <label for="profile-name-input" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">نام و عنوان:</label>
                  <input
                    #nameInput
                    id="profile-name-input"
                    type="text"
                    [value]="storage.profile().name"
                    class="w-full px-3.5 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100" />
                </div>

                <div>
                  <label for="profile-uni-input" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">دانشگاه فعلی و شهر:</label>
                  <input
                    #uniInput
                    id="profile-uni-input"
                    type="text"
                    [value]="storage.profile().university"
                    class="w-full px-3.5 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100" />
                </div>

                <div>
                  <label for="profile-topic-input" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">موضوع پایان‌نامه ارشد:</label>
                  <textarea
                    #topicInput
                    id="profile-topic-input"
                    rows="2"
                    [value]="storage.profile().thesisTopic"
                    class="w-full px-3.5 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100"></textarea>
                </div>

                <div>
                  <label for="profile-timeline-input" class="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">افق زمانی و هدف دکتری:</label>
                  <input
                    #timelineInput
                    id="profile-timeline-input"
                    type="text"
                    [value]="storage.profile().targetTimeline"
                    class="w-full px-3.5 py-2 rounded-xl text-xs bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100" />
                </div>

                <div class="pt-2">
                  <button
                    (click)="saveProfile(nameInput.value, uniInput.value, topicInput.value, timelineInput.value)"
                    class="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all flex items-center justify-center gap-2">
                    <mat-icon class="!text-[18px]">save</mat-icon>
                    <span>ذخیره تغییرات مشخصات</span>
                  </button>
                </div>
              </div>
            }

          </div>

        </div>
      </div>
    }
  `
})
export class AdminModal {
  readonly storage = inject(StorageService);
  readonly subTab = signal<'add-link' | 'custom-list' | 'backup' | 'profile'>('add-link');
  readonly actionSuccess = signal<boolean>(false);
  readonly importStatus = signal<{ success: boolean; message: string } | null>(null);

  close() {
    this.storage.isAdminOpen.set(false);
  }

  submitAddLink(
    titleEl: HTMLInputElement, 
    urlEl: HTMLInputElement, 
    catEl: HTMLSelectElement, 
    descEl: HTMLInputElement
  ) {
    const title = titleEl.value.trim();
    const url = urlEl.value.trim();
    const category = catEl.value as CustomLink['category'];
    const description = descEl.value.trim();

    if (!title || !url) return;

    this.storage.addCustomLink({
      title,
      url,
      category,
      description
    });

    titleEl.value = '';
    urlEl.value = '';
    descEl.value = '';

    this.actionSuccess.set(true);
    setTimeout(() => this.actionSuccess.set(false), 2500);
  }

  downloadBackup() {
    const jsonStr = this.storage.exportData();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `alireza-academic-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  performImport(jsonStr: string) {
    if (!jsonStr.trim()) return;
    const ok = this.storage.importData(jsonStr);
    if (ok) {
      this.importStatus.set({ success: true, message: 'اطلاعات با موفقیت بازیابی شد.' });
    } else {
      this.importStatus.set({ success: false, message: 'خطا: فرمت فایل نامعتبر است.' });
    }
  }

  saveProfile(name: string, uni: string, topic: string, timeline: string) {
    this.storage.updateProfile({
      name,
      university: uni,
      thesisTopic: topic,
      targetTimeline: timeline
    });
    this.close();
  }
}
