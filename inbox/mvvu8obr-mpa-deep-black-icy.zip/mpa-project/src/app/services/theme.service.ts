import { Injectable, signal, effect } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ThemeService {
  readonly isDarkMode = signal<boolean>(true);

  constructor() {
    if (typeof window !== 'undefined') {
      // Force deep black theme by default for MPA icy version
      this.isDarkMode.set(true);

      this.applyTheme(true);

      effect(() => {
        const dark = this.isDarkMode();
        this.applyTheme(dark);
        try {
          localStorage.setItem('alireza_theme', dark ? 'dark' : 'light');
        } catch { /* ignore */ }
      });
    }
  }

  toggleTheme() {
    this.isDarkMode.update(curr => !curr);
  }

  private applyTheme(isDark: boolean) {
    if (typeof document === 'undefined') return;
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }
}
