import { Injectable, signal, computed, effect, inject } from '@angular/core';
import { 
  SectionTab, 
  WeeklyPriority, 
  SkillItem, 
  CalendarEvent, 
  CustomLink, 
  UserProfile 
} from '../models/academic.models';
import { AcademicDataService } from './academic-data.service';

const STORAGE_KEYS = {
  BOOKMARKS: 'alireza_path_bookmarks',
  NOTES: 'alireza_path_notes',
  PRIORITIES: 'alireza_path_priorities',
  SKILLS: 'alireza_path_skills',
  CALENDAR_EVENTS: 'alireza_path_events',
  CUSTOM_LINKS: 'alireza_path_custom_links',
  PROFILE: 'alireza_path_profile'
};

@Injectable({
  providedIn: 'root'
})
export class StorageService {
  readonly activeTab = signal<SectionTab>('dashboard');
  readonly isSearchOpen = signal<boolean>(false);
  readonly isAdminOpen = signal<boolean>(false);
  readonly activeNoteItem = signal<{ id: string; title: string; categoryName: string } | null>(null);

  // Filter state
  readonly filterBookmarksOnly = signal<boolean>(false);
  readonly globalSearchTerm = signal<string>('');

  // Persistent States
  readonly bookmarks = signal<string[]>([]);
  readonly personalNotes = signal<Record<string, string>>({});
  readonly weeklyPriorities = signal<WeeklyPriority[]>([]);
  readonly skills = signal<SkillItem[]>([]);
  readonly customEvents = signal<CalendarEvent[]>([]);
  readonly customLinks = signal<CustomLink[]>([]);
  readonly profile = signal<UserProfile>({
    name: 'علیرضا',
    title: 'دانشجوی کارشناسی ارشد هوش مصنوعی',
    university: 'دانشگاه آزاد اسلامی واحد دزفول',
    city: 'دزفول / خوزستان',
    targetDegree: 'دکتری تخصصی (PhD) در هوش مصنوعی و یادگیری عمیق',
    thesisTopic: 'بهبود قابلیت تعمیم و پایداری در مدل‌های یادگیری عمیق با استفاده از شبکه‌های ترنسفورمر',
    targetTimeline: 'دفاع ارشد: تابستان ۱۴۰۶ | ورود به دکتری: پاییز ۱۴۰۶ / Fall 2027',
    advisorContactTarget: 30,
    papersTarget: 2
  });

  // Computed
  readonly completedSkillsCount = computed(() => {
    return this.skills().filter(s => s.completed).length;
  });

  readonly totalSkillsCount = computed(() => {
    return this.skills().length;
  });

  readonly skillsProgressPercent = computed(() => {
    const total = this.totalSkillsCount();
    if (total === 0) return 0;
    return Math.round((this.completedSkillsCount() / total) * 100);
  });

  readonly allEvents = computed(() => {
    const defaultEvents = this.academicData.defaultDeadlines;
    const userEvents = this.customEvents();
    return [...userEvents, ...defaultEvents].sort((a, b) => {
      return new Date(a.deadlineDate).getTime() - new Date(b.deadlineDate).getTime();
    });
  });

  readonly upcomingEvents = computed(() => {
    const now = new Date();
    // Events that are today or in future, or within recent past
    return this.allEvents().filter(e => {
      const eventTime = new Date(e.deadlineDate).getTime();
      return eventTime >= now.getTime() - (24 * 60 * 60 * 1000); // from today onwards
    }).slice(0, 5);
  });

  private readonly academicData = inject(AcademicDataService);

  constructor() {
    this.loadFromStorage();

    // Auto-save effects (runs only in browser context safely)
    if (typeof window !== 'undefined' && window.localStorage) {
      effect(() => {
        try {
          localStorage.setItem(STORAGE_KEYS.BOOKMARKS, JSON.stringify(this.bookmarks()));
        } catch { /* ignore */ }
      });

      effect(() => {
        try {
          localStorage.setItem(STORAGE_KEYS.NOTES, JSON.stringify(this.personalNotes()));
        } catch { /* ignore */ }
      });

      effect(() => {
        try {
          localStorage.setItem(STORAGE_KEYS.PRIORITIES, JSON.stringify(this.weeklyPriorities()));
        } catch { /* ignore */ }
      });

      effect(() => {
        try {
          localStorage.setItem(STORAGE_KEYS.SKILLS, JSON.stringify(this.skills()));
        } catch { /* ignore */ }
      });

      effect(() => {
        try {
          localStorage.setItem(STORAGE_KEYS.CALENDAR_EVENTS, JSON.stringify(this.customEvents()));
        } catch { /* ignore */ }
      });

      effect(() => {
        try {
          localStorage.setItem(STORAGE_KEYS.CUSTOM_LINKS, JSON.stringify(this.customLinks()));
        } catch { /* ignore */ }
      });

      effect(() => {
        try {
          localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(this.profile()));
        } catch { /* ignore */ }
      });
    }
  }

  private loadFromStorage() {
    if (typeof window === 'undefined' || !window.localStorage) {
      this.skills.set(this.academicData.defaultSkills);
      this.weeklyPriorities.set(this.academicData.defaultPriorities);
      return;
    }

    try {
      const savedBookmarks = localStorage.getItem(STORAGE_KEYS.BOOKMARKS);
      if (savedBookmarks) {
        this.bookmarks.set(JSON.parse(savedBookmarks));
      }

      const savedNotes = localStorage.getItem(STORAGE_KEYS.NOTES);
      if (savedNotes) {
        this.personalNotes.set(JSON.parse(savedNotes));
      }

      const savedPriorities = localStorage.getItem(STORAGE_KEYS.PRIORITIES);
      if (savedPriorities) {
        this.weeklyPriorities.set(JSON.parse(savedPriorities));
      } else {
        this.weeklyPriorities.set(this.academicData.defaultPriorities);
      }

      const savedSkills = localStorage.getItem(STORAGE_KEYS.SKILLS);
      if (savedSkills) {
        this.skills.set(JSON.parse(savedSkills));
      } else {
        this.skills.set(this.academicData.defaultSkills);
      }

      const savedEvents = localStorage.getItem(STORAGE_KEYS.CALENDAR_EVENTS);
      if (savedEvents) {
        this.customEvents.set(JSON.parse(savedEvents));
      }

      const savedCustomLinks = localStorage.getItem(STORAGE_KEYS.CUSTOM_LINKS);
      if (savedCustomLinks) {
        this.customLinks.set(JSON.parse(savedCustomLinks));
      }

      const savedProfile = localStorage.getItem(STORAGE_KEYS.PROFILE);
      if (savedProfile) {
        this.profile.set(JSON.parse(savedProfile));
      }
    } catch (e) {
      console.warn('Could not read from localStorage', e);
      this.skills.set(this.academicData.defaultSkills);
      this.weeklyPriorities.set(this.academicData.defaultPriorities);
    }
  }

  // Bookmarks
  isBookmarked(id: string): boolean {
    return this.bookmarks().includes(id);
  }

  toggleBookmark(id: string) {
    this.bookmarks.update(current => {
      if (current.includes(id)) {
        return current.filter(item => item !== id);
      } else {
        return [...current, id];
      }
    });
  }

  // Personal Notes
  getNote(id: string): string {
    return this.personalNotes()[id] || '';
  }

  hasNote(id: string): boolean {
    const note = this.personalNotes()[id];
    return !!(note && note.trim().length > 0);
  }

  saveNote(id: string, text: string) {
    this.personalNotes.update(current => {
      const updated = { ...current };
      if (!text || text.trim() === '') {
        delete updated[id];
      } else {
        updated[id] = text.trim();
      }
      return updated;
    });
  }

  openNoteModal(id: string, title: string, categoryName: string) {
    this.activeNoteItem.set({ id, title, categoryName });
  }

  closeNoteModal() {
    this.activeNoteItem.set(null);
  }

  // Priorities
  togglePriority(id: string) {
    this.weeklyPriorities.update(items =>
      items.map(p => p.id === id ? { ...p, done: !p.done } : p)
    );
  }

  addPriority(text: string, priority: 'high' | 'medium' | 'low' = 'medium') {
    if (!text.trim()) return;
    const newPri: WeeklyPriority = {
      id: 'pri-' + Date.now(),
      text: text.trim(),
      done: false,
      priority
    };
    this.weeklyPriorities.update(items => [newPri, ...items]);
  }

  deletePriority(id: string) {
    this.weeklyPriorities.update(items => items.filter(p => p.id !== id));
  }

  // Skills
  toggleSkill(id: string) {
    this.skills.update(items =>
      items.map(s => s.id === id ? { ...s, completed: !s.completed } : s)
    );
  }

  // Calendar
  addCustomEvent(event: Omit<CalendarEvent, 'id' | 'isCustom'>) {
    const newEvent: CalendarEvent = {
      ...event,
      id: 'event-' + Date.now(),
      isCustom: true
    };
    this.customEvents.update(items => [newEvent, ...items]);
  }

  deleteCustomEvent(id: string) {
    this.customEvents.update(items => items.filter(e => e.id !== id));
  }

  // Custom Links
  addCustomLink(link: Omit<CustomLink, 'id' | 'createdAt'>) {
    const newLink: CustomLink = {
      ...link,
      id: 'link-' + Date.now(),
      createdAt: new Date().toISOString()
    };
    this.customLinks.update(items => [newLink, ...items]);
  }

  deleteCustomLink(id: string) {
    this.customLinks.update(items => items.filter(l => l.id !== id));
  }

  // Profile update
  updateProfile(partial: Partial<UserProfile>) {
    this.profile.update(p => ({ ...p, ...partial }));
  }

  // Export / Import
  exportData(): string {
    const fullState = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      user: this.profile(),
      bookmarks: this.bookmarks(),
      notes: this.personalNotes(),
      priorities: this.weeklyPriorities(),
      skills: this.skills(),
      customEvents: this.customEvents(),
      customLinks: this.customLinks()
    };
    return JSON.stringify(fullState, null, 2);
  }

  importData(jsonString: string): boolean {
    try {
      const parsed = JSON.parse(jsonString);
      if (parsed.bookmarks) this.bookmarks.set(parsed.bookmarks);
      if (parsed.notes) this.personalNotes.set(parsed.notes);
      if (parsed.priorities) this.weeklyPriorities.set(parsed.priorities);
      if (parsed.skills) this.skills.set(parsed.skills);
      if (parsed.customEvents) this.customEvents.set(parsed.customEvents);
      if (parsed.customLinks) this.customLinks.set(parsed.customLinks);
      if (parsed.user) this.profile.set(parsed.user);
      return true;
    } catch (e) {
      console.error('Failed to import json', e);
      return false;
    }
  }

  resetToDefaults() {
    this.skills.set(this.academicData.defaultSkills);
    this.weeklyPriorities.set(this.academicData.defaultPriorities);
    this.customEvents.set([]);
    this.customLinks.set([]);
    this.bookmarks.set([]);
    this.personalNotes.set({});
  }
}
