import { Injectable } from '@angular/core';
import { 
  University, 
  AcademicResource, 
  ResearchLab, 
  ConferenceItem, 
  AcademicTool, 
  SkillItem, 
  CalendarEvent 
} from '../models/academic.models';

@Injectable({
  providedIn: 'root'
})
export class AcademicDataService {

  readonly universities: University[] = [
    // --- IRAN UNIVERSITIES ---
    {
      id: 'sharif-ai',
      name: 'دانشگاه صنعتی شریف',
      englishName: 'Sharif University of Technology (SUT)',
      region: 'iran',
      country: 'ایران',
      city: 'تهران',
      rankingText: 'رتبه ۱ مهندسی و علوم کامپیوتر ایران (QS: ~۳۵۰)',
      officialUrl: 'https://www.sharif.edu',
      admissionUrl: 'https://grad.sharif.ir',
      departments: ['دانشکده مهندسی کامپیوتر', 'پژوهشکده هوش مصنوعی و علوم داده'],
      specializations: ['یادگیری عمیق', 'بینایی ماشین', 'سیستم‌های هوشمند چندعامله', 'پردازش زبان طبیعی', 'بیوانفورماتیک'],
      admissionRequirements: [
        'کسب رتبه تک‌رقمی یا دو‌رقمی برتر در آزمون نیمه‌متمرکز دکتری سازمان سنجش (کد ۱۱۰۴)',
        'پذیرش بدون آزمون سهمیه استعداد درخشان (معدل بالای ۱۷ ارشد + حداقل ۱ مقاله علمی پژوهشی یا ISI معتبر)',
        'قبولی در مصاحبه تخصصی علمی، بررسی پایان‌نامه ارشد، سابقه تدریس و حل تمرین',
        'مدرک زبان انگلیسی معتبر با نمره حدنصاب (MSRT حداقل ۶۰، تولیمو حداقل ۵۱۰، آیلتس حداقل ۶ یا تافل حداقل ۷۵)'
      ],
      deadlinesSummary: 'ثبت‌نام سنجش: آبان/آذر | مصاحبه: خرداد و تیر | استعداد درخشان: اسفند تا فروردین',
      examType: 'آزمون دکتری سراسری سنجش + استعداد درخشان',
      capacityInfo: 'ظرفیت دکتری روزانه هوش مصنوعی: حدود ۶ تا ۱۰ نفر در سال',
      facultyMembers: [
        { name: 'دکتر حمیدرضا ربیعی', title: 'استاد تمام', specialty: 'هوش مصنوعی، بیوانفورماتیک و شبکه‌های پیچیده', profileUrl: 'http://sharif.edu/~rabiee', scholarUrl: 'https://scholar.google.com/citations?user=G6Kq-bYAAAAJ' },
        { name: 'دکتر محمدحسین رهبان', title: 'استادیار', specialty: 'یادگیری ماشین، بینایی و بازنمایی عمیق', profileUrl: 'http://sharif.edu/~rohban', scholarUrl: 'https://scholar.google.com/citations?user=Y9bWvIEAAAAJ' },
        { name: 'دکتر بیژن وثوقی وحدت', title: 'استاد تمام', specialty: 'پردازش سیگنال‌های زیستی و یادگیری الگو', profileUrl: 'http://sharif.edu/~vossoughi' },
        { name: 'دکتر شمس‌الدین مفیدی', title: 'دانشیار', specialty: 'هوش مصنوعی و یادگیری ماشین' }
      ],
      tags: ['شریف', 'تهران', 'مهندسی کامپیوتر', 'قطب هوش مصنوعی']
    },
    {
      id: 'tehran-ai',
      name: 'دانشگاه تهران',
      englishName: 'University of Tehran (UT)',
      region: 'iran',
      country: 'ایران',
      city: 'تهران',
      rankingText: 'دانشگاه مادر کشور و رتبه برتر جامع ایران',
      officialUrl: 'https://ut.ac.ir',
      admissionUrl: 'https://academics.ut.ac.ir/fa/phd',
      departments: ['دانشکده مهندسی برق و کامپیوتر', 'پردیس دانشکده‌های فنی', 'مرکز نوآوری هوش مصنوعی'],
      specializations: ['پردازش زبان طبیعی (NLP)', 'بینایی کامپیوتر', 'شناخت محاسباتی', 'داده‌کاوی و وب‌کاوی'],
      admissionRequirements: [
        'آزمون سراسری دکتری سازمان سنجش و کسب تراز لازم برای مرحله ارزیابی دانشگاه',
        'آیین‌نامه پذیرش دکتری بدون آزمون استعدادهای درخشان دانشگاه تهران',
        'نمره آزمون زبان عمومی دانشگاه تهران (UTEPT) با حداقل نمره ۶۰، یا MSRT/IELTS/TOEFL',
        'ارائه پروپوزال اولیه پژوهشی و ارزیابی کیفیت پایان‌نامه کارشناسی ارشد'
      ],
      deadlinesSummary: 'اعلام فراخوان استعداد درخشان: اسفند | مصاحبه مرحله دوم: تیرماه',
      examType: 'سنجش دکتری + استعداد درخشان پردیس فنی',
      capacityInfo: 'ظرفیت سالانه دکتری تخصصی: ۸ تا ۱۲ نفر',
      facultyMembers: [
        { name: 'دکتر هشام فیلی', title: 'دانشیار', specialty: 'پردازش زبان طبیعی، خط و زبان فارسی، یادگیری ماشین', scholarUrl: 'https://scholar.google.com/citations?user=P_R31XoAAAAJ' },
        { name: 'دکتر مسعود رحگوی', title: 'استاد تمام', specialty: 'داده‌کاوی، سیستم‌های توصیه‌گر و بازیابی اطلاعات' },
        { name: 'دکتر آزاده شاکری', title: 'استادیار', specialty: 'یادگیری ماشین گراف، نظریه یادگیری آماری' }
      ],
      tags: ['دانشگاه تهران', 'فنی تهران', 'NLP', 'شناخت محاسباتی']
    },
    {
      id: 'amirkabir-ai',
      name: 'دانشگاه صنعتی امیرکبیر (پلی‌تکنیک تهران)',
      englishName: 'Amirkabir University of Technology (AUT)',
      region: 'iran',
      country: 'ایران',
      city: 'تهران',
      rankingText: 'پلی‌تکنیک برتر ایران با سنت دیرینه در هوش محاسباتی',
      officialUrl: 'https://aut.ac.ir',
      admissionUrl: 'https://pgrad.aut.ac.ir',
      departments: ['دانشکده مهندسی کامپیوتر', 'پژوهشکده فناوری اطلاعات'],
      specializations: ['هوش محاسباتی', 'رباتیک و سیستم‌های خودمختار', 'محاسبات نرم و تکاملی', 'یادگیری تقویتی'],
      admissionRequirements: [
        'کنکور نیمه‌متمرکز سازمان سنجش',
        'مصاحبه تخصصی با تمرکز بر توانایی کدنویسی پژوهشی، الگوریتم‌ها و زمینه پایان‌نامه ارشد',
        'رزومه مقالات معتبر کنفرانسی و ژورنالی (ترجیحاً Scopus / ISI)',
        'حداقل نمره قبولی در آزمون زبان مورد تایید دانشگاه'
      ],
      deadlinesSummary: 'فراخوان استعداد درخشان: دی تا بهمن | مصاحبه: خرداد',
      examType: 'آزمون سنجش + استعداد درخشان',
      capacityInfo: 'ظرفیت دکتری: ۶ الی ۸ نفر',
      facultyMembers: [
        { name: 'دکتر مهدی خلیلی', title: 'استاد', specialty: 'سیستم‌های هوشمند و یادگیری ماشین' },
        { name: 'دکتر فرزان مجیدفر', title: 'دانشیار', specialty: 'محاسبات تکاملی، بهینه‌سازی و بینایی' },
        { name: 'دکتر مسعود صبایی', title: 'استاد', specialty: 'شبکه و محاسبات توزیع‌شده' }
      ],
      tags: ['امیرکبیر', 'پلی‌تکنیک', 'رباتیک', 'یادگیری ماشین']
    },
    {
      id: 'iust-ai',
      name: 'دانشگاه علم و صنعت ایران',
      englishName: 'Iran University of Science and Technology (IUST)',
      region: 'iran',
      country: 'ایران',
      city: 'تهران',
      rankingText: 'دانشگاه مهندسی مادر با قطب علمی پردازش داده‌های حجیم',
      officialUrl: 'https://www.iust.ac.ir',
      admissionUrl: 'https://pga.iust.ac.ir',
      departments: ['دانشکده مهندسی کامپیوتر'],
      specializations: ['سیستم‌های هوشمند و پردازش متن', 'کلان‌داده (Big Data)', 'بینایی ماشین', 'سیستم‌های چندرسانه‌ای'],
      admissionRequirements: [
        'آزمون سنجش + مصاحبه مرحله دوم',
        'پذیرش استعداد درخشان بر اساس رتبه‌بندی امتیازهای آموزشی و پژوهشی',
        'گواهی مدرک زبان (MSRT, تولیمو یا آیلتس)'
      ],
      deadlinesSummary: 'ثبت‌نام مصاحبه: خرداد | اعلام نتایج: شهریور',
      examType: 'سنجش و بدون آزمون استعداد درخشان',
      capacityInfo: 'ظرفیت: حدود ۶ نفر',
      facultyMembers: [
        { name: 'دکتر بهروز مینایی بیدگلی', title: 'استاد تمام', specialty: 'داده‌کاوی، هوش مصنوعی، متن‌کاوی و وب‌کاوی' },
        { name: 'دکتر ناصر مزینی', title: 'دانشیار', specialty: 'عوامل هوشمند و شبکه‌های عصبی' }
      ],
      tags: ['علم و صنعت', 'تهران', 'داده‌کاوی', 'سیستم‌های چندعامله']
    },
    {
      id: 'modares-ai',
      name: 'دانشگاه تربیت مدرس',
      englishName: 'Tarbiat Modares University (TMU)',
      region: 'iran',
      country: 'ایران',
      city: 'تهران',
      rankingText: 'تنها دانشگاه صرفاً تحصیلات تکمیلی جامع ایران',
      officialUrl: 'https://www.modares.ac.ir',
      admissionUrl: 'https://www.modares.ac.ir/admission',
      departments: ['دانشکده مهندسی برق و کامپیوتر', 'دانشکده علوم ریاضی'],
      specializations: ['هوش مصنوعی و یادگیری ماشین', 'بیوانفورماتیک محاسباتی', 'پردازش صوت و تصویر'],
      admissionRequirements: [
        'آزمون ورودی دکتری سنجش',
        'مصاحبه تخصصی علمی و بررسی مقالات پژوهشی چاپ‌شده در طول ارشد',
        'حدنصاب آزمون زبان دانشگاه تربیت مدرس یا آزمون‌های ملی'
      ],
      deadlinesSummary: 'فراخوان استعداد درخشان: بهمن و اسفند | مصاحبه: تیرماه',
      examType: 'سنجش و فراخوان استعداد درخشان اختصاصی',
      capacityInfo: 'ظرفیت: ۴ تا ۶ نفر',
      facultyMembers: [
        { name: 'دکتر بابک ناصرحجتی', title: 'استاد', specialty: 'هوش مصنوعی و شبکه‌های عصبی' },
        { name: 'دکتر احسان نظیفی', title: 'دانشیار', specialty: 'پردازش تصویر و سیستم‌های هوشمند' }
      ],
      tags: ['تربیت مدرس', 'تحصیلات تکمیلی', 'بیوانفورماتیک']
    },
    {
      id: 'iut-ai',
      name: 'دانشگاه صنعتی اصفهان',
      englishName: 'Isfahan University of Technology (IUT)',
      region: 'iran',
      country: 'ایران',
      city: 'اصفهان',
      rankingText: 'قطب دانشگاه‌های مهندسی مرکز و جنوب کشور',
      officialUrl: 'https://iut.ac.ir',
      admissionUrl: 'https://phd.iut.ac.ir',
      departments: ['دانشکده مهندسی برق و کامپیوتر'],
      specializations: ['هوش محاسباتی', 'پردازش تصویر پیشرفته', 'سیستم‌های نهفته هوشمند'],
      admissionRequirements: ['آزمون سنجش', 'بررسی سوابق ارشد و مقالات', 'آزمون زبان'],
      deadlinesSummary: 'مصاحبه: خرداد و تیر',
      examType: 'سنجش + استعداد درخشان',
      capacityInfo: 'ظرفیت: ۵ نفر',
      facultyMembers: [
        { name: 'دکتر حمید بهرامی', title: 'استاد', specialty: 'هوش مصنوعی و یادگیری ماشین' }
      ],
      tags: ['صنعتی اصفهان', 'اصفهان', 'پردازش تصویر']
    },
    {
      id: 'shiraz-ai',
      name: 'دانشگاه شیراز',
      englishName: 'Shiraz University',
      region: 'iran',
      country: 'ایران',
      city: 'شیراز',
      rankingText: 'قطب علمی جنوب کشور و دانشگاه برجسته جامع',
      officialUrl: 'https://shirazu.ac.ir',
      admissionUrl: 'https://grd.shirazu.ac.ir',
      departments: ['دانشکده مهندسی برق و کامپیوتر'],
      specializations: ['هوش مصنوعی', 'پردازش الگو', 'بینایی ماشین'],
      admissionRequirements: ['کنکور سنجش دکتری', 'مصاحبه علمی', 'تعهد تمام‌وقت بودن'],
      deadlinesSummary: 'مصاحبه: تیرماه',
      examType: 'سنجش و استعداد درخشان',
      capacityInfo: 'ظرفیت: ۴ تا ۶ نفر',
      facultyMembers: [
        { name: 'دکتر علی حمزه', title: 'استاد', specialty: 'داده‌کاوی، الگوریتم‌های ژنتیک و بازشناسی الگو' }
      ],
      tags: ['شیراز', 'جنوب', 'بازشناسی الگو']
    },
    {
      id: 'ferdowsi-ai',
      name: 'دانشگاه فردوسی مشهد',
      englishName: 'Ferdowsi University of Mashhad (FUM)',
      region: 'iran',
      country: 'ایران',
      city: 'مشهد',
      rankingText: 'بزرگترین دانشگاه شرق کشور با مرکز پردازش فوق سریع',
      officialUrl: 'https://um.ac.ir',
      admissionUrl: 'https://pga.um.ac.ir',
      departments: ['دانشکده مهندسی کامپیوتر'],
      specializations: ['سیستم‌های هوشمند', 'پردازش زبان طبیعی', 'شبکه‌های پیچیده'],
      admissionRequirements: ['آزمون سنجش دکتری', 'مصاحبه علمی', 'آزمون زبان TELP یا MSRT'],
      deadlinesSummary: 'مصاحبه: تیرماه',
      examType: 'سنجش و استعداد درخشان',
      capacityInfo: 'ظرفیت: ۵ نفر',
      facultyMembers: [
        { name: 'دکتر احسان عسگری', title: 'استادیار', specialty: 'بیوانفورماتیک و هوش مصنوعی' }
      ],
      tags: ['مشهد', 'فردوسی', 'زبان طبیعی']
    },
    {
      id: 'srbiau-ai',
      name: 'دانشگاه آزاد اسلامی - واحد علوم و تحقیقات تهران',
      englishName: 'Islamic Azad University, Science and Research Branch (SRBIAU)',
      region: 'iran',
      country: 'ایران',
      city: 'تهران',
      rankingText: 'برترین واحد تحصیلات تکمیلی دانشگاه آزاد با آزمایشگاه‌های مجهز دکتری',
      officialUrl: 'https://srbiau.ac.ir',
      admissionUrl: 'https://azmoon.iau.ir',
      departments: ['دانشکده مهندسی کامپیوتر و هوش مصنوعی'],
      specializations: ['هوش مصنوعی و رباتیک', 'محاسبات نرم', 'سیستم‌های تصمیم‌یار هوشمند', 'یادگیری ماشین'],
      admissionRequirements: [
        'ثبت‌نام در آزمون اختصاصی دکتری تخصصی دانشگاه آزاد (سامانه azmoon.iau.ir)',
        'پذیرش استعداد درخشان فارغ‌التحصیلان ارشد دانشگاه آزاد (شرط معدل ارشد بالای ۱۷.۵ + امتیاز پایان‌نامه درجه عالی)',
        'مصاحبه تخصصی حضوری یا متمرکز دکتری دانشگاه آزاد اسلامی',
        'مدرک زبان انگلیسی عمومی EPT دانشگاه آزاد با نماه قبولی بالای ۵۰، یا MSRT/TOLIMO'
      ],
      deadlinesSummary: 'ثبت‌نام آزمون: آبان تا آذر | مصاحبه: تیر تا مرداد',
      examType: 'آزمون اختصاصی دکتری دانشگاه آزاد + سهمیه استعداد درخشان آزاد',
      capacityInfo: 'ظرفیت دکتری: حدود ۱۵ تا ۲۰ نفر در دوره‌های روزانه و پژوهش‌محور',
      facultyMembers: [
        { name: 'دکتر امیرمسعود رحمانی', title: 'استاد تمام', specialty: 'رایانش ابری هوشمند، اینترنت اشیاء و یادگیری عمیق', scholarUrl: 'https://scholar.google.com/citations?user=dM-93sMAAAAJ' },
        { name: 'دکتر محمدرضا کیوان‌پور', title: 'استاد', specialty: 'داده‌کاوی، سیستم‌های فازی و هوش محاسباتی' }
      ],
      tags: ['دانشگاه آزاد', 'علوم و تحقیقات', 'استعداد درخشان آزاد', 'EPT']
    },

    // --- WORLD UNIVERSITIES ---
    {
      id: 'mit-ai',
      name: 'موسسه فناوری ماساچوست (MIT)',
      englishName: 'Massachusetts Institute of Technology (MIT)',
      region: 'world',
      country: 'آمریکا',
      city: 'کمبریج، ماساچوست',
      rankingText: 'رتبه ۱ علوم کامپیوتر جهان (QS World & CSRankings)',
      officialUrl: 'https://www.mit.edu',
      admissionUrl: 'https://www.eecs.mit.edu/academics/graduate-programs/admission-process/',
      departments: ['Department of Electrical Engineering and Computer Science (EECS)', 'MIT CSAIL (Computer Science & AI Lab)'],
      specializations: ['Machine Learning Theory', 'Computer Vision', 'Robotics', 'NLP', 'Foundational Models', 'AI Hardware'],
      admissionRequirements: [
        'Statement of Objectives / SOP بسیار قوی و مستند بر مقالات پژوهشی قبلی',
        'سه توصیه‌نامه آکادمیک (Recommendation Letters) از اساتید پژوهشی شناخته‌شده',
        'مدرک زبان: تافل iBT حداقل ۱۰۰ یا آیلتس حداقل ۷.۵',
        'نمره GRE عمومی (در حال حاضر اختیاری است اما سابقه ریاضی قوی بررسی می‌شود)',
        'بورسیه کامل (Full Funding / RA / TA) برای کلیه پذیرفته‌شدگان دکتری'
      ],
      deadlinesSummary: 'ددلاین دکتری پاییز: ۱۵ دسامبر (Dec 15)',
      examType: 'GRE (Optional) + TOEFL / IELTS',
      capacityInfo: 'نرخ پذیرش بسیار رقابتی (~۳٪)',
      facultyMembers: [
        { name: 'Prof. Regina Barzilay', title: 'AI & Healthcare Pioneer', specialty: 'NLP and Molecular AI' },
        { name: 'Prof. Antonio Torralba', title: 'Head of AI Faculty', specialty: 'Computer Vision, Generative AI' },
        { name: 'Prof. Leslie Kaelbling', title: 'Robotics Legend', specialty: 'Reinforcement Learning & Robotics' }
      ],
      tags: ['MIT', 'USA', 'EECS', 'CSAIL', 'Full Funding']
    },
    {
      id: 'stanford-ai',
      name: 'دانشگاه استنفورد (Stanford)',
      englishName: 'Stanford University',
      region: 'world',
      country: 'آمریکا',
      city: 'استنفورد، کالیفرنیا (سیلیکون ولی)',
      rankingText: 'قلب نوآوری هوش مصنوعی و سیلیکون ولی (رتبه ۲ جهان)',
      officialUrl: 'https://www.stanford.edu',
      admissionUrl: 'https://cs.stanford.edu/admissions/phd-admissions',
      departments: ['Department of Computer Science', 'Stanford AI Lab (SAIL)', 'HAI (Human-Centered AI Institute)'],
      specializations: ['Deep Learning', 'Computer Vision (ImageNet legacy)', 'NLP (Stanford CoreNLP)', 'Robotics & Embodied AI'],
      admissionRequirements: [
        'SOP با محوریت شفاف مسئله پژوهشی و همسویی با اساتید SAIL',
        '۳ توصیه نامه معتبر، ریزنمرات رسمی، رزومه آکادمیک (CV)',
        'آزمون تافل تایید شده (توفل اینترنتی حداقل ۱۰۰)',
        'کدها و مخازن گیت‌هاب معتبر و مقالات سابمیت‌شده امتیاز کلیدی محسوب می‌شوند'
      ],
      deadlinesSummary: 'ددلاین پاییز: اوایل دسامبر (معمولاً ۱ تا ۶ دسامبر)',
      examType: 'TOEFL + GRE Not Required for CS PhD',
      capacityInfo: 'پذیرش فول‌فاند (معافیت شهریه + حقوق ماهیانه کافی)',
      facultyMembers: [
        { name: 'Prof. Fei-Fei Li', title: 'Co-Director HAI', specialty: 'Computer Vision & Spatial Intelligence' },
        { name: 'Prof. Christopher Manning', title: 'Director SAIL', specialty: 'Natural Language Processing & Transformers' },
        { name: 'Prof. Chelsea Finn', title: 'Assistant Professor', specialty: 'Meta-Learning, Robotics, Reinforcement Learning' }
      ],
      tags: ['Stanford', 'USA', 'SAIL', 'Silicon Valley', 'Full Funding']
    },
    {
      id: 'cmu-ai',
      name: 'دانشگاه کارنگی ملون (CMU)',
      englishName: 'Carnegie Mellon University (CMU)',
      region: 'world',
      country: 'آمریکا',
      city: 'پیتسبورگ، پنسیلوانیا',
      rankingText: 'دارنده نخستین دانشکده اختصاصی علوم کامپیوتر در جهان (رتبه ۱ CSRankings AI)',
      officialUrl: 'https://www.cmu.edu',
      admissionUrl: 'https://www.cs.cmu.edu/academics/phd',
      departments: ['School of Computer Science (SCS)', 'Machine Learning Department (MLD)', 'Language Technologies Institute (LTI)', 'Robotics Institute (RI)'],
      specializations: ['Pure Machine Learning PhD', 'Language Technologies PhD', 'Robotics PhD', 'Societal Computing'],
      admissionRequirements: [
        'یک اپلیکیشن متمرکز برای حداکثر ۳ برنامه دکتری مختلف در SCS',
        'مدرک تافل (حداقل ۱۰۰) یا آیلتس (حداقل ۷.۵)',
        'SOP، سه توصیه‌نامه قوی، مقالات پژوهشی و رزومه کامل',
        'تامین مالی تضمین‌شده برای تمام دوران دکتری (۵ سال)'
      ],
      deadlinesSummary: 'ددلاین دکتری: ۱۲ دسامبر (Dec 12)',
      examType: 'TOEFL / IELTS / Duolingo',
      capacityInfo: 'یکی از بزرگترین خروجی‌های اعضای هیئت علمی و رهبران AI در جهان',
      facultyMembers: [
        { name: 'Prof. Ruslan Salakhutdinov', title: 'Professor', specialty: 'Deep Generative Models & Multimodal AI' },
        { name: 'Prof. Graham Neubig', title: 'Associate Professor', specialty: 'NLP, Large Language Models, Code Generation' }
      ],
      tags: ['CMU', 'USA', 'MLD', 'LTI', 'Machine Learning']
    },
    {
      id: 'berkeley-ai',
      name: 'دانشگاه کالیفرنیا، برکلی (UC Berkeley)',
      englishName: 'University of California, Berkeley (UCB)',
      region: 'world',
      country: 'آمریکا',
      city: 'برکلی، کالیفرنیا',
      rankingText: 'پیشتاز تحقیقات بازمتن هوش مصنوعی (BAIR)',
      officialUrl: 'https://www.berkeley.edu',
      admissionUrl: 'https://eecs.berkeley.edu/academics/graduate/apply',
      departments: ['Department of EECS', 'Berkeley Artificial Intelligence Research (BAIR) Lab'],
      specializations: ['Deep Reinforcement Learning', 'Autonomous Systems', 'Generative Models', 'Computer Vision'],
      admissionRequirements: [
        'Statement of Purpose و Personal History Statement جداگانه',
        'حداقل نمره تافل ۹۰ یا آیلتس ۷.۰',
        'ارائه ۳ توصیه‌نامه و کارنامه رسمی',
        'فول‌فاند کامل شامل شهریه و کمک‌هزینه زندگی سالانه'
      ],
      deadlinesSummary: 'ددلاین دکتری: حدود ۹ دسامبر',
      examType: 'TOEFL / IELTS (GRE is not accepted)',
      capacityInfo: 'پذیرش مستقیم در گروه اساتید BAIR',
      facultyMembers: [
        { name: 'Prof. Pieter Abbeel', title: 'Director of Robot Learning', specialty: 'Deep RL, Robotics, Foundational Models' },
        { name: 'Prof. Sergey Levine', title: 'Associate Professor', specialty: 'Robotics, Reinforcement Learning, Decision Making' },
        { name: 'Prof. Stuart Russell', title: 'Author of AI: Modern Approach', specialty: 'AI Safety, Rationality, Logic' }
      ],
      tags: ['Berkeley', 'BAIR', 'USA', 'Reinforcement Learning']
    },
    {
      id: 'eth-zurich',
      name: 'دانشگاه صنعتی زوریخ (ETH Zurich)',
      englishName: 'ETH Zurich (Swiss Federal Institute of Technology)',
      region: 'world',
      country: 'سوئیس',
      city: 'زوریخ، سوئیس',
      rankingText: 'برترین دانشگاه مهندسی قاره اروپا (QS World: ~۷)',
      officialUrl: 'https://ethz.ch',
      admissionUrl: 'https://inf.ethz.ch/doctorate/application.html',
      departments: ['Department of Computer Science (D-INFK)', 'ETH AI Center'],
      specializations: ['Medical AI', 'Secure AI', 'Computer Vision', 'Interactive Intelligent Systems', 'Robotics'],
      admissionRequirements: [
        'دو مسیر پذیرش: ۱) از طریق فرآیند مستقیم جذب توسط استاد (Direct Professor Hire)؛ ۲) از طریق Doctoral Fellowship دپارتمان کامپیوتر',
        'بدون شهریه دانشگاهی سرسام‌آور (شهریه دکتری نمادین)',
        'بالاترین حقوق پرداختی دکتری در جهان (حدود ۶۰,۰۰۰ تا ۸۰,۰۰۰ فرانک سوئیس در سال به عنوان کارمند پژوهشی)',
        'نمره مدرک زبان انگلیسی معتبر C1/C2 (آیلتس ۷ یا تافل ۱۰۰)'
      ],
      deadlinesSummary: 'پذیرش مستقیم: در تمام طول سال (Rolling) | بورسیه متمرکز: ۱ ژانویه',
      examType: 'Direct Advisor Application + CV + Research Proposal',
      capacityInfo: 'موقعیت‌های استخدامی با اعلام خالی بودن پوزیشن در سایت آزمایشگاه‌ها',
      facultyMembers: [
        { name: 'Prof. Luc Van Gool', title: 'Computer Vision Lab', specialty: '3D Vision and Autonomous Driving' },
        { name: 'Prof. Martin Vechev', title: 'SRI Lab', specialty: 'Safe and Robust AI, LLM Verification' }
      ],
      tags: ['ETH Zurich', 'سوئیس', 'Europe', 'بالاترین حقوق دکتری', 'بدون شهریه']
    },
    {
      id: 'epfl-ai',
      name: 'دانشگاه پلی‌تکنیک لوزان (EPFL)',
      englishName: 'École Polytechnique Fédérale de Lausanne (EPFL)',
      region: 'world',
      country: 'سوئیس',
      city: 'لوزان، سوئیس',
      rankingText: 'دومین قطب فناوری سوئیس با برنامه متمرکز EDIC PhD',
      officialUrl: 'https://www.epfl.ch',
      admissionUrl: 'https://www.epfl.ch/education/phd/edic-computer-and-communication-sciences/',
      departments: ['School of Computer and Communication Sciences (IC)', 'EDIC Doctoral School'],
      specializations: ['Information Theory', 'Deep Learning Theory', 'Graph Neural Networks', 'NLP'],
      admissionRequirements: [
        'پذیرش متمرکز از طریق کمیته EDIC با یک سال اول روتاسیون در آزمایشگاه‌های مختلف',
        'حقوق عالی دکتری (حدود ۵۵,۰۰۰ فرانک سوئیس)',
        'ریز نمرات ارشد ممتاز، ۳ توصیه‌نامه و انگیزه‌نامه قوی'
      ],
      deadlinesSummary: 'ددلاین دسامبر (Dec 15) و ددلاین آوریل (April 15)',
      examType: 'EDIC Centralized Portal',
      capacityInfo: 'فاند تضمینی برای تمامی دانشجویان پذیرفته‌شده',
      facultyMembers: [
        { name: 'Prof. Martin Jaggi', title: 'Machine Learning & Optimization Lab', specialty: 'Decentralized ML, Transformers' }
      ],
      tags: ['EPFL', 'سوئیس', 'EDIC', 'Rotations']
    },
    {
      id: 'toronto-ai',
      name: 'دانشگاه تورنتو (University of Toronto) و وکتور انستیتو',
      englishName: 'University of Toronto & Vector Institute',
      region: 'world',
      country: 'کانادا',
      city: 'تورنتو، اونتاریو',
      rankingText: 'مهد یادگیری عمیق نوین و شبکه عصبی کانوولوشنی با جفری هینتون',
      officialUrl: 'https://www.utoronto.ca',
      admissionUrl: 'https://web.cs.toronto.edu/graduate/admissions',
      departments: ['Department of Computer Science', 'Vector Institute for Artificial Intelligence'],
      specializations: ['Deep Learning', 'Computer Vision', 'Generative Models', 'Health AI', 'Theoretical CS'],
      admissionRequirements: [
        'حداقل معدل ارشد A- (معادل بالای ۱۷ در ایران)',
        'آزمون زبان تافل (حداقل ۹۳ با رایتینگ ۲۲) یا آیلتس (حداقل ۷.۰ با حداقل ۶.۵ در هر بند)',
        'پکیج فاند دکتری تضمین‌شده ۵ ساله برای دانشجویان بین‌المللی'
      ],
      deadlinesSummary: 'ددلاین سالانه دکتری: ۱ دسامبر (Dec 1)',
      examType: 'TOEFL / IELTS',
      capacityInfo: 'امکان دسترسی مستقیم به مراکز پژوهشی Vector Institute',
      facultyMembers: [
        { name: 'Prof. Jimmy Ba', title: 'Vector Faculty & Co-creator of Adam Optimizer', specialty: 'Deep Learning & Optimizers' },
        { name: 'Prof. Sanja Fidler', title: 'VP AI Research NVIDIA / UofT', specialty: 'Computer Vision & 3D AI' }
      ],
      tags: ['Toronto', 'Vector Institute', 'کانادا', 'جفری هینتون', 'Adam Optimizer']
    },
    {
      id: 'tum-ai',
      name: 'دانشگاه فنی مونیخ (TUM)',
      englishName: 'Technical University of Munich (TUM)',
      region: 'world',
      country: 'آلمان',
      city: 'مونیخ، آلمان',
      rankingText: 'برترین دانشگاه فنی آلمان با همکاری گسترده صنعتی با BMW و زیمنس',
      officialUrl: 'https://www.tum.de',
      admissionUrl: 'https://www.cit.tum.de/en/cit/studies/degree-programs/doctorate/',
      departments: ['TUM School of Computation, Information and Technology (CIT)', 'Munich Data Science Institute (MDSI)'],
      specializations: ['Automated Driving AI', 'Robotics & AI', 'Bio-Medical ML', 'Explainable AI'],
      admissionRequirements: [
        'مدل دکتری آلمان: قرارداد استخدام TV-L E13 (حقوق ماهانه ناخالص حدود ۴۲۰۰ یورو و خالص حدود ۲۶۰۰ یورو بدون شهریه)',
        'پیدا کردن استاد راهنما (Doktorvater) از طریق مکاتبه مستقیم (Cold Email) با پروپوزال متناسب با گرنت‌های فعال',
        'مدرک زبان انگلیسی معتبر، مدرک ارشد رسمی با ارزشیابی ZAB'
      ],
      deadlinesSummary: 'پذیرش پیوسته در تمام فصول سال بر اساس پوزیشن‌های خالی اعلامی',
      examType: 'استخدام پژوهشی TV-L E13 + مکاتبه با استاد',
      capacityInfo: 'بسیار پرطرفدار برای فارغ‌التحصیلان ارشد ایرانی',
      facultyMembers: [
        { name: 'Prof. Daniel Cremers', title: 'Chair of Computer Vision', specialty: 'Direct Visual SLAM, 3D Reconstruction' },
        { name: 'Prof. Sami Haddadin', title: 'Robotics & Machine Intelligence', specialty: 'Cobots, Tactile Robotics' }
      ],
      tags: ['TUM', 'آلمان', 'TV-L E13', 'بدون شهریه', 'قرارداد کاری']
    },
    {
      id: 'oxford-ai',
      name: 'دانشگاه آکسفورد (University of Oxford)',
      englishName: 'University of Oxford',
      region: 'world',
      country: 'انگلستان',
      city: 'آکسفورد، انگلستان',
      rankingText: 'قدیمی‌ترین دانشگاه جهان انگلیسی‌زبان با پژوهش‌های بنیادین AI',
      officialUrl: 'https://www.ox.ac.uk',
      admissionUrl: 'https://www.cs.ox.ac.uk/admissions/graduate/dphil/',
      departments: ['Department of Computer Science', 'Oxford Robotics Institute', 'Torr Vision Group'],
      specializations: ['Machine Learning', 'Automated Verification', 'Quantum AI', 'Computer Vision'],
      admissionRequirements: [
        'معدل فوق‌العاده بالا، پروپوزال پژوهشی (Research Proposal) دقیق ۳ تا ۵ صفحه‌ای',
        'نمره زبان استاندارد بالا: آیلتس ۷.۵ یا تافل ۱۱۰',
        'رقابت برای بورسیه‌های معتبر Clarendon و DeepMind PhD Scholarships'
      ],
      deadlinesSummary: 'ددلاین مرحله اول بورسیه‌ها: اوایل ژانویه (حدود ۵ ژانویه)',
      examType: 'DPhil Application + Research Proposal + IELTS',
      capacityInfo: 'مدارک دوره دکتری با عنوان DPhil ارائه می‌شود',
      facultyMembers: [
        { name: 'Prof. Philip Torr', title: 'Head of Torr Vision Group', specialty: 'Deep Learning, Safety, Computer Vision' },
        { name: 'Prof. Michael Wooldridge', title: 'Professor of CS', specialty: 'Multi-Agent Systems, Game Theory' }
      ],
      tags: ['Oxford', 'UK', 'Clarendon', 'DPhil']
    },
    {
      id: 'cambridge-ai',
      name: 'دانشگاه کمبریج (University of Cambridge)',
      englishName: 'University of Cambridge',
      region: 'world',
      country: 'انگلستان',
      city: 'کمبریج، انگلستان',
      rankingText: 'مهد آلن تورینگ و یکی از معتبرترین مراکز هوش محاسباتی',
      officialUrl: 'https://www.cam.ac.uk',
      admissionUrl: 'https://www.cst.cam.ac.uk/admissions/phd',
      departments: ['Department of Computer Science and Technology', 'Cambridge AI Center'],
      specializations: ['Probabilistic Machine Learning', 'Speech and Audio Processing', 'Robotics'],
      admissionRequirements: [
        'پروپوزال پژوهشی، مکاتبه اولیه با استاد مورد نظر، ۳ توصیه‌نامه',
        'مدرک زبان آیلتس ۷.۵ (با حداقل ۷.۰ در هر بخش) یا تافل ۱۰۷',
        'اقدام برای بورسیه همه‌جانبه Gates Cambridge Scholarship'
      ],
      deadlinesSummary: 'ددلاین برای بورسیه‌های جهانی: اوایل دسامبر / ژانویه',
      examType: 'PhD Portal + Research Proposal',
      capacityInfo: 'محیط بین‌رشته‌ای در کالج‌های سنتی کمبریج',
      facultyMembers: [
        { name: 'Prof. Zoubin Ghahramani', title: 'VP Research Google / Cambridge', specialty: 'Bayesian Machine Learning' }
      ],
      tags: ['Cambridge', 'UK', 'Gates Cambridge', 'آلن تورینگ']
    },
    {
      id: 'nus-ai',
      name: 'دانشگاه ملی سنگاپور (NUS)',
      englishName: 'National University of Singapore (NUS)',
      region: 'world',
      country: 'سنگاپور',
      city: 'سنگاپور',
      rankingText: 'برترین دانشگاه آسیا (رتبه ۸ جهان در QS)',
      officialUrl: 'https://nus.edu.sg',
      admissionUrl: 'https://www.comp.nus.edu.sg/programmes/pg/phdcs/',
      departments: ['School of Computing (SoC)'],
      specializations: ['Information Retrieval', 'Bio-Informatics', 'Computer Vision', 'Deep Learning Systems'],
      admissionRequirements: [
        'بورسیه دولتی SINGA (Singapore International Graduate Award) یا NUS Research Scholarship',
        'پوشش کامل شهریه + حقوق ماهانه عالی (۲,۲۰۰ تا ۲,۷۰۰ دلار سنگاپور)',
        'نمره GRE معتبر (معمولاً بالای ۳۲۰) و مدرک تافل/آیلتس'
      ],
      deadlinesSummary: 'ترم پاییز: اول نوامبر تا ۱۵ دسامبر | ترم بهار: اول جولای',
      examType: 'GRE + TOEFL / IELTS + SINGA Application',
      capacityInfo: 'هاب اتصال فناوری شرق و غرب با تجهیزات محاسباتی عظیم',
      facultyMembers: [
        { name: 'Prof. Tat-Seng Chua', title: 'KITHCT Chair Professor', specialty: 'Multimodal AI, Video Retrieval' }
      ],
      tags: ['NUS', 'سنگاپور', 'آسیا', 'SINGA', 'Full Scholarship']
    },
    {
      id: 'mila-ai',
      name: 'انستیتو هوش مصنوعی میلا و دانشگاه مونترال (Mila / UdeM)',
      englishName: 'Mila - Quebec AI Institute & Université de Montréal',
      region: 'world',
      country: 'کانادا',
      city: 'مونترال، کبک',
      rankingText: 'بزرگترین کانون دانشگاهی یادگیری عمیق در جهان تحت رهبری یوشوا بنجیو',
      officialUrl: 'https://mila.quebec',
      admissionUrl: 'https://mila.quebec/en/academic/admissions',
      departments: ['Department of Computer Science and Operations Research (DIRO)', 'Mila Institute'],
      specializations: ['Deep Learning Theory', 'Generative Flow Networks (GFlowNets)', 'AI for Drug Discovery', 'Climate AI'],
      admissionRequirements: [
        'سامانه پذیرش متمرکز Mila Matching Portal (ثبت‌نام سالانه جهت اتصال به اساتید میلا)',
        'پذیرش همزمان در یکی از دانشگاه‌های همکار (UdeM, McGill, Polytechnique)',
        'فاند سالانه تضمین‌شده دکتری برای همه پذیرفته‌شدگان'
      ],
      deadlinesSummary: 'ددلاین پورتال Mila: اوایل دسامبر (Dec 1)',
      examType: 'Mila Central Matching Process',
      capacityInfo: 'بیش از ۱۰۰۰ پژوهشگر و دانشجو در یک ساختمان اختصاصی در مونترال',
      facultyMembers: [
        { name: 'Prof. Yoshua Bengio', title: 'Turing Award Laureate & Founder', specialty: 'Deep Learning, GFlowNets, AI Safety' }
      ],
      tags: ['Mila', 'Montreal', 'کانادا', 'یوشوا بنجیو', 'Deep Learning Hub']
    }
  ];

  readonly resources: AcademicResource[] = [
    // Digital Libraries & Search Engines
    {
      id: 'google-scholar',
      title: 'گوگل اسکالر (Google Scholar)',
      englishTitle: 'Google Scholar',
      type: 'search-engine',
      category: 'general',
      url: 'https://scholar.google.com',
      description: 'مهم‌ترین موتور جستجوی جهانی مقالات علمی، اندازه‌گیری استنادات، محاسبه h-index، ساخت پروفایل پژوهشگر و دریافت هشدارهای انتشار مقاله جدید.',
      authorOrProvider: 'Google Inc.',
      accessType: 'free',
      recommendedFor: 'پژوهش روزمره، رصد مقالات، بررسی رزومه اساتید'
    },
    {
      id: 'semantic-scholar',
      title: 'سمانتیک اسکالر (Semantic Scholar)',
      englishTitle: 'Semantic Scholar',
      type: 'search-engine',
      category: 'general',
      url: 'https://www.semanticscholar.org',
      description: 'موتور جستجوی مبتنی بر هوش مصنوعی ساخته موسسه آلن (AI2) با قابلیت استخراج خودکار نتایج، نمودار ارتباط مقالات و تفکیک ارجاعات کلیدی.',
      authorOrProvider: 'Allen Institute for AI (AI2)',
      accessType: 'free',
      recommendedFor: 'مرور سیستماتیک پیشینه، پیدا کردن مقالات موثر در کوتاهترین زمان'
    },
    {
      id: 'arxiv-ai',
      title: 'مخزن پیش‌چاپ آرکایو (arXiv - بخش کامپیوتر و یادگیری ماشین)',
      englishTitle: 'arXiv (cs.AI, cs.LG, cs.CV, cs.CL)',
      type: 'paper-repo',
      category: 'general',
      url: 'https://arxiv.org/list/cs.AI/recent',
      description: 'هاب اصلی انتشارات اولیه تمام مقالات تراز اول هوش مصنوعی ماه‌ها قبل از چاپ رسمی در کنفرانس‌ها. بخش‌های cs.AI, cs.LG (یادگیری ماشین), cs.CV (بینایی), cs.CL (زبان).',
      authorOrProvider: 'Cornell University',
      accessType: 'open-access',
      recommendedFor: 'بررسی مقالات روز دنیا هر صبح، همگامی با پیشرفت‌های مرز دانش'
    },
    {
      id: 'ieee-xplore',
      title: 'پایگاه علمی آی‌تریپل‌ئی (IEEE Xplore)',
      englishTitle: 'IEEE Xplore Digital Library',
      type: 'library',
      category: 'general',
      url: 'https://ieeexplore.ieee.org',
      description: 'مرجع بیش از ۵ میلیون مقاله ژورنال‌های معتبر IEEE Transactions (مانند TPAMI, TNNLS, TIP) و کنفرانس‌های تخصصی رباتیک و کامپیوتر.',
      authorOrProvider: 'IEEE',
      accessType: 'institutional',
      recommendedFor: 'دانلود مقالات ترنزکشن‌های مرجع جهت فصل دوم پایان‌نامه ارشد'
    },
    {
      id: 'acm-dl',
      title: 'کتابخانه دیجیتال ای‌سی‌ام (ACM Digital Library)',
      englishTitle: 'ACM Digital Library',
      type: 'library',
      category: 'general',
      url: 'https://dl.acm.org',
      description: 'آرشیو مقالات انجمن ماشین‌های محاسباتی آمریکا، کنفرانس‌های KDD, SIGIR, FAccT و ژورنال‌های ACM Computing Surveys.',
      authorOrProvider: 'ACM',
      accessType: 'institutional',
      recommendedFor: 'یافتن مقالات پیمایشی (Surveys) جامع در شروع پایان‌نامه'
    },
    {
      id: 'sciencedirect',
      title: 'ساینس دایرکت (ScienceDirect - الزویر)',
      englishTitle: 'ScienceDirect (Elsevier)',
      type: 'library',
      category: 'general',
      url: 'https://www.sciencedirect.com',
      description: 'ناشر برترین ژورنال‌های هوش مصنوعی نظیر Artificial Intelligence Journal, Pattern Recognition, Neurocomputing, Information Fusion.',
      authorOrProvider: 'Elsevier',
      accessType: 'institutional',
      recommendedFor: 'انتخاب ژورنال‌های Q1 برای سابمیت مقاله ارشد علیرضا'
    },
    {
      id: 'springerlink',
      title: 'اشپرینگرلینک (SpringerLink)',
      englishTitle: 'SpringerLink',
      type: 'library',
      category: 'general',
      url: 'https://link.springer.com',
      description: 'میزبان سری کتاب‌های مشهور LNCS (کنفرانس‌های ECCV, MICCAI) و ژورنال معروف Machine Learning Journal.',
      authorOrProvider: 'Springer Nature',
      accessType: 'institutional',
      recommendedFor: 'کتاب‌های مرجع ریاضی و مهندسی، مقالات کنفرانسی LNCS'
    },
    {
      id: 'researchgate',
      title: 'ریسرچ‌گیت (ResearchGate)',
      englishTitle: 'ResearchGate',
      type: 'search-engine',
      category: 'general',
      url: 'https://www.researchgate.net',
      description: 'شبکه اجتماعی آکادمیک برای ارتباط مستقیم با نویسندگان مقالات، درخواست نسخه PDF مقالات پولی، و پرسش و پاسخ‌های فنی علمی.',
      authorOrProvider: 'ResearchGate GmbH',
      accessType: 'free',
      recommendedFor: 'درخواست مستقیم متن کامل مقالات از نویسندگان اصلی'
    },
    {
      id: 'dblp-cs',
      title: 'پایگاه کتاب‌شناختی کامپیوتر (DBLP)',
      englishTitle: 'DBLP Computer Science Bibliography',
      type: 'search-engine',
      category: 'general',
      url: 'https://dblp.org',
      description: 'دقیق‌ترین و پاک‌ترین دیتابیس شناسایی تاریخچه مقالات دانشمندان علوم کامپیوتر بدون خطا و تشابه نام.',
      authorOrProvider: 'Schloss Dagstuhl / University of Trier',
      accessType: 'free',
      recommendedFor: 'بررسی دقیق سابقه مقالات اساتید راهنما قبل از اپلای یا مصاحبه'
    },
    // Iranian National Portals
    {
      id: 'irandoc',
      title: 'پژوهشگاه علوم و فناوری اطلاعات ایران (ایران‌داک - پایگاه گنج)',
      englishTitle: 'IranDoc (Ganj Database)',
      type: 'iranian-portal',
      category: 'general',
      url: 'https://ganj.irandoc.ac.ir',
      description: 'سامانه ملی ثبت و استعلام پایان‌نامه‌های ارشد و رساله‌های دکتری کل دانشگاه‌های ایران. شامل سامانه پیشینه پژوهش و همانندجو برای دفاع ارشد.',
      authorOrProvider: 'وزارت علوم، تحقیقات و فناوری',
      accessType: 'free',
      recommendedFor: 'ثبت پروپوزال ارشد، پیشینه پژوهش، بررسی تکراری نبودن موضوع'
    },
    {
      id: 'sid-ir',
      title: 'مرکز اطلاعات علمی جهاد دانشگاهی (SID)',
      englishTitle: 'Scientific Information Database (SID)',
      type: 'iranian-portal',
      category: 'general',
      url: 'https://www.sid.ir',
      description: 'بزرگترین پایگاه دسترسی آزاد به مقالات علمی پژوهشی و علمی ترویجی دانشگاه‌ها و کنفرانس‌های معتبر داخل ایران به زبان فارسی.',
      authorOrProvider: 'جهاد دانشگاهی',
      accessType: 'open-access',
      recommendedFor: 'مطالعه مقالات فارسی برای ادبیات موضوع و آشنایی با اصطلاحات'
    },
    {
      id: 'magiran',
      title: 'بانک اطلاعات نشریات کشور (مگیران)',
      englishTitle: 'Magiran',
      type: 'iranian-portal',
      category: 'general',
      url: 'https://www.magiran.com',
      description: 'آرشیو نشریات علمی مصوب وزارتین علوم و بهداشت و نشریات تخصصی انجمن‌های علمی ایران.',
      authorOrProvider: 'Magiran',
      accessType: 'institutional',
      recommendedFor: 'جستجوی ژورنال‌های علمی پژوهشی فارسی جهت چاپ مقاله ارشد'
    },
    {
      id: 'nli-ir',
      title: 'سازمان اسناد و کتابخانه ملی جمهوری اسلامی ایران',
      englishTitle: 'National Library and Archives of I.R. Iran (NLI)',
      type: 'iranian-portal',
      category: 'general',
      url: 'https://www.nlai.ir',
      description: 'مرجع اسناد ملی، کتاب‌های مرجع چاپ‌شده در ایران، فیپا، و نسخه‌های خطی و کتب دانشگاهی.',
      authorOrProvider: 'کتابخانه ملی ایران',
      accessType: 'free',
      recommendedFor: 'عضویت پژوهشگران جهت استفاده از تالارهای تخصصی و منابع لاتین'
    },
    {
      id: 'sharif-library',
      title: 'کتابخانه مرکزی و مرکز اسناد دانشگاه صنعتی شریف',
      englishTitle: 'Sharif Central Library & Digital Repositories',
      type: 'library',
      category: 'general',
      url: 'https://library.sharif.ir',
      description: 'پرتال کتب مرجع، تزهای فارغ‌التحصیلی نخبگان هوش مصنوعی شریف و دسترسی‌های اشتراکی پایگاه‌ها.',
      authorOrProvider: 'دانشگاه صنعتی شریف',
      accessType: 'institutional',
      recommendedFor: 'بررسی رساله‌های دکتری دفاع‌شده در شریف برای الگوبرداری'
    },
    // Essential Textbooks
    {
      id: 'book-mml',
      title: 'کتاب ریاضیات برای یادگیری ماشین (MML)',
      englishTitle: 'Mathematics for Machine Learning (Deisenroth, Faisal, Ong)',
      type: 'textbook',
      category: 'math',
      url: 'https://mml-book.github.io',
      description: 'بهترین کتاب مدرن و رایگان برای تقویت پایه‌های جبر خطی، حساب دیفرانسیل چندمتغیره، بهینه‌سازی و احتمال در کاربردهای AI.',
      authorOrProvider: 'Marc Peter Deisenroth, A. Aldo Faisal, Cheng Soon Ong (Cambridge Univ Press)',
      accessType: 'open-access',
      recommendedFor: 'آمادگی کنکور دکتری و مصاحبه‌های علمی خارج از کشور'
    },
    {
      id: 'book-deeplearning',
      title: 'کتاب یادگیری عمیق (Deep Learning Book - Goodfellow)',
      englishTitle: 'Deep Learning (Goodfellow, Bengio, Courville)',
      type: 'textbook',
      category: 'deep-learning',
      url: 'https://www.deeplearningbook.org',
      description: 'معروف به "انجیل یادگیری عمیق"، تالیف سه تن از دانشمندان نامدار حوزه. پوشش نظریه شبکه‌های عصبی پیش‌خور، CNN، RNN و مدل‌های مولد.',
      authorOrProvider: 'Ian Goodfellow, Yoshua Bengio, Aaron Courville (MIT Press)',
      accessType: 'open-access',
      recommendedFor: 'تسلط مفهومی از روز اول ارشد تا آزمون جامع دکتری'
    },
    {
      id: 'book-d2l',
      title: 'شیرجه در یادگیری عمیق (Dive into Deep Learning - D2L)',
      englishTitle: 'Dive into Deep Learning (D2L.ai)',
      type: 'textbook',
      category: 'deep-learning',
      url: 'https://d2l.ai',
      description: 'کتاب تعاملی و عملی عالی همراه با کدهای کامل PyTorch برای پیاده‌سازی تمام شبکه‌ها، ترنسفورمرها و مدل‌های مدرن.',
      authorOrProvider: 'Aston Zhang, Zack C. Lipton, Mu Li, Alexander J. Smola',
      accessType: 'open-access',
      recommendedFor: 'تبدیل تئوری به کدنویسی عملیاتی و سریع در پایان‌نامه'
    },
    {
      id: 'book-prml',
      title: 'بازشناسی الگو و یادگیری ماشین (PRML - Christopher Bishop)',
      englishTitle: 'Pattern Recognition and Machine Learning',
      type: 'textbook',
      category: 'ml',
      url: 'https://www.microsoft.com/en-us/research/people/cmbishop/prml-book/',
      description: 'شاهکار کریستوفر بیشاپ در دیدگاه بیزی و یادگیری ماشین آماری، به رایگان توسط مایکروسافت ریسرچ ارائه شده است.',
      authorOrProvider: 'Christopher M. Bishop (Springer / Microsoft Research)',
      accessType: 'open-access',
      recommendedFor: 'آمادگی برای سوالات ریاضی و تئوری مصاحبه‌های دکتری'
    },
    {
      id: 'book-slp',
      title: 'پردازش گفتار و زبان (Jurafsky & Martin - Speech & Language Processing)',
      englishTitle: 'Speech and Language Processing (3rd ed. draft)',
      type: 'textbook',
      category: 'nlp',
      url: 'https://web.stanford.edu/~jurafsky/slp3/',
      description: 'جامع‌ترین کتاب مرجع NLP و LLM جهان، آپدیت‌شده شامل فصل‌های جدید Transformers، Prompt Engineering و Alignment.',
      authorOrProvider: 'Dan Jurafsky & James H. Martin (Stanford University)',
      accessType: 'open-access',
      recommendedFor: 'دانشجویان ارشد متمرکز بر NLP و مدل‌های زبانی بزرگ'
    },
    {
      id: 'book-rl',
      title: 'یادگیری تقویتی: مقدمه‌ای بر مبانی (Sutton & Barto)',
      englishTitle: 'Reinforcement Learning: An Introduction (2nd Edition)',
      type: 'textbook',
      category: 'rl',
      url: 'http://incompleteideas.net/book/the-book-2nd.html',
      description: 'کتاب پایه‌ای و معتبر یادگیری تقویتی از ریچارد ساتون (پدر یادگیری تقویتی مدرن)، شامل MDP، Q-Learning و Policy Gradients.',
      authorOrProvider: 'Richard S. Sutton and Andrew G. Barto (MIT Press)',
      accessType: 'open-access',
      recommendedFor: 'تسلط بر زیرساخت تئوری یادگیری تقویتی'
    },
    {
      id: 'book-szeliski',
      title: 'بینایی کامپیوتر: الگوریتم‌ها و کاربردها (Richard Szeliski)',
      englishTitle: 'Computer Vision: Algorithms and Applications (2nd ed.)',
      type: 'textbook',
      category: 'cv',
      url: 'https://szeliski.org/Book/',
      description: 'جامع‌ترین مرجع بینایی کامپیوتر، تبدیل تصاویر دو‌بعدی به سه‌بعدی، استخراج ویژگی، قطعه‌بندی و یادگیری عمیق در تصویر.',
      authorOrProvider: 'Richard Szeliski',
      accessType: 'open-access',
      recommendedFor: 'دانشجویان ارشد متمرکز بر پردازش تصویر و بینایی ماشین'
    },
    {
      id: 'guide-paper-writing',
      title: 'راهنمای چگونگی نگارش مقاله پژوهشی عالی (Simon Peyton Jones)',
      englishTitle: 'How to Write a Great Research Paper',
      type: 'textbook',
      category: 'writing',
      url: 'https://www.microsoft.com/en-us/research/academic-program/write-great-research-paper/',
      description: 'راهنمای طلایی سیمون پیتون جونز دانشمند مشهور مایکروسافت در مورد ساختاردهی به ایده، چکیده، مقدمه، بخش آزمایش‌ها و جذب نظر داوران.',
      authorOrProvider: 'Simon Peyton Jones (Microsoft Research)',
      accessType: 'free',
      recommendedFor: 'نگارش مقاله ISI ارشد علیرضا و افزایش ضریب قبولی داوری'
    }
  ];

  readonly labs: ResearchLab[] = [
    // Iran Labs
    {
      id: 'lab-sharif-ai',
      name: 'پژوهشکده هوش مصنوعی و علوم داده شریف',
      englishName: 'Sharif AI & Data Science Institute',
      region: 'iran',
      organization: 'دانشگاه صنعتی شریف',
      location: 'تهران، خیابان آزادی',
      websiteUrl: 'https://ai.sharif.edu',
      careersOrFellowshipUrl: 'https://ai.sharif.edu/join-us',
      leadPeople: ['دکتر حمیدرضا ربیعی', 'دکتر محمدحسین رهبان'],
      focusAreas: ['یادگیری عمیق پزشکی', 'هوش مصنوعی قابل اطمینان', 'پردازش زبان فارسی', 'دید ماشین سه‌بعدی'],
      description: 'پیشرفته‌ترین مرکز تحقیقاتی دانشگاهی کشور با سرورهای قدرتمند GPU و پروژه‌های مشترک بین‌المللی با مراکز برتر دنیا.',
      opportunityTypes: ['دستیار پژوهشی (RA)', 'پروژه‌های مشترک پایان‌نامه ارشد', 'فرصت پسادکتری']
    },
    {
      id: 'lab-ut-ai',
      name: 'مرکز تحقیقات و نوآوری هوش مصنوعی دانشگاه تهران',
      englishName: 'UT AI Innovation and Research Center',
      region: 'iran',
      organization: 'دانشگاه تهران',
      location: 'تهران، پردیس دانشکده‌های فنی (امیرآباد)',
      websiteUrl: 'https://ece.ut.ac.ir',
      leadPeople: ['دکتر هشام فیلی', 'دکتر فرزاد درودگر'],
      focusAreas: ['مدل‌های زبانی بزرگ فارسی', 'هوش مصنوعی شناختی', 'بینایی ماشین در خودروهای هوشمند'],
      description: 'مرکز متمرکز بر پروژه‌های صنعتی ملی و توسعه مدل‌های زبانی فارسی برای زبان و خط فارسی.',
      opportunityTypes: ['عضویت در تیم‌های پژوهشی', 'همکاری پژوهشی ارشد و دکتری']
    },
    {
      id: 'lab-ipm-cs',
      name: 'پژوهشکده علوم کامپیوتر پژوهشگاه دانش‌های بنیادی (IPM)',
      englishName: 'School of Computer Science, IPM',
      region: 'iran',
      organization: 'پژوهشگاه دانش‌های بنیادی (IPM)',
      location: 'تهران، فرمانیه',
      websiteUrl: 'http://cs.ipm.ac.ir',
      careersOrFellowshipUrl: 'http://cs.ipm.ac.ir/vacancies.jsp',
      leadPeople: ['دکتر حمید پزشک', 'دکتر علی شریفی زارچی'],
      focusAreas: ['بیوانفورماتیک محاسباتی', 'الگوریتم‌های یادگیری ماشین', 'تئوری علوم کامپیوتر'],
      description: 'مرکز پیشتاز تحقیقات نظری کشور با گرنت‌های پژوهشی مستقل و تعاملات مستقیم با محققان خارج از کشور.',
      opportunityTypes: ['بورسیه پژوهشی IPM', 'دستیار پژوهشی', 'پست داک']
    },
    {
      id: 'lab-aut-isl',
      name: 'آزمایشگاه سیستم‌های هوشمند امیرکبیر',
      englishName: 'AUT Intelligent Systems Laboratory',
      region: 'iran',
      organization: 'دانشگاه صنعتی امیرکبیر',
      location: 'تهران، خیابان حافظ',
      websiteUrl: 'https://aut.ac.ir',
      focusAreas: ['رباتیک توزیع‌شده', 'یادگیری تقویتی در بازی‌ها', 'محاسبات لبه هوشمند'],
      description: 'محیط پویا برای دانشجویان علاقه‌مند به کار بر روی ربات‌ها و یادگیری تقویتی عمیق.',
      opportunityTypes: ['همکاری آزمایشگاهی پایان‌نامه', 'تیم‌های بین‌المللی رباتیک Robocup']
    },
    // World Labs
    {
      id: 'lab-deepmind',
      name: 'گوگل دیپ‌مایند (Google DeepMind)',
      englishName: 'Google DeepMind',
      region: 'world',
      organization: 'Alphabet / Google',
      location: 'لندن (انگلستان) / مانتین‌ویو (آمریکا) / مونترال (کانادا)',
      websiteUrl: 'https://deepmind.google',
      careersOrFellowshipUrl: 'https://deepmind.google/about/careers/',
      leadPeople: ['Demis Hassabis (Nobel Laureate 2024)', 'Shane Legg'],
      focusAreas: ['AlphaFold & Science AI', 'AGI Theory', 'Gemini Foundational Models', 'Reinforcement Learning'],
      description: 'پیشگام‌ترین آزمایشگاه هوش مصنوعی جهان، برنده نوبل شیمی ۲۰۲۴ برای AlphaFold، خالق AlphaGo و مدل‌های خانواده جمینای.',
      opportunityTypes: ['Student Research Internships', 'DeepMind PhD Fellowship', 'Research Scientist Residency']
    },
    {
      id: 'lab-openai',
      name: 'اوپن‌ای‌آی (OpenAI)',
      englishName: 'OpenAI Research',
      region: 'world',
      organization: 'OpenAI',
      location: 'سانفرانسیسکو، کالیفرنیا، آمریکا',
      websiteUrl: 'https://openai.com/research',
      careersOrFellowshipUrl: 'https://openai.com/careers',
      leadPeople: ['Sam Altman', 'Jakub Pachocki (Chief Scientist)', 'Mark Chen'],
      focusAreas: ['Generative Pre-trained Transformers (GPT)', 'o1/o3 Reasoning Models', 'Multimodal Vision-Audio', 'AI Alignment'],
      description: 'رهبر تجاری و تحقیقاتی مدل‌های هوش مصنوعی زاینده و استدلال عمیق.',
      opportunityTypes: ['OpenAI Residency Program', 'Research Internship', 'Technical Fellow']
    },
    {
      id: 'lab-fair',
      name: 'متا فیر (Meta FAIR - Fundamental AI Research)',
      englishName: 'Meta FAIR (Fundamental AI Research)',
      region: 'world',
      organization: 'Meta Platforms Inc.',
      location: 'منلو پارک (آمریکا) / پاریس (فرانسه) / نیویورک',
      websiteUrl: 'https://ai.meta.com/research/',
      careersOrFellowshipUrl: 'https://www.metacareers.com/areas-of-work/fair/',
      leadPeople: ['Yann LeCun (Turing Award Laureate)', 'Joelle Pineau'],
      focusAreas: ['Open Science Foundation Models (Llama)', 'Self-Supervised Learning (JEPA)', 'Vision & Speech', 'PyTorch Ecosystem'],
      description: 'بزرگترین حامی هوش مصنوعی متن‌باز علمی در جهان، خالق سری مدل‌های Llama و فریم‌ورک محبوب PyTorch.',
      opportunityTypes: ['FAIR PhD Fellowship', 'Research Internships', 'Visiting Scholar']
    },
    {
      id: 'lab-msr',
      name: 'مایکروسافت ریسرچ (Microsoft Research - MSR)',
      englishName: 'Microsoft Research',
      region: 'world',
      organization: 'Microsoft Corp.',
      location: 'ردمونند، کمبریج (UK)، ردموند، پکن',
      websiteUrl: 'https://www.microsoft.com/en-us/research/',
      careersOrFellowshipUrl: 'https://www.microsoft.com/en-us/research/careers/',
      leadPeople: ['Peter Lee', 'Christopher Bishop'],
      focusAreas: ['Foundation Models for Science', 'Quantum Machine Learning', 'Code Intelligence (Copilot Research)'],
      description: 'از کهنه‌کارترین و موثرترین آزمایشگاه‌های تحقیقاتی جهان با انتشارات مداوم در کنفرانس‌های رده اول.',
      opportunityTypes: ['MSR PhD Fellowship Award', 'Research Intern (Summer/Fall)', 'Postdoc']
    },
    {
      id: 'lab-ai2',
      name: 'انستیتو هوش مصنوعی آلن (Allen Institute for AI - AI2)',
      englishName: 'Allen Institute for AI (AI2)',
      region: 'world',
      organization: 'Paul G. Allen Estate',
      location: 'سیاتل، واشینگتن، آمریکا',
      websiteUrl: 'https://allenai.org',
      careersOrFellowshipUrl: 'https://allenai.org/careers',
      leadPeople: ['Ali Farhadi (CEO)'],
      focusAreas: ['Open-Source LLMs (OLMo)', 'Semantic Scholar', 'Embodied AI (AI2-THOR)', 'Scientific NLP'],
      description: 'موسسه غیرانتفاعی برجسته متعهد به علم باز هوش مصنوعی، مدل‌های متن‌باز OLMo و دیتابیس عظیم سمانتیک اسکالر.',
      opportunityTypes: ['Predoctoral Young Investigator Program', 'Graduate Internships']
    },
    {
      id: 'lab-anthropic',
      name: 'آنتروپیک (Anthropic)',
      englishName: 'Anthropic Research',
      region: 'world',
      organization: 'Anthropic PBC',
      location: 'سانفرانسیسکو، آمریکا',
      websiteUrl: 'https://www.anthropic.com/research',
      careersOrFellowshipUrl: 'https://www.anthropic.com/careers',
      leadPeople: ['Dario Amodei', 'Daniela Amodei', 'Chris Olah'],
      focusAreas: ['Constitutional AI', 'Mechanistic Interpretability', 'Safety & Alignment', 'Claude Models'],
      description: 'پیشتاز درک سازوکار داخلی شبکه‌های عصبی (Mechanistic Interpretability) و هم‌راستاسازی ایمن مدل‌های بزرگ.',
      opportunityTypes: ['Research Fellowship', 'Residency in AI Safety', 'Engineering Internships']
    },
    {
      id: 'lab-mpi',
      name: 'موسسه ماکس پلانک برای سیستم‌های هوشمند (MPI-IS)',
      englishName: 'Max Planck Institute for Intelligent Systems',
      region: 'world',
      organization: 'Max Planck Society',
      location: 'اشتوتگارت و توبینگن، آلمان',
      websiteUrl: 'https://is.mpg.de',
      careersOrFellowshipUrl: 'https://imprs.is.mpg.de',
      leadPeople: ['Prof. Bernhard Schölkopf (Pioneer in Causal AI)', 'Prof. Michael J. Black'],
      focusAreas: ['Causal Inference & AI', 'Embodied Artificial Intelligence', 'Autonomous Motion Analysis'],
      description: 'معتبرترین موسسه تحقیقات بنیادی آلمان و اروپا در زمینه استنتاج علّی (Causality) و بینایی هوشمند.',
      opportunityTypes: ['IMPRS-IS PhD Program (فول‌فاند با مدرک دانشگاه‌های آلمان)']
    }
  ];

  readonly conferences: ConferenceItem[] = [
    // World Core A* Conferences
    {
      id: 'conf-neurips',
      name: 'کنفرانس سیستم‌های پردازش اطلاعات عصبی',
      acronym: 'NeurIPS',
      ranking: 'Core A* (h5-index: ~310)',
      field: 'یادگیری ماشین، تئوری و یادگیری عمیق',
      location: 'سن‌دیه‌گو، کالیفرنیا (و ونکوور)',
      conferenceDate: 'دسامبر هر سال (Dec)',
      submissionDeadline: 'اوایل خرداد / می (May 15-22)',
      websiteUrl: 'https://neurips.cc',
      submissionUrl: 'https://openreview.net/group?id=NeurIPS.cc',
      region: 'world',
      description: 'معتبرترین و بزرگترین کنفرانس هوش مصنوعی جهان با بالاترین میزان ارجاع و رقابت علمی.'
    },
    {
      id: 'conf-icml',
      name: 'کنفرانس بین‌المللی یادگیری ماشین',
      acronym: 'ICML',
      ranking: 'Core A* (h5-index: ~250)',
      field: 'یادگیری ماشین، بهینه‌سازی و مدل‌های آماری',
      location: 'وین / سئول / ونکوور',
      conferenceDate: 'تیر / جولای هر سال (July)',
      submissionDeadline: 'اوایل بهمن / ژانویه (Jan 25-30)',
      websiteUrl: 'https://icml.cc',
      submissionUrl: 'https://openreview.net/group?id=ICML.cc',
      region: 'world',
      description: 'یکی از دو گردهمایی اصلی جامعه آکادمیک برای مقالات تئوری و کاربردی بنیادین یادگیری ماشین.'
    },
    {
      id: 'conf-iclr',
      name: 'کنفرانس بین‌المللی یادگیری بازنمایی‌ها',
      acronym: 'ICLR',
      ranking: 'Core A* (h5-index: ~280)',
      field: 'یادگیری عمیق، شبکه‌های بازنمایی و مدل‌های مولد',
      location: 'سنگاپور / کیگالی / وین',
      conferenceDate: 'اردیبهشت / می هر سال (May)',
      submissionDeadline: 'اواخر شهریور / سپتامبر (Sep 25-30)',
      websiteUrl: 'https://iclr.cc',
      submissionUrl: 'https://openreview.net/group?id=ICLR.cc',
      region: 'world',
      description: 'تاسیس‌شده توسط یوشوا بنجیو و یان لکان، هاب اصلی مقالات خلاقانه معماری‌های شبکه عصبی با فرآیند بازداوری OpenReview.'
    },
    {
      id: 'conf-cvpr',
      name: 'کنفرانس بین‌المللی بینایی کامپیوتر و بازشناسی الگو',
      acronym: 'CVPR',
      ranking: 'Core A* (h5-index: ~380 - رتبه ۴ کل علوم جهان در Google Scholar)',
      field: 'بینایی ماشین، تولید تصویر و ویدیو، رندرینگ سه‌بعدی',
      location: 'سیاتل / نشویل / ونکوور',
      conferenceDate: 'خرداد / ژوئن هر سال (June)',
      submissionDeadline: 'اواسط آبان / نوامبر (Nov 10-15)',
      websiteUrl: 'https://cvpr.thecvf.com',
      submissionUrl: 'https://openaccess.thecvf.com',
      region: 'world',
      description: 'بزرگترین گردهمایی محققان پردازش تصویر و بینایی جهان با هزاران محقق و شرکت‌های بزرگ سیلیکون ولی.'
    },
    {
      id: 'conf-acl',
      name: 'انجمن زبان‌شناسی محاسباتی',
      acronym: 'ACL',
      ranking: 'Core A* (h5-index: ~190)',
      field: 'پردازش زبان طبیعی (NLP) و مدل‌های زبانی',
      location: 'بانکوک / تورنتو / وین',
      conferenceDate: 'مرداد / آگوست هر سال (August)',
      submissionDeadline: 'اواسط دی / ژانویه (Jan 15)',
      websiteUrl: 'https://www.aclweb.org',
      submissionUrl: 'https://openreview.net/group?id=aclweb.org/ACL',
      region: 'world',
      description: 'قله تحقیقات پردازش زبان‌های طبیعی، ترجمه ماشینی، خلاصه‌سازی و درک متن.'
    },
    {
      id: 'conf-emnlp',
      name: 'روش‌های تجربی در پردازش زبان طبیعی',
      acronym: 'EMNLP',
      ranking: 'Core A* (h5-index: ~180)',
      field: 'پردازش متن، استخراج اطلاعات و مدل‌های زبانی بزرگ',
      location: 'میامی / سنگاپور / ابوظبی',
      conferenceDate: 'آبان / نوامبر هر سال (November)',
      submissionDeadline: 'اواسط خرداد / ژوئن (June 15)',
      websiteUrl: 'https://www.emnlp.org',
      submissionUrl: 'https://openreview.net',
      region: 'world',
      description: 'کنفرانس بسیار معتبر تجربی NLP با بیشترین سهم در معرفی ابزارهای مدرن هوش مصنوعی زبانی.'
    },
    {
      id: 'conf-aaai',
      name: 'انجمن پیشبرد هوش مصنوعی آمریکا',
      acronym: 'AAAI',
      ranking: 'Core A* (h5-index: ~195)',
      field: 'هوش مصنوعی جامع، منطق، یادگیری، عامل‌ها',
      location: 'فیلادلفیا / ونکوور',
      conferenceDate: 'بهمن / فوریه هر سال (Feb)',
      submissionDeadline: 'مرداد / آگوست (Aug 15)',
      websiteUrl: 'https://aaai.org/conference/aaai/',
      submissionUrl: 'https://openreview.net',
      region: 'world',
      description: 'کنفرانس همه‌جانبه با قدمت بالا در تمام شاخه‌های هوش مصنوعی سنتی و مدرن.'
    },
    {
      id: 'conf-iccv',
      name: 'کنفرانس بین‌المللی بینایی کامپیوتر',
      acronym: 'ICCV',
      ranking: 'Core A* (دو سالانه)',
      field: 'بینایی ماشین، بازسازی سه‌بعدی و هوش بصری',
      location: 'پاریس / سئول / مونترال',
      conferenceDate: 'مهر / اکتبر (سال‌های فرد میلادی)',
      submissionDeadline: 'اسفند / مارس (March)',
      websiteUrl: 'https://iccv2025.thecvf.com',
      region: 'world',
      description: 'کنفرانس دو سال یک‌بار ممتاز که همراه CVPR و ECCV سه‌گانه طلایی بینایی را تشکیل می‌دهد.'
    },
    // Iran Reputable Conferences
    {
      id: 'conf-csicc',
      name: 'کنفرانس بین‌المللی سالانه انجمن کامپیوتر ایران',
      acronym: 'CSICC',
      ranking: 'معتبرترین کنفرانس ملی و بین‌المللی کامپیوتر در ایران (نمایه ISC و IEEE)',
      field: 'هوش مصنوعی، مهندسی نرم‌افزار، شبکه‌ها و داده',
      location: 'دانشگاه‌های برتر کشور به صورت چرخشی (شریف، تهران، امیرکبیر)',
      conferenceDate: 'اسفندماه هر سال',
      submissionDeadline: 'آذرماه هر سال',
      websiteUrl: 'https://csi.org.ir',
      region: 'iran',
      description: 'قدیمی‌ترین رویداد آکادمیک کامپیوتر ایران، بهترین بستر برای ارائه اولین مقالات ارشد علیرضا و دریافت فیدبک از داوران داخلی.'
    },
    {
      id: 'conf-icspis',
      name: 'کنفرانس بین‌المللی پردازش سیگنال و سیستم‌های هوشمند',
      acronym: 'ICSPIS',
      ranking: 'ملی / بین‌المللی با نمایه IEEE Xplore و ISC',
      field: 'پردازش صوت و تصویر، هوش مصنوعی، یادگیری ماشین',
      location: 'دانشگاه‌های کشور (امیرکبیر، علم و صنعت و صنعتی اصفهان)',
      conferenceDate: 'دی‌ماه هر سال',
      submissionDeadline: 'آبان‌ماه هر سال',
      websiteUrl: 'https://icspis.ir',
      region: 'iran',
      description: 'کنفرانس تخصصی با تاییدیه IEEE که مقالات انگلیسی پذیرفته‌شده مستقیماً در IEEE Xplore نمایه می‌شوند.'
    },
    {
      id: 'conf-pria',
      name: 'کنفرانس بین‌المللی بازشناسی الگو و پردازش تصویر ایران',
      acronym: 'PRIA',
      ranking: 'تخصصی انجمن ماشین بینایی و پردازش تصویر ایران (ISMVIP)',
      field: 'بینایی کامپیوتر، یادگیری عمیق در تصویر، تصویربرداری پزشکی',
      location: 'دانشگاه‌های منتخب ایران',
      conferenceDate: 'بهمن‌ماه (دو سالانه)',
      submissionDeadline: 'آبان‌ماه',
      websiteUrl: 'https://ismvip.ir',
      region: 'iran',
      description: 'رویداد تخصصی برای گرایش‌های بینایی ماشین و پردازش تصویر با حضور اساتید صاحب‌نام ایرانی.'
    }
  ];

  readonly tools: AcademicTool[] = [
    {
      id: 'tool-github',
      name: 'گیت‌هاب (GitHub) و Student Developer Pack',
      category: 'code',
      url: 'https://github.com',
      tagline: 'شناسنامه برنامه‌نویسی و پلتفرم کنترل نسخه بازمتن',
      description: 'میزبانی کدهای پایان‌نامه، بازتولید مقالات، گرفتن لایسنس رایگان ابزارهای پیشرفته با ایمیل دانشگاهی.',
      freeTier: true,
      benefitsForAlireza: 'اساتید برتر دنیا حتماً به اکانت گیت‌هاب نگاه می‌کنند. ایجاد ریپوزیتوری تمیز با Readme استاندارد برای پایان‌نامه الزامی است.'
    },
    {
      id: 'tool-overleaf',
      name: 'اورلیف (Overleaf - ابزار آنلاین LaTeX)',
      category: 'latex',
      url: 'https://www.overleaf.com',
      tagline: 'استاندارد جهانی نگارش مقالات علمی در علوم کامپیوتر',
      description: 'ویرایشگر آنلاین لاتک با قالب‌های آماده کنفرانس‌های IEEE, ACM, Springer, NeurIPS و کار گروهی با استاد راهنما.',
      freeTier: true,
      benefitsForAlireza: 'دیگر نیازی به نصب سنگین TeX Live نیست. تمام پیش‌نویس‌های مقاله و پروپوزال باید در اورلیف تایپ شوند.'
    },
    {
      id: 'tool-paperswithcode',
      name: 'پیپرز ویت کد (Papers With Code)',
      category: 'benchmarks',
      url: 'https://paperswithcode.com',
      tagline: 'ارتباط مستقیم بین مقالات آکادمیک و کدهای رسمی گیت‌هاب',
      description: 'جدول‌های مقایسه‌ای SOTA (State of the Art) برای تمام دیتاست‌ها و تسک‌های هوش مصنوعی همراه با کدهای پایتورچ.',
      freeTier: true,
      benefitsForAlireza: 'بهترین مرجع برای فصل چهارم پایان‌نامه علیرضا جهت مقایسه روش خود با بهترین مدل‌های روز دنیا بر روی دیتاست‌های استاندارد.'
    },
    {
      id: 'tool-huggingface',
      name: 'هاگینگ فیس (Hugging Face)',
      category: 'models',
      url: 'https://huggingface.co',
      tagline: 'گیت‌هاب دنیای هوش مصنوعی و مدل‌های یادگیری ماشین',
      description: 'میلیون‌ها وزن مدل آموزش‌دیده (Transformers, Diffusers)، هزاران دیتاست آماده، و امکان تست دمو در Spaces.',
      freeTier: true,
      benefitsForAlireza: 'بارگذاری سریع مدل‌های زبانی فارسی، ترنسفورمرهای بینایی و بارگیری دیتاست‌ها با چند خط کد در کتابخانه transformers.'
    },
    {
      id: 'tool-kaggle',
      name: 'کگل (Kaggle)',
      category: 'benchmarks',
      url: 'https://www.kaggle.com',
      tagline: 'بزرگترین جامعه دانشمندان داده و مسابقات جهانی یادگیری ماشین',
      description: 'دیتاست‌های فوق‌العاده متنوع، مسابقات یادگیری ماشین همراه با نوت‌بوک‌های با GPU رایگان T4/P100 تا ۳۰ ساعت در هفته.',
      freeTier: true,
      benefitsForAlireza: 'استفاده از پردازنده‌های گرافیکی رایگان برای ران کردن آزمایش‌های پایان‌نامه بدون نیاز به هزینه سخت‌افزار.'
    },
    {
      id: 'tool-colab',
      name: 'گوگل کولب (Google Colaboratory)',
      category: 'code',
      url: 'https://colab.research.google.com',
      tagline: 'محیط ژوپیتر نوت‌بوک ابری گوگل با کارت‌های گرافیک رایگان',
      description: 'اجرای کدهای پایتون و پایتورچ در محیط کلود بدون نیاز به نصب کتابخانه‌ها، متصل به گوگل درایو.',
      freeTier: true,
      benefitsForAlireza: 'تست اولیه ایده‌ها، اجرای آزمایش‌های کوچک و اشتراک‌گذاری آسان نوت‌بوک با استاد راهنما.'
    },
    {
      id: 'tool-zotero',
      name: 'زوترو (Zotero)',
      category: 'literature',
      url: 'https://www.zotero.org',
      tagline: 'بهترین نرم‌افزار مدیریت مراجع و ارجاع‌دهی مقالات',
      description: 'ذخیره خودکار مقالات با یک کلیک در مرورگر، استخراج BibTeX برای قرار دادن در LaTeX و سازمان‌دهی یادداشت‌های پژوهشی.',
      freeTier: true,
      benefitsForAlireza: 'مدیریت بیش از ۱۰۰ مقاله مورد مطالعه در طول ارشد و ساخت کتابخانه جامع مراجع با خروجی خودکار .bib'
    },
    {
      id: 'tool-connected-papers',
      name: 'کانکتد پیپرز (Connected Papers)',
      category: 'literature',
      url: 'https://www.connectedpapers.com',
      tagline: 'ترسیم بصری گراف ارتباط میان مقالات و کشف درخت پژوهش',
      description: 'با دادن یک مقاله اصلی، گرافی از مقالات قبلی، بعدی و نزدیک‌ترین پژوهش‌های هم‌راستا را ترسیم می‌کند.',
      freeTier: true,
      benefitsForAlireza: 'جلوگیری از جا افتادن مقالات کلیدی در مرور ادبیات موضوع (Literature Review) پایان‌نامه.'
    },
    {
      id: 'tool-wandb',
      name: 'ویتس اند باینسس (Weights & Biases - W&B)',
      category: 'experiments',
      url: 'https://wandb.ai',
      tagline: 'ردیابی و لاگ کردن آزمایش‌های یادگیری ماشین',
      description: 'پایش نمودارهای Loss، تغییرات هایپرپارامترها و مقایسه ران‌های مختلف مدل با ادغام در PyTorch.',
      freeTier: true,
      benefitsForAlireza: 'نشان دادن نمودارهای حرفه‌ای دقیق در مقالات و پایان‌نامه ارشد برای جلب نظر داوران سخت‌گیر.'
    }
  ];

  readonly defaultSkills: SkillItem[] = [
    // Phase 1
    {
      id: 'skill-1-1',
      phaseId: 1,
      title: 'تسلط عمیق بر پایتون ۳ و کتابخانه‌های علمی (NumPy, SciPy, Pandas)',
      description: 'کدنویسی برداری (Vectorized Code)، درک مدیریت حافظه در پایتون، بهینه‌سازی محاسبات ماتریسی.',
      category: 'core',
      completed: true
    },
    {
      id: 'skill-1-2',
      phaseId: 1,
      title: 'تسلط حرفه‌ای بر PyTorch و Autograd',
      description: 'نوشتن لایه‌های سفارشی، پیاده‌سازی Training Loop از صفر، استفاده از DataLoader سفارشی، آشنایی با Mixed Precision Training.',
      category: 'core',
      completed: true
    },
    {
      id: 'skill-1-3',
      phaseId: 1,
      title: 'مرور ریاضیات بنیادین (جبر خطی، گرادیان و بهینه‌سازی محدب)',
      description: 'تسلط بر تجزیه مقادیر منفرد (SVD)، ماتریس کوواریانس، قاعده زنجیره‌ای چندمتغیره، گرادیان کاهشی تصادفی (SGD, Adam).',
      category: 'core',
      completed: true
    },
    {
      id: 'skill-1-4',
      phaseId: 1,
      title: 'تسلط بر Git و لینوکس و Bash Scripting',
      description: 'مدیریت branchها، کار با سرور لینوکس ریموت از طریق SSH، دستورات htop, tmux, rsync و مانیتورینگ GPU با nvidia-smi.',
      category: 'core',
      completed: false
    },
    // Phase 2
    {
      id: 'skill-2-1',
      phaseId: 2,
      title: 'مطالعه هدفمند حداقل ۴۰ تا ۵۰ مقاله اخیر در حوزه پایان‌نامه',
      description: 'تشکیل جدول Literature Matrix در Zotero یا Excel شامل: مسئله، دیتاست، نوآوری، محدودیت‌ها، کد منبع.',
      category: 'research',
      completed: false
    },
    {
      id: 'skill-2-2',
      phaseId: 2,
      title: 'بازتولید (Reproduce) حداقل یک مقاله کنفرانس تراز اول (SOTA Baseline)',
      description: 'دانلود کد رسمی، ران کردن روی دیتاست، به دست آوردن همان اعداد گزارش‌شده در مقاله به منظور درک باگ‌ها و ریزه‌کاری‌ها.',
      category: 'research',
      completed: false
    },
    {
      id: 'skill-2-3',
      phaseId: 2,
      title: 'تدوین پروپوزال رسمی پایان‌نامه ارشد و تایید استاد راهنما در دانشگاه دزفول',
      description: 'تعریف فرضیه شفاف پژوهشی، فرمول‌بندی ریاضی نوآوری، برنامه زمان‌بندی آزمایش‌ها و استعلام در سامانه ایران‌داک.',
      category: 'research',
      completed: false
    },
    // Phase 3
    {
      id: 'skill-3-1',
      phaseId: 3,
      title: 'پیاده‌سازی نوآوری و مقایسه عددی دقیق با بیس‌لاین‌ها',
      description: 'اجرای تست‌های معناداری آماری (Ablation Studies, Statistical Significance)، سنجش پایداری با چند Seed مختلف.',
      category: 'research',
      completed: false
    },
    {
      id: 'skill-3-2',
      phaseId: 3,
      title: 'تسلط کامل بر نگارش آکادمیک در LaTeX با قالب رسمی IEEE / Elsevier',
      description: 'ساختار استاندارد مقاله: Abstract, Introduction, Related Work, Method, Experiments, Conclusion, References.',
      category: 'writing',
      completed: false
    },
    {
      id: 'skill-3-3',
      phaseId: 3,
      title: 'ارسال مقاله پژوهشی به ژورنال معتبر ISI (Q1/Q2) یا کنفرانس بین‌المللی',
      description: 'گرفتن تایید استاد راهنما، رعایت اصول داوری، آماده‌سازی کدهای آزمایش برای اشتراک‌گذاری جهت افزایش احتمال قبولی.',
      category: 'writing',
      completed: false
    },
    // Phase 4
    {
      id: 'skill-4-1',
      phaseId: 4,
      title: 'کسب مدرک زبان انگلیسی با نمره بالا (IELTS 7+ یا TOEFL 95+ یا MSRT 70+)',
      description: 'برنامه‌ریزی روزانه برای واژگان تخصصی، لیسنینگ و تقویت مهارت اسپیکینگ جهت آمادگی مصاحبه‌های دکتری.',
      category: 'language',
      completed: false
    },
    {
      id: 'skill-4-2',
      phaseId: 4,
      title: 'تدوین رزومه آکادمیک یکدست (Academic CV) به زبان انگلیسی در LaTeX',
      description: 'حاوی اطلاعات تحصیلی ارشد و کارشناسی، مقالات، علایق پژوهشی (Research Interests)، پروژه‌های برجسته و پیوند به مخزن کدها.',
      category: 'phd-prep',
      completed: false
    },
    {
      id: 'skill-4-3',
      phaseId: 4,
      title: 'نگارش انگیزه‌نامه پژوهشی هدفمند (Statement of Purpose - SOP)',
      description: 'پرهیز از کلی‌گویی و انشاهای احساسی؛ توضیح اینکه دقیقاً علیرضا چه مسئله‌ای را می‌خواهد حل کند و چرا آن استاد خاص.',
      category: 'writing',
      completed: false
    },
    // Phase 5
    {
      id: 'skill-5-1',
      phaseId: 5,
      title: 'تهیه فهرست ۳۰ استاد متناسب در دانشگاه‌های ایران و جهان',
      description: 'بررسی صفحات خانگی، گرنت‌های پژوهشی باز، مقالات اخیر سال جاری و موقعیت‌های دکتری اعلام‌شده.',
      category: 'phd-prep',
      completed: false
    },
    {
      id: 'skill-5-2',
      phaseId: 5,
      title: 'شروع مکاتبه هدفمند با اساتید (Academic Cold Emailing) با متن شخصی‌سازی‌شده',
      description: 'خوانش حداقل دو مقاله اخیر هر استاد، اشاره به اشتراک ایده و ارسال CV خلاصه با ایمیل دانشگاهی معتبر.',
      category: 'phd-prep',
      completed: false
    },
    {
      id: 'skill-5-3',
      phaseId: 5,
      title: 'آمادگی جامع برای مصاحبه علمی دکتری (مصاحبه سنجش / دانشگاه‌های خارج)',
      description: 'تسلط بی‌نقص بر جزئیات پایان‌نامه ارشد، پاسخ به سوالات پایه‌ای یادگیری عمیق و ارائه پرزنتیشن ۱۰ دقیقه‌ای شفاف.',
      category: 'phd-prep',
      completed: false
    }
  ];

  readonly defaultDeadlines: CalendarEvent[] = [
    {
      id: 'ev-us-deadlines',
      title: 'ددلاین پذیرش دکتری پاییز دانشگاه‌های آمریکا و کانادا (MIT, Stanford, CMU, Toronto)',
      type: 'phd_admission',
      deadlineDate: '2026-12-15',
      deadlineShamsi: '۲۴ آذر',
      priority: 'high',
      institutionOrOrg: 'دانشگاه‌های آمریکای شمالی',
      linkUrl: 'https://cs.stanford.edu/admissions/phd-admissions',
      notes: 'نیازمند آماده بودن نمرات تافل، ۳ ریکامندیشن و نسخه نهایی SOP.'
    },
    {
      id: 'ev-eth-fellowship',
      title: 'ددلاین بورسیه دکتری دپارتمان کامپیوتر ETH Zurich',
      type: 'phd_admission',
      deadlineDate: '2027-01-01',
      deadlineShamsi: '۱۱ دی',
      priority: 'high',
      institutionOrOrg: 'ETH Zurich (سوئیس)',
      linkUrl: 'https://inf.ethz.ch/doctorate/application.html',
      notes: 'بدون شهریه، فول فاند حقوقی کامل'
    },
    {
      id: 'ev-sanfesh-phd',
      title: 'آزمون نیمه‌متمرکز دکتری سراسری و آزاد سازمان سنجش کشور',
      type: 'exam',
      deadlineDate: '2027-03-05',
      deadlineShamsi: '۱۵ اسفند',
      priority: 'high',
      institutionOrOrg: 'سازمان سنجش آموزش کشور',
      linkUrl: 'https://sanjesh.org',
      notes: 'آزمون دروس تخصصی ارشد و کارشناسی + استعداد تحصیلی + زبان انگلیسی'
    },
    {
      id: 'ev-icml-sub',
      title: 'ددلاین سابمیت مقالات کنفرانس بین‌المللی ICML 2027',
      type: 'conference',
      deadlineDate: '2027-01-29',
      deadlineShamsi: '۹ بهمن',
      priority: 'medium',
      institutionOrOrg: 'ICML',
      linkUrl: 'https://icml.cc',
      notes: 'سابمیت متن کامل مقاله در سامانه OpenReview'
    },
    {
      id: 'ev-msrt-exam',
      title: 'ثبت‌نام آزمون زبان MSRT وزارت علوم (دوره بعدی)',
      type: 'exam',
      deadlineDate: '2026-11-20',
      deadlineShamsi: '۳۰ آبان',
      priority: 'medium',
      institutionOrOrg: 'سازمان امور دانشجویان وزارت علوم',
      linkUrl: 'https://portal.saorg.ir',
      notes: 'مدرک زبان لازم برای مصاحبه دکتری دانشگاه‌های برتر ایران (شریف، تهران و...)'
    },
    {
      id: 'ev-cvpr-sub',
      title: 'ددلاین سابمیت مقالات کنفرانس CVPR',
      type: 'conference',
      deadlineDate: '2026-11-14',
      deadlineShamsi: '۲۳ آبان',
      priority: 'medium',
      institutionOrOrg: 'CVPR / CVF',
      linkUrl: 'https://cvpr.thecvf.com',
      notes: 'بخش مقالات اصلی هوش بصری و بینایی کامپیوتر'
    },
    {
      id: 'ev-csicc-sub',
      title: 'ددلاین ارسال مقالات کنفرانس انجمن کامپیوتر ایران (CSICC)',
      type: 'conference',
      deadlineDate: '2026-12-05',
      deadlineShamsi: '۱۴ آذر',
      priority: 'medium',
      institutionOrOrg: 'انجمن کامپیوتر ایران',
      linkUrl: 'https://csi.org.ir',
      notes: 'فرصت عالی برای ارائه مقاله اول ارشد علیرضا و نمایه در ISC و IEEE'
    },
    {
      id: 'ev-talent-srbiau',
      title: 'فراخوان پذیرش بدون آزمون دکتری استعداد درخشان دانشگاه آزاد اسلامی',
      type: 'phd_admission',
      deadlineDate: '2027-04-15',
      deadlineShamsi: '۲۶ فروردین',
      priority: 'high',
      institutionOrOrg: 'مرکز سنجش و پذیرش دانشگاه آزاد (azmoon.iau.ir)',
      linkUrl: 'https://azmoon.iau.ir',
      notes: 'ویژه فارغ‌التحصیلان ارشد با معدل بالای ۱۷.۵ و نمره پایان‌نامه عالی جهت ورود به علوم و تحقیقات تهران'
    }
  ];

  readonly defaultPriorities = [
    { id: 'pri-1', text: 'نهایی‌کردن مرور پیشینه (Literature Review) در موضوع یادگیری عمیق پایان‌نامه', done: false, priority: 'high' as const },
    { id: 'pri-2', text: 'بازتولید کد بیس‌لاین پایتورچ مقاله شاخص در کولب یا سرور', done: false, priority: 'high' as const },
    { id: 'pri-3', text: 'مطالعه روزانه ۴۵ دقیقه لغات آکادمیک زبان انگلیسی و اصطلاحات مقاله', done: false, priority: 'medium' as const },
    { id: 'pri-4', text: 'بررسی صفحه اعضای هیئت علمی پژوهشکده هوش مصنوعی شریف و دانشگاه تهران', done: true, priority: 'medium' as const },
    { id: 'pri-5', text: 'ساخت اکانت Zotero و دسته‌بندی مراجع با برچسب‌های موضوعی', done: true, priority: 'low' as const }
  ];
}
