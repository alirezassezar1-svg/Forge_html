import { ChangeDetectionStrategy, Component, inject, HostListener } from '@angular/core';
import { StorageService } from './services/storage.service';
import { ThemeService } from './services/theme.service';
import { Header } from './components/header/header';
import { BottomNav } from './components/bottom-nav/bottom-nav';
import { Dashboard } from './components/dashboard/dashboard';
import { Universities } from './components/universities/universities';
import { Resources } from './components/resources/resources';
import { Labs } from './components/labs/labs';
import { Conferences } from './components/conferences/conferences';
import { ToolsSkills } from './components/tools-skills/tools-skills';
import { Calendar } from './components/calendar/calendar';
import { NotesModal } from './components/notes-modal/notes-modal';
import { SearchModal } from './components/search-modal/search-modal';
import { AdminModal } from './components/admin-modal/admin-modal';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    Header,
    BottomNav,
    Dashboard,
    Universities,
    Resources,
    Labs,
    Conferences,
    ToolsSkills,
    Calendar,
    NotesModal,
    SearchModal,
    AdminModal,
    MatIconModule
  ],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  readonly storage = inject(StorageService);
  readonly theme = inject(ThemeService);

  @HostListener('window:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      this.storage.isSearchOpen.update(v => !v);
    } else if (event.key === 'Escape') {
      if (this.storage.isSearchOpen()) this.storage.isSearchOpen.set(false);
      if (this.storage.isAdminOpen()) this.storage.isAdminOpen.set(false);
      if (this.storage.activeNoteItem()) this.storage.closeNoteModal();
    }
  }
}
