export type SectionTab = 
  | 'dashboard' 
  | 'universities' 
  | 'resources' 
  | 'labs' 
  | 'conferences' 
  | 'tools-skills' 
  | 'calendar';

export interface FacultyMember {
  name: string;
  title: string;
  specialty: string;
  profileUrl?: string;
  scholarUrl?: string;
}

export interface University {
  id: string;
  name: string;
  englishName: string;
  region: 'iran' | 'world';
  country: string;
  city: string;
  rankingText: string;
  admissionUrl: string;
  officialUrl: string;
  departments: string[];
  specializations: string[];
  admissionRequirements: string[];
  deadlinesSummary: string;
  examType?: string; // e.g. "کنکور دکتری تخصصی / استعداد درخشان" or "GRE/TOEFL"
  capacityInfo?: string;
  facultyMembers: FacultyMember[];
  tags: string[];
  notes?: string;
  isBookmarked?: boolean;
}

export interface AcademicResource {
  id: string;
  title: string;
  englishTitle: string;
  type: 'search-engine' | 'library' | 'iranian-portal' | 'textbook' | 'paper-repo';
  category: 'general' | 'math' | 'deep-learning' | 'ml' | 'nlp' | 'cv' | 'rl' | 'writing';
  url: string;
  description: string;
  authorOrProvider: string;
  accessType: 'free' | 'open-access' | 'institutional' | 'commercial';
  recommendedFor: string; // e.g., "شروع ارشد", "پایان‌نامه", "آمادگی دکتری"
  isBookmarked?: boolean;
}

export interface ResearchLab {
  id: string;
  name: string;
  englishName: string;
  region: 'iran' | 'world';
  organization: string; // e.g., "دانشگاه صنعتی شریف", "OpenAI"
  location: string;
  websiteUrl: string;
  careersOrFellowshipUrl?: string;
  leadPeople?: string[];
  focusAreas: string[];
  description: string;
  opportunityTypes: string[]; // e.g., "PhD Fellowship", "کارآموزی پژوهشی", "دستیار پژوهشی RA"
  isBookmarked?: boolean;
}

export interface ConferenceItem {
  id: string;
  name: string;
  acronym: string;
  ranking: string; // Core A*, Core A, Iranian National
  field: string; // "یادگیری ماشین", "پردازش زبان طبیعی", "بینایی ماشین", "چندمنظوره"
  location: string;
  conferenceDate: string;
  submissionDeadline: string;
  websiteUrl: string;
  submissionUrl?: string;
  region: 'world' | 'iran';
  description: string;
  isBookmarked?: boolean;
}

export interface AcademicTool {
  id: string;
  name: string;
  category: 'code' | 'latex' | 'benchmarks' | 'models' | 'literature' | 'experiments';
  url: string;
  tagline: string;
  description: string;
  freeTier: boolean;
  benefitsForAlireza: string;
  isBookmarked?: boolean;
}

export interface SkillItem {
  id: string;
  phaseId: 1 | 2 | 3 | 4 | 5;
  title: string;
  description: string;
  category: 'core' | 'research' | 'writing' | 'language' | 'phd-prep';
  completed: boolean;
  notes?: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  type: 'phd_admission' | 'conference' | 'exam' | 'term' | 'personal';
  deadlineDate: string; // YYYY-MM-DD
  deadlineShamsi: string;
  priority: 'high' | 'medium' | 'low';
  institutionOrOrg: string;
  linkUrl?: string;
  notes?: string;
  isCustom?: boolean;
}

export interface WeeklyPriority {
  id: string;
  text: string;
  done: boolean;
  dueDate?: string;
  priority: 'high' | 'medium' | 'low';
}

export interface CustomLink {
  id: string;
  title: string;
  url: string;
  category: 'university' | 'resource' | 'lab' | 'conference' | 'tool' | 'other';
  description?: string;
  createdAt: string;
}

export interface UserProfile {
  name: string;
  title: string;
  university: string;
  city: string;
  targetDegree: string;
  thesisTopic: string;
  targetTimeline: string;
  advisorContactTarget: number;
  papersTarget: number;
}
