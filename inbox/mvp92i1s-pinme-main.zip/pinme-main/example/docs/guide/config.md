# config
pinme -help