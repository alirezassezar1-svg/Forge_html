import React, { useState } from 'react';
import { TitaniumFinish } from '../../types/phone';
import { soundEffects } from '../../utils/soundEffects';
import { Camera, Flashlight, VolumeX, Sparkles, Sliders } from 'lucide-react';

interface IPhoneChassisProps {
  children: React.ReactNode;
  finish: TitaniumFinish;
  onPowerClick: () => void;
  onPowerLongPress: () => void;
  onActionButtonClick: () => void;
  onCameraControlClick: () => void;
  onVolumeUp: () => void;
  onVolumeDown: () => void;
  soundEnabled: boolean;
  brightness: number;
  flashlightOn: boolean;
}

export const IPhoneChassis: React.FC<IPhoneChassisProps> = ({
  children,
  finish,
  onPowerClick,
  onPowerLongPress,
  onActionButtonClick,
  onCameraControlClick,
  onVolumeUp,
  onVolumeDown,
  soundEnabled,
  brightness,
  flashlightOn,
}) => {
  const [actionButtonActive, setActionButtonActive] = useState(false);
  const [cameraControlHovered, setCameraControlHovered] = useState(false);

  // Titanium Chassis styles based on finish
  const FINISH_CONFIG = {
    desert: {
      outerBorder: 'border-[#B48860]',
      outerBg: 'bg-gradient-to-b from-[#C49B74] via-[#A87B54] to-[#8F643F]',
      bezelHighlight: 'from-[#DFBCA0]/30 to-[#8F643F]/20',
      shadowColor: 'rgba(180, 136, 96, 0.25)',
      buttonColor: 'bg-[#C49B74]',
      name: 'Desert Titanium',
    },
    black: {
      outerBorder: 'border-[#383735]',
      outerBg: 'bg-gradient-to-b from-[#403F3D] via-[#2A2927] to-[#1C1B1A]',
      bezelHighlight: 'from-white/10 to-transparent',
      shadowColor: 'rgba(0, 0, 0, 0.6)',
      buttonColor: 'bg-[#3A3937]',
      name: 'Black Titanium',
    },
    natural: {
      outerBorder: 'border-[#98928A]',
      outerBg: 'bg-gradient-to-b from-[#AFA9A1] via-[#948E86] to-[#7D776F]',
      bezelHighlight: 'from-white/20 to-[#6E6860]/20',
      shadowColor: 'rgba(152, 146, 138, 0.3)',
      buttonColor: 'bg-[#98928A]',
      name: 'Natural Titanium',
    },
    white: {
      outerBorder: 'border-[#D1D1D6]',
      outerBg: 'bg-gradient-to-b from-[#F2F2F7] via-[#E5E5EA] to-[#D1D1D6]',
      bezelHighlight: 'from-white/50 to-[#C7C7CC]/30',
      shadowColor: 'rgba(200, 200, 210, 0.3)',
      buttonColor: 'bg-[#E5E5EA]',
      name: 'White Titanium',
    },
  };

  const currentCfg = FINISH_CONFIG[finish];

  const handleActionPress = () => {
    setActionButtonActive(true);
    soundEffects.haptic(25);
    onActionButtonClick();
    setTimeout(() => setActionButtonActive(false), 300);
  };

  return (
    <div className="relative select-none flex items-center justify-center p-2 sm:p-4">
      {/* Phone Body with Titanium Edge */}
      <div
        className={`relative w-[390px] h-[812px] sm:w-[412px] sm:h-[860px] rounded-[56px] p-[10px] ${currentCfg.outerBg} shadow-2xl transition-all duration-500`}
        style={{
          boxShadow: `0 25px 60px -15px ${currentCfg.shadowColor}, 0 0 0 1px rgba(255,255,255,0.15) inset`,
        }}
      >
        {/* Brushed Titanium Specular Highlight Bevel */}
        <div className="absolute inset-0 rounded-[56px] pointer-events-none border border-white/20" />

        {/* LEFT HARDWARE BUTTONS */}
        {/* 1. Action Button (دکمه اکشن) */}
        <div className="absolute -left-[9px] top-[125px] flex flex-col items-center">
          <button
            onClick={handleActionPress}
            title="دکمه اکشن (Action Button)"
            className={`w-[6px] h-[34px] rounded-l-md transition-all ${
              actionButtonActive ? 'bg-amber-400 w-[4px]' : `${currentCfg.buttonColor} hover:brightness-125`
            }`}
          />
        </div>

        {/* 2. Volume Up */}
        <div className="absolute -left-[9px] top-[180px]">
          <button
            onClick={() => {
              soundEffects.click(soundEnabled);
              onVolumeUp();
            }}
            title="افزایش صدا"
            className={`w-[6px] h-[52px] rounded-l-md ${currentCfg.buttonColor} hover:brightness-125 active:w-[4px] transition-all`}
          />
        </div>

        {/* 3. Volume Down */}
        <div className="absolute -left-[9px] top-[242px]">
          <button
            onClick={() => {
              soundEffects.click(soundEnabled);
              onVolumeDown();
            }}
            title="کاهش صدا"
            className={`w-[6px] h-[52px] rounded-l-md ${currentCfg.buttonColor} hover:brightness-125 active:w-[4px] transition-all`}
          />
        </div>

        {/* RIGHT HARDWARE BUTTONS */}
        {/* 1. Side / Power Button */}
        <div className="absolute -right-[9px] top-[175px]">
          <button
            onClick={() => {
              soundEffects.click(soundEnabled);
              onPowerClick();
            }}
            onContextMenu={(e) => {
              e.preventDefault();
              onPowerLongPress();
            }}
            title="دکمه پاور (قفل/بازکردن) - کلیک راست برای سیری"
            className={`w-[6px] h-[78px] rounded-r-md ${currentCfg.buttonColor} hover:brightness-125 active:w-[4px] transition-all`}
          />
        </div>

        {/* 2. New iPhone 16 Pro "Camera Control" Button */}
        <div className="absolute -right-[9px] top-[540px] group">
          <button
            onClick={() => {
              soundEffects.cameraShutter(soundEnabled);
              onCameraControlClick();
            }}
            onMouseEnter={() => setCameraControlHovered(true)}
            onMouseLeave={() => setCameraControlHovered(false)}
            title="دکمه جدید کنترل دوربین (Camera Control)"
            className={`w-[6px] h-[64px] rounded-r-md transition-all ${
              cameraControlHovered
                ? 'bg-amber-400 shadow-md shadow-amber-400/50'
                : 'bg-neutral-800 border-l border-neutral-700 hover:brightness-150'
            }`}
          />
          {/* Tooltip hint on hover */}
          {cameraControlHovered && (
            <div className="absolute left-8 top-1/2 -translate-y-1/2 px-2.5 py-1 rounded-lg bg-black/90 border border-amber-400 text-[10px] text-amber-300 whitespace-nowrap shadow-xl z-50">
              Camera Control (لمس یا کلیک)
            </div>
          )}
        </div>

        {/* ULTRA-SLIM 1.15mm DISPLAY BEZEL CONTAINER */}
        <div
          className="w-full h-full rounded-[48px] bg-black p-[2.5px] relative overflow-hidden shadow-inner flex flex-col justify-between"
          style={{
            filter: `brightness(${brightness}%)`,
          }}
        >
          {/* Inner OLED Glass screen */}
          <div className="w-full h-full rounded-[46px] overflow-hidden relative bg-black flex flex-col">
            {children}
          </div>
        </div>

        {/* Antenna bands */}
        <div className="absolute left-0 top-[80px] w-2.5 h-[3px] bg-neutral-600/40" />
        <div className="absolute right-0 top-[80px] w-2.5 h-[3px] bg-neutral-600/40" />
        <div className="absolute left-0 bottom-[80px] w-2.5 h-[3px] bg-neutral-600/40" />
        <div className="absolute right-0 bottom-[80px] w-2.5 h-[3px] bg-neutral-600/40" />
      </div>
    </div>
  );
};
