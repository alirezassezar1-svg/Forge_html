import React, { useState, useRef } from 'react';
import {
  Search,
  Download,
  Check,
  Package,
  HardDrive,
  FileCode,
  Upload,
  RotateCcw,
  ShieldCheck,
  Star,
  Play,
  Share2,
  Trash2,
  Layers,
  ArrowRight,
  Database,
  Smartphone,
  ExternalLink,
} from 'lucide-react';
import { ApkPackage, AppLanguage, CustomApp, ProductItem, NoteItem, TitaniumFinish } from '../../types/phone';
import { t, formatDigits } from '../../utils/i18n';
import { soundEffects } from '../../utils/soundEffects';

interface GooglePlayApkAppProps {
  installedApps: CustomApp[];
  onInstallCustomApp: (app: CustomApp) => void;
  products: ProductItem[];
  onRestoreProducts: (prods: ProductItem[]) => void;
  notes: NoteItem[];
  onRestoreNotes: (notes: NoteItem[]) => void;
  language: AppLanguage;
  soundEnabled: boolean;
  titaniumFinish: TitaniumFinish;
  wallpaperUrl: string;
}

const PLAY_STORE_APPS: ApkPackage[] = [
  {
    id: 'apk_snapp',
    packageName: 'cab.snapp.passenger',
    appName: 'اسنپ (Snapp!)',
    versionName: 'v5.8.4',
    sizeMb: 24.2,
    icon: '🚕',
    category: 'سفر و حمل و نقل',
    rating: 4.7,
    downloads: '10M+',
    description: 'سوپراپلیکیشن جامع درخواست خودرو، موتور، وانت، سفارش غذا و خرید اقلام سوپرمارکت.',
    permissions: ['INTERNET', 'ACCESS_FINE_LOCATION', 'CAMERA', 'VIBRATE'],
  },
  {
    id: 'apk_digikala',
    packageName: 'com.digikala.mobile',
    appName: 'دیجی‌کالا (Digikala)',
    versionName: 'v3.1.2',
    sizeMb: 36.8,
    icon: '🛍️',
    category: 'خرید آنلاین و فروشگاه',
    rating: 4.6,
    downloads: '10M+',
    description: 'بزرگ‌ترین فروشگاه اینترنتی ایران با تنوع بیش از ۷ میلیون کالا و ارسال سریع کالا.',
    permissions: ['INTERNET', 'WAKE_LOCK', 'WRITE_EXTERNAL_STORAGE'],
  },
  {
    id: 'apk_torob',
    packageName: 'ir.torob',
    appName: 'ترب (Torob)',
    versionName: 'v4.2.0',
    sizeMb: 18.5,
    icon: '🥕',
    category: 'خرید و مقایسه قیمت',
    rating: 4.8,
    downloads: '5M+',
    description: 'موتور جستجوی هوشمند کالا و مقایسه قیمت میان صدها هزار فروشگاه معتبر.',
    permissions: ['INTERNET', 'ACCESS_NETWORK_STATE'],
  },
  {
    id: 'apk_divar',
    packageName: 'ir.divar',
    appName: 'دیوار (Divar)',
    versionName: 'v12.0.4',
    sizeMb: 22.0,
    icon: '🧱',
    category: 'نیازمندی‌ها و تجارت',
    rating: 4.5,
    downloads: '10M+',
    description: 'سامانه ثبت رایگان آگهی‌های خرید و فروش خودرو، مسکن، لوازم دیجیتال و استخدام.',
    permissions: ['INTERNET', 'CAMERA', 'ACCESS_COARSE_LOCATION'],
  },
  {
    id: 'apk_telegram',
    packageName: 'org.telegram.messenger',
    appName: 'Telegram Messenger',
    versionName: 'v10.14.0',
    sizeMb: 52.4,
    icon: '✈️',
    category: 'پیام‌رسان و ارتباطات',
    rating: 4.8,
    downloads: '1B+',
    description: 'پیام‌رسان پرسرعت، امن، رمزنگاری‌شده با کانال‌ها و قابلیت‌های پیشرفته هوش مصنوعی.',
    permissions: ['INTERNET', 'RECORD_AUDIO', 'CAMERA', 'READ_CONTACTS'],
  },
  {
    id: 'apk_whatsapp',
    packageName: 'com.whatsapp',
    appName: 'WhatsApp Messenger',
    versionName: 'v2.24.18',
    sizeMb: 46.1,
    icon: '💬',
    category: 'ارتباطات',
    rating: 4.4,
    downloads: '5B+',
    description: 'تماس صوتی و تصویری با کیفیت بالا، گروه‌های گفتگو و پیام‌رسانی امن.',
    permissions: ['INTERNET', 'CAMERA', 'RECORD_AUDIO', 'ACCESS_FINE_LOCATION'],
  },
  {
    id: 'apk_instagram',
    packageName: 'com.instagram.android',
    appName: 'Instagram',
    versionName: 'v340.0.0',
    sizeMb: 61.2,
    icon: '📷',
    category: 'شبکه اجتماعی',
    rating: 4.3,
    downloads: '5B+',
    description: 'اشتراک‌گذاری لحظات، تصاویر، ریلز و ارتباط با میلیون‌ها صفحه تجاری و محصولات.',
    permissions: ['INTERNET', 'CAMERA', 'RECORD_AUDIO', 'ACCESS_MEDIA_LOCATION'],
  },
  {
    id: 'apk_vscode',
    packageName: 'com.microsoft.vscode.mobile',
    appName: 'VS Code Mobile IDE',
    versionName: 'v1.94.0',
    sizeMb: 78.5,
    icon: '💻',
    category: 'ابزار توسعه‌دهندگان',
    rating: 4.9,
    downloads: '50M+',
    description: 'محیط کدنویسی سبک برای ویرایش کدهای JavaScript، Python، HTML و اجرای ترمینال.',
    permissions: ['INTERNET', 'MANAGE_EXTERNAL_STORAGE', 'FOREGROUND_SERVICE'],
  },
];

export const GooglePlayApkApp: React.FC<GooglePlayApkAppProps> = ({
  installedApps,
  onInstallCustomApp,
  products,
  onRestoreProducts,
  notes,
  onRestoreNotes,
  language,
  soundEnabled,
  titaniumFinish,
  wallpaperUrl,
}) => {
  const [activeTab, setActiveTab] = useState<'store' | 'installer' | 'backup'>('store');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedApk, setSelectedApk] = useState<ApkPackage | null>(null);

  // Installer state
  const [uploadedFile, setUploadedFile] = useState<{
    name: string;
    sizeMb: number;
    packageName: string;
    appName: string;
  } | null>(null);
  const [isInstalling, setIsInstalling] = useState(false);
  const [installSuccessMessage, setInstallSuccessMessage] = useState('');

  // Backup state
  const [backupNotice, setBackupNotice] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const restoreFileInputRef = useRef<HTMLInputElement>(null);

  const filteredApps = PLAY_STORE_APPS.filter(
    (app) =>
      app.appName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.packageName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      app.category.includes(searchQuery)
  );

  // Install APK package onto ALI phone
  const handleInstallApk = (apk: ApkPackage) => {
    soundEffects.click(soundEnabled);
    setIsInstalling(true);

    setTimeout(() => {
      const customApp: CustomApp = {
        id: `apk_${apk.packageName.replace(/\./g, '_')}`,
        name: apk.appName,
        nameFa: apk.appName,
        iconName: 'Package',
        color: 'from-emerald-600 to-teal-800',
        category: 'tools',
        type: 'calculator_tool',
        data: { apk },
      };
      onInstallCustomApp(customApp);
      setIsInstalling(false);
      soundEffects.notification(soundEnabled);
      setInstallSuccessMessage(`بسته ${apk.appName} با فرمت APK با موفقیت روی علی‌فون نصب شد!`);
      setTimeout(() => setInstallSuccessMessage(''), 3500);
    }, 800);
  };

  // Download official APK file
  const handleDownloadApkFile = (apk: ApkPackage) => {
    soundEffects.click(soundEnabled);
    const simulatedApkManifest = {
      header: 'ANDROID_PACKAGE_ARCHIVE_APK',
      packageName: apk.packageName,
      versionName: apk.versionName,
      architecture: 'arm64-v8a',
      targetSdk: 35,
      builtForDevice: 'ALI phone iPhone 16 Pro Max Simulation',
      permissions: apk.permissions,
      createdAt: new Date().toISOString(),
    };

    const blob = new Blob([JSON.stringify(simulatedApkManifest, null, 2)], {
      type: 'application/vnd.android.package-archive',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${apk.packageName}_${apk.versionName}.apk`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setInstallSuccessMessage(`فایل ${apk.packageName}.apk شروع به دانلود شد.`);
    setTimeout(() => setInstallSuccessMessage(''), 3000);
  };

  // Handle uploaded APK file from user's computer
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    soundEffects.click(soundEnabled);
    const cleanName = file.name.replace(/\.[^/.]+$/, '');
    const pkgName = `com.aliphone.${cleanName.toLowerCase().replace(/[^a-z0-9]/g, '')}`;

    setUploadedFile({
      name: file.name,
      sizeMb: parseFloat((file.size / (1024 * 1024)).toFixed(2)),
      packageName: pkgName,
      appName: cleanName,
    });
  };

  // Install the user's custom uploaded APK
  const handleInstallUploadedApk = () => {
    if (!uploadedFile) return;
    soundEffects.click(soundEnabled);
    setIsInstalling(true);

    setTimeout(() => {
      const customApp: CustomApp = {
        id: `custom_apk_${Date.now()}`,
        name: uploadedFile.appName,
        nameFa: uploadedFile.appName,
        iconName: 'Package',
        color: 'from-blue-600 to-indigo-800',
        category: 'tools',
        type: 'calculator_tool',
        data: { uploadedFile },
      };
      onInstallCustomApp(customApp);
      setIsInstalling(false);
      soundEffects.notification(soundEnabled);
      setInstallSuccessMessage(`برنامه اختصاصی ${uploadedFile.name} با موفقیت نصب گردید!`);
      setUploadedFile(null);
      setTimeout(() => setInstallSuccessMessage(''), 3500);
    }, 1000);
  };

  // Generate & Download Full System Backup File (.alibackup)
  const handleGenerateBackup = () => {
    soundEffects.click(soundEnabled);
    const backupData = {
      backupId: `ALI_BACKUP_${Date.now()}`,
      backupDate: new Date().toISOString(),
      deviceName: 'ALI phone - iPhone 16 Pro Max',
      chip: 'Apple A18 Pro',
      osVersion: 'ALI OS 18.2',
      installedApps,
      products,
      notes,
      settings: {
        language,
        titaniumFinish,
        wallpaperUrl,
        soundEnabled,
      },
    };

    const jsonString = JSON.stringify(backupData, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `aliphone_full_backup_${new Date().toISOString().split('T')[0]}.alibackup`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    soundEffects.notification(soundEnabled);
    setBackupNotice(t('gp_backup_success', language));
    setTimeout(() => setBackupNotice(''), 4000);
  };

  // Restore from uploaded .alibackup / JSON file
  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    soundEffects.click(soundEnabled);
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.products && Array.isArray(parsed.products)) {
          onRestoreProducts(parsed.products);
        }
        if (parsed.notes && Array.isArray(parsed.notes)) {
          onRestoreNotes(parsed.notes);
        }
        soundEffects.notification(soundEnabled);
        setBackupNotice(t('gp_restore_success', language));
        setTimeout(() => setBackupNotice(''), 4500);
      } catch (err) {
        alert('فایل پشتیبان نامعتبر است یا ساختار فایل مخدوش می‌باشد.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="h-full flex flex-col bg-neutral-950 text-white select-none">
      {/* Top Header - Google Play branding */}
      <div className="pt-13 px-4 pb-2 border-b border-neutral-800 bg-neutral-900/90 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {/* Official Google Play multicolor triangle */}
          <div className="w-8 h-8 rounded-xl bg-neutral-800 border border-neutral-700/80 flex items-center justify-center shadow-md">
            <svg viewBox="0 0 24 24" className="w-5 h-5">
              <path fill="#4285F4" d="M3.6 2.1c-.2.2-.4.6-.4 1v17.8c0 .4.2.8.4 1l9.9-9.9L3.6 2.1z" />
              <path fill="#FBBC05" d="M17.4 8.2l-3.9 3.9 3.9 3.9 4.3-2.5c1.2-.7 1.2-1.8 0-2.5l-4.3-2.8z" />
              <path fill="#34A853" d="M13.5 12.1L3.6 22c.4.4 1.1.5 1.8.1l12-6.9-3.9-3.1z" />
              <path fill="#EA4335" d="M13.5 12.1l3.9-3.9L5.4 1.3C4.7.9 4 1 3.6 1.4l9.9 10.7z" />
            </svg>
          </div>
          <div>
            <h1 className="text-sm font-bold text-white tracking-tight">{t('gp_title', language)}</h1>
            <p className="text-[10px] text-neutral-400">Google Play Store & APK Engine</p>
          </div>
        </div>
        <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-mono">
          APK v35
        </span>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-1 p-2 bg-neutral-900 border-b border-neutral-800 text-xs">
        <button
          onClick={() => setActiveTab('store')}
          className={`flex-1 py-1.5 rounded-lg font-medium transition-colors ${
            activeTab === 'store' ? 'bg-neutral-800 text-emerald-400 font-bold shadow-sm' : 'text-neutral-400 hover:text-white'
          }`}
        >
          {t('gp_tab_store', language)}
        </button>
        <button
          onClick={() => setActiveTab('installer')}
          className={`flex-1 py-1.5 rounded-lg font-medium transition-colors ${
            activeTab === 'installer' ? 'bg-neutral-800 text-blue-400 font-bold shadow-sm' : 'text-neutral-400 hover:text-white'
          }`}
        >
          {t('gp_tab_installer', language)}
        </button>
        <button
          onClick={() => setActiveTab('backup')}
          className={`flex-1 py-1.5 rounded-lg font-medium transition-colors ${
            activeTab === 'backup' ? 'bg-neutral-800 text-amber-400 font-bold shadow-sm' : 'text-neutral-400 hover:text-white'
          }`}
        >
          {t('gp_tab_backup', language)}
        </button>
      </div>

      {/* Success Notification Bar */}
      {(installSuccessMessage || backupNotice) && (
        <div className="mx-4 mt-3 p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-fadeIn">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{installSuccessMessage || backupNotice}</span>
        </div>
      )}

      {/* Main Tab Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* TAB 1: Google Play Store */}
        {activeTab === 'store' && (
          <div className="space-y-4">
            {/* Search Bar */}
            <div className="relative">
              <Search className="w-4 h-4 text-neutral-400 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('gp_search', language)}
                className="w-full bg-neutral-900 border border-neutral-700/80 rounded-2xl pr-9 pl-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* Android / APK Package List */}
            <div className="space-y-2.5">
              {filteredApps.map((apk) => {
                const isInstalled = installedApps.some(
                  (a) => a.id === `apk_${apk.packageName.replace(/\./g, '_')}`
                );

                return (
                  <div
                    key={apk.id}
                    className="p-3.5 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 transition-colors flex flex-col gap-2.5 shadow-md"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-3">
                        <span className="text-3xl shrink-0 p-1 bg-neutral-800 rounded-xl">{apk.icon}</span>
                        <div>
                          <h4 className="text-xs font-bold text-white">{apk.appName}</h4>
                          <p className="text-[10px] text-neutral-400 font-mono">{apk.packageName}</p>
                          <div className="flex items-center gap-2 text-[10px] text-neutral-400 mt-1">
                            <span className="text-amber-400 flex items-center gap-0.5 font-bold">
                              <Star className="w-3 h-3 fill-amber-400" />
                              {apk.rating}
                            </span>
                            <span>·</span>
                            <span>{apk.downloads} دانلود</span>
                            <span>·</span>
                            <span className="font-mono">{apk.sizeMb} MB</span>
                          </div>
                        </div>
                      </div>

                      <span className="text-[10px] px-2 py-0.5 rounded bg-neutral-800 text-neutral-400 font-mono">
                        {apk.versionName}
                      </span>
                    </div>

                    <p className="text-[11px] text-neutral-400 line-clamp-2 leading-relaxed">
                      {apk.description}
                    </p>

                    {/* Actions: Install APK & Download .apk */}
                    <div className="flex items-center justify-between pt-2 border-t border-neutral-800 text-xs">
                      <div className="flex items-center gap-2">
                        {isInstalled ? (
                          <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-[11px] font-bold flex items-center gap-1">
                            <Check className="w-3.5 h-3.5" />
                            <span>{t('installed', language)}</span>
                          </span>
                        ) : (
                          <button
                            onClick={() => handleInstallApk(apk)}
                            disabled={isInstalling}
                            className="px-3.5 py-1.5 rounded-full bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs flex items-center gap-1 shadow-md active:scale-95 transition-all"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>{t('gp_install_apk', language)}</span>
                          </button>
                        )}

                        <button
                          onClick={() => handleDownloadApkFile(apk)}
                          className="px-3 py-1 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-300 text-[11px] font-medium flex items-center gap-1 border border-neutral-700"
                          title="دانلود فایل خام APK"
                        >
                          <FileCode className="w-3.5 h-3.5 text-emerald-400" />
                          <span>دانلود فایل .apk</span>
                        </button>
                      </div>

                      <button
                        onClick={() => setSelectedApk(selectedApk?.id === apk.id ? null : apk)}
                        className="text-[11px] text-neutral-400 hover:text-white"
                      >
                        {selectedApk?.id === apk.id ? 'بستن مجوزها' : 'مجوزها ↵'}
                      </button>
                    </div>

                    {/* Expandable Permissions view */}
                    {selectedApk?.id === apk.id && (
                      <div className="p-2.5 rounded-xl bg-neutral-800/80 border border-neutral-700 text-[10px] space-y-1 mt-1">
                        <p className="font-semibold text-neutral-300">{t('gp_permissions', language)}:</p>
                        <div className="flex flex-wrap gap-1">
                          {apk.permissions.map((perm) => (
                            <span key={perm} className="px-2 py-0.5 rounded bg-neutral-900 text-neutral-400 font-mono">
                              {perm}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 2: APK Sideload & File Installer */}
        {activeTab === 'installer' && (
          <div className="space-y-4">
            <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
              <div className="flex items-center gap-2 text-blue-400">
                <FileCode className="w-5 h-5" />
                <h3 className="text-sm font-bold text-white">نصب بسته دلخواه با فرمت APK</h3>
              </div>
              <p className="text-xs text-neutral-400 leading-relaxed">
                می‌توانید هر فایل نصبی با پسوند <span className="text-blue-400 font-mono">.apk</span> یا <span className="text-blue-400 font-mono">.zip</span> را از رایانه خود بارگذاری کرده و به صورت مستقیم روی پردازنده A18 Pro شبیه‌ساز علی‌فون اجرا نمایید.
              </p>

              {/* Upload Dropzone */}
              <div
                onClick={() => fileInputRef.current?.click()}
                className="p-6 rounded-2xl border-2 border-dashed border-neutral-700 hover:border-blue-500 bg-neutral-800/50 text-center cursor-pointer transition-colors space-y-2"
              >
                <Upload className="w-8 h-8 text-blue-400 mx-auto" />
                <p className="text-xs font-semibold text-white">{t('gp_drop_apk', language)}</p>
                <p className="text-[10px] text-neutral-400">پشتیبانی کامل از ساختار بسته APK و امضای اندروید</p>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".apk,.zip"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>

              {/* Uploaded File Manifest Details */}
              {uploadedFile && (
                <div className="p-3.5 rounded-2xl bg-neutral-800 border border-blue-500/40 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">{uploadedFile.name}</span>
                    <span className="text-[10px] text-blue-400 font-mono">{uploadedFile.sizeMb} MB</span>
                  </div>
                  <div className="text-[10px] text-neutral-400 space-y-1">
                    <p>شناسه بسته شبیه‌سازی: <span className="font-mono text-neutral-300">{uploadedFile.packageName}</span></p>
                    <p className="text-emerald-400 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>سازگار با معماری ARM64 و چیپ A18 Pro علی‌فون</span>
                    </p>
                  </div>

                  <button
                    onClick={handleInstallUploadedApk}
                    disabled={isInstalling}
                    className="w-full py-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-lg"
                  >
                    <Download className="w-4 h-4" />
                    <span>نصب فوری روی صفحه اصلی علی‌فون</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 3: Full Backup & Restore System */}
        {activeTab === 'backup' && (
          <div className="space-y-4">
            {/* Backup Generation Card */}
            <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
              <div className="flex items-center gap-2 text-amber-400">
                <Database className="w-5 h-5" />
                <h3 className="text-sm font-bold text-white">پشتیبان‌گیری جامع سیستم و محصولات</h3>
              </div>
              <p className="text-xs text-neutral-400 leading-relaxed">
                از تمامی محصولات ثبت‌شده، بسته‌های APK نصب‌شده، یادداشت‌ها، لیست ابزارها و تنظیمات علی‌فون نسخه پشتیبان کامل تهیه کنید و در رایانه خود ذخیره نمایید.
              </p>

              {/* Backup Stats */}
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2.5 rounded-xl bg-neutral-800/80 border border-neutral-700/60">
                  <p className="text-[10px] text-neutral-400">محصولات انبار</p>
                  <p className="text-sm font-bold text-amber-400 font-mono mt-0.5">{products.length}</p>
                </div>
                <div className="p-2.5 rounded-xl bg-neutral-800/80 border border-neutral-700/60">
                  <p className="text-[10px] text-neutral-400">برنامه‌ها و APK</p>
                  <p className="text-sm font-bold text-emerald-400 font-mono mt-0.5">{installedApps.length}</p>
                </div>
                <div className="p-2.5 rounded-xl bg-neutral-800/80 border border-neutral-700/60">
                  <p className="text-[10px] text-neutral-400">یادداشت‌ها</p>
                  <p className="text-sm font-bold text-purple-400 font-mono mt-0.5">{notes.length}</p>
                </div>
              </div>

              <button
                onClick={handleGenerateBackup}
                className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-black font-bold text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all"
              >
                <Download className="w-4 h-4" />
                <span>{t('gp_backup_btn', language)}</span>
              </button>
            </div>

            {/* Restore Card */}
            <div className="p-4 rounded-3xl bg-neutral-900 border border-neutral-800 space-y-3">
              <div className="flex items-center gap-2 text-emerald-400">
                <RotateCcw className="w-5 h-5" />
                <h3 className="text-sm font-bold text-white">بازیابی اطلاعات (Restore Backup)</h3>
              </div>
              <p className="text-xs text-neutral-400 leading-relaxed">
                فایل بکاپ دانلود‌شده (<span className="text-amber-400 font-mono">.alibackup</span> یا <span className="text-amber-400 font-mono">.json</span>) را انتخاب کنید تا تمامی اطلاعات بلافاصله در گوشی بازنشانی شوند.
              </p>

              <div
                onClick={() => restoreFileInputRef.current?.click()}
                className="p-4 rounded-2xl border border-dashed border-neutral-700 hover:border-emerald-500 bg-neutral-800/40 text-center cursor-pointer transition-colors"
              >
                <Upload className="w-6 h-6 text-emerald-400 mx-auto mb-1" />
                <span className="text-xs font-semibold text-neutral-200">{t('gp_restore_btn', language)}</span>
                <input
                  ref={restoreFileInputRef}
                  type="file"
                  accept=".alibackup,.json"
                  onChange={handleRestoreFile}
                  className="hidden"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
