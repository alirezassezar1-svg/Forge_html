import React, { useState } from 'react';
import {
  Search,
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Share2,
  Bookmark,
  ShieldCheck,
  ExternalLink,
  Globe,
  Compass,
} from 'lucide-react';
import { soundEffects } from '../../utils/soundEffects';

interface SafariAppProps {
  initialUrl?: string;
  soundEnabled: boolean;
}

export const SafariApp: React.FC<SafariAppProps> = ({
  initialUrl = 'https://google.com',
  soundEnabled,
}) => {
  const [urlInput, setUrlInput] = useState(initialUrl);
  const [currentUrl, setCurrentUrl] = useState(initialUrl);
  const [isLoading, setIsLoading] = useState(false);

  const BOOKMARKS = [
    { title: 'Google', url: 'https://www.google.com/search?igu=1', icon: '🔍' },
    { title: 'ویکی‌پدیا فارسی', url: 'https://fa.m.wikipedia.org', icon: '📚' },
    { title: 'آب و هوا و ماهواره', url: 'https://zoom.earth', icon: '🌍' },
    { title: 'ماشین‌حساب نمودار', url: 'https://www.desmos.com/calculator', icon: '📈' },
  ];

  const handleNavigate = (targetUrl: string) => {
    soundEffects.click(soundEnabled);
    let formatted = targetUrl.trim();
    if (!formatted.startsWith('http://') && !formatted.startsWith('https://')) {
      if (formatted.includes('.') && !formatted.includes(' ')) {
        formatted = `https://${formatted}`;
      } else {
        formatted = `https://www.google.com/search?q=${encodeURIComponent(formatted)}&igu=1`;
      }
    }
    setUrlInput(formatted);
    setCurrentUrl(formatted);
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 800);
  };

  const handleReload = () => {
    soundEffects.click(soundEnabled);
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 600);
  };

  return (
    <div className="h-full flex flex-col bg-neutral-950 text-white select-none">
      {/* Top Address Bar (iOS Safari) */}
      <div className="pt-13 px-4 pb-2 bg-neutral-900 border-b border-neutral-800 space-y-2">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleNavigate(urlInput);
          }}
          className="relative flex items-center"
        >
          <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1.5 text-neutral-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <input
            type="text"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            placeholder="جستجو یا وارد کردن آدرس وب..."
            className="w-full bg-neutral-800 border border-neutral-700/80 rounded-2xl pr-8 pl-8 py-2 text-xs text-white placeholder-neutral-500 font-mono text-left focus:outline-none focus:border-blue-500"
            dir="ltr"
          />
          <button
            type="button"
            onClick={handleReload}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white"
          >
            <RotateCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </form>
      </div>

      {/* Main Web Viewport */}
      <div className="flex-1 relative bg-white overflow-hidden flex flex-col">
        {currentUrl.includes('google') || currentUrl.includes('wikipedia') || currentUrl.includes('zoom.earth') || currentUrl.includes('desmos') ? (
          <iframe
            src={currentUrl}
            title="Safari Viewer"
            className="w-full h-full border-0"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
          />
        ) : (
          <div className="h-full bg-neutral-950 text-white p-5 flex flex-col justify-between overflow-y-auto">
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-blue-400 text-xs font-semibold">
                <Compass className="w-4 h-4" />
                <span>صفحه شروع Safari</span>
              </div>

              {/* Bookmarks Grid */}
              <div>
                <h4 className="text-xs font-semibold text-neutral-400 mb-2.5">علاقه‌مندی‌ها و ابزارهای سریع</h4>
                <div className="grid grid-cols-4 gap-3 text-center">
                  {BOOKMARKS.map((b, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleNavigate(b.url)}
                      className="flex flex-col items-center gap-1.5 p-2 rounded-2xl bg-neutral-900 border border-neutral-800 hover:border-neutral-700 transition-colors"
                    >
                      <span className="text-2xl">{b.icon}</span>
                      <span className="text-[10px] text-neutral-300 font-medium truncate w-full">{b.title}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Web Tool Sandbox Info */}
              <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800 space-y-2">
                <h4 className="text-xs font-bold text-white flex items-center gap-2">
                  <Globe className="w-4 h-4 text-emerald-400" />
                  <span>پشتیبانی از اجرای ابزارهای وب اختصاصی شما</span>
                </h4>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  می‌توانید هر آدرس اینترنتی یا ابزار آنلاینی را در نوار آدرس بالا وارد کنید یا از طریق "اپ استور علی‌فون" آن را به عنوان یک برنامه مستقل نصب نمایید.
                </p>
                <div className="pt-2">
                  <button
                    onClick={() => handleNavigate('https://fa.m.wikipedia.org')}
                    className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium"
                  >
                    مشاهده دانشنامه ویکی‌پدیا
                  </button>
                </div>
              </div>
            </div>

            <div className="text-center text-[10px] text-neutral-500 py-2">
              Safari ALI OS · موتور وب بهینه‌شده A18 Pro
            </div>
          </div>
        )}
      </div>

      {/* Bottom Safari Bar */}
      <div className="h-11 bg-neutral-900 border-t border-neutral-800 flex items-center justify-around px-4 text-neutral-400">
        <button
          onClick={() => soundEffects.click(soundEnabled)}
          className="p-1 hover:text-white"
        >
          <ArrowRight className="w-4 h-4" />
        </button>
        <button
          onClick={() => soundEffects.click(soundEnabled)}
          className="p-1 hover:text-white"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <button
          onClick={() => handleNavigate('https://google.com')}
          className="p-1 hover:text-white"
        >
          <Compass className="w-4 h-4" />
        </button>
        <button
          onClick={() => soundEffects.click(soundEnabled)}
          className="p-1 hover:text-white"
        >
          <Bookmark className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
