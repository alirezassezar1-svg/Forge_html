<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/ae1a41e0-f002-40b0-b9b9-78263793267e

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`

## PWA / نصب به‌عنوان اپ

- `npm run build && NODE_ENV=production npm start` (باید روی **HTTPS** یا localhost سرو شود تا نصب فعال شود)
- Android/Chrome/Edge: دکمه‌ی «نصب برنامه» یا منوی مرورگر. iPhone/Safari: Share ← Add to Home Screen
- روی گوشی واقعی یا نسخه‌ی نصب‌شده، گوشی تمام‌صفحه و بدون قاب اجرا می‌شود (بالا را به پایین بکشید = Control Center، دوبار تپ بالا = قفل، نگه‌داشتن نوار پایین = Siri)
- داده‌های واقعی: باتری، شبکه، ساعت/تقویم، آب‌وهوا (Open-Meteo)، دوربین، چراغ‌قوه، موزیک (WebAudio + فایل‌های خودتان)
