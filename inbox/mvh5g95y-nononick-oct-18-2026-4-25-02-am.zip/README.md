# Code Isolation & Cleanup Workbench V1.0

A mobile-first, privacy-focused, zero-telemetry web workbench engineered to import legacy source code and multi-file projects, format code, analyze AST syntax and dependencies, isolate inline scripts/styles into clean modular architectures, validate transformations with line-by-line diffs, and safely export results.

---

## 🌟 Key Capabilities

1. **Multi-Source Ingestion & Robust Path Traversal Protection**
   - Import code via direct text paste, individual files, multi-file selection, entire directory trees (`webkitdirectory`), or `.ZIP` archives.
   - Strict security filtering: automatically rejects directory traversal attempts (`../`, `..\`), absolute root paths (`/etc/`, `C:\`), null bytes (`\0`), and duplicate collisions.
   - Configurable safety limits: 250 files maximum, 25MB decompressed size, 5MB per-file maximum.

2. **Language Detection & Diagnostic Reporting**
   - Heuristic and extension-based detection for JavaScript, TypeScript, JSX, HTML, CSS, JSON, Markdown, and configuration files.
   - Transparently flags unsupported or ambiguous files with actionable diagnostic guidance.

3. **Dual Processing Modes**
   - **Format Only Mode**: Uses Prettier Standalone with custom indentation (2/4/tabs), semicolon preferences, and quote styles. Guarantees code logic and module boundaries remain untouched.
   - **Modularize & Isolate Mode**:
     * Extracts inline `<script>` and `<style>` blocks from HTML into dedicated standalone files (`scripts/app-module-*.js`, `styles/theme-style-*.css`) and updates references.
     * Analyzes CommonJS (`require()`, `module.exports`) and converts to standard ES Module syntax (`import`, `export`).
     * Detects and isolates global variable assignments (`window.foo = ...`).

4. **Topology & Dependency Graph Engine**
   - Visual SVG topology map with interactive node inspection.
   - Automatic detection of:
     * Circular dependency chains (cycles)
     * Missing file references
     * Dynamic imports (`import()`, dynamic `require()`)
     * Global scope pollution risks

5. **Human-in-the-Loop Transformation Planning**
   - Generates a concrete transformation plan before touching any files.
   - Interactive review modal allows users to inspect individual actions, risk levels, and toggle specific modifications on or off.
   - Strict user approval gate: changes are never applied without explicit confirmation. Original files are always kept in memory.

6. **Side-by-Side & Unified Line Diffs**
   - Full Myers LCS line-level diff calculation.
   - Dual viewing modes: Split (side-by-side) and Unified.
   - Color-coded addition and deletion statistics (+lines / -lines).

7. **Post-Transformation Validation & Secret Scanning**
   - Acorn AST validation for JavaScript syntax errors.
   - CSS brace balance and block validation.
   - Asset reference integrity checking across all output files.
   - Best-effort secret and credential detection (AWS Access Keys, Google API keys, bearer tokens, private key headers) with automatic redactions.
   - Explicit semantic equivalence disclaimer.

8. **Export Options**
   - Export Complete Project ZIP: includes transformed code, `README.md`, `analysis-report.json`, and `transformation-report.md`.
   - Export Single Self-Contained File (inlined HTML or bundled script).
   - Download Standalone Offline Workbench ZIP.

9. **Bilingual English (LTR) & Persian فارسی (RTL)**
   - Complete localized interface with RTL layout flipping and Vazirmatn font support.

10. **Built-in Automated Acceptance Test Suite**
    - 10 comprehensive in-browser tests with genuine assertions verifying syntax parsing, idempotence, path traversal rejection, dependency cycle detection, archive extraction integrity, and offline isolation.

---

## 🔒 Security & Privacy Policy

- **100% Client-Side Processing**: All parsing, AST manipulation, and file compression occur strictly inside your local browser tab.
- **Zero Telemetry**: No tracking, analytics, or external API calls.
- **Opt-in Storage**: Project state is only saved to browser IndexedDB when the user explicitly clicks "Save".

---

## 📄 License
MIT License. Pinned local dependencies: Acorn (MIT), JSZip (MIT/GPL-3), Prettier Standalone (MIT).
