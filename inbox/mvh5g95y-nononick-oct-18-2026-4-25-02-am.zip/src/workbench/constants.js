// ============================================================================
// Code Isolation & Cleanup Workbench V1.0 - Constants & Sample Fixtures
// ============================================================================

export const APP_VERSION = '1.0.0';
export const APP_NAME = 'Code Isolation & Cleanup Workbench';
export const APP_TITLE_FA = 'میزکار جداسازی و پاک‌سازی کد';

export const DEFAULT_LIMITS = {
  maxFiles: 250,              // Max file count in archive
  maxDecompressedBytes: 25 * 1024 * 1024, // 25 MB max decompressed
  maxSingleFileBytes: 5 * 1024 * 1024,    // 5 MB max single file
  maxLinesForDiff: 5000       // Max lines for synchronous line-by-line diff
};

export const DEFAULT_FORMAT_OPTIONS = {
  indentSize: 2,
  useTabs: false,
  semi: true,
  singleQuote: true,
  printWidth: 80,
  trailingComma: 'es5'
};

export const SUPPORTED_LANGUAGES = {
  javascript: {
    id: 'javascript',
    label: 'JavaScript',
    extensions: ['.js', '.mjs', '.cjs'],
    mime: 'text/javascript',
    canFormat: true,
    canParseAST: true,
    canModularize: true
  },
  typescript: {
    id: 'typescript',
    label: 'TypeScript',
    extensions: ['.ts', '.tsx', '.mts', '.cts'],
    mime: 'text/typescript',
    canFormat: true,
    canParseAST: true,
    canModularize: true
  },
  jsx: {
    id: 'jsx',
    label: 'JSX',
    extensions: ['.jsx'],
    mime: 'text/jsx',
    canFormat: true,
    canParseAST: true,
    canModularize: true
  },
  html: {
    id: 'html',
    label: 'HTML',
    extensions: ['.html', '.htm'],
    mime: 'text/html',
    canFormat: true,
    canParseAST: true,
    canModularize: true
  },
  css: {
    id: 'css',
    label: 'CSS',
    extensions: ['.css'],
    mime: 'text/css',
    canFormat: true,
    canParseAST: true,
    canModularize: true
  },
  json: {
    id: 'json',
    label: 'JSON',
    extensions: ['.json'],
    mime: 'application/json',
    canFormat: true,
    canParseAST: true,
    canModularize: false
  },
  markdown: {
    id: 'markdown',
    label: 'Markdown',
    extensions: ['.md', '.markdown'],
    mime: 'text/markdown',
    canFormat: false,
    canParseAST: false,
    canModularize: false
  },
  text: {
    id: 'text',
    label: 'Plain Text / Config',
    extensions: ['.txt', '.env', '.conf', '.ini'],
    mime: 'text/plain',
    canFormat: false,
    canParseAST: false,
    canModularize: false
  }
};

// Built-in Sample Project for Instant Testing and Demo
export const SAMPLE_PROJECT_FILES = [
  {
    path: 'index.html',
    content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Legacy E-Commerce Dashboard</title>
  <style>
    /* Unformatted inline style with nested layout */
    body{font-family:sans-serif;margin:0;padding:20px;background:#0f172a;color:#f8fafc}
    .header{display:flex;justify-content:space-between;border-bottom:1px solid #334155;padding-bottom:15px}
    .card{background:#1e293b;border-radius:8px;padding:16px;margin-top:15px;box-shadow:0 4px 6px -1px rgba(0,0,0,0.3)}
    button{background:#0284c7;color:#fff;border:none;padding:8px 16px;border-radius:4px;cursor:pointer}
    button:hover{background:#0369a1}
  </style>
</head>
<body>
  <div class="header">
    <h1>Mission Control</h1>
    <button id="refresh-btn">Sync Data</button>
  </div>
  <div class="card" id="metrics-card">
    <p>Status: <span id="status-text">Idle</span></p>
  </div>

  <script>
    // Inline script that pollutes global scope and uses legacy CommonJS / globals
    window.API_KEY = "AKIA1234567890EXAMPLE_KEY"; // Flagged by secret scanner!
    var globalCounter = 0;

    function handleSync() {
      globalCounter++;
      document.getElementById('status-text').innerText = 'Synced ' + globalCounter + ' times';
      console.log("Global counter updated:", globalCounter);
    }

    document.getElementById('refresh-btn').addEventListener('click', handleSync);
  </script>
</body>
</html>`
  },
  {
    path: 'src/analytics.js',
    content: `// Unformatted legacy analytics module with CommonJS require and globals
const config = require('./config.js');
const missingLib = require('./missing-metrics-helper.js'); // Missing reference test

var sessionStart = Date.now();
window.userTelemetryId = "session_" + Math.random();

function trackEvent(name, data) {
  var payload = {
    event: name,
    data: data,
    timestamp: Date.now(),
    endpoint: config.getEndpoint()
  };
  return payload;
}

module.exports = {
  trackEvent: trackEvent,
  startTime: sessionStart
};`
  },
  {
    path: 'src/config.js',
    content: `// Cyclic dependency: config requires state, state requires config!
const state = require('./state.js');

function getEndpoint() {
  if (state.isLive()) {
    return 'https://api.internal.service/v1/prod';
  }
  return 'https://api.internal.service/v1/staging';
}

module.exports = {
  getEndpoint: getEndpoint,
  version: '1.2.0'
};`
  },
  {
    path: 'src/state.js',
    content: `// Part of circular dependency chain
const config = require('./config.js');

let liveMode = false;

function isLive() {
  return liveMode;
}

function setLive(val) {
  liveMode = !!val;
}

module.exports = {
  isLive: isLive,
  setLive: setLive
};`
  },
  {
    path: 'styles/components.css',
    content: `/* Badly formatted and messy CSS */
.nav-bar   {display:flex;padding:12px;background:#0f172a;border-bottom:1px solid #334155;}
.nav-link{color:#94a3b8;text-decoration:none;margin-right:16px;}
.nav-link:hover{color:#38bdf8;}
@media(max-width:768px){.nav-bar{flex-direction:column;}}`
  }
];
