// ============================================================================
// Code Isolation & Cleanup Workbench V1.0 - Internationalization (i18n)
// English (LTR) & Persian فارسی (RTL)
// ============================================================================

export const TRANSLATIONS = {
  en: {
    app: {
      title: 'Code Isolation & Cleanup Workbench',
      subtitle: 'Static Analysis, Module Isolation, Format & Clean Architecture',
      version: 'v1.0.0 (Production Engine)',
      privacyBadge: '100% Local In-Browser Processing • Zero Telemetry',
      privacyTooltip: 'All parsing, AST walk, formatting, and file exports execute strictly inside your local browser sandbox. No source code or metadata leaves your device.'
    },
    nav: {
      workbench: 'Workbench',
      depGraph: 'Dependency Graph',
      diffView: 'Diff & Comparison',
      validation: 'Validation & Secrets',
      testSuite: 'Acceptance Tests',
      helpSettings: 'Settings & Specs'
    },
    import: {
      title: 'Source Ingestion',
      subtitle: 'Paste code, select files, folder, or drag-and-drop a ZIP archive',
      pasteTab: 'Paste Code',
      filesTab: 'Import Files',
      folderTab: 'Import Folder',
      zipTab: 'Import ZIP',
      sampleBtn: 'Load Sample Project',
      clearBtn: 'Clear Project',
      dragDropText: 'Drag & Drop files or .ZIP here',
      pastePlaceholder: 'Paste your JavaScript, HTML, CSS, or JSON source code here...',
      filenameLabel: 'Virtual File Path (e.g. src/app.js or index.html):',
      addPastedFile: 'Add Pasted File to Project',
      activeFilesCount: 'Loaded Files:',
      securityRules: 'Path Traversal & Archive Limits Active',
      limitsNotice: 'Rejects ../, absolute paths, null bytes, duplicate names. Limits: 250 files, 25MB decompressed.'
    },
    modes: {
      formatOnly: 'Format Only Mode',
      formatOnlyDesc: 'Formats code without altering file structure, AST modules, or logic.',
      modularize: 'Modularize & Isolate Mode',
      modularizeDesc: 'Extracts inline HTML scripts/styles into standalone modules, resolves CommonJS/ESM, isolates globals, and builds clean architecture.',
      runAction: 'Analyze & Process',
      viewPlan: 'Review Transformation Plan',
      approvePlan: 'Approve & Apply Plan',
      cancelPlan: 'Cancel Plan'
    },
    actions: {
      exportZip: 'Export Project (ZIP)',
      exportSingle: 'Export Single File',
      exportWorkbench: 'Download Standalone Workbench (ZIP)',
      saveIndexedDB: 'Save to Local IndexedDB',
      loadIndexedDB: 'Load Saved Project',
      purgeIndexedDB: 'Purge Stored Data',
      filterAll: 'All Files',
      filterChanged: 'Only Changed Files',
      switchOriginal: 'Original',
      switchTransformed: 'Transformed',
      splitView: 'Split Diff',
      unifiedView: 'Unified Diff',
      runTests: 'Execute All Acceptance Tests'
    },
    graph: {
      title: 'Dependency & Topology Graph',
      subtitle: 'Visual module relationship map, cycle warnings, missing references, and dynamic imports',
      totalNodes: 'Total Modules:',
      totalEdges: 'Total Dependencies:',
      cyclesCount: 'Circular Chains:',
      missingCount: 'Missing References:',
      globalsCount: 'Global Risk Warnings:',
      legendModules: 'Module Node',
      legendCycle: 'Cyclic Link',
      legendMissing: 'Missing Dependency',
      noData: 'Load or paste files to analyze module relationships.'
    },
    diff: {
      title: 'Line-by-Line Change Comparison',
      subtitle: 'High-fidelity diff showing additions, deletions, and structural isolation',
      selectFile: 'Select File to Compare:',
      noChanges: 'No modifications made to this file.',
      linesAdded: 'Added Lines:',
      linesRemoved: 'Removed Lines:',
      unmodified: 'Unmodified Lines:'
    },
    validation: {
      title: 'Post-Transformation Verification & Diagnostics',
      subtitle: 'AST syntax validity, reference integrity checks, and sensitive key detection',
      astValid: 'Syntax & AST Check',
      refValid: 'Reference Resolution Check',
      secretsCheck: 'Sensitive Data & Secret Scan',
      semanticDisclaimer: 'Equivalence Notice: Structural and reference validity confirmed. Semantic runtime equivalence requires unit test coverage.',
      secretsFoundTitle: 'Sensitive Key / Secret Warnings (Best-Effort)',
      noSecretsFound: 'No common high-entropy keys or credentials detected in project.',
      validAll: 'All output files passed ECMAScript and CSS syntax validation with 0 fatal errors.'
    },
    tests: {
      title: 'Built-in Automated Acceptance Test Suite',
      subtitle: 'Genuine in-browser assertions verifying all 10+ core requirements',
      runAllBtn: 'Run Test Suite Now',
      passed: 'Passed',
      failed: 'Failed',
      skipped: 'Skipped',
      total: 'Total Tests',
      filterAll: 'All Tests',
      filterFailed: 'Failed Only'
    },
    settings: {
      title: 'Workbench Preferences & Formatting Rules',
      indentSize: 'Indentation Spaces:',
      useTabs: 'Use Tabs Instead of Spaces',
      semi: 'Require Semicolons in JS',
      quotes: 'Quote Style:',
      singleQuote: 'Single Quotes (\')',
      doubleQuote: 'Double Quotes (")',
      printWidth: 'Target Line Width:',
      maxFilesLimit: 'Max Files in ZIP Import:',
      maxSizeLimit: 'Max Decompressed Size (MB):',
      saveSettings: 'Save Preferences'
    },
    dialogs: {
      confirmClear: 'Are you sure you want to clear the current project? Unsaved changes will be discarded.',
      planNotice: 'A transformation plan has been prepared. Review the proposed file modifications and module extractions below before applying.',
      planApproved: 'Transformation plan approved and successfully applied.',
      planCancelled: 'Transformation cancelled. Original files retained without change.',
      exportComplete: 'Archive generated successfully. Download started.',
      savedSuccess: 'Project snapshot safely saved to browser IndexedDB storage.',
      purgeSuccess: 'IndexedDB cache purged completely.'
    }
  },

  fa: {
    app: {
      title: 'میزکار جداسازی و پاک‌سازی کد',
      subtitle: 'تحلیل ایستا، ماژولارسازی، فرمت‌بندی و پالایش ساختار نرم‌افزار',
      version: 'نسخه ۱.۰.۰ (موتور تولیدی)',
      privacyBadge: 'پردازش ۱۰۰٪ محلی در مرورگر • بدون ارسال داده یا تله‌متری',
      privacyTooltip: 'تمام پردازش‌ها، تحلیل درخت گرامری (AST)، قالب‌بندی و خروجی‌ها منحصراً در داخل مرورگر شما و به صورت آفلاین انجام می‌شوند.'
    },
    nav: {
      workbench: 'میزکار و ویرایشگر',
      depGraph: 'گراف وابستگی‌ها',
      diffView: 'مقایسه تغییرات (Diff)',
      validation: 'اعتبارسنجی و امنیت',
      testSuite: 'تست‌های پذیرش',
      helpSettings: 'تنظیمات و راهنما'
    },
    import: {
      title: 'ورود کد و پروژه‌ها',
      subtitle: 'جای‌گذاری مستقیم متن، انتخاب فایل‌ها، پوشه یا فایل فشرده ZIP',
      pasteTab: 'جای‌گذاری متن کد',
      filesTab: 'انتخاب چند فایل',
      folderTab: 'انتخاب پوشه',
      zipTab: 'بارگذاری فایل ZIP',
      sampleBtn: 'بارگذاری پروژه نمونه',
      clearBtn: 'پاک‌سازی پروژه',
      dragDropText: 'فایل‌ها یا آرشیو ZIP را به اینجا بکشید و رها کنید',
      pastePlaceholder: 'کد جاوااسکریپت، HTML، CSS یا JSON خود را اینجا قرار دهید...',
      filenameLabel: 'مسیر مجازی فایل (مثلاً src/app.js یا index.html):',
      addPastedFile: 'افزودن فایل جای‌گذاری‌شده به پروژه',
      activeFilesCount: 'فایل‌های بارگذاری‌شده:',
      securityRules: 'قوانین امنیتی و محدودیت‌های آرشیو فعال است',
      limitsNotice: 'رد مسیرهای مخرب ../، مسیرهای مطلق، بایت صفر و اسامی تکراری. سقف: ۲۵۰ فایل و ۲۵ مگابایت.'
    },
    modes: {
      formatOnly: 'حالت فقط قالب‌بندی (Format Only)',
      formatOnlyDesc: 'قالب‌بندی زیبای کدها بدون دستکاری ساختار ماژول‌ها یا تغییر منطق اجرایی.',
      modularize: 'حالت جداسازی و ماژولارسازی (Modularize)',
      modularizeDesc: 'استخراج اسکریپت‌ها و استایل‌های درون‌خطی HTML به ماژول‌های مجزا، تبدیل CommonJS به ESM، عایق‌سازی متغیرهای سراسری و ایجاد ساختار تمیز.',
      runAction: 'تحلیل و پردازش پروژه',
      viewPlan: 'مشاهده طرح تحول پیشنهادی',
      approvePlan: 'تأیید و اعمال طرح تحول',
      cancelPlan: 'انصراف از اعمال طرح'
    },
    actions: {
      exportZip: 'دریافت خروجی پروژه (ZIP)',
      exportSingle: 'خروجی تک‌فایلی',
      exportWorkbench: 'دانلود نسخه مستقل میزکار (ZIP)',
      saveIndexedDB: 'ذخیره در پایگاه داده محلی (IndexedDB)',
      loadIndexedDB: 'بارگذاری آخرین وضعیت ذخیره‌شده',
      purgeIndexedDB: 'پاک‌سازی داده‌های ذخیره‌شده',
      filterAll: 'همه فایل‌ها',
      filterChanged: 'فقط فایل‌های تغییر یافته',
      switchOriginal: 'نسخه اصلی',
      switchTransformed: 'نسخه پردازش‌شده',
      splitView: 'نمایش مقایسه دوتایی (Split)',
      unifiedView: 'نمایش مقایسه یکپارچه (Unified)',
      runTests: 'اجرای تمام تست‌های پذیرش'
    },
    graph: {
      title: 'گراف توپولوژی و وابستگی‌های ماژولار',
      subtitle: 'نقشه بصری روابط ماژول‌ها، هشدارهای وابستگی حلقوی، مراجع گم‌شده و ایمپورت‌های پویا',
      totalNodes: 'تعداد کل ماژول‌ها:',
      totalEdges: 'تعداد وابستگی‌ها:',
      cyclesCount: 'زنجیره‌های حلقوی (Cycle):',
      missingCount: 'فایل‌های مفقود:',
      globalsCount: 'ریسک‌های متغیر سراسری:',
      legendModules: 'گره ماژول',
      legendCycle: 'ارتباط حلقوی خطرناک',
      legendMissing: 'وابستگی ناموجود',
      noData: 'برای مشاهده تحلیل روابط، ابتدا فایلی را بارگذاری یا جای‌گذاری کنید.'
    },
    diff: {
      title: 'مقایسه خط به خط تغییرات',
      subtitle: 'نمایش دقیق خطوط افزوده، کاسته و فایل‌های استخراج‌شده با رنگ‌بندی استاندارد',
      selectFile: 'انتخاب فایل جهت مقایسه:',
      noChanges: 'هیچ تغییری در این فایل اعمال نشده است.',
      linesAdded: 'خطوط افزوده:',
      linesRemoved: 'خطوط حذف‌شده:',
      unmodified: 'خطوط دست‌نخورده:'
    },
    validation: {
      title: 'اعتبارسنجی ساختار و بررسی امنیتی',
      subtitle: 'بررسی صحت درخت گرامری (AST)، راستی‌آزمایی مراجع و پویش کلیدهای حساس',
      astValid: 'بررسی گرامر و ساختار AST',
      refValid: 'راستی‌آزمایی ارتباط فایل‌ها',
      secretsCheck: 'پویش کلیدها و اسرار حساس',
      semanticDisclaimer: 'اطلاعیه هم‌ارزی: صحت ساختاری و ارجاعی تأیید شد. تضمین قطعی هم‌ارزی معنایی مستلزم آزمون‌های واحد نرم‌افزاری است.',
      secretsFoundTitle: 'هشدارهای شناسایی کلیدها و توکن‌های حساس',
      noSecretsFound: 'هیچ کلید خصوصی، توکن یا رمز عبوری در پروژه شناسایی نشد.',
      validAll: 'تمام فایل‌های خروجی با موفقیت و بدون خطای ساختاری ارزیابی شدند.'
    },
    tests: {
      title: 'مجموعه آزمون‌های خودکار پذیرش سامانه',
      subtitle: 'ارزیابی واقعی و شفاف در محیط مرورگر برای بیش از ۱۰ معیار اصلی مهندسی',
      runAllBtn: 'اجرای فوری آزمون‌ها',
      passed: 'موفق',
      failed: 'ناموفق',
      skipped: 'رد شده',
      total: 'کل آزمون‌ها',
      filterAll: 'همه آزمون‌ها',
      filterFailed: 'فقط خطادارها'
    },
    settings: {
      title: 'تنظیمات میزکار و قواعد قالب‌بندی',
      indentSize: 'تعداد فواصل تورفتگی (Spaces):',
      useTabs: 'استفاده از Tab به‌جای Space',
      semi: 'درج نقطه‌ویرگول (Semicolon) در JS',
      quotes: 'سبک علامت نقل‌قول:',
      singleQuote: 'نقل‌قول تکی (\')',
      doubleQuote: 'نقل‌قول دوتایی (")',
      printWidth: 'حداکثر طول خط (Characters):',
      maxFilesLimit: 'حداکثر تعداد فایل در فایل فشرده:',
      maxSizeLimit: 'حداکثر حجم مجاز پس از استخراج (MB):',
      saveSettings: 'ذخیره تنظیمات'
    },
    dialogs: {
      confirmClear: 'آیا از پاک کردن پروژه فعلی اطمینان دارید؟ تغییرات ذخیره‌نشده از دست خواهند رفت.',
      planNotice: 'طرح تحول ساختاری آماده است. پیش از اعمال تغییرات، لطفاً جزئیات را در پنجره زیر مرور و تأیید فرمایید.',
      planApproved: 'طرح تحول تأیید گردید و با موفقیت روی پروژه اعمال شد.',
      planCancelled: 'عملیات لغو شد و فایل‌های اصلی بدون هیچ تغییری حفظ شدند.',
      exportComplete: 'بسته فشرده پروژه با موفقیت تولید و دانلود شد.',
      savedSuccess: 'وضعیت پروژه در حافظه محلی مرورگر (IndexedDB) ثبت گردید.',
      purgeSuccess: 'حافظه محلی میزکار به طور کامل پاک‌سازی شد.'
    }
  }
};
