// ============================================================================
// Code Isolation & Cleanup Workbench V1.0 - Diff Engine
// Line-level Myers / LCS Diff, Side-by-Side & Unified View Models
// ============================================================================

export class DiffEngine {
  /**
   * Computes line-by-line diff between two strings.
   * @param {string} originalText
   * @param {string} newText
   * @returns {{
   *   isIdentical: boolean,
   *   lines: Array<{ type: 'unchanged' | 'added' | 'removed', oldLineNum: number | null, newLineNum: number | null, content: string }>,
   *   stats: { added: number, removed: number, unchanged: number, totalOld: number, totalNew: number }
   * }}
   */
  static computeDiff(originalText = '', newText = '') {
    const oldLines = (originalText || '').replace(/\r\n/g, '\n').split('\n');
    const newLines = (newText || '').replace(/\r\n/g, '\n').split('\n');

    // Handle identical cases fast
    if (originalText === newText) {
      const lines = oldLines.map((content, idx) => ({
        type: 'unchanged',
        oldLineNum: idx + 1,
        newLineNum: idx + 1,
        content
      }));
      return {
        isIdentical: true,
        lines,
        stats: {
          added: 0,
          removed: 0,
          unchanged: oldLines.length,
          totalOld: oldLines.length,
          totalNew: newLines.length
        }
      };
    }

    // Longest Common Subsequence (LCS) matrix
    const m = oldLines.length;
    const n = newLines.length;

    // Safety guard for excessively large files
    if (m * n > 4000000) {
      // For very large inputs, perform fast line scan
      return this.fastChunkDiff(oldLines, newLines);
    }

    // dp table
    const dp = Array.from({ length: m + 1 }, () => new Int32Array(n + 1));

    for (let i = 1; i <= m; i++) {
      for (let j = 1; j <= n; j++) {
        if (oldLines[i - 1] === newLines[j - 1]) {
          dp[i][j] = dp[i - 1][j - 1] + 1;
        } else {
          dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
        }
      }
    }

    // Backtrack to build diff
    const diff = [];
    let i = m;
    let j = n;

    while (i > 0 || j > 0) {
      if (i > 0 && j > 0 && oldLines[i - 1] === newLines[j - 1]) {
        diff.push({
          type: 'unchanged',
          oldLineNum: i,
          newLineNum: j,
          content: oldLines[i - 1]
        });
        i--;
        j--;
      } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
        diff.push({
          type: 'added',
          oldLineNum: null,
          newLineNum: j,
          content: newLines[j - 1]
        });
        j--;
      } else if (i > 0 && (j === 0 || dp[i][j - 1] < dp[i - 1][j])) {
        diff.push({
          type: 'removed',
          oldLineNum: i,
          newLineNum: null,
          content: oldLines[i - 1]
        });
        i--;
      }
    }

    diff.reverse();

    let added = 0;
    let removed = 0;
    let unchanged = 0;

    for (const d of diff) {
      if (d.type === 'added') added++;
      else if (d.type === 'removed') removed++;
      else unchanged++;
    }

    return {
      isIdentical: added === 0 && removed === 0,
      lines: diff,
      stats: {
        added,
        removed,
        unchanged,
        totalOld: m,
        totalNew: n
      }
    };
  }

  /**
   * Fast line-by-line scan for files that exceed matrix limits
   */
  static fastChunkDiff(oldLines, newLines) {
    const diff = [];
    let oldIdx = 0;
    let newIdx = 0;

    while (oldIdx < oldLines.length && newIdx < newLines.length) {
      if (oldLines[oldIdx] === newLines[newIdx]) {
        diff.push({
          type: 'unchanged',
          oldLineNum: oldIdx + 1,
          newLineNum: newIdx + 1,
          content: oldLines[oldIdx]
        });
        oldIdx++;
        newIdx++;
      } else {
        diff.push({
          type: 'removed',
          oldLineNum: oldIdx + 1,
          newLineNum: null,
          content: oldLines[oldIdx]
        });
        oldIdx++;
        diff.push({
          type: 'added',
          oldLineNum: null,
          newLineNum: newIdx + 1,
          content: newLines[newIdx]
        });
        newIdx++;
      }
    }

    while (oldIdx < oldLines.length) {
      diff.push({
        type: 'removed',
        oldLineNum: oldIdx + 1,
        newLineNum: null,
        content: oldLines[oldIdx]
      });
      oldIdx++;
    }

    while (newIdx < newLines.length) {
      diff.push({
        type: 'added',
        oldLineNum: null,
        newLineNum: newIdx + 1,
        content: newLines[newIdx]
      });
      newIdx++;
    }

    const added = diff.filter(d => d.type === 'added').length;
    const removed = diff.filter(d => d.type === 'removed').length;
    const unchanged = diff.filter(d => d.type === 'unchanged').length;

    return {
      isIdentical: added === 0 && removed === 0,
      lines: diff,
      stats: {
        added,
        removed,
        unchanged,
        totalOld: oldLines.length,
        totalNew: newLines.length
      }
    };
  }
}
