// ============================================================================
// Code Isolation & Cleanup Workbench V1.0 - Language Detector
// Heuristics, extension mapping, ambiguity & unsupported reporting
// ============================================================================

import { SUPPORTED_LANGUAGES } from './constants.js';

export class LanguageDetector {
  /**
   * Detects language for a given file path and optional content.
   * @param {string} filePath - Path or filename (e.g. "src/app.js")
   * @param {string} [content=''] - Content snippet or full file text
   * @returns {{
   *   id: string,
   *   label: string,
   *   supported: boolean,
   *   confidence: number,
   *   method: 'extension' | 'content-heuristic' | 'ambiguous' | 'unsupported',
   *   canFormat: boolean,
   *   canParseAST: boolean,
   *   canModularize: boolean,
   *   warning?: string
   * }}
   */
  static detect(filePath = '', content = '') {
    const cleanPath = (filePath || '').trim().toLowerCase();
    const extMatch = cleanPath.match(/\.([a-z0-9_-]+)$/i);
    const extension = extMatch ? `.${extMatch[1]}` : '';

    // 1. Direct extension match
    for (const [key, lang] of Object.entries(SUPPORTED_LANGUAGES)) {
      if (lang.extensions.includes(extension)) {
        return {
          id: lang.id,
          label: lang.label,
          supported: true,
          confidence: 0.95,
          method: 'extension',
          canFormat: lang.canFormat,
          canParseAST: lang.canParseAST,
          canModularize: lang.canModularize
        };
      }
    }

    // 2. Content Heuristics if no extension or unknown extension
    if (content && content.trim().length > 0) {
      const trimmed = content.trim();

      // Check JSON
      if ((trimmed.startsWith('{') && trimmed.endsWith('}')) || (trimmed.startsWith('[') && trimmed.endsWith(']'))) {
        try {
          JSON.parse(trimmed);
          return {
            id: 'json',
            label: 'JSON',
            supported: true,
            confidence: 0.9,
            method: 'content-heuristic',
            canFormat: true,
            canParseAST: true,
            canModularize: false
          };
        } catch {
          // May not be pure JSON
        }
      }

      // Check HTML
      if (
        /^\s*<!doctype\s+html/i.test(trimmed) ||
        /^\s*<html[\s>]/i.test(trimmed) ||
        (/<head[\s>]/i.test(trimmed) && /<body[\s>]/i.test(trimmed)) ||
        (/<script[\s>]/i.test(trimmed) && /<\/script>/i.test(trimmed)) ||
        (/<style[\s>]/i.test(trimmed) && /<\/style>/i.test(trimmed))
      ) {
        return {
          id: 'html',
          label: 'HTML',
          supported: true,
          confidence: 0.88,
          method: 'content-heuristic',
          canFormat: true,
          canParseAST: true,
          canModularize: true
        };
      }

      // Check CSS
      if (
        /(@import|@media|@keyframes|@font-face)\b/i.test(trimmed) ||
        (/[.#][a-z0-9_-]+\s*\{[^}]*:[^}]*\}/i.test(trimmed) && !/function\s*\{/i.test(trimmed))
      ) {
        return {
          id: 'css',
          label: 'CSS',
          supported: true,
          confidence: 0.82,
          method: 'content-heuristic',
          canFormat: true,
          canParseAST: true,
          canModularize: true
        };
      }

      // Check JavaScript / TypeScript
      if (
        /^(#!|\/\/|\/\*)/.test(trimmed) ||
        /\b(import\s+.+from|export\s+(default|const|let|function|class)|require\s*\(|module\.exports)\b/.test(trimmed) ||
        /\b(const|let|var)\s+[a-zA-Z_$][0-9a-zA-Z_$]*\s*=/i.test(trimmed) ||
        /\bfunction\s+[a-zA-Z_$][0-9a-zA-Z_$]*\s*\(/.test(trimmed) ||
        /console\.(log|warn|error)\(/.test(trimmed)
      ) {
        return {
          id: 'javascript',
          label: 'JavaScript',
          supported: true,
          confidence: 0.85,
          method: 'content-heuristic',
          canFormat: true,
          canParseAST: true,
          canModularize: true
        };
      }

      // Check Markdown
      if (/^#+\s+.+/m.test(trimmed) || /```[a-z]*\n[\s\S]+?```/.test(trimmed)) {
        return {
          id: 'markdown',
          label: 'Markdown',
          supported: true,
          confidence: 0.75,
          method: 'content-heuristic',
          canFormat: false,
          canParseAST: false,
          canModularize: false
        };
      }
    }

    // 3. Ambiguous or Unsupported fallback
    return {
      id: 'unknown',
      label: extension ? `Unsupported (${extension})` : 'Unknown / Ambiguous',
      supported: false,
      confidence: 0.2,
      method: extension ? 'unsupported' : 'ambiguous',
      canFormat: false,
      canParseAST: false,
      canModularize: false,
      warning: extension
        ? `File extension '${extension}' is not currently supported for automated AST parsing or formatting.`
        : 'Could not determine file language with high confidence. Treated as raw text without transformation.'
    };
  }
}
