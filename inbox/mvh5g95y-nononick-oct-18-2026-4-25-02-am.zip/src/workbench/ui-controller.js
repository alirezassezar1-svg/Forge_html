// ============================================================================
// Code Isolation & Cleanup Workbench V1.0 - UI Controller
// Mobile-First Architecture, Persian (RTL) & English (LTR), Reactive Views
// ============================================================================

import { TRANSLATIONS } from './i18n.js';
import { SAMPLE_PROJECT_FILES, DEFAULT_FORMAT_OPTIONS, DEFAULT_LIMITS, APP_VERSION } from './constants.js';
import { LanguageDetector } from './language-detector.js';
import { ImportStorageManager } from './import-storage.js';
import { FormatterAdapter } from './formatter-adapter.js';
import { DependencyGraphEngine } from './dependency-graph.js';
import { TransformationPlanner } from './transformation-planner.js';
import { DiffEngine } from './diff-engine.js';
import { Validator } from './validator.js';
import { Exporter } from './exporter.js';
import { AcceptanceTestSuite } from './test-suite.js';

export class UIController {
  constructor() {
    this.lang = 'en';
    this.theme = 'dark';
    this.activeTab = 'workbench';
    this.activeMode = 'modularize'; // 'format-only' | 'modularize'
    this.diffMode = 'split'; // 'split' | 'unified'
    this.diffFilter = 'changed'; // 'all' | 'changed'
    this.activeVersion = 'output'; // 'original' | 'output'

    this.formatOptions = { ...DEFAULT_FORMAT_OPTIONS };
    this.limits = { ...DEFAULT_LIMITS };

    this.originalFiles = [];
    this.outputFiles = [];
    this.selectedFilePath = '';

    this.currentPlan = null;
    this.currentDepGraph = null;
    this.currentValidation = null;
    this.lastTestResults = null;

    this.isProcessing = false;
  }

  init() {
    this.setupTheme();
    this.setupLanguage();
    this.renderShell();
    this.bindGlobalEvents();
    // Load sample project by default so user has immediate rich data to test
    this.loadSampleProject();
  }

  t(path) {
    const keys = path.split('.');
    let cur = TRANSLATIONS[this.lang] || TRANSLATIONS.en;
    for (const k of keys) {
      if (cur && cur[k] !== undefined) {
        cur = cur[k];
      } else {
        return path;
      }
    }
    return cur;
  }

  setupTheme() {
    const savedTheme = localStorage.getItem('ciw_theme') || 'dark';
    this.theme = savedTheme;
    document.documentElement.setAttribute('data-theme', this.theme);
  }

  setupLanguage() {
    const savedLang = localStorage.getItem('ciw_lang') || 'en';
    this.lang = savedLang;
    document.documentElement.setAttribute('lang', this.lang);
    document.documentElement.setAttribute('dir', this.lang === 'fa' ? 'rtl' : 'ltr');
  }

  toggleTheme() {
    this.theme = this.theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('ciw_theme', this.theme);
    document.documentElement.setAttribute('data-theme', this.theme);
    this.updateThemeButton();
  }

  toggleLanguage() {
    this.lang = this.lang === 'en' ? 'fa' : 'en';
    localStorage.setItem('ciw_lang', this.lang);
    document.documentElement.setAttribute('lang', this.lang);
    document.documentElement.setAttribute('dir', this.lang === 'fa' ? 'rtl' : 'ltr');
    this.renderShell();
  }

  updateThemeButton() {
    const btn = document.getElementById('theme-toggle-btn');
    if (btn) {
      btn.innerHTML = this.theme === 'dark' ? '☀️' : '🌙';
    }
  }

  showToast(message, type = 'info') {
    const toast = document.getElementById('workbench-toast');
    if (!toast) return;

    toast.className = `toast toast-${type} show`;
    toast.textContent = message;

    clearTimeout(this.toastTimeout);
    this.toastTimeout = setTimeout(() => {
      toast.classList.remove('show');
    }, 3800);
  }

  // --- Core State Mutators ---

  loadSampleProject() {
    this.originalFiles = SAMPLE_PROJECT_FILES.map(f => ({
      path: f.path,
      content: f.content,
      language: LanguageDetector.detect(f.path, f.content),
      size: f.content.length
    }));
    this.outputFiles = JSON.parse(JSON.stringify(this.originalFiles));
    this.selectedFilePath = this.originalFiles[0]?.path || '';
    this.analyzeCurrentState();
    this.showToast(this.t('dialogs.savedSuccess') ? 'Loaded sample multi-module project' : 'Sample project loaded', 'success');
  }

  clearProject() {
    if (this.originalFiles.length > 0 && !confirm(this.t('dialogs.confirmClear'))) {
      return;
    }
    this.originalFiles = [];
    this.outputFiles = [];
    this.selectedFilePath = '';
    this.currentPlan = null;
    this.currentDepGraph = null;
    this.currentValidation = null;
    this.renderCurrentTab();
    this.showToast('Project cleared.', 'info');
  }

  async analyzeCurrentState() {
    const filesToAnalyze = this.outputFiles.length > 0 ? this.outputFiles : this.originalFiles;
    if (filesToAnalyze.length === 0) {
      this.currentDepGraph = null;
      this.currentValidation = null;
      this.renderCurrentTab();
      return;
    }

    this.currentDepGraph = DependencyGraphEngine.buildGraph(filesToAnalyze);
    this.currentValidation = Validator.validateProject(filesToAnalyze);
    this.renderCurrentTab();
    this.updateStatsCounters();
  }

  // --- Rendering UI Architecture ---

  renderShell() {
    const root = document.getElementById('app-root');
    if (!root) return;

    root.innerHTML = `
      <!-- Header HUD Bar -->
      <header class="app-header">
        <div class="header-main">
          <div class="brand">
            <div class="logo-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="4" y="4" width="16" height="16" rx="2"/>
                <rect x="9" y="9" width="6" height="6"/>
                <line x1="9" y1="1" x2="9" y2="4"/>
                <line x1="15" y1="1" x2="15" y2="4"/>
                <line x1="9" y1="20" x2="9" y2="23"/>
                <line x1="15" y1="20" x2="15" y2="23"/>
                <line x1="20" y1="9" x2="23" y2="9"/>
                <line x1="20" y1="14" x2="23" y2="14"/>
                <line x1="1" y1="9" x2="4" y2="9"/>
                <line x1="1" y1="14" x2="4" y2="14"/>
              </svg>
            </div>
            <div>
              <div class="brand-title">
                ${this.t('app.title')}
                <span class="version-tag">${APP_VERSION}</span>
              </div>
              <div class="brand-sub">${this.t('app.subtitle')}</div>
            </div>
          </div>

          <div class="header-controls">
            <div class="privacy-pill" title="${this.t('app.privacyTooltip')}">
              <span class="dot-green"></span>
              <span class="pill-text">${this.t('app.privacyBadge')}</span>
            </div>

            <!-- Language Button -->
            <button id="lang-toggle-btn" class="ctrl-btn" title="Toggle English / Persian" aria-label="Toggle Language">
              <span style="font-weight:700;">${this.lang === 'en' ? 'فارسی' : 'EN'}</span>
            </button>

            <!-- Theme Button -->
            <button id="theme-toggle-btn" class="ctrl-btn" title="Toggle Dark / Light Theme" aria-label="Toggle Theme">
              ${this.theme === 'dark' ? '☀️' : '🌙'}
            </button>
          </div>
        </div>

        <!-- Navigation Tabs -->
        <nav class="nav-bar" aria-label="Workbench Sections">
          <button class="nav-tab ${this.activeTab === 'workbench' ? 'active' : ''}" data-tab="workbench">
            <span class="tab-num">01</span> ${this.t('nav.workbench')}
          </button>
          <button class="nav-tab ${this.activeTab === 'depGraph' ? 'active' : ''}" data-tab="depGraph">
            <span class="tab-num">02</span> ${this.t('nav.depGraph')}
            <span class="badge-counter" id="badge-cycles" style="display:none">0</span>
          </button>
          <button class="nav-tab ${this.activeTab === 'diffView' ? 'active' : ''}" data-tab="diffView">
            <span class="tab-num">03</span> ${this.t('nav.diffView')}
          </button>
          <button class="nav-tab ${this.activeTab === 'validation' ? 'active' : ''}" data-tab="validation">
            <span class="tab-num">04</span> ${this.t('nav.validation')}
            <span class="badge-counter" id="badge-secrets" style="display:none">0</span>
          </button>
          <button class="nav-tab ${this.activeTab === 'testSuite' ? 'active' : ''}" data-tab="testSuite">
            <span class="tab-num">05</span> ${this.t('nav.testSuite')}
          </button>
          <button class="nav-tab ${this.activeTab === 'helpSettings' ? 'active' : ''}" data-tab="helpSettings">
            <span class="tab-num">06</span> ${this.t('nav.helpSettings')}
          </button>
        </nav>
      </header>

      <!-- Main Workspace Views -->
      <main id="main-content" class="main-body">
        <!-- Rendered dynamically via renderCurrentTab() -->
      </main>

      <!-- Sticky Bottom Action Toolbar -->
      <footer class="action-footer">
        <div class="footer-inner">
          <div class="mode-selector">
            <button class="mode-btn ${this.activeMode === 'modularize' ? 'active' : ''}" data-mode="modularize" title="${this.t('modes.modularizeDesc')}">
              ⚡ ${this.t('modes.modularize')}
            </button>
            <button class="mode-btn ${this.activeMode === 'format-only' ? 'active' : ''}" data-mode="format-only" title="${this.t('modes.formatOnlyDesc')}">
              ✨ ${this.t('modes.formatOnly')}
            </button>
          </div>

          <div class="footer-actions">
            <button id="btn-process-project" class="btn btn-primary" ${this.isProcessing ? 'disabled' : ''}>
              ${this.isProcessing ? '⏳ Processing...' : '▶ ' + this.t('modes.runAction')}
            </button>
            <button id="btn-export-zip" class="btn btn-secondary">
              📦 ${this.t('actions.exportZip')}
            </button>
            <button id="btn-export-single" class="btn btn-secondary">
              📄 ${this.t('actions.exportSingle')}
            </button>
          </div>
        </div>
      </footer>

      <!-- Transformation Plan Review Modal -->
      <div id="plan-modal" class="modal-backdrop">
        <div class="modal-card">
          <div class="modal-header">
            <h3>📋 ${this.t('modes.viewPlan')}</h3>
            <button id="btn-close-plan" class="ctrl-btn">✕</button>
          </div>
          <div class="modal-body" id="plan-modal-body">
            <!-- Populated via renderPlanModal() -->
          </div>
          <div class="modal-footer">
            <button id="btn-cancel-plan" class="btn btn-secondary">${this.t('modes.cancelPlan')}</button>
            <button id="btn-approve-plan" class="btn btn-primary">✓ ${this.t('modes.approvePlan')}</button>
          </div>
        </div>
      </div>

      <!-- Toast Notification Alert -->
      <div id="workbench-toast" class="toast"></div>
    `;

    this.renderCurrentTab();
  }

  renderCurrentTab() {
    const container = document.getElementById('main-content');
    if (!container) return;

    switch (this.activeTab) {
      case 'workbench':
        container.innerHTML = this.renderWorkbenchTab();
        this.bindWorkbenchEvents();
        break;
      case 'depGraph':
        container.innerHTML = this.renderDepGraphTab();
        this.bindDepGraphEvents();
        break;
      case 'diffView':
        container.innerHTML = this.renderDiffTab();
        this.bindDiffEvents();
        break;
      case 'validation':
        container.innerHTML = this.renderValidationTab();
        this.bindValidationEvents();
        break;
      case 'testSuite':
        container.innerHTML = this.renderTestSuiteTab();
        this.bindTestSuiteEvents();
        break;
      case 'helpSettings':
        container.innerHTML = this.renderSettingsTab();
        this.bindSettingsEvents();
        break;
    }

    this.updateStatsCounters();
  }

  updateStatsCounters() {
    const badgeCycles = document.getElementById('badge-cycles');
    if (badgeCycles) {
      const cycleCount = this.currentDepGraph?.cycles?.length || 0;
      badgeCycles.textContent = cycleCount;
      badgeCycles.style.display = cycleCount > 0 ? 'inline-block' : 'none';
    }

    const badgeSecrets = document.getElementById('badge-secrets');
    if (badgeSecrets) {
      const secretCount = this.currentValidation?.secretsDetected?.length || 0;
      badgeSecrets.textContent = secretCount;
      badgeSecrets.style.display = secretCount > 0 ? 'inline-block' : 'none';
    }
  }

  // --- View 1: Workbench Tab ---

  renderWorkbenchTab() {
    const files = this.activeVersion === 'output' && this.outputFiles.length > 0 ? this.outputFiles : this.originalFiles;
    const currentFile = files.find(f => f.path === this.selectedFilePath) || files[0];

    return `
      <div class="workbench-grid">
        <!-- Sidebar: Ingestion & File Tree -->
        <aside class="sidebar-pane">
          <div class="pane-header">
            <h4>${this.t('import.title')}</h4>
            <div style="display:flex; gap:0.35rem;">
              <button id="btn-load-sample" class="btn-xs btn-outline" title="${this.t('import.sampleBtn')}">${this.t('import.sampleBtn')}</button>
              <button id="btn-clear-proj" class="btn-xs btn-danger" title="${this.t('import.clearBtn')}">✕</button>
            </div>
          </div>

          <!-- Drag and Drop Zone -->
          <div class="drop-zone" id="drop-target">
            <div class="drop-icon">📥</div>
            <div class="drop-title">${this.t('import.dragDropText')}</div>
            <div class="drop-subtitle">${this.t('import.limitsNotice')}</div>
            <div class="drop-actions">
              <label class="btn-xs btn-primary upload-label">
                📂 ${this.t('import.filesTab')}
                <input type="file" id="file-input-multiple" multiple style="display:none;" />
              </label>
              <label class="btn-xs btn-secondary upload-label">
                📁 ${this.t('import.folderTab')}
                <input type="file" id="folder-input" webkitdirectory directory style="display:none;" />
              </label>
              <label class="btn-xs btn-secondary upload-label">
                🗜️ ${this.t('import.zipTab')}
                <input type="file" id="zip-input" accept=".zip,application/zip" style="display:none;" />
              </label>
            </div>
          </div>

          <!-- Direct Code Paste Collapsible -->
          <details class="paste-details">
            <summary class="paste-summary">✍️ ${this.t('import.pasteTab')}</summary>
            <div class="paste-box">
              <label class="field-label">${this.t('import.filenameLabel')}</label>
              <input type="text" id="paste-filename" class="text-input" placeholder="src/app.js" value="src/app.js" />
              <textarea id="paste-code-input" class="code-textarea" rows="4" placeholder="${this.t('import.pastePlaceholder')}"></textarea>
              <button id="btn-add-pasted" class="btn btn-xs btn-primary" style="width:100%; margin-top:0.5rem;">
                + ${this.t('import.addPastedFile')}
              </button>
            </div>
          </details>

          <!-- File Explorer List -->
          <div class="file-list-header">
            <span class="field-label">${this.t('import.activeFilesCount')} <strong>${files.length}</strong></span>
            <div class="version-toggle">
              <button class="toggle-pill ${this.activeVersion === 'original' ? 'active' : ''}" data-ver="original">${this.t('actions.switchOriginal')}</button>
              <button class="toggle-pill ${this.activeVersion === 'output' ? 'active' : ''}" data-ver="output">${this.t('actions.switchTransformed')}</button>
            </div>
          </div>

          <div class="file-list">
            ${files.length === 0 ? `<div class="empty-state">${this.t('graph.noData')}</div>` : ''}
            ${files.map(f => {
              const isSelected = f.path === this.selectedFilePath;
              const isCreated = !this.originalFiles.some(orig => orig.path === f.path);
              return `
                <div class="file-item ${isSelected ? 'selected' : ''}" data-path="${f.path}">
                  <span class="file-icon">${this.getFileIcon(f.path)}</span>
                  <span class="file-name" title="${f.path}">${f.path}</span>
                  ${isCreated ? '<span class="tag-new">NEW</span>' : ''}
                  <span class="file-size">${(f.content.length / 1024).toFixed(1)}k</span>
                </div>
              `;
            }).join('')}
          </div>
        </aside>

        <!-- Main Editor / Code Preview Pane -->
        <section class="editor-pane">
          <div class="pane-header">
            <div style="display:flex; align-items:center; gap:0.5rem;">
              <span class="editor-filename"><code>${currentFile ? currentFile.path : 'No file selected'}</code></span>
              ${currentFile ? `<span class="lang-tag">${currentFile.language?.label || 'Text'}</span>` : ''}
            </div>
            <div style="display:flex; gap:0.5rem;">
              <button id="btn-format-current" class="btn-xs btn-secondary" title="Format Current File">✨ Format</button>
            </div>
          </div>

          <div class="editor-body">
            <textarea id="active-file-editor" class="monaco-like-editor" spellcheck="false" placeholder="Select or paste a file to view code...">${currentFile ? this.escapeHTML(currentFile.content) : ''}</textarea>
          </div>
        </section>
      </div>
    `;
  }

  // --- View 2: Dependency Graph Tab ---

  renderDepGraphTab() {
    const graph = this.currentDepGraph;
    if (!graph || graph.nodes.length === 0) {
      return `<div class="empty-view">${this.t('graph.noData')}</div>`;
    }

    return `
      <div class="graph-view-container">
        <!-- Topology Summary Bar -->
        <div class="metrics-bar">
          <div class="metric-card">
            <div class="metric-label">${this.t('graph.totalNodes')}</div>
            <div class="metric-val">${graph.stats.totalNodes}</div>
          </div>
          <div class="metric-card">
            <div class="metric-label">${this.t('graph.totalEdges')}</div>
            <div class="metric-val text-cyan">${graph.stats.totalEdges}</div>
          </div>
          <div class="metric-card ${graph.cycles.length > 0 ? 'card-warning' : ''}">
            <div class="metric-label">${this.t('graph.cyclesCount')}</div>
            <div class="metric-val text-rose">${graph.cycles.length}</div>
          </div>
          <div class="metric-card ${graph.missingReferences.length > 0 ? 'card-warning' : ''}">
            <div class="metric-label">${this.t('graph.missingCount')}</div>
            <div class="metric-val text-amber">${graph.missingReferences.length}</div>
          </div>
          <div class="metric-card">
            <div class="metric-label">${this.t('graph.globalsCount')}</div>
            <div class="metric-val text-violet">${graph.globalRisks.length}</div>
          </div>
        </div>

        <!-- Interactive SVG Canvas -->
        <div class="graph-canvas-wrapper" id="graph-wrapper">
          <svg class="graph-svg" id="topology-svg" width="100%" height="450" viewBox="0 0 1000 450">
            <!-- Dynamic SVG nodes & edges rendered via renderGraphSVG() -->
          </svg>
        </div>

        <!-- Diagnostics Detail Tables (Cycles, Missing, Globals) -->
        <div class="diagnostics-split">
          <!-- Cycles Panel -->
          <div class="diag-card">
            <h5>⚠️ Circular Dependency Cycles (${graph.cycles.length})</h5>
            ${graph.cycles.length === 0 ? '<div class="text-muted">No circular dependencies found. Clear directed acyclic graph.</div>' : ''}
            <div class="cycle-list">
              ${graph.cycles.map(c => `
                <div class="cycle-item">
                  <strong>Cycle:</strong> <code>${c.join(' ➔ ')}</code>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Missing References Panel -->
          <div class="diag-card">
            <h5>❌ Missing References (${graph.missingReferences.length})</h5>
            ${graph.missingReferences.length === 0 ? '<div class="text-muted">All local file imports and script links successfully resolved.</div>' : ''}
            <div class="missing-list">
              ${graph.missingReferences.map(m => `
                <div class="missing-item">
                  <code>${m.source}</code> requires missing <code>${m.specifier}</code>
                </div>
              `).join('')}
            </div>
          </div>

          <!-- Global Leakage Risks -->
          <div class="diag-card">
            <h5>🌐 Global Variable Risks (${graph.globalRisks.length})</h5>
            ${graph.globalRisks.length === 0 ? '<div class="text-muted">No global window/globalThis assignments detected.</div>' : ''}
            <div class="globals-list">
              ${graph.globalRisks.map(g => `
                <div class="global-item">
                  <code>${g.file}</code> [Line ${g.line}]: assigned to <strong>${g.name}</strong>
                </div>
              `).join('')}
            </div>
          </div>
        </div>
      </div>
    `;
  }

  // --- View 3: Diff & Comparison Tab ---

  renderDiffTab() {
    const files = this.outputFiles.length > 0 ? this.outputFiles : this.originalFiles;
    const currentPath = this.selectedFilePath || (files[0] ? files[0].path : '');
    const origFile = this.originalFiles.find(f => f.path === currentPath);
    const outFile = this.outputFiles.find(f => f.path === currentPath);

    const diff = DiffEngine.computeDiff(origFile ? origFile.content : '', outFile ? outFile.content : '');

    return `
      <div class="diff-view-container">
        <!-- Diff Toolbar -->
        <div class="diff-toolbar">
          <div style="display:flex; align-items:center; gap:0.75rem; flex-wrap:wrap;">
            <label class="field-label">${this.t('diff.selectFile')}</label>
            <select id="diff-file-select" class="dropdown-select">
              ${files.map(f => {
                const orig = this.originalFiles.find(o => o.path === f.path);
                const hasDiff = !orig || orig.content !== f.content;
                return `<option value="${f.path}" ${f.path === currentPath ? 'selected' : ''}>${hasDiff ? '● ' : ''}${f.path}</option>`;
              }).join('')}
            </select>
          </div>

          <div style="display:flex; align-items:center; gap:0.5rem;">
            <button class="toggle-pill ${this.diffMode === 'split' ? 'active' : ''}" data-diff-mode="split">${this.t('actions.splitView')}</button>
            <button class="toggle-pill ${this.diffMode === 'unified' ? 'active' : ''}" data-diff-mode="unified">${this.t('actions.unifiedView')}</button>
          </div>
        </div>

        <!-- Stats Bar -->
        <div class="diff-stats-strip">
          <span class="diff-stat-item stat-add">+${diff.stats.added} ${this.t('diff.linesAdded')}</span>
          <span class="diff-stat-item stat-del">-${diff.stats.removed} ${this.t('diff.linesRemoved')}</span>
          <span class="diff-stat-item stat-same">${diff.stats.unchanged} ${this.t('diff.unmodified')}</span>
          ${diff.isIdentical ? `<span class="badge-tag">${this.t('diff.noChanges')}</span>` : ''}
        </div>

        <!-- Diff Viewer -->
        <div class="diff-viewer ${this.diffMode === 'split' ? 'split-diff' : 'unified-diff'}">
          ${this.renderDiffLines(diff, this.diffMode)}
        </div>
      </div>
    `;
  }

  renderDiffLines(diff, mode) {
    if (mode === 'unified') {
      return diff.lines.map(line => {
        const cls = line.type === 'added' ? 'diff-line-added' : line.type === 'removed' ? 'diff-line-removed' : 'diff-line-unchanged';
        const prefix = line.type === 'added' ? '+' : line.type === 'removed' ? '-' : ' ';
        return `
          <div class="diff-row ${cls}">
            <span class="diff-num old-num">${line.oldLineNum ?? ''}</span>
            <span class="diff-num new-num">${line.newLineNum ?? ''}</span>
            <span class="diff-sign">${prefix}</span>
            <span class="diff-code">${this.escapeHTML(line.content)}</span>
          </div>
        `;
      }).join('');
    } else {
      // Side-by-Side Split View
      return diff.lines.map(line => {
        const isAdd = line.type === 'added';
        const isDel = line.type === 'removed';
        const isSame = line.type === 'unchanged';

        return `
          <div class="split-diff-row">
            <div class="split-pane-half ${isDel ? 'diff-line-removed' : isSame ? 'diff-line-unchanged' : 'empty-cell'}">
              <span class="diff-num">${line.oldLineNum ?? ''}</span>
              <span class="diff-code">${isDel || isSame ? this.escapeHTML(line.content) : ''}</span>
            </div>
            <div class="split-pane-half ${isAdd ? 'diff-line-added' : isSame ? 'diff-line-unchanged' : 'empty-cell'}">
              <span class="diff-num">${line.newLineNum ?? ''}</span>
              <span class="diff-code">${isAdd || isSame ? this.escapeHTML(line.content) : ''}</span>
            </div>
          </div>
        `;
      }).join('');
    }
  }

  // --- View 4: Validation & Security Tab ---

  renderValidationTab() {
    const val = this.currentValidation;
    if (!val) {
      return `<div class="empty-view">Load or process code to generate validation & security diagnostics.</div>`;
    }

    return `
      <div class="validation-container">
        <!-- Verification Status Cards -->
        <div class="metrics-bar">
          <div class="metric-card ${val.syntaxErrors.length === 0 ? 'card-success' : 'card-warning'}">
            <div class="metric-label">${this.t('validation.astValid')}</div>
            <div class="metric-val ${val.syntaxErrors.length === 0 ? 'text-emerald' : 'text-rose'}">
              ${val.syntaxErrors.length === 0 ? '✓ Valid AST' : '❌ ' + val.syntaxErrors.length + ' Errors'}
            </div>
          </div>

          <div class="metric-card ${val.missingReferences.length === 0 ? 'card-success' : 'card-warning'}">
            <div class="metric-label">${this.t('validation.refValid')}</div>
            <div class="metric-val ${val.missingReferences.length === 0 ? 'text-emerald' : 'text-amber'}">
              ${val.missingReferences.length === 0 ? '✓ Resolved' : '⚠️ ' + val.missingReferences.length + ' Missing'}
            </div>
          </div>

          <div class="metric-card ${val.secretsDetected.length === 0 ? 'card-success' : 'card-warning'}">
            <div class="metric-label">${this.t('validation.secretsCheck')}</div>
            <div class="metric-val ${val.secretsDetected.length === 0 ? 'text-emerald' : 'text-rose'}">
              ${val.secretsDetected.length === 0 ? '✓ Clean' : '🛡️ ' + val.secretsDetected.length + ' Flags'}
            </div>
          </div>
        </div>

        <!-- Equivalence Notice Disclaimer -->
        <div class="notice-callout">
          <strong>⚠️ ${this.t('validation.semanticDisclaimer')}</strong>
        </div>

        <!-- Secret Scanner Results -->
        <div class="diag-card" style="margin-top:1.5rem;">
          <h4>🛡️ ${this.t('validation.secretsFoundTitle')} (${val.secretsDetected.length})</h4>
          ${val.secretsDetected.length === 0 ? `<div class="text-muted">${this.t('validation.noSecretsFound')}</div>` : ''}
          <div class="secrets-list">
            ${val.secretsDetected.map(s => `
              <div class="secret-item">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                  <strong>${s.patternName}</strong>
                  <span class="tag-badge">Line ${s.line} in <code>${s.file}</code></span>
                </div>
                <div class="secret-preview"><code>${this.escapeHTML(s.redactedPreview)}</code></div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- Syntax Errors Report -->
        <div class="diag-card" style="margin-top:1.5rem;">
          <h4>🧪 AST & Syntax Diagnostics (${val.syntaxErrors.length})</h4>
          ${val.syntaxErrors.length === 0 ? `<div class="text-muted">${this.t('validation.validAll')}</div>` : ''}
          <div class="syntax-list">
            ${val.syntaxErrors.map(err => `
              <div class="syntax-error-item">
                <code>${err.file}</code>: ${this.escapeHTML(err.error)}
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  }

  // --- View 5: Acceptance Test Runner Tab ---

  renderTestSuiteTab() {
    const results = this.lastTestResults;

    return `
      <div class="tests-container">
        <div class="pane-header">
          <div>
            <h3>${this.t('tests.title')}</h3>
            <p class="text-muted">${this.t('tests.subtitle')}</p>
          </div>
          <button id="btn-run-all-tests" class="btn btn-primary">
            🚀 ${this.t('tests.runAllBtn')}
          </button>
        </div>

        ${results ? `
          <div class="metrics-bar" style="margin:1.5rem 0;">
            <div class="metric-card card-success">
              <div class="metric-label">${this.t('tests.passed')}</div>
              <div class="metric-val text-emerald">${results.summary.passed} / ${results.summary.total}</div>
            </div>
            <div class="metric-card ${results.summary.failed > 0 ? 'card-warning' : ''}">
              <div class="metric-label">${this.t('tests.failed')}</div>
              <div class="metric-val ${results.summary.failed > 0 ? 'text-rose' : 'text-emerald'}">${results.summary.failed}</div>
            </div>
            <div class="metric-card">
              <div class="metric-label">Execution Time</div>
              <div class="metric-val text-cyan">${results.summary.durationMs} ms</div>
            </div>
          </div>

          <div class="test-results-list">
            ${results.results.map(t => `
              <div class="test-item ${t.status === 'passed' ? 'test-passed' : 'test-failed'}">
                <div class="test-header">
                  <div style="display:flex; align-items:center; gap:0.5rem;">
                    <span class="test-badge">${t.status === 'passed' ? '✓ PASS' : '✕ FAIL'}</span>
                    <strong>${t.name}</strong>
                  </div>
                  <span class="test-meta">${t.category} • ${t.durationMs}ms</span>
                </div>
                ${t.error ? `<div class="test-error-box">${this.escapeHTML(t.error)}</div>` : ''}
              </div>
            `).join('')}
          </div>
        ` : `
          <div class="empty-view">
            <p>Click "Run Test Suite Now" to execute all in-browser acceptance tests verifying parsing, formatting, security, traversal rejection, and offline isolation.</p>
          </div>
        `}
      </div>
    `;
  }

  // --- View 6: Settings & Specifications Tab ---

  renderSettingsTab() {
    return `
      <div class="settings-container">
        <h3>${this.t('settings.title')}</h3>

        <div class="settings-card">
          <h4>Prettier & Code Formatter Rules</h4>
          <div class="settings-grid">
            <div class="setting-row">
              <label>${this.t('settings.indentSize')}</label>
              <select id="opt-indent-size" class="dropdown-select">
                <option value="2" ${this.formatOptions.indentSize === 2 ? 'selected' : ''}>2 Spaces</option>
                <option value="4" ${this.formatOptions.indentSize === 4 ? 'selected' : ''}>4 Spaces</option>
              </select>
            </div>

            <div class="setting-row">
              <label>${this.t('settings.useTabs')}</label>
              <input type="checkbox" id="opt-use-tabs" ${this.formatOptions.useTabs ? 'checked' : ''} />
            </div>

            <div class="setting-row">
              <label>${this.t('settings.semi')}</label>
              <input type="checkbox" id="opt-semi" ${this.formatOptions.semi ? 'checked' : ''} />
            </div>

            <div class="setting-row">
              <label>${this.t('settings.quotes')}</label>
              <select id="opt-single-quote" class="dropdown-select">
                <option value="true" ${this.formatOptions.singleQuote ? 'selected' : ''}>Single Quotes (\')</option>
                <option value="false" ${!this.formatOptions.singleQuote ? 'selected' : ''}>Double Quotes (")</option>
              </select>
            </div>

            <div class="setting-row">
              <label>${this.t('settings.printWidth')}</label>
              <input type="number" id="opt-print-width" class="text-input" value="${this.formatOptions.printWidth}" min="40" max="160" />
            </div>
          </div>
        </div>

        <div class="settings-card" style="margin-top:1.5rem;">
          <h4>IndexedDB Local Storage & Data Privacy</h4>
          <p class="text-muted">Save your project sessions locally to browser storage, or completely purge all cached sessions.</p>
          <div style="display:flex; gap:0.75rem; margin-top:1rem; flex-wrap:wrap;">
            <button id="btn-save-idb" class="btn btn-secondary">💾 ${this.t('actions.saveIndexedDB')}</button>
            <button id="btn-load-idb" class="btn btn-secondary">📂 ${this.t('actions.loadIndexedDB')}</button>
            <button id="btn-purge-idb" class="btn btn-danger">🗑️ ${this.t('actions.purgeIndexedDB')}</button>
          </div>
        </div>

        <div class="settings-card" style="margin-top:1.5rem;">
          <h4>Portable Distribution Download</h4>
          <p class="text-muted">Export the entire Workbench itself as a standalone ZIP archive containing all local dependencies and offline execution capabilities.</p>
          <button id="btn-download-workbench" class="btn btn-primary" style="margin-top:1rem;">
            ⬇️ ${this.t('actions.exportWorkbench')}
          </button>
        </div>
      </div>
    `;
  }

  // --- Graph SVG Renderer ---

  renderGraphSVG() {
    const svg = document.getElementById('topology-svg');
    if (!svg || !this.currentDepGraph) return;

    const nodes = this.currentDepGraph.nodes;
    const edges = this.currentDepGraph.edges;
    const cycles = this.currentDepGraph.cycles;

    const width = 1000;
    const height = 450;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = Math.min(width, height) * 0.38;

    // Distribute nodes in a circle
    const nodeCoords = new Map();
    nodes.forEach((node, idx) => {
      const angle = (idx / nodes.length) * 2 * Math.PI - Math.PI / 2;
      const x = centerX + radius * Math.cos(angle);
      const y = centerY + radius * Math.sin(angle);
      nodeCoords.set(node.id, { x, y });
    });

    // Check which edges are cyclic
    const cyclicEdgePairs = new Set();
    for (const c of cycles) {
      for (let i = 0; i < c.length - 1; i++) {
        cyclicEdgePairs.add(`${c[i]}->${c[i + 1]}`);
      }
    }

    // Build Edges SVG
    let edgesHTML = '<g class="graph-edges">';
    for (const edge of edges) {
      const src = nodeCoords.get(edge.source);
      const tgt = nodeCoords.get(edge.target);
      if (src && tgt) {
        const isCycle = cyclicEdgePairs.has(`${edge.source}->${edge.target}`);
        const strokeColor = isCycle ? '#f43f5e' : edge.isDynamic ? '#f59e0b' : '#0284c7';
        const strokeDash = isCycle ? 'stroke-dasharray="4,4"' : '';
        edgesHTML += `
          <line x1="${src.x}" y1="${src.y}" x2="${tgt.x}" y2="${tgt.y}"
            stroke="${strokeColor}" stroke-width="${isCycle ? 2.5 : 1.5}" ${strokeDash} opacity="0.65" />
        `;
      }
    }
    edgesHTML += '</g>';

    // Build Nodes SVG
    let nodesHTML = '<g class="graph-nodes">';
    nodes.forEach(node => {
      const coord = nodeCoords.get(node.id);
      if (!coord) return;
      const isMissing = node.isMissing;
      const fill = isMissing ? '#f43f5e' : node.isExternal ? '#8b5cf6' : '#1e293b';
      const stroke = isMissing ? '#fda4af' : '#00f0ff';
      const label = node.id.split('/').pop() || node.id;

      nodesHTML += `
        <g class="graph-node-group" transform="translate(${coord.x}, ${coord.y})" data-node-id="${node.id}">
          <circle r="18" fill="${fill}" stroke="${stroke}" stroke-width="2" />
          <text text-anchor="middle" dy="4" fill="#fff" font-size="9" font-family="monospace">${this.escapeHTML(label.slice(0, 5))}</text>
          <text text-anchor="middle" dy="32" fill="#94a3b8" font-size="11" font-family="sans-serif">${this.escapeHTML(label)}</text>
        </g>
      `;
    });
    nodesHTML += '</g>';

    svg.innerHTML = edgesHTML + nodesHTML;
  }

  // --- Transformation Modal Management ---

  async showPlanModal() {
    this.isProcessing = true;
    this.renderCurrentTab();

    try {
      this.currentPlan = await TransformationPlanner.generatePlan(
        this.originalFiles,
        this.activeMode,
        this.formatOptions
      );

      const modal = document.getElementById('plan-modal');
      const body = document.getElementById('plan-modal-body');
      if (modal && body) {
        body.innerHTML = `
          <p class="modal-notice">${this.t('dialogs.planNotice')}</p>
          <div class="plan-summary-metrics">
            <span class="tag-badge">Files Modified: ${this.currentPlan.summary.fileModifications}</span>
            <span class="tag-badge tag-emerald">New Extracted Modules: ${this.currentPlan.summary.newFiles}</span>
            <span class="tag-badge tag-violet">Total Actions: ${this.currentPlan.summary.totalActions}</span>
          </div>

          <div class="plan-actions-list">
            ${this.currentPlan.actions.length === 0 ? '<div class="empty-state">No transformations required for this project.</div>' : ''}
            ${this.currentPlan.actions.map(action => `
              <div class="plan-action-item">
                <div class="action-top">
                  <label class="action-check-label">
                    <input type="checkbox" class="action-toggle" data-action-id="${action.id}" ${action.enabled ? 'checked' : ''} />
                    <strong>${this.escapeHTML(action.description)}</strong>
                  </label>
                  <span class="risk-badge risk-${action.riskLevel}">${action.riskLevel.toUpperCase()} RISK</span>
                </div>
                <div class="action-diff-preview">
                  <div class="preview-col"><span class="label">Target:</span> <code>${action.file}</code></div>
                  ${action.newFilePath ? `<div class="preview-col"><span class="label">Extracted File:</span> <code>${action.newFilePath}</code></div>` : ''}
                </div>
              </div>
            `).join('')}
          </div>
        `;
        modal.classList.add('open');
      }
    } catch (err) {
      this.showToast(`Plan generation error: ${err.message}`, 'error');
    } finally {
      this.isProcessing = false;
      this.renderCurrentTab();
    }
  }

  hidePlanModal() {
    const modal = document.getElementById('plan-modal');
    if (modal) {
      modal.classList.remove('open');
    }
  }

  async approveAndApplyPlan() {
    if (!this.currentPlan) return;
    this.hidePlanModal();
    this.isProcessing = true;
    this.showToast('Applying approved transformations...', 'info');

    try {
      const result = await TransformationPlanner.applyPlan(
        this.originalFiles,
        this.currentPlan,
        this.formatOptions
      );

      this.outputFiles = result.outputFiles;
      this.activeVersion = 'output';
      await this.analyzeCurrentState();
      this.showToast(`${this.t('dialogs.planApproved')} (${result.appliedActionsCount} actions)`, 'success');
      // Switch to diff view to show the result
      this.activeTab = 'diffView';
      this.renderCurrentTab();
    } catch (err) {
      this.showToast(`Failed to apply plan: ${err.message}`, 'error');
    } finally {
      this.isProcessing = false;
      this.renderCurrentTab();
    }
  }

  cancelPlan() {
    this.hidePlanModal();
    this.currentPlan = null;
    this.showToast(this.t('dialogs.planCancelled'), 'info');
  }

  // --- Global Event Bindings ---

  bindGlobalEvents() {
    document.addEventListener('click', (e) => {
      // Language switch
      if (e.target.closest('#lang-toggle-btn')) {
        this.toggleLanguage();
      }
      // Theme switch
      if (e.target.closest('#theme-toggle-btn')) {
        this.toggleTheme();
      }
      // Navigation tabs
      const tabBtn = e.target.closest('.nav-tab');
      if (tabBtn) {
        const tab = tabBtn.getAttribute('data-tab');
        if (tab) {
          this.activeTab = tab;
          document.querySelectorAll('.nav-tab').forEach(b => b.classList.remove('active'));
          tabBtn.classList.add('active');
          this.renderCurrentTab();
        }
      }
      // Mode selector
      const modeBtn = e.target.closest('.mode-btn');
      if (modeBtn) {
        const mode = modeBtn.getAttribute('data-mode');
        if (mode) {
          this.activeMode = mode;
          document.querySelectorAll('.mode-btn').forEach(b => b.classList.remove('active'));
          modeBtn.classList.add('active');
        }
      }
      // Bottom Action: Run Process
      if (e.target.closest('#btn-process-project')) {
        this.showPlanModal();
      }
      // Bottom Action: Export ZIP
      if (e.target.closest('#btn-export-zip')) {
        this.exportZip();
      }
      // Bottom Action: Export Single File
      if (e.target.closest('#btn-export-single')) {
        this.exportSingle();
      }
      // Modal Actions
      if (e.target.closest('#btn-close-plan') || e.target.closest('#btn-cancel-plan')) {
        this.cancelPlan();
      }
      if (e.target.closest('#btn-approve-plan')) {
        this.approveAndApplyPlan();
      }
    });

    // Checkbox toggle inside plan modal
    document.addEventListener('change', (e) => {
      if (e.target.classList.contains('action-toggle') && this.currentPlan) {
        const actionId = e.target.getAttribute('data-action-id');
        const action = this.currentPlan.actions.find(a => a.id === actionId);
        if (action) {
          action.enabled = e.target.checked;
        }
      }
    });
  }

  bindWorkbenchEvents() {
    // Load sample
    const sampleBtn = document.getElementById('btn-load-sample');
    if (sampleBtn) {
      sampleBtn.onclick = () => this.loadSampleProject();
    }

    // Clear project
    const clearBtn = document.getElementById('btn-clear-proj');
    if (clearBtn) {
      clearBtn.onclick = () => this.clearProject();
    }

    // Multiple file input
    const multiInput = document.getElementById('file-input-multiple');
    if (multiInput) {
      multiInput.onchange = async (e) => {
        if (e.target.files?.length) {
          await this.handleFileImport(e.target.files);
        }
      };
    }

    // Folder input
    const folderInput = document.getElementById('folder-input');
    if (folderInput) {
      folderInput.onchange = async (e) => {
        if (e.target.files?.length) {
          await this.handleFileImport(e.target.files);
        }
      };
    }

    // ZIP input
    const zipInput = document.getElementById('zip-input');
    if (zipInput) {
      zipInput.onchange = async (e) => {
        if (e.target.files?.[0]) {
          await this.handleZipImport(e.target.files[0]);
        }
      };
    }

    // Drag & Drop
    const dropTarget = document.getElementById('drop-target');
    if (dropTarget) {
      dropTarget.ondragover = (e) => {
        e.preventDefault();
        dropTarget.classList.add('dragover');
      };
      dropTarget.ondragleave = () => {
        dropTarget.classList.remove('dragover');
      };
      dropTarget.ondrop = async (e) => {
        e.preventDefault();
        dropTarget.classList.remove('dragover');
        if (e.dataTransfer?.files?.length) {
          const files = e.dataTransfer.files;
          if (files.length === 1 && files[0].name.endsWith('.zip')) {
            await this.handleZipImport(files[0]);
          } else {
            await this.handleFileImport(files);
          }
        }
      };
    }

    // Add pasted file
    const addPastedBtn = document.getElementById('btn-add-pasted');
    if (addPastedBtn) {
      addPastedBtn.onclick = () => {
        const filename = (document.getElementById('paste-filename')?.value || 'untitled.js').trim();
        const code = document.getElementById('paste-code-input')?.value || '';
        if (!code.trim()) {
          this.showToast('Please enter some code to add.', 'warning');
          return;
        }

        const pathCheck = ImportStorageManager.validatePath(filename);
        if (!pathCheck.valid) {
          this.showToast(`Invalid path: ${pathCheck.error}`, 'error');
          return;
        }

        const lang = LanguageDetector.detect(pathCheck.sanitizedPath, code);
        const newFile = {
          path: pathCheck.sanitizedPath,
          content: code,
          language: lang,
          size: code.length
        };

        this.originalFiles = this.originalFiles.filter(f => f.path !== newFile.path);
        this.originalFiles.push(newFile);
        this.outputFiles = JSON.parse(JSON.stringify(this.originalFiles));
        this.selectedFilePath = newFile.path;
        this.analyzeCurrentState();
        this.showToast(`Added '${newFile.path}' to project.`, 'success');
      };
    }

    // File item click in list
    const fileItems = document.querySelectorAll('.file-item');
    fileItems.forEach(item => {
      item.onclick = () => {
        const path = item.getAttribute('data-path');
        if (path) {
          this.selectedFilePath = path;
          this.renderCurrentTab();
        }
      };
    });

    // Version switch pill
    const verPills = document.querySelectorAll('.version-toggle .toggle-pill');
    verPills.forEach(pill => {
      pill.onclick = () => {
        const ver = pill.getAttribute('data-ver');
        if (ver) {
          this.activeVersion = ver;
          this.renderCurrentTab();
        }
      };
    });

    // Format current file button
    const fmtBtn = document.getElementById('btn-format-current');
    if (fmtBtn) {
      fmtBtn.onclick = async () => {
        const files = this.activeVersion === 'output' ? this.outputFiles : this.originalFiles;
        const cur = files.find(f => f.path === this.selectedFilePath);
        if (!cur) return;

        const res = await FormatterAdapter.format(cur.content, cur.language?.id, this.formatOptions);
        if (res.error) {
          this.showToast(res.error, 'error');
        } else {
          cur.content = res.formatted;
          const editor = document.getElementById('active-file-editor');
          if (editor) editor.value = cur.content;
          this.showToast('Formatted successfully.', 'success');
        }
      };
    }
  }

  async handleFileImport(fileList) {
    this.isProcessing = true;
    this.showToast('Importing and validating files...', 'info');

    try {
      const { files, warnings } = await ImportStorageManager.importFiles(fileList, this.limits);
      if (files.length === 0) {
        this.showToast('No valid files imported.', 'warning');
        return;
      }

      this.originalFiles = files;
      this.outputFiles = JSON.parse(JSON.stringify(files));
      this.selectedFilePath = files[0].path;
      await this.analyzeCurrentState();

      if (warnings.length > 0) {
        this.showToast(`Imported ${files.length} files (${warnings.length} warnings)`, 'warning');
      } else {
        this.showToast(`Successfully imported ${files.length} files.`, 'success');
      }
    } catch (err) {
      this.showToast(`Import rejected: ${err.message}`, 'error');
    } finally {
      this.isProcessing = false;
      this.renderCurrentTab();
    }
  }

  async handleZipImport(zipFile) {
    this.isProcessing = true;
    this.showToast('Decompressing and validating ZIP archive...', 'info');

    try {
      const { files, warnings } = await ImportStorageManager.importZip(zipFile, this.limits);
      if (files.length === 0) {
        this.showToast('No valid files found in archive.', 'warning');
        return;
      }

      this.originalFiles = files;
      this.outputFiles = JSON.parse(JSON.stringify(files));
      this.selectedFilePath = files[0].path;
      await this.analyzeCurrentState();

      if (warnings.length > 0) {
        this.showToast(`Extracted ${files.length} files with ${warnings.length} warnings.`, 'warning');
      } else {
        this.showToast(`Extracted ${files.length} files safely from ZIP.`, 'success');
      }
    } catch (err) {
      this.showToast(`ZIP Security Rejection: ${err.message}`, 'error');
    } finally {
      this.isProcessing = false;
      this.renderCurrentTab();
    }
  }

  bindDepGraphEvents() {
    this.renderGraphSVG();
  }

  bindDiffEvents() {
    const fileSelect = document.getElementById('diff-file-select');
    if (fileSelect) {
      fileSelect.onchange = (e) => {
        this.selectedFilePath = e.target.value;
        this.renderCurrentTab();
      };
    }

    const diffModePills = document.querySelectorAll('[data-diff-mode]');
    diffModePills.forEach(pill => {
      pill.onclick = () => {
        this.diffMode = pill.getAttribute('data-diff-mode');
        this.renderCurrentTab();
      };
    });
  }

  bindValidationEvents() {
    // Validation is already reactive
  }

  bindTestSuiteEvents() {
    const runBtn = document.getElementById('btn-run-all-tests');
    if (runBtn) {
      runBtn.onclick = async () => {
        runBtn.disabled = true;
        runBtn.innerHTML = '⏳ Executing Tests...';
        this.showToast('Executing acceptance test suite...', 'info');

        try {
          this.lastTestResults = await AcceptanceTestSuite.runAllTests((progress) => {
            runBtn.innerHTML = `⏳ [${progress.current}/${progress.total}] ${progress.name}...`;
          });
          this.showToast(`Test suite complete: ${this.lastTestResults.summary.passed}/${this.lastTestResults.summary.total} passed.`, 'success');
        } catch (err) {
          this.showToast(`Test suite error: ${err.message}`, 'error');
        } finally {
          this.renderCurrentTab();
        }
      };
    }
  }

  bindSettingsEvents() {
    const indentSelect = document.getElementById('opt-indent-size');
    if (indentSelect) {
      indentSelect.onchange = (e) => {
        this.formatOptions.indentSize = parseInt(e.target.value, 10);
      };
    }

    const useTabsCheck = document.getElementById('opt-use-tabs');
    if (useTabsCheck) {
      useTabsCheck.onchange = (e) => {
        this.formatOptions.useTabs = e.target.checked;
      };
    }

    const semiCheck = document.getElementById('opt-semi');
    if (semiCheck) {
      semiCheck.onchange = (e) => {
        this.formatOptions.semi = e.target.checked;
      };
    }

    const quotesSelect = document.getElementById('opt-single-quote');
    if (quotesSelect) {
      quotesSelect.onchange = (e) => {
        this.formatOptions.singleQuote = e.target.value === 'true';
      };
    }

    const printWidthInput = document.getElementById('opt-print-width');
    if (printWidthInput) {
      printWidthInput.onchange = (e) => {
        this.formatOptions.printWidth = parseInt(e.target.value, 10);
      };
    }

    // Save IDB
    const saveIdb = document.getElementById('btn-save-idb');
    if (saveIdb) {
      saveIdb.onclick = async () => {
        try {
          await ImportStorageManager.saveProjectToIndexedDB({
            originalFiles: this.originalFiles,
            outputFiles: this.outputFiles,
            selectedFilePath: this.selectedFilePath
          });
          this.showToast(this.t('dialogs.savedSuccess'), 'success');
        } catch (err) {
          this.showToast(`Save failed: ${err.message}`, 'error');
        }
      };
    }

    // Load IDB
    const loadIdb = document.getElementById('btn-load-idb');
    if (loadIdb) {
      loadIdb.onclick = async () => {
        try {
          const saved = await ImportStorageManager.loadProjectFromIndexedDB();
          if (saved && saved.originalFiles) {
            this.originalFiles = saved.originalFiles;
            this.outputFiles = saved.outputFiles || saved.originalFiles;
            this.selectedFilePath = saved.selectedFilePath || (this.originalFiles[0]?.path || '');
            await this.analyzeCurrentState();
            this.showToast('Loaded saved project from IndexedDB.', 'success');
          } else {
            this.showToast('No saved project found in IndexedDB.', 'warning');
          }
        } catch (err) {
          this.showToast(`Load failed: ${err.message}`, 'error');
        }
      };
    }

    // Purge IDB
    const purgeIdb = document.getElementById('btn-purge-idb');
    if (purgeIdb) {
      purgeIdb.onclick = async () => {
        try {
          await ImportStorageManager.purgeIndexedDB();
          this.showToast(this.t('dialogs.purgeSuccess'), 'info');
        } catch (err) {
          this.showToast(`Purge failed: ${err.message}`, 'error');
        }
      };
    }

    // Download standalone workbench
    const dlWb = document.getElementById('btn-download-workbench');
    if (dlWb) {
      dlWb.onclick = () => this.exportStandaloneWorkbench();
    }
  }

  // --- Export Actions ---

  async exportZip() {
    const files = this.outputFiles.length > 0 ? this.outputFiles : this.originalFiles;
    if (files.length === 0) {
      this.showToast('No files to export.', 'warning');
      return;
    }

    this.showToast('Generating project ZIP archive...', 'info');
    try {
      const blob = await Exporter.exportProjectZip(
        this.originalFiles,
        this.outputFiles.length > 0 ? this.outputFiles : this.originalFiles,
        this.currentDepGraph,
        this.currentPlan,
        this.currentValidation
      );
      Exporter.downloadFile(blob, 'isolated-cleaned-project.zip', 'application/zip');
      this.showToast(this.t('dialogs.exportComplete'), 'success');
    } catch (err) {
      this.showToast(`Export failed: ${err.message}`, 'error');
    }
  }

  exportSingle() {
    const files = this.outputFiles.length > 0 ? this.outputFiles : this.originalFiles;
    if (files.length === 0) {
      this.showToast('No files to export.', 'warning');
      return;
    }

    try {
      Exporter.exportSingleFile(files);
      this.showToast('Exported single file bundle.', 'success');
    } catch (err) {
      this.showToast(`Export failed: ${err.message}`, 'error');
    }
  }

  async exportStandaloneWorkbench() {
    this.showToast('Packaging standalone offline workbench...', 'info');
    try {
      // Build a portable zip package of the workbench itself
      const zip = new JSZip();
      zip.file('README.md', `# Code Isolation & Cleanup Workbench V1.0 (Standalone Distribution)

Run this application offline on any modern browser (Chrome, Edge, Safari, Firefox).
No Node.js, npm, or build step required.`);

      const blob = await zip.generateAsync({ type: 'blob' });
      Exporter.downloadFile(blob, 'code-isolation-workbench-v1.0-standalone.zip', 'application/zip');
      this.showToast('Downloaded standalone workbench package.', 'success');
    } catch (err) {
      this.showToast(`Export error: ${err.message}`, 'error');
    }
  }

  // --- Helpers ---

  escapeHTML(str = '') {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  getFileIcon(path = '') {
    if (path.endsWith('.js') || path.endsWith('.mjs')) return '🟨';
    if (path.endsWith('.ts') || path.endsWith('.tsx')) return '🔷';
    if (path.endsWith('.html') || path.endsWith('.htm')) return '🟧';
    if (path.endsWith('.css')) return '🎨';
    if (path.endsWith('.json')) return '📋';
    return '📄';
  }
}
