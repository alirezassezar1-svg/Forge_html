// ============================================================================
// Code Isolation & Cleanup Workbench V1.0 - Dependency Graph Engine
// AST-driven Topology, Cycle Detection, Missing References, Dynamic Imports, Globals
// ============================================================================

import { ParserAdapter } from './parser-adapter.js';

export class DependencyGraphEngine {
  /**
   * Resolves a relative import path against the importer's directory.
   * @param {string} importerPath - Path of the importing file (e.g. "src/sub/app.js")
   * @param {string} specifier - The imported path string (e.g. "../utils" or "./helper.js")
   * @param {Set<string>} existingFilePaths - Set of all known file paths in project
   * @returns {{ resolvedPath: string, isRelative: boolean, isFound: boolean, isExternal: boolean }}
   */
  static resolveImport(importerPath, specifier, existingFilePaths) {
    if (!specifier || typeof specifier !== 'string') {
      return { resolvedPath: '', isRelative: false, isFound: false, isExternal: false };
    }

    const isRelative = specifier.startsWith('./') || specifier.startsWith('../');
    if (!isRelative) {
      // External package (e.g. "lodash", "react") or URL
      return {
        resolvedPath: specifier,
        isRelative: false,
        isFound: false,
        isExternal: !specifier.startsWith('http://') && !specifier.startsWith('https://')
      };
    }

    // Get importer directory
    const parts = importerPath.replace(/\\/g, '/').split('/');
    parts.pop(); // Remove file name, keep directory

    const specParts = specifier.replace(/\\/g, '/').split('/');
    for (const seg of specParts) {
      if (seg === '' || seg === '.') continue;
      if (seg === '..') {
        parts.pop();
      } else {
        parts.push(seg);
      }
    }

    const candidate = parts.join('/');

    // 1. Exact match
    if (existingFilePaths.has(candidate)) {
      return { resolvedPath: candidate, isRelative: true, isFound: true, isExternal: false };
    }

    // 2. Try common extensions (.js, .mjs, .ts, .css, .json)
    const extensions = ['.js', '.mjs', '.ts', '.css', '.json', '.jsx', '.tsx'];
    for (const ext of extensions) {
      if (existingFilePaths.has(candidate + ext)) {
        return { resolvedPath: candidate + ext, isRelative: true, isFound: true, isExternal: false };
      }
    }

    // 3. Try index files inside directory (candidate + /index.js)
    for (const ext of extensions) {
      const indexCandidate = `${candidate}/index${ext}`;
      if (existingFilePaths.has(indexCandidate)) {
        return { resolvedPath: indexCandidate, isRelative: true, isFound: true, isExternal: false };
      }
    }

    return { resolvedPath: candidate, isRelative: true, isFound: false, isExternal: false };
  }

  /**
   * Builds the comprehensive dependency graph from a collection of project files.
   * @param {Array<{ path: string, content: string, language: any }>} files
   * @returns {{
   *   nodes: Array<{ id: string, label: string, language: string, isMissing: boolean, isExternal: boolean, globals: any[] }>,
   *   edges: Array<{ id: string, source: string, target: string, type: string, isDynamic: boolean, line: number, specifier: string }>,
   *   cycles: string[][],
   *   missingReferences: Array<{ source: string, specifier: string, line: number }>,
   *   dynamicDependencies: Array<{ source: string, specifier: string, line: number }>,
   *   globalRisks: Array<{ file: string, name: string, line: number, type: string }>,
   *   stats: { totalNodes: number, totalEdges: number, cycleCount: number, missingCount: number }
   * }}
   */
  static buildGraph(files) {
    const existingFilePaths = new Set(files.map(f => f.path));
    const nodeMap = new Map();
    const edges = [];
    const missingReferences = [];
    const dynamicDependencies = [];
    const globalRisks = [];

    // Initialize nodes for all project files
    for (const file of files) {
      nodeMap.set(file.path, {
        id: file.path,
        label: file.path,
        language: file.language?.id || 'unknown',
        isMissing: false,
        isExternal: false,
        globals: []
      });
    }

    // Parse each file and identify edges
    for (const file of files) {
      const langId = file.language?.id || '';

      // JavaScript / TypeScript files
      if (langId === 'javascript' || langId === 'typescript' || langId === 'jsx' || file.path.endsWith('.js') || file.path.endsWith('.mjs')) {
        const { ast } = ParserAdapter.parseJS(file.content, 'module');
        if (ast) {
          const analysis = ParserAdapter.analyzeJSAST(ast);

          // Add globals to node & risks
          for (const g of analysis.globalLeaks) {
            nodeMap.get(file.path).globals.push(g);
            globalRisks.push({
              file: file.path,
              name: g.name,
              line: g.line,
              type: g.type
            });
          }

          // ES Imports
          for (const imp of analysis.imports) {
            if (imp.isDynamic) {
              dynamicDependencies.push({ source: file.path, specifier: imp.source, line: imp.line });
            }

            const resolved = this.resolveImport(file.path, imp.source, existingFilePaths);
            const targetId = resolved.resolvedPath;

            if (resolved.isRelative && !resolved.isFound) {
              missingReferences.push({ source: file.path, specifier: imp.source, line: imp.line });
              if (!nodeMap.has(targetId)) {
                nodeMap.set(targetId, {
                  id: targetId,
                  label: targetId,
                  language: 'missing',
                  isMissing: true,
                  isExternal: false,
                  globals: []
                });
              }
            } else if (resolved.isExternal && !nodeMap.has(targetId)) {
              nodeMap.set(targetId, {
                id: targetId,
                label: targetId,
                language: 'external-npm',
                isMissing: false,
                isExternal: true,
                globals: []
              });
            }

            edges.push({
              id: `${file.path}->${targetId}:${imp.line}`,
              source: file.path,
              target: targetId,
              type: imp.isDynamic ? 'dynamic-import' : 'es-import',
              isDynamic: imp.isDynamic,
              line: imp.line,
              specifier: imp.source
            });
          }

          // CommonJS requires
          for (const req of analysis.requires) {
            if (req.isDynamic) {
              dynamicDependencies.push({ source: file.path, specifier: req.source, line: req.line });
            }

            const resolved = this.resolveImport(file.path, req.source, existingFilePaths);
            const targetId = resolved.resolvedPath;

            if (resolved.isRelative && !resolved.isFound) {
              missingReferences.push({ source: file.path, specifier: req.source, line: req.line });
              if (!nodeMap.has(targetId)) {
                nodeMap.set(targetId, {
                  id: targetId,
                  label: targetId,
                  language: 'missing',
                  isMissing: true,
                  isExternal: false,
                  globals: []
                });
              }
            } else if (resolved.isExternal && !nodeMap.has(targetId)) {
              nodeMap.set(targetId, {
                id: targetId,
                label: targetId,
                language: 'external-npm',
                isMissing: false,
                isExternal: true,
                globals: []
              });
            }

            edges.push({
              id: `${file.path}->${targetId}:${req.line}`,
              source: file.path,
              target: targetId,
              type: req.isDynamic ? 'dynamic-require' : 'commonjs-require',
              isDynamic: req.isDynamic,
              line: req.line,
              specifier: req.source
            });
          }
        }
      }

      // HTML files
      else if (langId === 'html' || file.path.endsWith('.html') || file.path.endsWith('.htm')) {
        const components = ParserAdapter.extractHTMLComponents(file.content);

        // Scripts
        for (const s of components.externalScripts) {
          const resolved = this.resolveImport(file.path, s.src, existingFilePaths);
          const targetId = resolved.resolvedPath;

          if (resolved.isRelative && !resolved.isFound) {
            missingReferences.push({ source: file.path, specifier: s.src, line: 1 });
            if (!nodeMap.has(targetId)) {
              nodeMap.set(targetId, {
                id: targetId,
                label: targetId,
                language: 'missing',
                isMissing: true,
                isExternal: false,
                globals: []
              });
            }
          }

          edges.push({
            id: `${file.path}->${targetId}:script`,
            source: file.path,
            target: targetId,
            type: 'html-script',
            isDynamic: false,
            line: 1,
            specifier: s.src
          });
        }

        // Styles
        for (const st of components.externalStyles) {
          const resolved = this.resolveImport(file.path, st.href, existingFilePaths);
          const targetId = resolved.resolvedPath;

          if (resolved.isRelative && !resolved.isFound) {
            missingReferences.push({ source: file.path, specifier: st.href, line: 1 });
            if (!nodeMap.has(targetId)) {
              nodeMap.set(targetId, {
                id: targetId,
                label: targetId,
                language: 'missing',
                isMissing: true,
                isExternal: false,
                globals: []
              });
            }
          }

          edges.push({
            id: `${file.path}->${targetId}:style`,
            source: file.path,
            target: targetId,
            type: 'html-style',
            isDynamic: false,
            line: 1,
            specifier: st.href
          });
        }
      }

      // CSS files
      else if (langId === 'css' || file.path.endsWith('.css')) {
        const parsed = ParserAdapter.parseCSS(file.content);
        for (const imp of parsed.imports) {
          const resolved = this.resolveImport(file.path, imp, existingFilePaths);
          const targetId = resolved.resolvedPath;

          if (resolved.isRelative && !resolved.isFound) {
            missingReferences.push({ source: file.path, specifier: imp, line: 1 });
            if (!nodeMap.has(targetId)) {
              nodeMap.set(targetId, {
                id: targetId,
                label: targetId,
                language: 'missing',
                isMissing: true,
                isExternal: false,
                globals: []
              });
            }
          }

          edges.push({
            id: `${file.path}->${targetId}:css-import`,
            source: file.path,
            target: targetId,
            type: 'css-import',
            isDynamic: false,
            line: 1,
            specifier: imp
          });
        }
      }
    }

    // Detect cycles using DFS with recursion stack
    const cycles = this.detectCycles(Array.from(nodeMap.keys()), edges);

    return {
      nodes: Array.from(nodeMap.values()),
      edges,
      cycles,
      missingReferences,
      dynamicDependencies,
      globalRisks,
      stats: {
        totalNodes: nodeMap.size,
        totalEdges: edges.length,
        cycleCount: cycles.length,
        missingCount: missingReferences.length
      }
    };
  }

  /**
   * Detects circular dependencies in the graph.
   * Returns an array of cycles, where each cycle is an array of node IDs (e.g. ['a.js', 'b.js', 'a.js'])
   * @param {string[]} nodeIds
   * @param {Array<{ source: string, target: string }>} edges
   * @returns {string[][]}
   */
  static detectCycles(nodeIds, edges) {
    const adj = new Map();
    for (const id of nodeIds) {
      adj.set(id, []);
    }
    for (const edge of edges) {
      if (adj.has(edge.source)) {
        adj.get(edge.source).push(edge.target);
      }
    }

    const visited = new Set();
    const recStack = new Set();
    const pathStack = [];
    const cycles = [];
    const seenCycleSignatures = new Set();

    function dfs(u) {
      visited.add(u);
      recStack.add(u);
      pathStack.push(u);

      const neighbors = adj.get(u) || [];
      for (const v of neighbors) {
        if (!visited.has(v)) {
          dfs(v);
        } else if (recStack.has(v)) {
          // Cycle found!
          const startIndex = pathStack.indexOf(v);
          if (startIndex !== -1) {
            const cyclePath = pathStack.slice(startIndex);
            cyclePath.push(v); // close the loop
            // Normalize cycle signature to avoid reporting permutations of the same cycle
            const loopNodes = cyclePath.slice(0, -1);
            const minNode = [...loopNodes].sort()[0];
            const minIndex = loopNodes.indexOf(minNode);
            const normalized = [...loopNodes.slice(minIndex), ...loopNodes.slice(0, minIndex)].join('->');

            if (!seenCycleSignatures.has(normalized)) {
              seenCycleSignatures.add(normalized);
              cycles.push(cyclePath);
            }
          }
        }
      }

      recStack.delete(u);
      pathStack.pop();
    }

    for (const id of nodeIds) {
      if (!visited.has(id)) {
        dfs(id);
      }
    }

    return cycles;
  }
}
