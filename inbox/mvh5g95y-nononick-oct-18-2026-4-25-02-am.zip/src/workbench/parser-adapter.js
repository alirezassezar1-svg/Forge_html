// ============================================================================
// Code Isolation & Cleanup Workbench V1.0 - Parser Adapter
// Acorn JS AST Parsing, CSS Tokenization & AST, HTML Asset & Script Extraction
// ============================================================================

import * as acorn from 'acorn';

export class ParserAdapter {
  /**
   * Parses JavaScript source code using Acorn.
   * Supports ES2022+ syntax, both module and script modes.
   * @param {string} code
   * @param {'module'|'script'} [sourceType='module']
   * @returns {{ ast: any, errors: string[], sourceType: string }}
   */
  static parseJS(code, sourceType = 'module') {
    const errors = [];
    try {
      const ast = acorn.parse(code, {
        ecmaVersion: 'latest',
        sourceType,
        locations: true,
        ranges: true
      });
      return { ast, errors: [], sourceType };
    } catch (err1) {
      // If module parse fails, attempt script parse fallback
      if (sourceType === 'module') {
        try {
          const ast = acorn.parse(code, {
            ecmaVersion: 'latest',
            sourceType: 'script',
            locations: true,
            ranges: true
          });
          return { ast, errors: [], sourceType: 'script' };
        } catch (err2) {
          errors.push(`JS Syntax Error (Line ${err1.loc?.line || '?'}, Col ${err1.loc?.column || '?'}): ${err1.message}`);
          return { ast: null, errors, sourceType };
        }
      }
      errors.push(`JS Syntax Error (Line ${err1.loc?.line || '?'}, Col ${err1.loc?.column || '?'}): ${err1.message}`);
      return { ast: null, errors, sourceType };
    }
  }

  /**
   * Traverses an Acorn AST using recursive depth-first walk.
   * @param {any} node
   * @param {Record<string, (node: any, parent: any) => void>} visitors
   * @param {any} [parent=null]
   */
  static walkAST(node, visitors, parent = null) {
    if (!node || typeof node !== 'object') return;

    if (visitors[node.type]) {
      visitors[node.type](node, parent);
    }

    for (const key of Object.keys(node)) {
      if (key === 'loc' || key === 'range') continue;
      const child = node[key];
      if (Array.isArray(child)) {
        for (const item of child) {
          if (item && typeof item.type === 'string') {
            this.walkAST(item, visitors, node);
          }
        }
      } else if (child && typeof child.type === 'string') {
        this.walkAST(child, visitors, node);
      }
    }
  }

  /**
   * Inspects a JS AST to extract dependencies, exports, globals, and dynamic imports.
   * @param {any} ast
   * @returns {{
   *   imports: Array<{ source: string, specifiers: string[], isDynamic: boolean, line: number }>,
   *   requires: Array<{ source: string, line: number, isDynamic: boolean }>,
   *   exports: Array<{ name: string, isDefault: boolean, line: number }>,
   *   globalLeaks: Array<{ name: string, line: number, type: 'window'|'implicit'|'globalThis' }>,
   *   topLevelDeclarations: Array<{ name: string, type: string, line: number }>
   * }}
   */
  static analyzeJSAST(ast) {
    const results = {
      imports: [],
      requires: [],
      exports: [],
      globalLeaks: [],
      topLevelDeclarations: []
    };

    if (!ast) return results;

    const declaredTopLevel = new Set();

    // 1. Collect top-level declarations
    if (ast.body && Array.isArray(ast.body)) {
      for (const statement of ast.body) {
        if (statement.type === 'VariableDeclaration') {
          for (const decl of statement.declarations) {
            if (decl.id && decl.id.name) {
              declaredTopLevel.add(decl.id.name);
              results.topLevelDeclarations.push({
                name: decl.id.name,
                type: statement.kind,
                line: statement.loc?.start?.line || 1
              });
            }
          }
        } else if (statement.type === 'FunctionDeclaration' && statement.id) {
          declaredTopLevel.add(statement.id.name);
          results.topLevelDeclarations.push({
            name: statement.id.name,
            type: 'function',
            line: statement.loc?.start?.line || 1
          });
        } else if (statement.type === 'ClassDeclaration' && statement.id) {
          declaredTopLevel.add(statement.id.name);
          results.topLevelDeclarations.push({
            name: statement.id.name,
            type: 'class',
            line: statement.loc?.start?.line || 1
          });
        }
      }
    }

    // 2. Walk AST to find imports, requires, dynamic imports, exports, and global leaks
    this.walkAST(ast, {
      ImportDeclaration: (node) => {
        const source = node.source?.value;
        if (typeof source === 'string') {
          const specifiers = (node.specifiers || []).map(s => {
            if (s.type === 'ImportDefaultSpecifier') return `default as ${s.local?.name}`;
            if (s.type === 'ImportNamespaceSpecifier') return `* as ${s.local?.name}`;
            return s.imported?.name ? `${s.imported.name} as ${s.local?.name}` : s.local?.name;
          });
          results.imports.push({
            source,
            specifiers,
            isDynamic: false,
            line: node.loc?.start?.line || 1
          });
        }
      },

      ImportExpression: (node) => {
        // dynamic import(...)
        const isLiteral = node.source && node.source.type === 'Literal' && typeof node.source.value === 'string';
        results.imports.push({
          source: isLiteral ? node.source.value : '<dynamic_expression>',
          specifiers: ['* (dynamic)'],
          isDynamic: true,
          line: node.loc?.start?.line || 1
        });
      },

      ExportNamedDeclaration: (node) => {
        if (node.declaration) {
          if (node.declaration.declarations) {
            for (const d of node.declaration.declarations) {
              if (d.id?.name) {
                results.exports.push({ name: d.id.name, isDefault: false, line: node.loc?.start?.line || 1 });
              }
            }
          } else if (node.declaration.id?.name) {
            results.exports.push({ name: node.declaration.id.name, isDefault: false, line: node.loc?.start?.line || 1 });
          }
        }
        if (node.specifiers) {
          for (const s of node.specifiers) {
            results.exports.push({ name: s.exported?.name || s.local?.name, isDefault: false, line: node.loc?.start?.line || 1 });
          }
        }
      },

      ExportDefaultDeclaration: (node) => {
        results.exports.push({
          name: node.declaration?.id?.name || 'default',
          isDefault: true,
          line: node.loc?.start?.line || 1
        });
      },

      CallExpression: (node) => {
        // CommonJS require('path')
        if (node.callee && node.callee.type === 'Identifier' && node.callee.name === 'require') {
          const firstArg = node.arguments?.[0];
          if (firstArg && firstArg.type === 'Literal' && typeof firstArg.value === 'string') {
            results.requires.push({
              source: firstArg.value,
              line: node.loc?.start?.line || 1,
              isDynamic: false
            });
          } else {
            results.requires.push({
              source: '<dynamic_require_expression>',
              line: node.loc?.start?.line || 1,
              isDynamic: true
            });
          }
        }
      },

      AssignmentExpression: (node) => {
        // Detect window.xyz = ... or globalThis.xyz = ...
        if (node.left && node.left.type === 'MemberExpression') {
          const obj = node.left.object;
          const prop = node.left.property;
          if (obj && obj.type === 'Identifier' && (obj.name === 'window' || obj.name === 'globalThis' || obj.name === 'global')) {
            const propName = prop?.name || prop?.value || '<unknown>';
            results.globalLeaks.push({
              name: `${obj.name}.${propName}`,
              line: node.loc?.start?.line || 1,
              type: obj.name
            });
          }
        }
      }
    });

    return results;
  }

  /**
   * HTML Extractor: Extracts inline scripts and styles, and references to external links/scripts.
   * @param {string} htmlContent
   * @returns {{
   *   externalScripts: Array<{ src: string, isModule: boolean, rawTag: string }>,
   *   externalStyles: Array<{ href: string, rawTag: string }>,
   *   inlineScripts: Array<{ id: number, content: string, isModule: boolean, rawTag: string }>,
   *   inlineStyles: Array<{ id: number, content: string, rawTag: string }>
   * }}
   */
  static extractHTMLComponents(htmlContent) {
    const results = {
      externalScripts: [],
      externalStyles: [],
      inlineScripts: [],
      inlineStyles: []
    };

    if (!htmlContent || typeof htmlContent !== 'string') return results;

    // 1. External styles: <link rel="stylesheet" href="...">
    const linkRegex = /<link\b([^>]*?)>/gi;
    let linkMatch;
    while ((linkMatch = linkRegex.exec(htmlContent)) !== null) {
      const attrs = linkMatch[1];
      if (/rel=["']stylesheet["']/i.test(attrs)) {
        const hrefMatch = attrs.match(/href=["']([^"']+)["']/i);
        if (hrefMatch) {
          results.externalStyles.push({
            href: hrefMatch[1],
            rawTag: linkMatch[0]
          });
        }
      }
    }

    // 2. Inline styles: <style...>...</style>
    const styleRegex = /<style\b([^>]*)>([\s\S]*?)<\/style>/gi;
    let styleMatch;
    let styleCount = 0;
    while ((styleMatch = styleRegex.exec(htmlContent)) !== null) {
      styleCount++;
      results.inlineStyles.push({
        id: styleCount,
        content: styleMatch[2].trim(),
        rawTag: styleMatch[0]
      });
    }

    // 3. Scripts: <script...>...</script>
    const scriptRegex = /<script\b([^>]*)>([\s\S]*?)<\/script>/gi;
    let scriptMatch;
    let scriptCount = 0;
    while ((scriptMatch = scriptRegex.exec(htmlContent)) !== null) {
      const attrs = scriptMatch[1];
      const body = scriptMatch[2].trim();
      const isModule = /type=["']module["']/i.test(attrs);
      const srcMatch = attrs.match(/src=["']([^"']+)["']/i);

      if (srcMatch) {
        results.externalScripts.push({
          src: srcMatch[1],
          isModule,
          rawTag: scriptMatch[0]
        });
      } else if (body.length > 0) {
        scriptCount++;
        results.inlineScripts.push({
          id: scriptCount,
          content: body,
          isModule,
          rawTag: scriptMatch[0]
        });
      }
    }

    return results;
  }

  /**
   * Parses and validates CSS syntax and extracts @import dependencies.
   * @param {string} cssContent
   * @returns {{
   *   valid: boolean,
   *   imports: string[],
   *   ruleCount: number,
   *   errors: string[]
   * }}
   */
  static parseCSS(cssContent) {
    const imports = [];
    const errors = [];
    let ruleCount = 0;

    if (!cssContent || typeof cssContent !== 'string') {
      return { valid: true, imports: [], ruleCount: 0, errors: [] };
    }

    // Check balanced braces
    let openBraces = 0;
    let inComment = false;
    let inString = false;
    let stringChar = '';

    for (let i = 0; i < cssContent.length; i++) {
      const char = cssContent[i];
      const nextChar = cssContent[i + 1];

      if (!inComment && !inString && char === '/' && nextChar === '*') {
        inComment = true;
        i++;
        continue;
      }
      if (inComment && char === '*' && nextChar === '/') {
        inComment = false;
        i++;
        continue;
      }
      if (inComment) continue;

      if (!inString && (char === '"' || char === "'")) {
        inString = true;
        stringChar = char;
        continue;
      }
      if (inString && char === stringChar && cssContent[i - 1] !== '\\') {
        inString = false;
        continue;
      }
      if (inString) continue;

      if (char === '{') {
        openBraces++;
        ruleCount++;
      } else if (char === '}') {
        openBraces--;
        if (openBraces < 0) {
          errors.push(`Unmatched closing brace '}' at character position ${i}`);
          break;
        }
      }
    }

    if (openBraces > 0) {
      errors.push(`Unclosed block: ${openBraces} opening brace(s) '{' not closed.`);
    }

    // Extract @import statements
    const importRegex = /@import\s+(?:url\(['"]?([^'"\)]+)['"]?\)|['"]([^'"]+)['"])\s*;/gi;
    let match;
    while ((match = importRegex.exec(cssContent)) !== null) {
      const importPath = match[1] || match[2];
      if (importPath) {
        imports.push(importPath);
      }
    }

    return {
      valid: errors.length === 0,
      imports,
      ruleCount,
      errors
    };
  }
}
