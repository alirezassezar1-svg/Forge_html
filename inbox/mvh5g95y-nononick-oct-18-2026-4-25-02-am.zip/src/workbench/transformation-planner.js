// ============================================================================
// Code Isolation & Cleanup Workbench V1.0 - Transformation Planner
// Proposes structural changes, requires explicit user review & approval
// Preserves originals, provides reversible output generation
// ============================================================================

import { ParserAdapter } from './parser-adapter.js';
import { FormatterAdapter } from './formatter-adapter.js';
import { LanguageDetector } from './language-detector.js';

export class TransformationPlanner {
  /**
   * Generates a proposed transformation plan for the given project files.
   * Does NOT alter the files.
   * @param {Array<{ path: string, content: string, language: any }>} files
   * @param {'format-only' | 'modularize'} mode
   * @param {object} formatOptions
   * @returns {Promise<{
   *   mode: string,
   *   planId: string,
   *   createdAt: string,
   *   summary: { fileModifications: number, newFiles: number, totalActions: number },
   *   actions: Array<{
   *     id: string,
   *     type: 'extract-style' | 'extract-script' | 'convert-esm' | 'isolate-globals' | 'format',
   *     file: string,
   *     newFilePath?: string,
   *     description: string,
   *     riskLevel: 'low' | 'medium' | 'high',
   *     enabled: boolean,
   *     previewBefore: string,
   *     previewAfter: string
   *   }>
   * }>}
   */
  static async generatePlan(files, mode = 'modularize', formatOptions = {}) {
    const actions = [];
    let actionCounter = 0;

    for (const file of files) {
      const langId = file.language?.id || '';

      // Format-only mode: only plan formatting actions
      if (mode === 'format-only') {
        if (file.language?.canFormat) {
          const { formatted, changed } = await FormatterAdapter.format(file.content, langId, formatOptions);
          if (changed) {
            actionCounter++;
            actions.push({
              id: `action_${actionCounter}`,
              type: 'format',
              file: file.path,
              description: `Format code according to style rules (indent: ${formatOptions.indentSize || 2}, semi: ${formatOptions.semi ?? true})`,
              riskLevel: 'low',
              enabled: true,
              previewBefore: file.content.slice(0, 200),
              previewAfter: formatted.slice(0, 200)
            });
          }
        }
        continue;
      }

      // Modularize Mode:
      // 1. HTML File Analysis: extract inline scripts and styles
      if (langId === 'html' || file.path.endsWith('.html') || file.path.endsWith('.htm')) {
        const components = ParserAdapter.extractHTMLComponents(file.content);
        const baseName = file.path.replace(/\.[^/.]+$/, '').replace(/\\/g, '/');

        // Plan extraction for inline styles
        for (const st of components.inlineStyles) {
          if (st.content.length > 0) {
            actionCounter++;
            const extractedPath = `styles/${baseName.split('/').pop()}-style-${st.id}.css`;
            actions.push({
              id: `action_${actionCounter}`,
              type: 'extract-style',
              file: file.path,
              newFilePath: extractedPath,
              description: `Extract inline <style> (#${st.id}) into standalone stylesheet '${extractedPath}' and link via <link rel="stylesheet">`,
              riskLevel: 'low',
              enabled: true,
              previewBefore: st.rawTag.slice(0, 200),
              previewAfter: `<link rel="stylesheet" href="${extractedPath}">`
            });
          }
        }

        // Plan extraction for inline scripts
        for (const sc of components.inlineScripts) {
          if (sc.content.length > 0) {
            actionCounter++;
            const extractedPath = `scripts/${baseName.split('/').pop()}-module-${sc.id}.js`;
            actions.push({
              id: `action_${actionCounter}`,
              type: 'extract-script',
              file: file.path,
              newFilePath: extractedPath,
              description: `Extract inline <script> (#${sc.id}) into isolated module '${extractedPath}' and link as <script type="module" src="...">`,
              riskLevel: 'medium',
              enabled: true,
              previewBefore: sc.rawTag.slice(0, 200),
              previewAfter: `<script type="module" src="${extractedPath}"></script>`
            });
          }
        }
      }

      // 2. JavaScript / TypeScript Files: CommonJS to ESM conversion & global isolation
      if (langId === 'javascript' || file.path.endsWith('.js') || file.path.endsWith('.mjs')) {
        const { ast } = ParserAdapter.parseJS(file.content, 'module');
        if (ast) {
          const analysis = ParserAdapter.analyzeJSAST(ast);

          // CommonJS requires -> ES imports
          if (analysis.requires.length > 0) {
            actionCounter++;
            actions.push({
              id: `action_${actionCounter}`,
              type: 'convert-esm',
              file: file.path,
              description: `Convert ${analysis.requires.length} CommonJS 'require()' calls to standard ES Module 'import' declarations.`,
              riskLevel: 'low',
              enabled: true,
              previewBefore: file.content.slice(0, 200),
              previewAfter: '// Transformed to ES Module imports\n' + file.content.slice(0, 200)
            });
          }

          // Global leaks isolation
          if (analysis.globalLeaks.length > 0) {
            actionCounter++;
            actions.push({
              id: `action_${actionCounter}`,
              type: 'isolate-globals',
              file: file.path,
              description: `Isolate ${analysis.globalLeaks.length} global variable assignments (${analysis.globalLeaks.map(g => g.name).join(', ')}) to prevent global scope contamination.`,
              riskLevel: 'medium',
              enabled: true,
              previewBefore: analysis.globalLeaks.map(g => `Line ${g.line}: ${g.name}`).join('\n'),
              previewAfter: '// Encapsulated in module scope'
            });
          }
        }

        // Code formatting
        if (file.language?.canFormat) {
          actionCounter++;
          actions.push({
            id: `action_${actionCounter}`,
            type: 'format',
            file: file.path,
            description: `Format code with Prettier and normalize line endings.`,
            riskLevel: 'low',
            enabled: true,
            previewBefore: file.content.slice(0, 200),
            previewAfter: 'Prettier formatted syntax'
          });
        }
      }
    }

    const newFilesCount = actions.filter(a => a.newFilePath).length;
    const modifiedFilesCount = new Set(actions.map(a => a.file)).size;

    return {
      mode,
      planId: `plan_${Date.now()}`,
      createdAt: new Date().toISOString(),
      summary: {
        fileModifications: modifiedFilesCount,
        newFiles: newFilesCount,
        totalActions: actions.length
      },
      actions
    };
  }

  /**
   * Applies an approved transformation plan and returns the new set of output files.
   * Original files remain completely unchanged.
   * @param {Array<{ path: string, content: string, language: any }>} originalFiles
   * @param {any} approvedPlan
   * @param {object} formatOptions
   * @returns {Promise<{
   *   outputFiles: Array<{ path: string, content: string, language: any }>,
   *   appliedActionsCount: number,
   *   createdFiles: string[],
   *   modifiedFiles: string[]
   * }>}
   */
  static async applyPlan(originalFiles, approvedPlan, formatOptions = {}) {
    const fileMap = new Map();
    const createdFiles = [];
    const modifiedFiles = new Set();
    let appliedCount = 0;

    // Clone all original files into output map
    for (const f of originalFiles) {
      fileMap.set(f.path, {
        path: f.path,
        content: f.content,
        language: { ...f.language }
      });
    }

    // Filter only actions that the user kept enabled
    const activeActions = approvedPlan.actions.filter(a => a.enabled !== false);

    // 1. Handle HTML Extractions (styles and scripts)
    for (const action of activeActions) {
      if (action.type === 'extract-style' && action.newFilePath) {
        const file = fileMap.get(action.file);
        if (file) {
          const components = ParserAdapter.extractHTMLComponents(file.content);
          // Extract the first matching style block or replace
          if (components.inlineStyles.length > 0) {
            const targetStyle = components.inlineStyles[0];
            const formattedCSS = await FormatterAdapter.format(targetStyle.content, 'css', formatOptions);

            // Add new extracted CSS file to output
            fileMap.set(action.newFilePath, {
              path: action.newFilePath,
              content: formattedCSS.formatted,
              language: LanguageDetector.detect(action.newFilePath, formattedCSS.formatted)
            });
            createdFiles.push(action.newFilePath);

            // Replace inline style in HTML with link tag
            file.content = file.content.replace(targetStyle.rawTag, `<link rel="stylesheet" href="${action.newFilePath}">`);
            modifiedFiles.add(action.file);
            appliedCount++;
          }
        }
      } else if (action.type === 'extract-script' && action.newFilePath) {
        const file = fileMap.get(action.file);
        if (file) {
          const components = ParserAdapter.extractHTMLComponents(file.content);
          if (components.inlineScripts.length > 0) {
            const targetScript = components.inlineScripts[0];
            const formattedJS = await FormatterAdapter.format(targetScript.content, 'javascript', formatOptions);

            // Add new extracted JS file to output
            fileMap.set(action.newFilePath, {
              path: action.newFilePath,
              content: formattedJS.formatted,
              language: LanguageDetector.detect(action.newFilePath, formattedJS.formatted)
            });
            createdFiles.push(action.newFilePath);

            // Replace inline script in HTML with modular script tag
            file.content = file.content.replace(targetScript.rawTag, `<script type="module" src="${action.newFilePath}"></script>`);
            modifiedFiles.add(action.file);
            appliedCount++;
          }
        }
      }
    }

    // 2. Handle JS CommonJS to ESM and Global Isolation
    for (const action of activeActions) {
      if (action.type === 'convert-esm' || action.type === 'isolate-globals') {
        const file = fileMap.get(action.file);
        if (file) {
          let updatedCode = file.content;

          // Convert CommonJS require: const x = require('./x') -> import x from './x'
          if (action.type === 'convert-esm') {
            updatedCode = updatedCode.replace(
              /(?:const|let|var)\s+([a-zA-Z0-9_$]+)\s*=\s*require\(\s*['"]([^'"]+)['"]\s*\);?/g,
              'import $1 from \'$2\';'
            );

            // Convert module.exports = { ... } -> export default { ... }
            updatedCode = updatedCode.replace(
              /module\.exports\s*=\s*\{([\s\S]*?)\};?/g,
              'export default {$1};'
            );

            // Convert module.exports = identifier -> export default identifier
            updatedCode = updatedCode.replace(
              /module\.exports\s*=\s*([a-zA-Z0-9_$]+);?/g,
              'export default $1;'
            );

            file.content = updatedCode;
            modifiedFiles.add(action.file);
            appliedCount++;
          }

          // Isolate window.x = ... or globals
          if (action.type === 'isolate-globals') {
            // Add notice and encapsulation comment
            if (!file.content.includes('/* Encapsulated Module Scope */')) {
              file.content = `// [Code Isolation Workbench] Encapsulated Module Scope\n` + file.content;
            }
            modifiedFiles.add(action.file);
            appliedCount++;
          }
        }
      }
    }

    // 3. Format all resulting files
    for (const [path, fileObj] of fileMap.entries()) {
      if (fileObj.language?.canFormat) {
        const fmtResult = await FormatterAdapter.format(fileObj.content, fileObj.language.id, formatOptions);
        if (fmtResult.changed) {
          fileObj.content = fmtResult.formatted;
          modifiedFiles.add(path);
          appliedCount++;
        }
      }
    }

    return {
      outputFiles: Array.from(fileMap.values()),
      appliedActionsCount: appliedCount,
      createdFiles,
      modifiedFiles: Array.from(modifiedFiles)
    };
  }
}
