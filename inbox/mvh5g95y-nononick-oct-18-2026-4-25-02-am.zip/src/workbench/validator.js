// ============================================================================
// Code Isolation & Cleanup Workbench V1.0 - Validator & Diagnostics
// AST Syntax Validation, Reference Resolution, Best-Effort Secret Detection
// ============================================================================

import { ParserAdapter } from './parser-adapter.js';
import { DependencyGraphEngine } from './dependency-graph.js';

export class Validator {
  /**
   * Secret detection rules (Best-effort regex heuristics)
   */
  static SECRET_PATTERNS = [
    {
      id: 'aws-access-key',
      name: 'AWS Access Key ID',
      regex: /\b(AKIA[0-9A-Z]{16})\b/g
    },
    {
      id: 'google-api-key',
      name: 'Google API Key',
      regex: /\b(AIza[0-9A-Za-z\-_]{35})\b/g
    },
    {
      id: 'generic-secret',
      name: 'Potential Hardcoded Secret / Token',
      regex: /(?:api_?key|auth_?token|secret_?key|client_?secret|access_?token)\s*[:=]\s*['"]([a-zA-Z0-9_\-\.]{16,})['"]/gi
    },
    {
      id: 'private-key-header',
      name: 'Private Cryptographic Key Header',
      regex: /-----BEGIN\s+(?:RSA|EC|DSA|OPENSSH|PGP)\s+PRIVATE\s+KEY-----/g
    },
    {
      id: 'bearer-token',
      name: 'Bearer Authorization Token',
      regex: /\bBearer\s+([a-zA-Z0-9_\-\.]{24,})\b/gi
    }
  ];

  /**
   * Validates all transformed output files.
   * Checks syntax, references, and scans for sensitive secrets.
   * @param {Array<{ path: string, content: string, language: any }>} outputFiles
   * @returns {{
   *   isValid: boolean,
   *   hasSyntaxErrors: boolean,
   *   hasMissingReferences: boolean,
   *   syntaxErrors: Array<{ file: string, error: string }>,
   *   missingReferences: Array<{ source: string, specifier: string, line: number }>,
   *   secretsDetected: Array<{ file: string, patternName: string, line: number, redactedPreview: string }>,
   *   summary: { totalChecked: number, passedSyntax: number, failedSyntax: number, missingRefsCount: number, secretsCount: number },
   *   semanticDisclaimer: string
   * }}
   */
  static validateProject(outputFiles) {
    const syntaxErrors = [];
    let passedSyntax = 0;
    const existingPaths = new Set(outputFiles.map(f => f.path));
    const missingReferences = [];
    const secretsDetected = [];

    for (const file of outputFiles) {
      const langId = file.language?.id || '';
      let fileSyntaxValid = true;

      // 1. JS Syntax Check via Acorn
      if (langId === 'javascript' || langId === 'typescript' || langId === 'jsx' || file.path.endsWith('.js') || file.path.endsWith('.mjs')) {
        const { errors } = ParserAdapter.parseJS(file.content, 'module');
        if (errors.length > 0) {
          fileSyntaxValid = false;
          for (const err of errors) {
            syntaxErrors.push({ file: file.path, error: err });
          }
        }
      }

      // 2. CSS Syntax Check
      else if (langId === 'css' || file.path.endsWith('.css')) {
        const cssCheck = ParserAdapter.parseCSS(file.content);
        if (!cssCheck.valid) {
          fileSyntaxValid = false;
          for (const err of cssCheck.errors) {
            syntaxErrors.push({ file: file.path, error: `CSS Syntax Error: ${err}` });
          }
        }
      }

      // 3. JSON Syntax Check
      else if (langId === 'json' || file.path.endsWith('.json')) {
        try {
          JSON.parse(file.content);
        } catch (jsonErr) {
          fileSyntaxValid = false;
          syntaxErrors.push({ file: file.path, error: `JSON Parse Error: ${jsonErr.message}` });
        }
      }

      if (fileSyntaxValid) {
        passedSyntax++;
      }

      // 4. Secret & Sensitive Data Scan
      const lines = file.content.split('\n');
      for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
        const lineText = lines[lineIdx];
        for (const pattern of this.SECRET_PATTERNS) {
          pattern.regex.lastIndex = 0; // reset regex state
          let match;
          while ((match = pattern.regex.exec(lineText)) !== null) {
            const rawVal = match[1] || match[0];
            const redacted = rawVal.length > 8
              ? `${rawVal.slice(0, 4)}...[REDACTED_SECRET_${rawVal.length}_CHARS]`
              : '[REDACTED]';

            secretsDetected.push({
              file: file.path,
              patternName: pattern.name,
              line: lineIdx + 1,
              redactedPreview: lineText.replace(rawVal, redacted).trim()
            });
          }
        }
      }
    }

    // 5. Recheck reference integrity across all output files
    const graph = DependencyGraphEngine.buildGraph(outputFiles);
    for (const ref of graph.missingReferences) {
      missingReferences.push(ref);
    }

    const hasSyntaxErrors = syntaxErrors.length > 0;
    const hasMissingReferences = missingReferences.length > 0;

    return {
      isValid: !hasSyntaxErrors && !hasMissingReferences,
      hasSyntaxErrors,
      hasMissingReferences,
      syntaxErrors,
      missingReferences,
      secretsDetected,
      summary: {
        totalChecked: outputFiles.length,
        passedSyntax,
        failedSyntax: syntaxErrors.length,
        missingRefsCount: missingReferences.length,
        secretsCount: secretsDetected.length
      },
      semanticDisclaimer: 'Equivalence Notice: Structural AST and reference validity verified. Note: Semantic runtime equivalence cannot be mathematically guaranteed without comprehensive automated test coverage.'
    };
  }
}
