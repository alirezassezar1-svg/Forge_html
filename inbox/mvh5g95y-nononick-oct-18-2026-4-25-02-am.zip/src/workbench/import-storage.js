// ============================================================================
// Code Isolation & Cleanup Workbench V1.0 - Import & Storage Manager
// Path Traversal Security, Archive Limits, Decompression, IndexedDB
// ============================================================================

import JSZip from 'jszip';
import { DEFAULT_LIMITS } from './constants.js';
import { LanguageDetector } from './language-detector.js';

const DB_NAME = 'CodeIsolationWorkbenchDB';
const DB_VERSION = 1;
const STORE_NAME = 'saved_projects';

export class ImportStorageManager {
  /**
   * Sanitizes and validates a virtual relative file path.
   * Rejects path traversal attacks (../, ..\), absolute paths, null bytes, Windows drive letters.
   * @param {string} rawPath
   * @returns {{ valid: boolean, sanitizedPath: string, error?: string }}
   */
  static validatePath(rawPath) {
    if (!rawPath || typeof rawPath !== 'string') {
      return { valid: false, sanitizedPath: '', error: 'Empty or invalid file path.' };
    }

    // Check null bytes or control characters
    if (/[\0\x00-\x1f]/.test(rawPath)) {
      return { valid: false, sanitizedPath: '', error: 'Path contains illegal null bytes or control characters.' };
    }

    // Normalize slashes
    let normalized = rawPath.replace(/\\/g, '/').trim();

    // Check Windows drive letter (e.g., C:/ or D:/)
    if (/^[a-zA-Z]:/.test(normalized)) {
      return { valid: false, sanitizedPath: '', error: 'Absolute Windows drive path is rejected for security.' };
    }

    // Check absolute path starting with /
    if (normalized.startsWith('/')) {
      return { valid: false, sanitizedPath: '', error: 'Absolute path is rejected for security. Paths must be relative.' };
    }

    // Check directory traversal segments (.. or ../ or /../)
    const segments = normalized.split('/');
    for (const seg of segments) {
      if (seg === '..') {
        return { valid: false, sanitizedPath: '', error: 'Directory traversal sequence ("..") is rejected for security.' };
      }
    }

    // Remove redundant './' prefixes and clean empty segments
    const cleanSegments = segments.filter(s => s.length > 0 && s !== '.');
    if (cleanSegments.length === 0) {
      return { valid: false, sanitizedPath: '', error: 'Path resolves to an empty root target.' };
    }

    const sanitizedPath = cleanSegments.join('/');
    return { valid: true, sanitizedPath };
  }

  /**
   * Processes a list of imported File objects (from <input type="file" multiple> or webkitdirectory)
   * @param {FileList|File[]} fileList
   * @param {typeof DEFAULT_LIMITS} [customLimits]
   * @returns {Promise<{ files: Array<{ path: string, content: string, language: any, size: number }>, warnings: string[] }>}
   */
  static async importFiles(fileList, customLimits = DEFAULT_LIMITS) {
    const files = [];
    const warnings = [];
    const seenPaths = new Set();
    let totalBytes = 0;

    const items = Array.from(fileList);

    if (items.length > customLimits.maxFiles) {
      throw new Error(`Import exceeds maximum allowed file count limit (${customLimits.maxFiles} files).`);
    }

    for (const file of items) {
      const rawPath = file.webkitRelativePath || file.name;
      const pathCheck = this.validatePath(rawPath);

      if (!pathCheck.valid) {
        warnings.push(`Skipped '${rawPath}': ${pathCheck.error}`);
        continue;
      }

      const cleanPath = pathCheck.sanitizedPath;

      if (seenPaths.has(cleanPath)) {
        warnings.push(`Duplicate path detected: '${cleanPath}' - overwritten with latest entry.`);
      }
      seenPaths.add(cleanPath);

      if (file.size > customLimits.maxSingleFileBytes) {
        warnings.push(`Skipped '${cleanPath}': File size (${(file.size / 1024 / 1024).toFixed(1)}MB) exceeds maximum single file limit.`);
        continue;
      }

      totalBytes += file.size;
      if (totalBytes > customLimits.maxDecompressedBytes) {
        throw new Error(`Total imported size exceeds maximum allowed limit (${(customLimits.maxDecompressedBytes / 1024 / 1024).toFixed(1)}MB).`);
      }

      const content = await file.text();
      const language = LanguageDetector.detect(cleanPath, content);

      files.push({
        path: cleanPath,
        content,
        language,
        size: file.size
      });
    }

    return { files, warnings };
  }

  /**
   * Imports and safely extracts a ZIP archive buffer
   * @param {ArrayBuffer|Blob|File} zipSource
   * @param {typeof DEFAULT_LIMITS} [customLimits]
   * @returns {Promise<{ files: Array<{ path: string, content: string, language: any, size: number }>, warnings: string[] }>}
   */
  static async importZip(zipSource, customLimits = DEFAULT_LIMITS) {
    const zip = new JSZip();
    let loadedZip;

    try {
      loadedZip = await zip.loadAsync(zipSource);
    } catch (err) {
      throw new Error(`Failed to decode ZIP archive: ${err.message || 'Corrupted archive data'}`);
    }

    const files = [];
    const warnings = [];
    const seenPaths = new Set();
    let totalDecompressedBytes = 0;
    let fileCount = 0;

    const entries = Object.keys(loadedZip.files);

    for (const rawName of entries) {
      const zipEntry = loadedZip.files[rawName];

      // Skip directory descriptors
      if (zipEntry.dir) {
        continue;
      }

      fileCount++;
      if (fileCount > customLimits.maxFiles) {
        throw new Error(`ZIP archive exceeds maximum file count limit of ${customLimits.maxFiles} files.`);
      }

      // Security check for archive path traversal
      const pathCheck = this.validatePath(rawName);
      if (!pathCheck.valid) {
        warnings.push(`Rejected malicious or invalid archive entry '${rawName}': ${pathCheck.error}`);
        continue;
      }

      const cleanPath = pathCheck.sanitizedPath;

      // Ignore common OS junk files automatically
      if (cleanPath.startsWith('__MACOSX/') || cleanPath.endsWith('/.DS_Store') || cleanPath === '.DS_Store' || cleanPath.endsWith('/Thumbs.db')) {
        continue;
      }

      if (seenPaths.has(cleanPath)) {
        warnings.push(`Archive contains duplicate entry '${cleanPath}' - overwritten.`);
      }
      seenPaths.add(cleanPath);

      // Read text content
      const content = await zipEntry.async('text');
      const entrySize = content.length;

      if (entrySize > customLimits.maxSingleFileBytes) {
        warnings.push(`Skipped '${cleanPath}': File size exceeds limit of ${(customLimits.maxSingleFileBytes / 1024 / 1024).toFixed(1)}MB.`);
        continue;
      }

      totalDecompressedBytes += entrySize;
      if (totalDecompressedBytes > customLimits.maxDecompressedBytes) {
        throw new Error(`Decompressed archive size exceeds maximum safety limit of ${(customLimits.maxDecompressedBytes / 1024 / 1024).toFixed(1)}MB.`);
      }

      const language = LanguageDetector.detect(cleanPath, content);

      files.push({
        path: cleanPath,
        content,
        language,
        size: entrySize
      });
    }

    return { files, warnings };
  }

  // --- IndexedDB Local Storage (Opt-in only) ---

  static async openDB() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = (event) => {
        const db = event.target.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Saves project state to IndexedDB only when explicitly initiated by user.
   */
  static async saveProjectToIndexedDB(projectData) {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const record = {
        id: 'current_active_project',
        savedAt: new Date().toISOString(),
        ...projectData
      };
      const req = store.put(record);
      req.onsuccess = () => resolve(record);
      req.onerror = () => reject(req.error);
    });
  }

  /**
   * Loads saved project state from IndexedDB.
   */
  static async loadProjectFromIndexedDB() {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get('current_active_project');
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
  }

  /**
   * Completely purges all stored project data from browser IndexedDB.
   */
  static async purgeIndexedDB() {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.clear();
      req.onsuccess = () => resolve(true);
      req.onerror = () => reject(req.error);
    });
  }
}
