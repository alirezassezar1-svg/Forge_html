// ============================================================================
// Code Isolation & Cleanup Workbench V1.0 - Formatter Adapter
// Prettier Standalone (JS, CSS, HTML, JSON) with Configurable Rules & Fallbacks
// ============================================================================

import * as prettier from 'prettier/standalone';
import * as prettierPluginBabel from 'prettier/plugins/babel';
import * as prettierPluginEstree from 'prettier/plugins/estree';
import * as prettierPluginPostcss from 'prettier/plugins/postcss';
import * as prettierPluginHtml from 'prettier/plugins/html';

import { DEFAULT_FORMAT_OPTIONS } from './constants.js';

export class FormatterAdapter {
  /**
   * Formats source code according to language and user options using Prettier Standalone.
   * @param {string} code - Source code string
   * @param {string} languageId - 'javascript' | 'typescript' | 'html' | 'css' | 'json'
   * @param {Partial<typeof DEFAULT_FORMAT_OPTIONS>} [options={}]
   * @returns {Promise<{ formatted: string, changed: boolean, error: string | null }>}
   */
  static async format(code, languageId, options = {}) {
    if (!code || typeof code !== 'string') {
      return { formatted: code || '', changed: false, error: null };
    }

    const mergedOptions = { ...DEFAULT_FORMAT_OPTIONS, ...options };
    const prettierConfig = {
      tabWidth: mergedOptions.indentSize ?? 2,
      useTabs: !!mergedOptions.useTabs,
      semi: mergedOptions.semi ?? true,
      singleQuote: mergedOptions.singleQuote ?? true,
      printWidth: mergedOptions.printWidth ?? 80,
      trailingComma: mergedOptions.trailingComma ?? 'es5'
    };

    try {
      let formattedText = code;

      switch (languageId) {
        case 'javascript':
        case 'typescript':
        case 'jsx':
          formattedText = await prettier.format(code, {
            ...prettierConfig,
            parser: 'babel',
            plugins: [prettierPluginBabel, prettierPluginEstree]
          });
          break;

        case 'json':
          formattedText = await prettier.format(code, {
            ...prettierConfig,
            parser: 'json',
            plugins: [prettierPluginBabel, prettierPluginEstree]
          });
          break;

        case 'css':
          formattedText = await prettier.format(code, {
            ...prettierConfig,
            parser: 'css',
            plugins: [prettierPluginPostcss]
          });
          break;

        case 'html':
          formattedText = await prettier.format(code, {
            ...prettierConfig,
            parser: 'html',
            plugins: [prettierPluginHtml, prettierPluginBabel, prettierPluginEstree, prettierPluginPostcss]
          });
          break;

        default:
          // For markdown or plain text, perform safe indentation and whitespace cleanup
          formattedText = this.fallbackFormat(code, mergedOptions);
          break;
      }

      // Normalize line endings to \n
      const normalizedFormatted = formattedText.replace(/\r\n/g, '\n');
      const normalizedOriginal = code.replace(/\r\n/g, '\n');

      return {
        formatted: normalizedFormatted,
        changed: normalizedFormatted !== normalizedOriginal,
        error: null
      };
    } catch (err) {
      // In case of syntax error or unsupported construct in Prettier, fallback gracefully
      return {
        formatted: code,
        changed: false,
        error: `Formatting error: ${err.message || String(err)}`
      };
    }
  }

  /**
   * Tests whether formatting is idempotent (running formatting twice yields the exact same string).
   * @param {string} code
   * @param {string} languageId
   * @param {Partial<typeof DEFAULT_FORMAT_OPTIONS>} [options]
   * @returns {Promise<{ isIdempotent: boolean, firstPass: string, secondPass: string }>}
   */
  static async checkIdempotence(code, languageId, options = {}) {
    const firstResult = await this.format(code, languageId, options);
    const secondResult = await this.format(firstResult.formatted, languageId, options);
    return {
      isIdempotent: firstResult.formatted === secondResult.formatted,
      firstPass: firstResult.formatted,
      secondPass: secondResult.formatted
    };
  }

  /**
   * Lightweight fallback whitespace and indentation normalizer
   */
  static fallbackFormat(code, options) {
    const indent = options.useTabs ? '\t' : ' '.repeat(options.indentSize || 2);
    const lines = code.split('\n');
    const result = [];
    let depth = 0;

    for (let line of lines) {
      line = line.trim();
      if (!line) {
        result.push('');
        continue;
      }

      if (line.endsWith('}') || line.startsWith('}') || line.endsWith(']') || line.startsWith(']')) {
        depth = Math.max(0, depth - 1);
      }

      result.push(indent.repeat(depth) + line);

      if (line.endsWith('{') || line.endsWith('[') || line.endsWith('(')) {
        depth++;
      }
    }

    return result.join('\n');
  }
}
