// ============================================================================
// Code Isolation & Cleanup Workbench V1.0 - Main Entry Point
// ============================================================================

import './index.css';
import { UIController } from './workbench/ui-controller.js';

// Initialize the Workbench singleton when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  const workbench = new UIController();
  workbench.init();
  window.workbench = workbench;
});
