# Security Architecture, Limits, and Operational Boundaries

## 1. Threat Model & Ingestion Security

### 1.1 Archive Traversal (Zip Slip) Protection
Imported archives are processed using `ImportStorageManager.validatePath()`. Every virtual file entry is normalized and checked against the following constraints before extraction:
- Rejection of relative path traversal segments (`../`, `..\`, `/../`).
- Rejection of root and absolute paths (`/etc/`, `C:\`, `\\network\share`).
- Rejection of null byte injections (`\0`) and control characters (`\x00-\x1f`).
- Duplicate path detection with transparent warning logs.

### 1.2 Archive Bomb & Memory Exhaustion Controls
To prevent browser tab freezing or memory exhaustion during ZIP decompression:
- **Maximum File Count**: 250 files per archive (configurable).
- **Maximum Decompressed Size**: 25 MB aggregate uncompressed payload.
- **Maximum Single File Size**: 5 MB per individual file.
- Archives exceeding any limit are immediately rejected prior to memory expansion.

### 1.3 Untrusted Code Execution Boundary
- The workbench **NEVER** automatically evaluates, executes, or runs imported user code (`eval`, `new Function`, or dynamic script injection are strictly forbidden in workbench analysis).
- All structural analysis is performed via static AST parsing (Acorn for ECMAScript, static CSS tokenizer for stylesheets).

## 2. Best-Effort Secret Detection Disclaimers

The integrated Secret Scanner employs static regular expressions to detect common patterns of hardcoded credentials:
- AWS Access Key ID (`AKIA...`)
- Google API Key (`AIza...`)
- Common secret assignments (`api_key = "..."`, `secret = "..."`)
- Private cryptographic key headers (`-----BEGIN RSA PRIVATE KEY-----`)
- Bearer tokens (`Bearer ...`)

### Limitations:
1. **Best-Effort Only**: Regular expressions cannot identify obfuscated, encrypted, dynamically constructed, or unconventional secrets.
2. **False Negatives**: A clean scan does not guarantee the complete absence of sensitive material.
3. **Redaction in Reports**: When secrets are detected, reports (`analysis-report.json`) redact the actual tokens and only output pattern categories and line numbers.

## 3. Semantic Equivalence Boundary

The workbench performs structural AST transformations (extracting inline blocks, reformatting syntax, and converting CommonJS module syntax).

### Critical Disclaimer:
> **Never claim semantic equivalence without sufficient evidence.**
> While structural syntax and reference resolution are statically verified by Acorn and the Dependency Graph Engine, mathematical runtime semantic equivalence cannot be guaranteed without comprehensive dynamic unit test suites.
