# VOID CINEMA — نسخه PWA

این نسخه یک **PWA استاتیک** است (بدون SSR و بدون Node در سرور): قابل نصب، کاملاً آفلاین، با فونت‌ها و تصاویر محلی.

## ساخت
```bash
npm install --legacy-peer-deps
npm run build            # خروجی: dist/app/browser
```
> service worker فقط در build پروداکشن فعال است (در `npm run dev` غیرفعال می‌ماند).

## انتشار روی هاست (cPanel / شتابان)
1. محتویات پوشه‌ی `dist/app/browser` را داخل `public_html` آپلود کنید (خود پوشه نه، محتویاتش).
2. سایت باید روی **HTTPS** باشد، وگرنه service worker و نصب کار نمی‌کند.
3. اگر روی زیرپوشه می‌گذارید (مثلاً `/void/`):
   ```bash
   ng build --base-href /void/
   ```
   و `start_url`/`scope` در `manifest.webmanifest` نسبی هستند و نیازی به تغییر ندارند.

## انتشار روی GitHub Pages
`ng build --base-href /<repo-name>/` و محتویات `dist/app/browser` را روی شاخه‌ی `gh-pages` بگذارید.

## VOID AI (اختیاری)
- بدون هیچ تنظیمی، دستیار با **پلنر محلی** کار می‌کند (آفلاین هم همین است).
- برای استفاده از Gemini روی هاست PHP: `api/ai/config.sample.php` را به `config.php` کپی و کلید را وارد کنید. اگر سرور به API گوگل دسترسی نداشته باشد، برنامه خودکار به پلنر محلی برمی‌گردد.

## تغییرات نسبت به نسخه‌ی AI Studio
- حذف Express/SSR و `server.ts`؛ endpoint هوش مصنوعی به `public/api/ai/chat.php` رفت.
- افزودن `manifest.webmanifest`، آیکون‌ها (`npm run icons` برای ساخت دوباره)، `ngsw-config.json`، بنر نصب/آپدیت/آفلاین.
- فونت‌ها (Vazirmatn, Plus Jakarta Sans, JetBrains Mono, Material Icons) به‌جای Google Fonts از npm و محلی لود می‌شوند.
- مسیر تصاویر از `/src/assets/...` (که در build پروداکشن کار نمی‌کرد) به `assets/images/...` اصلاح شد.
