#!/usr/bin/env python3
"""Generates the PWA icon set into public/icons (needs Pillow)."""
from PIL import Image, ImageDraw, ImageFilter
import os

OUT = os.path.join(os.path.dirname(__file__), '..', 'public', 'icons')
os.makedirs(OUT, exist_ok=True)
ICE, CYAN = (185, 229, 255), (85, 200, 255)
S = 2048  # supersampled canvas


def draw_mark(scale: float) -> Image.Image:
    """Lens ring + 'V' mark. scale = fraction of canvas used by the ring diameter."""
    img = Image.new('RGBA', (S, S), (0, 0, 0, 255))
    c = S / 2
    r = S * scale / 2
    w = int(r * 0.09)

    glow = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    g = ImageDraw.Draw(glow)
    g.ellipse([c - r, c - r, c + r, c + r], outline=CYAN + (255,), width=w)
    vw = int(r * 0.16)
    pts = [(c - r * 0.50, c - r * 0.42), (c, c + r * 0.48), (c + r * 0.50, c - r * 0.42)]
    g.line(pts, fill=CYAN + (255,), width=vw, joint='curve')
    glow = glow.filter(ImageFilter.GaussianBlur(r * 0.06))
    img = Image.alpha_composite(img, glow)

    d = ImageDraw.Draw(img)
    d.ellipse([c - r, c - r, c + r, c + r], outline=ICE + (255,), width=w)
    d.line(pts, fill=ICE + (255,), width=vw, joint='curve')
    for p in (pts[0], pts[1], pts[2]):
        d.ellipse([p[0] - vw / 2, p[1] - vw / 2, p[0] + vw / 2, p[1] + vw / 2], fill=ICE + (255,))
    # 2.39:1 "scope" bar under the V
    bw, bh = r * 0.9, r * 0.075
    d.rounded_rectangle([c - bw / 2, c + r * 0.66, c + bw / 2, c + r * 0.66 + bh], radius=bh / 2, fill=CYAN + (255,))
    return img


def save(img: Image.Image, name: str, size: int):
    img.resize((size, size), Image.LANCZOS).convert('RGB').save(os.path.join(OUT, name), optimize=True)


any_icon = draw_mark(0.78)
mask_icon = draw_mark(0.52)   # inside the 80% maskable safe zone
for sz in (192, 512):
    save(any_icon, f'icon-{sz}.png', sz)
    save(mask_icon, f'icon-maskable-{sz}.png', sz)
save(any_icon, 'apple-touch-icon.png', 180)
save(any_icon, 'favicon-48.png', 48)
print('icons written to', os.path.abspath(OUT))
