<?php
// Optional VOID AI proxy for PHP hosts (cPanel). The PWA works without it:
// on any failure it answers {"fallback":true} and the app uses its local planner.
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function fallback(string $reason): void {
    echo json_encode(['fallback' => true, 'reason' => $reason]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); fallback('method'); }

$cfgFile = __DIR__ . '/config.php';          // copy config.sample.php -> config.php
$cfg = file_exists($cfgFile) ? require $cfgFile : [];
$apiKey = $cfg['GEMINI_API_KEY'] ?? getenv('GEMINI_API_KEY');
$model  = $cfg['MODEL'] ?? 'gemini-2.5-flash';
if (!$apiKey) fallback('GEMINI_API_KEY not configured');

$in = json_decode(file_get_contents('php://input'), true) ?: [];
$prompt = trim((string)($in['prompt'] ?? ''));
if ($prompt === '' || strlen($prompt) > 4000) { http_response_code(400); fallback('bad prompt'); }
$lang = ($in['language'] ?? 'en') === 'fa' ? 'fa' : 'en';
$ctx  = json_encode($in['projectContext'] ?? new stdClass(), JSON_UNESCAPED_UNICODE);

$system = <<<TXT
You are VOID AI, the personal AI Film Director & Studio Agent for VOID CINEMA.
You communicate fluently in both Persian (fa-IR) and English (en-US).
You operate strictly under ASSISTANT (Human-in-the-loop) mode: understand what the user needs, analyze the current project state, and propose an explicit structured execution plan. Never execute without approval.
Available tools you can plan:
- update_project_title(title, reel)
- save_project()
- load_project()
- reset_project()
- get_screenplay()
- write_screenplay(type, text)
- rewrite_screenplay(lines: [{type, text}])
- split_story_into_scenes(sceneCount)
- update_scene_text(sceneNumber, slugline, summary)
- get_storyboard()
- create_scene_shot(title, sceneNumber, lens, aperture, lighting, durationSeconds)
- delete_scene_shot(shotId)
- update_scene_shot(shotId, title, lens, aperture, lighting)
- set_shot_duration(shotId, durationSeconds)
- get_timeline()
- add_timeline_clip(trackId, title, startFrame, durationFrames)
- split_clip(frame)
- move_clip(clipId, newStartFrame)
- set_track_mute(trackId, isMuted)
- set_track_solo(trackId, isSolo)
- get_audio_state()
- set_audio_volume(channelId, volumeDb)
- set_audio_pan(channelId, pan)
- toggle_audio_mute(channelId)
- toggle_audio_solo(channelId)
- get_subtitles()
- generate_subtitles(language)
- update_subtitles(mode)
- get_render_settings()
- update_render_settings(codec, resolution, colorSpace, burnInTimecode)
- export_video()
Return a JSON object conforming to the schema. Provide clear explanations in both Persian and English.
TXT;

$body = [
    'systemInstruction' => ['parts' => [['text' => $system]]],
    'contents' => [['role' => 'user', 'parts' => [['text' => "User Prompt: $prompt\nLanguage: $lang\nCurrent Project State:\n$ctx"]]]],
    'generationConfig' => [
        'responseMimeType' => 'application/json',
        'responseSchema' => [
            'type' => 'OBJECT',
            'properties' => [
                'plan' => [
                    'type' => 'OBJECT',
                    'properties' => [
                        'summaryEn' => ['type' => 'STRING'],
                        'summaryFa' => ['type' => 'STRING'],
                        'actions' => [
                            'type' => 'ARRAY',
                            'items' => [
                                'type' => 'OBJECT',
                                'properties' => [
                                    'tool' => ['type' => 'STRING'],
                                    'descriptionEn' => ['type' => 'STRING'],
                                    'descriptionFa' => ['type' => 'STRING'],
                                    'requiresConfirmation' => ['type' => 'BOOLEAN'],
                                    'argsJson' => ['type' => 'STRING'],
                                ],
                                'required' => ['tool', 'descriptionEn', 'descriptionFa'],
                            ],
                        ],
                    ],
                    'required' => ['summaryEn', 'summaryFa', 'actions'],
                ],
                'message' => ['type' => 'STRING'],
            ],
            'required' => ['plan'],
        ],
    ],
];

$ch = curl_init("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent");
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json', "x-goog-api-key: $apiKey"],
    CURLOPT_POSTFIELDS => json_encode($body, JSON_UNESCAPED_UNICODE),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 25,
]);
$raw = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
if ($raw === false || $code !== 200) fallback("upstream $code");

$res  = json_decode($raw, true);
$text = $res['candidates'][0]['content']['parts'][0]['text'] ?? '';
$out  = json_decode($text, true);
if (!is_array($out) || empty($out['plan']['actions'])) fallback('empty plan');

// The schema carries tool args as a JSON string (Gemini rejects free-form OBJECTs); decode it back.
foreach ($out['plan']['actions'] as &$a) {
    $a['args'] = isset($a['argsJson']) ? (json_decode($a['argsJson'], true) ?: new stdClass()) : new stdClass();
    unset($a['argsJson']);
}
echo json_encode($out, JSON_UNESCAPED_UNICODE);
