<?php
// Copy to config.php and fill in. config.php is blocked from web access by .htaccess.
return [
    'GEMINI_API_KEY' => 'YOUR_KEY_HERE',
    'MODEL' => 'gemini-2.5-flash',
];
