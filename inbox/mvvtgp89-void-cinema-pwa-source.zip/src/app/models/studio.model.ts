export interface Shot {
  id: string;
  sceneNumber: string;
  shotCode: string;
  title: string;
  description: string;
  imageSrc: string;
  durationSeconds: number;
  camera: {
    lens: string;
    aperture: string;
    shutterAngle: string;
    iso: number;
    sensor: string;
    movement: string;
    aspectRatio: string;
  };
  lightingSetup: string;
  dialoguePreview: string;
  status: 'Storyboarded' | 'Captured' | 'Rough Cut' | 'Color Graded' | 'Final Locked';
}

export interface TimelineClip {
  id: string;
  shotId?: string;
  title: string;
  trackId: string; // 'v1' | 'v2' | 'a1' | 'a2'
  startFrame: number;
  durationFrames: number;
  colorGrade: string;
  imageSrc?: string;
  audioWaveformData?: number[];
}

export interface TimelineTrack {
  id: string;
  name: string;
  type: 'video' | 'audio';
  isMuted: boolean;
  isSolo: boolean;
  isLocked: boolean;
  volumeOrOpacity: number; // 0 to 100
}

export interface AudioChannel {
  id: string;
  name: string;
  type: 'dialogue' | 'ambience' | 'score' | 'foley' | 'master';
  volumeDb: number; // -60 to +6 dB
  isMuted: boolean;
  isSolo: boolean;
  pan: number; // -50 to +50
  peakLevel: number; // 0 to 1 for VU meter
}

export interface Scene {
  id: string;
  number: number;
  act: string;
  slugline: string;
  timeOfDay: 'NIGHT' | 'TWILIGHT' | 'DAWN' | 'DAY';
  locationType: 'EXT' | 'INT';
  locationName: string;
  summary: string;
  pageCount: number;
  status: 'In Cut' | 'Locked' | 'VFX Pending';
  shotIds: string[];
}

export interface ScreenplayLine {
  id: string;
  type: 'scene-heading' | 'action' | 'character' | 'parenthetical' | 'dialogue' | 'transition';
  text: string;
}

export interface ExportSettings {
  codec: 'ProRes 4444 XQ' | 'ProRes 422 HQ' | 'Avid DNxHR HQX' | 'DCI Cinema DCP 4K';
  resolution: '4096x1716 (2.39:1 CinemaScope)' | '3840x2160 (16:9 UHD)' | '2048x858 (2K Scope)' | '1920x1080 (HD)';
  frameRate: '24.00 fps (SMPTE Film)' | '23.976 fps' | '48.00 fps (HFR)' | '60.00 fps';
  colorSpace: 'ACEScc (Cinema Spec)' | 'P3-DCI Cinema' | 'Rec.709 (OLED True)' | 'ST 2084 PQ (HDR)';
  audioFormat: 'Linear PCM 24-bit 48kHz (5.1 Surround)' | 'Dolby Atmos Cinema Bed' | 'Stereo 24-bit PCM';
  burnInTimecode: boolean;
  anamorphicDeSqueeze: boolean;
}

export interface SubtitleCue {
  id: string;
  startFrame: number;
  endFrame: number;
  textEn: string;
  textFa: string;
}

export type ToolName =
  | 'get_project_state'
  | 'update_project_title'
  | 'save_project'
  | 'load_project'
  | 'reset_project'
  | 'get_screenplay'
  | 'write_screenplay'
  | 'rewrite_screenplay'
  | 'split_story_into_scenes'
  | 'update_scene_text'
  | 'get_storyboard'
  | 'create_scene_shot'
  | 'delete_scene_shot'
  | 'update_scene_shot'
  | 'set_shot_duration'
  | 'get_timeline'
  | 'add_timeline_clip'
  | 'split_clip'
  | 'move_clip'
  | 'set_track_mute'
  | 'set_track_solo'
  | 'get_audio_state'
  | 'set_audio_volume'
  | 'set_audio_pan'
  | 'toggle_audio_mute'
  | 'toggle_audio_solo'
  | 'get_subtitles'
  | 'generate_subtitles'
  | 'update_subtitles'
  | 'get_render_settings'
  | 'update_render_settings'
  | 'export_video';

export interface PlannedToolAction {
  id: string;
  tool: ToolName;
  descriptionEn: string;
  descriptionFa: string;
  args: Record<string, unknown>;
  requiresConfirmation: boolean;
  status: 'pending' | 'executing' | 'success' | 'failed' | 'cancelled';
  error?: string;
  result?: unknown;
}

export interface ExecutionPlan {
  id: string;
  userPrompt: string;
  detectedLanguage: 'fa' | 'en';
  summaryEn: string;
  summaryFa: string;
  actions: PlannedToolAction[];
  status: 'awaiting_approval' | 'executing' | 'completed' | 'cancelled' | 'failed';
}

export interface AgentChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  language?: 'fa' | 'en';
  plan?: ExecutionPlan;
  isStreaming?: boolean;
}

