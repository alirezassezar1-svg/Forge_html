import { Injectable, inject, signal, computed } from '@angular/core';
import { SwUpdate, VersionReadyEvent } from '@angular/service-worker';
import { filter } from 'rxjs';

interface BeforeInstallPromptEvent extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

@Injectable({ providedIn: 'root' })
export class PwaService {
  private readonly sw = inject(SwUpdate);
  private deferredPrompt: BeforeInstallPromptEvent | null = null;

  readonly isOnline = signal<boolean>(typeof navigator === 'undefined' ? true : navigator.onLine);
  readonly canInstall = signal<boolean>(false);
  readonly updateReady = signal<boolean>(false);
  readonly installDismissed = signal<boolean>(false);

  readonly isStandalone = computed(() => this.detectStandalone());
  readonly isIos =
    typeof navigator !== 'undefined' && /iphone|ipad|ipod/i.test(navigator.userAgent);
  /** iOS Safari has no install prompt; show the "Add to Home Screen" hint instead. */
  readonly showIosHint = computed(
    () => this.isIos && !this.isStandalone() && !this.installDismissed(),
  );

  constructor() {
    if (typeof window === 'undefined') return;

    window.addEventListener('online', () => this.isOnline.set(true));
    window.addEventListener('offline', () => this.isOnline.set(false));

    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      this.deferredPrompt = e as BeforeInstallPromptEvent;
      this.canInstall.set(true);
    });
    window.addEventListener('appinstalled', () => {
      this.deferredPrompt = null;
      this.canInstall.set(false);
    });

    if (this.sw.isEnabled) {
      this.sw.versionUpdates
        .pipe(filter((e): e is VersionReadyEvent => e.type === 'VERSION_READY'))
        .subscribe(() => this.updateReady.set(true));
      // Re-check for a new version whenever the app comes back to the foreground.
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') this.sw.checkForUpdate().catch(() => undefined);
      });
    }
  }

  async install(): Promise<void> {
    if (!this.deferredPrompt) return;
    await this.deferredPrompt.prompt();
    await this.deferredPrompt.userChoice;
    this.deferredPrompt = null;
    this.canInstall.set(false);
  }

  applyUpdate(): void {
    this.sw
      .activateUpdate()
      .catch(() => undefined)
      .finally(() => document.location.reload());
  }

  dismissInstall(): void {
    this.installDismissed.set(true);
    this.canInstall.set(false);
  }

  private detectStandalone(): boolean {
    if (typeof window === 'undefined') return false;
    return (
      window.matchMedia?.('(display-mode: standalone)').matches ||
      (navigator as Navigator & { standalone?: boolean }).standalone === true
    );
  }
}
