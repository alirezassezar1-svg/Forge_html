import { Injectable, computed, signal } from '@angular/core';
import {
  Shot,
  TimelineClip,
  TimelineTrack,
  AudioChannel,
  Scene,
  ScreenplayLine,
  ExportSettings,
  SubtitleCue,
} from '../models/studio.model';

@Injectable({
  providedIn: 'root',
})
export class StudioState {
  // Active Workspace Tab
  readonly activeWorkspace = signal<'editing' | 'storyboard' | 'screenplay' | 'mixer'>('editing');

  // Film Project Details
  readonly projectTitle = signal<string>('CHRONO STATIC');
  readonly projectReel = signal<string>('REEL 02 / ACT II');
  readonly fps = signal<number>(24);
  readonly totalFrames = signal<number>(2880); // 2 minutes @ 24fps
  readonly currentFrame = signal<number>(432); // frame 432 = 00:00:18:00
  readonly isPlaying = signal<boolean>(false);
  readonly playbackSpeed = signal<number>(1);
  readonly loopPlayback = signal<boolean>(true);

  // Monitor Display Controls
  readonly activeAspectRatio = signal<'2.39:1' | '1.85:1' | '16:9'>('2.39:1');
  readonly activeLUT = signal<string>('Cyan Night 500T');
  readonly activeScope = signal<'none' | 'waveform' | 'vectorscope' | 'histogram'>('none');
  readonly showFramingGuides = signal<boolean>(true);
  readonly showSafeAction = signal<boolean>(true);
  readonly monitorZoom = signal<number>(100); // 100% Fit

  // Export Modal
  readonly isExportModalOpen = signal<boolean>(false);
  readonly isRendering = signal<boolean>(false);
  readonly renderProgress = signal<number>(0);
  readonly exportSettings = signal<ExportSettings>({
    codec: 'ProRes 4444 XQ',
    resolution: '4096x1716 (2.39:1 CinemaScope)',
    frameRate: '24.00 fps (SMPTE Film)',
    colorSpace: 'ACEScc (Cinema Spec)',
    audioFormat: 'Linear PCM 24-bit 48kHz (5.1 Surround)',
    burnInTimecode: false,
    anamorphicDeSqueeze: true,
  });

  // Storyboard Shots List
  readonly shots = signal<Shot[]>([
    {
      id: 'shot-1',
      sceneNumber: '14A',
      shotCode: 'S14A-01',
      title: 'Neon Tokyo Alley Surveillance',
      description: 'Ext. Neon rain-soaked alley. Agent Kaelen stands motionless under a flickering cyan vapor lamp waiting for courier beacon.',
      imageSrc: 'assets/images/film_frame_tokyo_noir_1793404704926.jpg',
      durationSeconds: 6.5,
      camera: {
        lens: 'Panavision C-Series 40mm Anamorphic',
        aperture: 'T1.4',
        shutterAngle: '180.0°',
        iso: 800,
        sensor: 'Arri Alexa 65 Large Format',
        movement: 'Slow Slow Push-In on Dolly Track',
        aspectRatio: '2.39:1 CinemaScope',
      },
      lightingSetup: 'Key: High overhead cyan vapor discharge; Fill: Pure pitch darkness; Rim: Wet asphalt reflection.',
      dialoguePreview: 'KAELEN: The frequency is shifting. It knows we are watching.',
      status: 'Final Locked',
    },
    {
      id: 'shot-2',
      sceneNumber: '14B',
      shotCode: 'S14B-02',
      title: 'Orbital Tether Observatory',
      description: 'Ext. Low Earth Orbit. Monolithic deep-space research platform rotating silently against the cold pale nebula.',
      imageSrc: 'assets/images/film_frame_orbital_monolith_1793404716142.jpg',
      durationSeconds: 8.0,
      camera: {
        lens: 'Arri Master Prime 27mm T1.3',
        aperture: 'T2.0',
        shutterAngle: '180.0°',
        iso: 400,
        sensor: 'Arri Alexa LF 4.5K',
        movement: 'Zero-G Orbital Jib Drift',
        aspectRatio: '2.39:1 CinemaScope',
      },
      lightingSetup: 'Cold distant blue starlight rim, pure void black shadows, interior bridge cyan glow.',
      dialoguePreview: 'VOICE (RADIO): Chrono Station status: Zero containment variance detected.',
      status: 'Color Graded',
    },
    {
      id: 'shot-3',
      sceneNumber: '15A',
      shotCode: 'S15A-01',
      title: 'Kaelen Tactical Close-Up',
      description: 'Int. Interrogation Chamber. Extreme close-up of Kaelen in shadow, horizontal anamorphic flare slicing across field of view.',
      imageSrc: 'assets/images/film_frame_actor_profile_1793404727880.jpg',
      durationSeconds: 4.8,
      camera: {
        lens: 'Atlas Orion 65mm T2.0 2x Anamorphic',
        aperture: 'T1.8',
        shutterAngle: '144.0° (Cinematic Shutter)',
        iso: 1250,
        sensor: 'RED V-Raptor XL 8K VV',
        movement: 'Static Locked Off / Handheld Micro-Tremor',
        aspectRatio: '2.39:1 CinemaScope',
      },
      lightingSetup: 'Pale ice blue hard backlight cheek rim, pure black negative fill.',
      dialoguePreview: 'KAELEN: You think time flows forward because that is the only way your eyes can process decay.',
      status: 'Rough Cut',
    },
    {
      id: 'shot-4',
      sceneNumber: '15B',
      shotCode: 'S15B-03',
      title: 'Obsidian Monolith On Desert Ridge',
      description: 'Ext. Obsidian volcanic desert under twilight aurora. Towering geometric alien spire pulsing with hairline pale cyan energy lines.',
      imageSrc: 'assets/images/film_frame_monolith_desert_1793404738600.jpg',
      durationSeconds: 9.2,
      camera: {
        lens: 'Cooke Anamorphic /i Full Frame Plus 32mm',
        aperture: 'T2.8',
        shutterAngle: '180.0°',
        iso: 640,
        sensor: 'Sony Venice 2 8.6K',
        movement: 'Technocrane 50ft Rising Reveal',
        aspectRatio: '2.39:1 CinemaScope',
      },
      lightingSetup: 'Aurora atmospheric cold ambient, low-angle obsidian ground bounce, electric cyan conduit glow.',
      dialoguePreview: 'DIRECTOR NOTE: Sound design cuts to dead vacuum silence before sub-bass impact.',
      status: 'Final Locked',
    },
  ]);

  readonly activeShotId = signal<string>('shot-1');
  readonly selectedShot = computed(() => {
    const list = this.shots();
    return list.find((s) => s.id === this.activeShotId()) || list[0];
  });

  // Scenes
  readonly scenes = signal<Scene[]>([
    {
      id: 'scene-1',
      number: 14,
      act: 'Act II: The Perimeter',
      slugline: 'EXT. TOKYO SECTOR 9 - NIGHT',
      timeOfDay: 'NIGHT',
      locationType: 'EXT',
      locationName: 'Sector 9 Cyber Alley',
      summary: 'Kaelen arrives at the extraction coordinates. The atmospheric humidity carries an encoded radio broadcast.',
      pageCount: 3.5,
      status: 'In Cut',
      shotIds: ['shot-1'],
    },
    {
      id: 'scene-2',
      number: 15,
      act: 'Act II: The Perimeter',
      slugline: 'INT. ORBITAL OBSERVATORY - TWILIGHT CYCLE',
      timeOfDay: 'TWILIGHT',
      locationType: 'INT',
      locationName: 'Chrono Orbital Station Hub',
      summary: 'Telemetry indicates an irreversible temporal shift at the southern quadrant coordinates.',
      pageCount: 2.2,
      status: 'In Cut',
      shotIds: ['shot-2', 'shot-3'],
    },
    {
      id: 'scene-3',
      number: 16,
      act: 'Act III: The Descent',
      slugline: 'EXT. OBSIDIAN CRATER VALLEY - TWILIGHT',
      timeOfDay: 'TWILIGHT',
      locationType: 'EXT',
      locationName: 'Sub-Zero Monolith Valley',
      summary: 'The expedition reaches the perimeter of the silent spire. Auroral discharge bathes the landscape.',
      pageCount: 4.8,
      status: 'Locked',
      shotIds: ['shot-4'],
    },
  ]);

  // Timeline Tracks
  readonly tracks = signal<TimelineTrack[]>([
    { id: 'v2', name: 'V2: VFX & Anamorphic Overlays', type: 'video', isMuted: false, isSolo: false, isLocked: false, volumeOrOpacity: 100 },
    { id: 'v1', name: 'V1: Primary A-Cam CinemaScope', type: 'video', isMuted: false, isSolo: false, isLocked: false, volumeOrOpacity: 100 },
    { id: 'a1', name: 'A1: Production Dialogue (Boom & Lav)', type: 'audio', isMuted: false, isSolo: false, isLocked: false, volumeOrOpacity: 90 },
    { id: 'a2', name: 'A2: Ambient Atmos & Sub-Bass Sound FX', type: 'audio', isMuted: false, isSolo: false, isLocked: false, volumeOrOpacity: 85 },
  ]);

  // Timeline Clips
  readonly clips = signal<TimelineClip[]>([
    {
      id: 'clip-v1-1',
      shotId: 'shot-1',
      title: 'S14A-01: Neon Alley Tokyo',
      trackId: 'v1',
      startFrame: 0,
      durationFrames: 156, // 6.5s
      colorGrade: 'Cyan Night 500T',
      imageSrc: 'assets/images/film_frame_tokyo_noir_1793404704926.jpg',
    },
    {
      id: 'clip-v1-2',
      shotId: 'shot-2',
      title: 'S14B-02: Orbital Station Drift',
      trackId: 'v1',
      startFrame: 156,
      durationFrames: 192, // 8.0s
      colorGrade: 'OLED True 709',
      imageSrc: 'assets/images/film_frame_orbital_monolith_1793404716142.jpg',
    },
    {
      id: 'clip-v1-3',
      shotId: 'shot-3',
      title: 'S15A-01: Kaelen Profile Flare',
      trackId: 'v1',
      startFrame: 348,
      durationFrames: 115, // 4.8s
      colorGrade: 'Pure Log-C',
      imageSrc: 'assets/images/film_frame_actor_profile_1793404727880.jpg',
    },
    {
      id: 'clip-v1-4',
      shotId: 'shot-4',
      title: 'S15B-03: Obsidian Spire Aurora',
      trackId: 'v1',
      startFrame: 463,
      durationFrames: 220, // 9.2s
      colorGrade: 'Monolith 2383 Kodak',
      imageSrc: 'assets/images/film_frame_monolith_desert_1793404738600.jpg',
    },
    // V2 FX clip
    {
      id: 'clip-v2-1',
      title: 'Anamorphic Blue Streak FX',
      trackId: 'v2',
      startFrame: 348,
      durationFrames: 115,
      colorGrade: 'Screen Blend',
    },
    // Audio clips
    {
      id: 'clip-a1-1',
      title: 'Dialogue: Kaelen Tokyo Sync',
      trackId: 'a1',
      startFrame: 24,
      durationFrames: 120,
      colorGrade: 'WAV 24/48',
      audioWaveformData: [20, 35, 60, 45, 80, 75, 40, 25, 90, 85, 30, 20, 50, 40, 15],
    },
    {
      id: 'clip-a1-2',
      title: 'Dialogue: Radio Telemetry Voice',
      trackId: 'a1',
      startFrame: 180,
      durationFrames: 150,
      colorGrade: 'WAV 24/48',
      audioWaveformData: [10, 40, 55, 65, 70, 60, 45, 20, 35, 75, 80, 40, 15, 10],
    },
    {
      id: 'clip-a2-1',
      title: 'Score: Sub-Bass Dronescape 04',
      trackId: 'a2',
      startFrame: 0,
      durationFrames: 683,
      colorGrade: '5.1 Mix',
      audioWaveformData: [40, 45, 55, 60, 65, 70, 75, 80, 85, 90, 85, 75, 65, 50, 40],
    },
  ]);

  // Audio Channels for Studio Mixer
  readonly audioChannels = signal<AudioChannel[]>([
    { id: 'ch-master', name: 'Master Mix', type: 'master', volumeDb: 0, isMuted: false, isSolo: false, pan: 0, peakLevel: 0.72 },
    { id: 'ch-dialogue', name: 'Dialogue A1', type: 'dialogue', volumeDb: -2.5, isMuted: false, isSolo: false, pan: 0, peakLevel: 0.65 },
    { id: 'ch-score', name: 'Film Score A2', type: 'score', volumeDb: -6.0, isMuted: false, isSolo: false, pan: -10, peakLevel: 0.58 },
    { id: 'ch-ambience', name: 'Atmos Ambience', type: 'ambience', volumeDb: -12.0, isMuted: false, isSolo: false, pan: 15, peakLevel: 0.42 },
    { id: 'ch-foley', name: 'Foley & FX', type: 'foley', volumeDb: -8.5, isMuted: false, isSolo: false, pan: 5, peakLevel: 0.51 },
  ]);

  // Screenplay Content
  readonly screenplayLines = signal<ScreenplayLine[]>([
    { id: 'line-1', type: 'scene-heading', text: 'EXT. TOKYO SECTOR 9 - NIGHT' },
    { id: 'line-2', type: 'action', text: 'Torrential rain streaks downward against dark obsidian alleys. The pale cyan glow of an overhead lamp hums with high-frequency electromagnetic noise.' },
    { id: 'line-3', type: 'action', text: 'AGENT KAELEN (40s) stands motionless in a heavy dark tactical coat, water dripping from the brim of his collar. His breathing is measured, calm, dangerous.' },
    { id: 'line-4', type: 'character', text: 'KAELEN' },
    { id: 'line-5', type: 'parenthetical', text: '(into bone-conduction comm)' },
    { id: 'line-6', type: 'dialogue', text: 'The frequency is shifting. It knows we are watching.' },
    { id: 'line-7', type: 'character', text: 'ORBITAL CONTROL (V.O.)' },
    { id: 'line-8', type: 'dialogue', text: 'Chrono Station status: Zero containment variance detected. Proceed to the vault coordinates.' },
    { id: 'line-9', type: 'transition', text: 'CUT TO:' },
    { id: 'line-10', type: 'scene-heading', text: 'INT. INTERROGATION CHAMBER - CONTINUOUS' },
    { id: 'line-11', type: 'action', text: 'Total darkness. A singular blade of pale ice blue edge light slices across Kaelen’s face. He stares directly into the lens.' },
    { id: 'line-12', type: 'character', text: 'KAELEN' },
    { id: 'line-13', type: 'dialogue', text: 'You think time flows forward because that is the only way your eyes can process decay. But out in the valley... it has already collapsed.' },
    { id: 'line-14', type: 'transition', text: 'SMASH CUT TO:' },
    { id: 'line-15', type: 'scene-heading', text: 'EXT. OBSIDIAN CRATER VALLEY - TWILIGHT' },
    { id: 'line-16', type: 'action', text: 'The monolithic alien obelisk pierces the twilight sky. Auroral ribbons of cold cyan light cascade over the silent obsidian dunes.' },
  ]);

  // Timeline UI State
  readonly timelineZoom = signal<number>(1.2); // 0.5 to 3
  readonly isSnappingEnabled = signal<boolean>(true);
  readonly selectedTool = signal<'select' | 'blade' | 'ripple'>('select');

  // Playback timer reference
  private playbackTimer: ReturnType<typeof setInterval> | null = null;

  // Computed SMPTE Timecode: HH:MM:SS:FF
  readonly formattedTimecode = computed(() => {
    const frame = this.currentFrame();
    const rate = this.fps();
    const totalSeconds = Math.floor(frame / rate);
    const ff = frame % rate;
    const ss = totalSeconds % 60;
    const mm = Math.floor(totalSeconds / 60) % 60;
    const hh = Math.floor(totalSeconds / 3600);

    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${pad(hh)}:${pad(mm)}:${pad(ss)}:${pad(ff)}`;
  });

  // Current Active Clip according to Playhead
  readonly currentActiveClip = computed(() => {
    const frame = this.currentFrame();
    return this.clips().find(
      (c) => c.trackId === 'v1' && frame >= c.startFrame && frame < c.startFrame + c.durationFrames
    ) || this.clips()[0];
  });

  // Active preview image based on playhead position or selected shot
  readonly activePreviewImage = computed(() => {
    const activeClip = this.currentActiveClip();
    if (activeClip && activeClip.imageSrc) {
      return activeClip.imageSrc;
    }
    return this.selectedShot().imageSrc;
  });

  // Subtitles System (Bilingual Persian & English)
  readonly subtitles = signal<SubtitleCue[]>([
    {
      id: 'sub-1',
      startFrame: 24,
      endFrame: 144,
      textEn: 'The frequency is shifting. It knows we are watching.',
      textFa: 'فرکانس در حال تغییر است. او می‌داند که ما نظاره‌گر هستیم.',
    },
    {
      id: 'sub-2',
      startFrame: 180,
      endFrame: 330,
      textEn: 'Chrono Station status: Zero containment variance detected.',
      textFa: 'وضعیت پایگاه کرونو: هیچ انحراف مهاری شناسایی نشد.',
    },
    {
      id: 'sub-3',
      startFrame: 360,
      endFrame: 470,
      textEn: 'You think time flows forward because that is the only way your eyes can process decay.',
      textFa: 'تو فکر می‌کنی زمان رو به جلو می‌رود، چون چشم‌های تو فقط زوال را درک می‌کنند.',
    },
  ]);

  readonly showSubtitles = signal<boolean>(true);
  readonly subtitleLanguage = signal<'both' | 'fa' | 'en' | 'off'>('both');

  // VOID AI Personal Assistant Panel State
  readonly isAIAssistantOpen = signal<boolean>(false);

  // Active Subtitle for current playhead frame
  readonly activeSubtitleCue = computed(() => {
    if (!this.showSubtitles() || this.subtitleLanguage() === 'off') return null;
    const f = this.currentFrame();
    return this.subtitles().find((sub) => f >= sub.startFrame && f <= sub.endFrame) || null;
  });

  constructor() {
    this.startVUOscillation();
    this.loadProjectFromStorage();
  }

  // Transport Methods
  togglePlay(): void {
    if (this.isPlaying()) {
      this.pause();
    } else {
      this.play();
    }
  }

  play(): void {
    this.isPlaying.set(true);
    if (this.playbackTimer) clearInterval(this.playbackTimer);

    const intervalMs = Math.round(1000 / (this.fps() * this.playbackSpeed()));
    this.playbackTimer = setInterval(() => {
      this.currentFrame.update((f) => {
        const next = f + 1;
        if (next >= this.totalFrames()) {
          if (this.loopPlayback()) {
            return 0;
          } else {
            this.pause();
            return f;
          }
        }
        return next;
      });
    }, intervalMs);
  }

  pause(): void {
    this.isPlaying.set(false);
    if (this.playbackTimer) {
      clearInterval(this.playbackTimer);
      this.playbackTimer = null;
    }
  }

  stepFrame(delta: number): void {
    this.pause();
    this.currentFrame.update((f) => {
      const next = f + delta;
      return Math.max(0, Math.min(this.totalFrames() - 1, next));
    });
  }

  scrubToFrame(frame: number): void {
    this.currentFrame.set(Math.max(0, Math.min(this.totalFrames() - 1, Math.round(frame))));
  }

  jumpToIn(): void {
    this.scrubToFrame(0);
  }

  jumpToOut(): void {
    this.scrubToFrame(this.totalFrames() - 1);
  }

  setPlaybackSpeed(speed: number): void {
    this.playbackSpeed.set(speed);
    if (this.isPlaying()) {
      this.play(); // reset interval with new speed
    }
  }

  selectShot(id: string): void {
    this.activeShotId.set(id);
    const shot = this.shots().find((s) => s.id === id);
    if (shot) {
      const correspondingClip = this.clips().find((c) => c.shotId === id);
      if (correspondingClip) {
        this.scrubToFrame(correspondingClip.startFrame);
      }
    }
  }

  addScreenplayLine(type: ScreenplayLine['type'], text: string): void {
    const newLine: ScreenplayLine = {
      id: 'line-' + Date.now(),
      type,
      text,
    };
    this.screenplayLines.update((lines) => [...lines, newLine]);
  }

  updateScreenplayLine(id: string, newText: string): void {
    this.screenplayLines.update((lines) =>
      lines.map((l) => (l.id === id ? { ...l, text: newText } : l))
    );
  }

  deleteScreenplayLine(id: string): void {
    this.screenplayLines.update((lines) => lines.filter((l) => l.id !== id));
  }

  // Audio Channel Controls
  setChannelVolume(channelId: string, volumeDb: number): void {
    this.audioChannels.update((channels) =>
      channels.map((ch) => (ch.id === channelId ? { ...ch, volumeDb } : ch))
    );
  }

  toggleChannelMute(channelId: string): void {
    this.audioChannels.update((channels) =>
      channels.map((ch) => (ch.id === channelId ? { ...ch, isMuted: !ch.isMuted } : ch))
    );
  }

  toggleChannelSolo(channelId: string): void {
    this.audioChannels.update((channels) =>
      channels.map((ch) => (ch.id === channelId ? { ...ch, isSolo: !ch.isSolo } : ch))
    );
  }

  setChannelPan(channelId: string, pan: number): void {
    this.audioChannels.update((channels) =>
      channels.map((ch) => (ch.id === channelId ? { ...ch, pan } : ch))
    );
  }

  // Track toggles
  toggleTrackMute(trackId: string): void {
    this.tracks.update((tracks) =>
      tracks.map((t) => (t.id === trackId ? { ...t, isMuted: !t.isMuted } : t))
    );
  }

  toggleTrackSolo(trackId: string): void {
    this.tracks.update((tracks) =>
      tracks.map((t) => (t.id === trackId ? { ...t, isSolo: !t.isSolo } : t))
    );
  }

  toggleTrackLock(trackId: string): void {
    this.tracks.update((tracks) =>
      tracks.map((t) => (t.id === trackId ? { ...t, isLocked: !t.isLocked } : t))
    );
  }

  // Export render simulation
  triggerRender(): void {
    this.isRendering.set(true);
    this.renderProgress.set(0);

    const step = () => {
      this.renderProgress.update((p) => {
        if (p >= 100) {
          this.isRendering.set(false);
          return 100;
        }
        setTimeout(step, 80);
        return Math.min(100, p + Math.floor(Math.random() * 8) + 3);
      });
    };
    step();
  }

  // Simulated VU oscillation for ultra-realistic cinema studio desk
  private startVUOscillation(): void {
    setInterval(() => {
      const playing = this.isPlaying();
      this.audioChannels.update((channels) =>
        channels.map((ch) => {
          if (ch.isMuted) return { ...ch, peakLevel: 0 };
          const base = playing ? 0.6 : 0.15;
          const jitter = (Math.random() - 0.5) * 0.35;
          const level = Math.max(0.05, Math.min(0.98, base + jitter));
          return { ...ch, peakLevel: level };
        })
      );
    }, 120);
  }

  // Project Snapshot for AI Awareness and Persistence
  getProjectSnapshot() {
    return {
      title: this.projectTitle(),
      reel: this.projectReel(),
      fps: this.fps(),
      totalFrames: this.totalFrames(),
      currentFrame: this.currentFrame(),
      timecode: this.formattedTimecode(),
      aspectRatio: this.activeAspectRatio(),
      lut: this.activeLUT(),
      shotCount: this.shots().length,
      shots: this.shots().map((s) => ({
        id: s.id,
        code: s.shotCode,
        title: s.title,
        duration: s.durationSeconds,
        lens: s.camera.lens,
        aperture: s.camera.aperture,
        status: s.status,
      })),
      sceneCount: this.scenes().length,
      scenes: this.scenes().map((sc) => ({
        number: sc.number,
        slugline: sc.slugline,
        status: sc.status,
      })),
      screenplayLineCount: this.screenplayLines().length,
      timelineTrackCount: this.tracks().length,
      timelineClipCount: this.clips().length,
      audioChannels: this.audioChannels().map((ch) => ({
        id: ch.id,
        name: ch.name,
        volumeDb: ch.volumeDb,
        isMuted: ch.isMuted,
        isSolo: ch.isSolo,
      })),
      subtitlesCount: this.subtitles().length,
      exportSettings: this.exportSettings(),
    };
  }

  // Save Project to Browser LocalStorage
  saveProjectToStorage(): boolean {
    if (typeof window === 'undefined' || !window.localStorage) return false;
    try {
      const payload = {
        title: this.projectTitle(),
        reel: this.projectReel(),
        shots: this.shots(),
        scenes: this.scenes(),
        screenplayLines: this.screenplayLines(),
        clips: this.clips(),
        tracks: this.tracks(),
        audioChannels: this.audioChannels(),
        subtitles: this.subtitles(),
        exportSettings: this.exportSettings(),
        savedAt: new Date().toISOString(),
      };
      localStorage.setItem('void_cinema_project_state', JSON.stringify(payload));
      return true;
    } catch {
      return false;
    }
  }

  // Load Project from Browser LocalStorage
  loadProjectFromStorage(): boolean {
    if (typeof window === 'undefined' || !window.localStorage) return false;
    try {
      const raw = localStorage.getItem('void_cinema_project_state');
      if (!raw) return false;
      const data = JSON.parse(raw);
      if (data.title) this.projectTitle.set(data.title);
      if (data.reel) this.projectReel.set(data.reel);
      if (Array.isArray(data.shots) && data.shots.length > 0) this.shots.set(data.shots);
      if (Array.isArray(data.scenes) && data.scenes.length > 0) this.scenes.set(data.scenes);
      if (Array.isArray(data.screenplayLines) && data.screenplayLines.length > 0) this.screenplayLines.set(data.screenplayLines);
      if (Array.isArray(data.clips) && data.clips.length > 0) this.clips.set(data.clips);
      if (Array.isArray(data.tracks) && data.tracks.length > 0) this.tracks.set(data.tracks);
      if (Array.isArray(data.audioChannels) && data.audioChannels.length > 0) this.audioChannels.set(data.audioChannels);
      if (Array.isArray(data.subtitles) && data.subtitles.length > 0) this.subtitles.set(data.subtitles);
      if (data.exportSettings) this.exportSettings.set(data.exportSettings);
      return true;
    } catch {
      return false;
    }
  }

  // Reset Project to Standard Void Cinema Baseline
  resetProject(): void {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.removeItem('void_cinema_project_state');
    }
    this.projectTitle.set('CHRONO STATIC');
    this.projectReel.set('REEL 02 / ACT II');
    this.currentFrame.set(432);
    this.activeLUT.set('Cyan Night 500T');
    this.activeAspectRatio.set('2.39:1');
    // reset playback
    this.pause();
  }
}
