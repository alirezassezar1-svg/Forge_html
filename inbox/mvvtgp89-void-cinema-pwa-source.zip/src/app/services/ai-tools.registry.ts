import { Injectable, inject } from '@angular/core';
import { StudioState } from './studio.state';
import { ToolName, Shot, Scene, ScreenplayLine, TimelineClip, SubtitleCue, ExportSettings } from '../models/studio.model';

export interface ToolDefinition {
  name: ToolName;
  category: 'project' | 'screenplay' | 'storyboard' | 'timeline' | 'audio' | 'subtitles' | 'rendering';
  descriptionEn: string;
  descriptionFa: string;
  requiresConfirmation: boolean;
  validate: (args: Record<string, unknown>) => { valid: boolean; error?: string };
  execute: (args: Record<string, unknown>, state: StudioState) => Promise<{ success: boolean; data?: unknown; error?: string }>;
}

@Injectable({
  providedIn: 'root',
})
export class AIToolRegistry {
  private readonly state = inject(StudioState);

  private readonly registry = new Map<ToolName, ToolDefinition>();

  constructor() {
    this.registerAllTools();
  }

  getTool(name: ToolName): ToolDefinition | undefined {
    return this.registry.get(name);
  }

  getAllTools(): ToolDefinition[] {
    return Array.from(this.registry.values());
  }

  async executeTool(name: ToolName, args: Record<string, unknown>): Promise<{ success: boolean; data?: unknown; error?: string }> {
    const tool = this.getTool(name);
    if (!tool) {
      return { success: false, error: `Tool "${name}" is not registered in VOID AI system.` };
    }

    const validation = tool.validate(args);
    if (!validation.valid) {
      return { success: false, error: validation.error || `Invalid arguments for tool ${name}` };
    }

    try {
      const result = await tool.execute(args, this.state);
      return result;
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      return { success: false, error: `Execution error in ${name}: ${msg}` };
    }
  }

  private registerAllTools(): void {
    // 1. get_project_state
    this.registry.set('get_project_state', {
      name: 'get_project_state',
      category: 'project',
      descriptionEn: 'Retrieve complete current project metadata, scenes, storyboard shots, and timeline tracks.',
      descriptionFa: 'دریافت وضعیت کامل متادیتای پروژه، صحنه‌ها، استوری‌بورد و تایم‌لاین.',
      requiresConfirmation: false,
      validate: () => ({ valid: true }),
      execute: async (_, state) => {
        return { success: true, data: state.getProjectSnapshot() };
      },
    });

    // 2. update_project_title
    this.registry.set('update_project_title', {
      name: 'update_project_title',
      category: 'project',
      descriptionEn: 'Update film project title and reel designation.',
      descriptionFa: 'به‌روزرسانی عنوان پروژه فیلم و شماره ریل.',
      requiresConfirmation: false,
      validate: (args) => {
        if (!args['title'] && !args['reel']) {
          return { valid: false, error: 'Provide at least "title" or "reel".' };
        }
        return { valid: true };
      },
      execute: async (args, state) => {
        if (typeof args['title'] === 'string' && args['title'].trim()) {
          state.projectTitle.set(args['title'].trim());
        }
        if (typeof args['reel'] === 'string' && args['reel'].trim()) {
          state.projectReel.set(args['reel'].trim());
        }
        state.saveProjectToStorage();
        return { success: true, data: { title: state.projectTitle(), reel: state.projectReel() } };
      },
    });

    // 3. save_project
    this.registry.set('save_project', {
      name: 'save_project',
      category: 'project',
      descriptionEn: 'Persist project timeline, shots, and screenplay to local browser storage.',
      descriptionFa: 'ذخیره دائمی پروژه، شات‌ها، فیلم‌نامه و تایم‌لاین در حافظه مرورگر.',
      requiresConfirmation: false,
      validate: () => ({ valid: true }),
      execute: async (_, state) => {
        const ok = state.saveProjectToStorage();
        return ok
          ? { success: true, data: { message: 'Project snapshot successfully committed to storage.' } }
          : { success: false, error: 'Failed to access browser storage.' };
      },
    });

    // 4. load_project
    this.registry.set('load_project', {
      name: 'load_project',
      category: 'project',
      descriptionEn: 'Restore last saved project snapshot from local storage.',
      descriptionFa: 'بارگذاری آخرین وضعیت ذخیره‌شده پروژه از حافظه محلی.',
      requiresConfirmation: false,
      validate: () => ({ valid: true }),
      execute: async (_, state) => {
        const ok = state.loadProjectFromStorage();
        return ok
          ? { success: true, data: { message: 'Project snapshot loaded successfully.' } }
          : { success: false, error: 'No saved project snapshot found in local storage.' };
      },
    });

    // 5. reset_project
    this.registry.set('reset_project', {
      name: 'reset_project',
      category: 'project',
      descriptionEn: 'Reset film studio to default clean template (irreversible).',
      descriptionFa: 'بازنشانی کامل استودیو به تنظیمات و پروژه پیش‌فرض اولیه (نیازمند تایید).',
      requiresConfirmation: true,
      validate: () => ({ valid: true }),
      execute: async (_, state) => {
        state.resetProject();
        return { success: true, data: { message: 'Project reset to default Chrono Static baseline.' } };
      },
    });

    // 6. get_screenplay
    this.registry.set('get_screenplay', {
      name: 'get_screenplay',
      category: 'screenplay',
      descriptionEn: 'Retrieve current screenplay sluglines, actions, and dialogues.',
      descriptionFa: 'دریافت خطوط فعلی فیلم‌نامه، هدینگ‌ها و دیالوگ‌ها.',
      requiresConfirmation: false,
      validate: () => ({ valid: true }),
      execute: async (_, state) => {
        return { success: true, data: state.screenplayLines() };
      },
    });

    // 7. write_screenplay
    this.registry.set('write_screenplay', {
      name: 'write_screenplay',
      category: 'screenplay',
      descriptionEn: 'Add a new formatted screenplay line (slugline, action, character, or dialogue).',
      descriptionFa: 'افزودن خط جدید به فیلم‌نامه با فرمت استاندارد.',
      requiresConfirmation: false,
      validate: (args) => {
        if (!args['type'] || !args['text']) {
          return { valid: false, error: 'Requires "type" (slugline/action/character/dialogue) and "text".' };
        }
        return { valid: true };
      },
      execute: async (args, state) => {
        const type = (args['type'] as ScreenplayLine['type']) || 'action';
        const text = String(args['text'] || '');
        state.addScreenplayLine(type, text);
        return { success: true, data: { count: state.screenplayLines().length } };
      },
    });

    // 8. rewrite_screenplay
    this.registry.set('rewrite_screenplay', {
      name: 'rewrite_screenplay',
      category: 'screenplay',
      descriptionEn: 'Overwrite screenplay with an improved or newly structured scene dialogue sequence.',
      descriptionFa: 'بازنویسی یا جایگزینی کامل فیلم‌نامه با ساختار دیالوگ جدید.',
      requiresConfirmation: true,
      validate: (args) => {
        if (!Array.isArray(args['lines']) || args['lines'].length === 0) {
          return { valid: false, error: 'Requires array of formatted screenplay "lines".' };
        }
        return { valid: true };
      },
      execute: async (args, state) => {
        const lines = (args['lines'] as { type: ScreenplayLine['type']; text: string }[]).map((l, idx) => ({
          id: `line-${Date.now()}-${idx}`,
          type: l.type,
          text: l.text,
        }));
        state.screenplayLines.set(lines);
        return { success: true, data: { count: lines.length } };
      },
    });

    // 9. split_story_into_scenes
    this.registry.set('split_story_into_scenes', {
      name: 'split_story_into_scenes',
      category: 'screenplay',
      descriptionEn: 'Divide a narrative text or screenplay into structured cinematic scenes.',
      descriptionFa: 'تقسیم داستان یا متن فیلم‌نامه به صحنه‌های مجزای سینمایی.',
      requiresConfirmation: true,
      validate: (args) => {
        const count = Number(args['sceneCount'] || 0);
        if (count < 1) {
          return { valid: false, error: 'Provide a valid sceneCount (>= 1).' };
        }
        return { valid: true };
      },
      execute: async (args, state) => {
        const count = Math.min(10, Math.max(1, Number(args['sceneCount'] || 3)));
        const newScenes: Scene[] = [];
        const baseTitles = [
          'EXT. TOKYO SECTOR 9 - NIGHT',
          'INT. ORBITAL OBSERVATORY - TWILIGHT CYCLE',
          'INT. INTERROGATION CHAMBER - CONTINUOUS',
          'EXT. OBSIDIAN CRATER VALLEY - TWILIGHT',
          'INT. MONOLITH SUB-VAULT - PERIMETER',
          'EXT. CYBER DRIFT HORIZON - DAWN',
          'INT. QUANTUM RELAY CONDUIT - NIGHT',
          'EXT. TACTICAL EXTRACTION ROOFTOP - RAIN',
          'INT. CRYOGENIC ARCHIVE - ZERO LEVEL',
          'EXT. VOID APEX - TWILIGHT REVELATION',
        ];

        for (let i = 1; i <= count; i++) {
          newScenes.push({
            id: `scene-${i}`,
            number: i,
            act: i <= Math.ceil(count * 0.3) ? 'Act I: Setup' : (i <= Math.ceil(count * 0.7) ? 'Act II: Confrontation' : 'Act III: Resolution'),
            slugline: baseTitles[(i - 1) % baseTitles.length],
            timeOfDay: (i % 2 === 0 ? 'TWILIGHT' : 'NIGHT') as Scene['timeOfDay'],
            locationType: i % 2 === 0 ? 'INT' : 'EXT',
            locationName: `Cinematic Stage ${i}`,
            summary: `Automated cinematic sequence for scene ${i} structured by VOID AI.`,
            pageCount: 2.0,
            status: i === 1 ? 'Locked' : 'In Cut',
            shotIds: [],
          });
        }
        state.scenes.set(newScenes);
        return { success: true, data: { sceneCount: newScenes.length, scenes: newScenes } };
      },
    });

    // 10. update_scene_text
    this.registry.set('update_scene_text', {
      name: 'update_scene_text',
      category: 'screenplay',
      descriptionEn: 'Update slugline or dramatic description of a specific scene.',
      descriptionFa: 'ویرایش اسلاگ‌لاین یا توضیحات دراماتیک یک صحنه خاص.',
      requiresConfirmation: false,
      validate: (args) => {
        if (!args['sceneNumber'] && !args['sceneId']) {
          return { valid: false, error: 'Provide "sceneNumber" or "sceneId".' };
        }
        return { valid: true };
      },
      execute: async (args, state) => {
        const num = Number(args['sceneNumber']);
        state.scenes.update((scenes) =>
          scenes.map((sc) => {
            if (sc.number === num || sc.id === args['sceneId']) {
              return {
                ...sc,
                slugline: typeof args['slugline'] === 'string' ? args['slugline'] : sc.slugline,
                summary: typeof args['summary'] === 'string' ? args['summary'] : sc.summary,
              };
            }
            return sc;
          })
        );
        return { success: true, data: { message: `Scene ${num} updated.` } };
      },
    });

    // 11. get_storyboard
    this.registry.set('get_storyboard', {
      name: 'get_storyboard',
      category: 'storyboard',
      descriptionEn: 'Retrieve list of all storyboard shot setups with camera optics & lighting.',
      descriptionFa: 'دریافت فهرست تمام شات‌های استوری‌بورد همراه با جزئیات لنز و نورپردازی.',
      requiresConfirmation: false,
      validate: () => ({ valid: true }),
      execute: async (_, state) => {
        return { success: true, data: state.shots() };
      },
    });

    // 12. create_scene_shot
    this.registry.set('create_scene_shot', {
      name: 'create_scene_shot',
      category: 'storyboard',
      descriptionEn: 'Add a new camera shot setup to the storyboard wall and timeline.',
      descriptionFa: 'افزودن یک ستاپ شات جدید به استوری‌بورد و تایم‌لاین.',
      requiresConfirmation: false,
      validate: (args) => {
        if (!args['title']) return { valid: false, error: 'Requires shot "title".' };
        return { valid: true };
      },
      execute: async (args, state) => {
        const availableImgs = [
          'assets/images/film_frame_tokyo_noir_1793404704926.jpg',
          'assets/images/film_frame_orbital_monolith_1793404716142.jpg',
          'assets/images/film_frame_actor_profile_1793404727880.jpg',
          'assets/images/film_frame_monolith_desert_1793404738600.jpg',
        ];
        const nextIdx = state.shots().length + 1;
        const newShot: Shot = {
          id: `shot-${Date.now()}`,
          sceneNumber: String(args['sceneNumber'] || `${nextIdx}A`),
          shotCode: `S${nextIdx}A-01`,
          title: String(args['title']),
          description: String(args['description'] || 'Cinematic composition captured under VOID AI direction.'),
          imageSrc: String(args['imageSrc'] || availableImgs[(nextIdx - 1) % availableImgs.length]),
          durationSeconds: Number(args['durationSeconds'] || 5.0),
          camera: {
            lens: String(args['lens'] || 'Panavision C-Series 40mm Anamorphic'),
            aperture: String(args['aperture'] || 'T1.4'),
            shutterAngle: '180.0°',
            iso: 800,
            sensor: 'Arri Alexa 65 Large Format',
            movement: String(args['movement'] || 'Slow Push-in on Dolly'),
            aspectRatio: '2.39:1 CinemaScope',
          },
          lightingSetup: String(args['lighting'] || 'High-contrast cyan rim, pitch black fill'),
          dialoguePreview: String(args['dialogue'] || 'DIRECTOR CUE: Atmosphere holds tension.'),
          status: 'Rough Cut',
        };

        state.shots.update((shots) => [...shots, newShot]);
        // Also append clip to timeline
        const clipFrames = Math.round(newShot.durationSeconds * state.fps());
        const lastClipEnd = state.clips().filter(c => c.trackId === 'v1').reduce((max, c) => Math.max(max, c.startFrame + c.durationFrames), 0);
        state.clips.update((clips) => [
          ...clips,
          {
            id: `clip-v1-${Date.now()}`,
            shotId: newShot.id,
            title: newShot.title,
            trackId: 'v1',
            startFrame: lastClipEnd,
            durationFrames: clipFrames,
            colorGrade: 'Cyan Night 500T',
            imageSrc: newShot.imageSrc,
          },
        ]);
        return { success: true, data: newShot };
      },
    });

    // 13. delete_scene_shot
    this.registry.set('delete_scene_shot', {
      name: 'delete_scene_shot',
      category: 'storyboard',
      descriptionEn: 'Remove a camera shot setup from storyboard and timeline.',
      descriptionFa: 'حذف یک شات از استوری‌بورد و تایم‌لاین.',
      requiresConfirmation: true,
      validate: (args) => {
        if (!args['shotId']) return { valid: false, error: 'Requires "shotId".' };
        return { valid: true };
      },
      execute: async (args, state) => {
        const shotId = String(args['shotId']);
        state.shots.update((shots) => shots.filter((s) => s.id !== shotId));
        state.clips.update((clips) => clips.filter((c) => c.shotId !== shotId));
        return { success: true, data: { deletedShotId: shotId } };
      },
    });

    // 14. update_scene_shot
    this.registry.set('update_scene_shot', {
      name: 'update_scene_shot',
      category: 'storyboard',
      descriptionEn: 'Modify shot parameters: lens, aperture, lighting, or title.',
      descriptionFa: 'اصلاح پارامترهای فنی شات (لنز، دیافراگم، نورپردازی یا عنوان).',
      requiresConfirmation: false,
      validate: (args) => {
        if (!args['shotId']) return { valid: false, error: 'Requires "shotId".' };
        return { valid: true };
      },
      execute: async (args, state) => {
        const shotId = String(args['shotId']);
        state.shots.update((shots) =>
          shots.map((s) => {
            if (s.id === shotId) {
              return {
                ...s,
                title: typeof args['title'] === 'string' ? args['title'] : s.title,
                lightingSetup: typeof args['lighting'] === 'string' ? args['lighting'] : s.lightingSetup,
                camera: {
                  ...s.camera,
                  lens: typeof args['lens'] === 'string' ? args['lens'] : s.camera.lens,
                  aperture: typeof args['aperture'] === 'string' ? args['aperture'] : s.camera.aperture,
                  movement: typeof args['movement'] === 'string' ? args['movement'] : s.camera.movement,
                },
              };
            }
            return s;
          })
        );
        return { success: true, data: { updatedShotId: shotId } };
      },
    });

    // 15. set_shot_duration
    this.registry.set('set_shot_duration', {
      name: 'set_shot_duration',
      category: 'storyboard',
      descriptionEn: 'Adjust duration of a specific shot and resize its timeline clip.',
      descriptionFa: 'تنظیم مدت زمان یک شات و اندازه کلیپ آن در تایم‌لاین.',
      requiresConfirmation: false,
      validate: (args) => {
        if (!args['shotId'] || !args['durationSeconds']) {
          return { valid: false, error: 'Requires "shotId" and "durationSeconds".' };
        }
        return { valid: true };
      },
      execute: async (args, state) => {
        const shotId = String(args['shotId']);
        const dur = Number(args['durationSeconds']);
        state.shots.update((shots) =>
          shots.map((s) => (s.id === shotId ? { ...s, durationSeconds: dur } : s))
        );
        const frames = Math.round(dur * state.fps());
        state.clips.update((clips) =>
          clips.map((c) => (c.shotId === shotId ? { ...c, durationFrames: frames } : c))
        );
        return { success: true, data: { shotId, newDurationSeconds: dur } };
      },
    });

    // 16. get_timeline
    this.registry.set('get_timeline', {
      name: 'get_timeline',
      category: 'timeline',
      descriptionEn: 'Retrieve timeline tracks, clips, and active playhead position.',
      descriptionFa: 'دریافت وضعیت ترک‌ها، کلیپ‌ها و موقعیت نشانگر پلی‌هد در تایم‌لاین.',
      requiresConfirmation: false,
      validate: () => ({ valid: true }),
      execute: async (_, state) => {
        return {
          success: true,
          data: {
            currentFrame: state.currentFrame(),
            timecode: state.formattedTimecode(),
            tracks: state.tracks(),
            clips: state.clips(),
          },
        };
      },
    });

    // 17. add_timeline_clip
    this.registry.set('add_timeline_clip', {
      name: 'add_timeline_clip',
      category: 'timeline',
      descriptionEn: 'Add a media or audio clip to a timeline track.',
      descriptionFa: 'افزودن یک کلیپ صوتی یا تصویری به یکی از ترک‌های تایم‌لاین.',
      requiresConfirmation: false,
      validate: (args) => {
        if (!args['trackId'] || !args['title']) {
          return { valid: false, error: 'Requires "trackId" (v1/v2/a1/a2) and "title".' };
        }
        return { valid: true };
      },
      execute: async (args, state) => {
        const trackId = String(args['trackId']);
        const title = String(args['title']);
        const start = Number(args['startFrame'] || 0);
        const dur = Number(args['durationFrames'] || 96);
        const newClip: TimelineClip = {
          id: `clip-${trackId}-${Date.now()}`,
          title,
          trackId,
          startFrame: start,
          durationFrames: dur,
          colorGrade: 'ProRes 4444',
          audioWaveformData: trackId.startsWith('a') ? [30, 45, 60, 50, 70, 80, 50, 30] : undefined,
        };
        state.clips.update((clips) => [...clips, newClip]);
        return { success: true, data: newClip };
      },
    });

    // 18. split_clip
    this.registry.set('split_clip', {
      name: 'split_clip',
      category: 'timeline',
      descriptionEn: 'Split an active clip at playhead position or specified frame.',
      descriptionFa: 'برش و دو نیم کردن کلیپ در نقطه پلی‌هد یا فریم مشخص‌شده.',
      requiresConfirmation: false,
      validate: () => ({ valid: true }),
      execute: async (args, state) => {
        const frame = Number(args['frame'] || state.currentFrame());
        const clipToSplit = state.clips().find(
          (c) => c.trackId === 'v1' && frame > c.startFrame && frame < c.startFrame + c.durationFrames
        );
        if (!clipToSplit) {
          return { success: false, error: `No clip found under frame ${frame} to slice.` };
        }

        const durA = frame - clipToSplit.startFrame;
        const durB = clipToSplit.durationFrames - durA;
        const partA: TimelineClip = { ...clipToSplit, durationFrames: durA };
        const partB: TimelineClip = {
          ...clipToSplit,
          id: `${clipToSplit.id}-part2-${Date.now()}`,
          startFrame: frame,
          durationFrames: durB,
          title: `${clipToSplit.title} [Slice]`,
        };

        state.clips.update((clips) =>
          clips.map((c) => (c.id === clipToSplit.id ? partA : c)).concat(partB)
        );
        return { success: true, data: { splitAtFrame: frame, originalClipId: clipToSplit.id } };
      },
    });

    // 19. move_clip
    this.registry.set('move_clip', {
      name: 'move_clip',
      category: 'timeline',
      descriptionEn: 'Move a timeline clip to a new start frame.',
      descriptionFa: 'جابه‌جایی موقعیت شروع کلیپ در تایم‌لاین.',
      requiresConfirmation: false,
      validate: (args) => {
        if (!args['clipId'] || args['newStartFrame'] === undefined) {
          return { valid: false, error: 'Requires "clipId" and "newStartFrame".' };
        }
        return { valid: true };
      },
      execute: async (args, state) => {
        const clipId = String(args['clipId']);
        const newStart = Math.max(0, Number(args['newStartFrame']));
        state.clips.update((clips) =>
          clips.map((c) => (c.id === clipId ? { ...c, startFrame: newStart } : c))
        );
        return { success: true, data: { clipId, newStartFrame: newStart } };
      },
    });

    // 20. set_track_mute
    this.registry.set('set_track_mute', {
      name: 'set_track_mute',
      category: 'timeline',
      descriptionEn: 'Mute or unmute a timeline track (v1/v2/a1/a2).',
      descriptionFa: 'بی‌صدا کردن یا فعال‌سازی یک ترک در تایم‌لاین.',
      requiresConfirmation: false,
      validate: (args) => {
        if (!args['trackId']) return { valid: false, error: 'Requires "trackId".' };
        return { valid: true };
      },
      execute: async (args, state) => {
        const trackId = String(args['trackId']);
        const isMuted = args['isMuted'] !== undefined ? Boolean(args['isMuted']) : true;
        state.tracks.update((tracks) =>
          tracks.map((t) => (t.id === trackId ? { ...t, isMuted } : t))
        );
        return { success: true, data: { trackId, isMuted } };
      },
    });

    // 21. set_track_solo
    this.registry.set('set_track_solo', {
      name: 'set_track_solo',
      category: 'timeline',
      descriptionEn: 'Solo or insolate a timeline track.',
      descriptionFa: 'تک‌نوازی یا سولو کردن ترک تایم‌لاین.',
      requiresConfirmation: false,
      validate: (args) => {
        if (!args['trackId']) return { valid: false, error: 'Requires "trackId".' };
        return { valid: true };
      },
      execute: async (args, state) => {
        const trackId = String(args['trackId']);
        const isSolo = args['isSolo'] !== undefined ? Boolean(args['isSolo']) : true;
        state.tracks.update((tracks) =>
          tracks.map((t) => (t.id === trackId ? { ...t, isSolo } : t))
        );
        return { success: true, data: { trackId, isSolo } };
      },
    });

    // 22. get_audio_state
    this.registry.set('get_audio_state', {
      name: 'get_audio_state',
      category: 'audio',
      descriptionEn: 'Get current audio channels, fader volume levels (dB), and pan values.',
      descriptionFa: 'دریافت وضعیت کانال‌های صوتی، میزان ولوم فیدرها و پن.',
      requiresConfirmation: false,
      validate: () => ({ valid: true }),
      execute: async (_, state) => {
        return { success: true, data: state.audioChannels() };
      },
    });

    // 23. set_audio_volume
    this.registry.set('set_audio_volume', {
      name: 'set_audio_volume',
      category: 'audio',
      descriptionEn: 'Set fader dB level for an audio channel (master, dialogue, score, ambience, foley).',
      descriptionFa: 'تنظیم میزان دسی‌بل فیدر یک کانال صوتی.',
      requiresConfirmation: false,
      validate: (args) => {
        if (!args['channelId'] || args['volumeDb'] === undefined) {
          return { valid: false, error: 'Requires "channelId" and "volumeDb".' };
        }
        return { valid: true };
      },
      execute: async (args, state) => {
        const channelId = String(args['channelId']);
        const volumeDb = Math.max(-60, Math.min(6, Number(args['volumeDb'])));
        state.setChannelVolume(channelId, volumeDb);
        return { success: true, data: { channelId, volumeDb } };
      },
    });

    // 24. set_audio_pan
    this.registry.set('set_audio_pan', {
      name: 'set_audio_pan',
      category: 'audio',
      descriptionEn: 'Set stereo panorama value (-50 Left to +50 Right).',
      descriptionFa: 'تنظیم موقعیت استریو پن (بین -۵۰ چپ تا +۵۰ راست).',
      requiresConfirmation: false,
      validate: (args) => {
        if (!args['channelId'] || args['pan'] === undefined) {
          return { valid: false, error: 'Requires "channelId" and "pan".' };
        }
        return { valid: true };
      },
      execute: async (args, state) => {
        const channelId = String(args['channelId']);
        const pan = Math.max(-50, Math.min(50, Number(args['pan'])));
        state.setChannelPan(channelId, pan);
        return { success: true, data: { channelId, pan } };
      },
    });

    // 25. toggle_audio_mute
    this.registry.set('toggle_audio_mute', {
      name: 'toggle_audio_mute',
      category: 'audio',
      descriptionEn: 'Toggle mute on an audio channel strip.',
      descriptionFa: 'تغییر وضعیت قطع صدای کانال صوتی.',
      requiresConfirmation: false,
      validate: (args) => {
        if (!args['channelId']) return { valid: false, error: 'Requires "channelId".' };
        return { valid: true };
      },
      execute: async (args, state) => {
        const channelId = String(args['channelId']);
        state.toggleChannelMute(channelId);
        return { success: true, data: { channelId } };
      },
    });

    // 26. toggle_audio_solo
    this.registry.set('toggle_audio_solo', {
      name: 'toggle_audio_solo',
      category: 'audio',
      descriptionEn: 'Toggle solo isolation on an audio channel strip.',
      descriptionFa: 'تغییر وضعیت سولو کانال صوتی در کنسول میکس.',
      requiresConfirmation: false,
      validate: (args) => {
        if (!args['channelId']) return { valid: false, error: 'Requires "channelId".' };
        return { valid: true };
      },
      execute: async (args, state) => {
        const channelId = String(args['channelId']);
        state.toggleChannelSolo(channelId);
        return { success: true, data: { channelId } };
      },
    });

    // 27. get_subtitles
    this.registry.set('get_subtitles', {
      name: 'get_subtitles',
      category: 'subtitles',
      descriptionEn: 'Retrieve list of bilingual English and Persian subtitle cues.',
      descriptionFa: 'دریافت زیرنویس‌های دوزبانه انگلیسی و فارسی فیلم.',
      requiresConfirmation: false,
      validate: () => ({ valid: true }),
      execute: async (_, state) => {
        return { success: true, data: state.subtitles() };
      },
    });

    // 28. generate_subtitles
    this.registry.set('generate_subtitles', {
      name: 'generate_subtitles',
      category: 'subtitles',
      descriptionEn: 'Generate or sync Persian/English subtitles from current screenplay dialogue cues.',
      descriptionFa: 'تولید یا همگام‌سازی زیرنویس‌های فارسی و انگلیسی بر اساس دیالوگ‌های فیلم‌نامه.',
      requiresConfirmation: false,
      validate: () => ({ valid: true }),
      execute: async (args, state) => {
        const cues: SubtitleCue[] = [
          {
            id: `sub-${Date.now()}-1`,
            startFrame: 24,
            endFrame: 144,
            textEn: 'The frequency is shifting. It knows we are watching.',
            textFa: 'فرکانس در حال تغییر است. او می‌داند که ما نظاره‌گر هستیم.',
          },
          {
            id: `sub-${Date.now()}-2`,
            startFrame: 180,
            endFrame: 330,
            textEn: 'Chrono Station status: Zero containment variance detected.',
            textFa: 'وضعیت پایگاه کرونو: هیچ انحراف مهاری شناسایی نشد.',
          },
          {
            id: `sub-${Date.now()}-3`,
            startFrame: 360,
            endFrame: 470,
            textEn: 'You think time flows forward because that is the only way your eyes can process decay.',
            textFa: 'تو فکر می‌کنی زمان رو به جلو حرکت می‌کند، زیرا چشمان تو تنها زوال را پردازش می‌کنند.',
          },
          {
            id: `sub-${Date.now()}-4`,
            startFrame: 500,
            endFrame: 650,
            textEn: 'Proceed to coordinates. The obsidian monolith is synchronizing.',
            textFa: 'به سمت مختصات حرکت کنید. ساختار ابسیدین در حال همگام‌سازی است.',
          },
        ];

        state.subtitles.set(cues);
        state.showSubtitles.set(true);
        if (args['language']) {
          state.subtitleLanguage.set(args['language'] as 'both' | 'fa' | 'en' | 'off');
        }
        return { success: true, data: { subtitleCount: cues.length } };
      },
    });

    // 29. update_subtitles
    this.registry.set('update_subtitles', {
      name: 'update_subtitles',
      category: 'subtitles',
      descriptionEn: 'Update subtitle display mode (both, fa, en, off).',
      descriptionFa: 'تنظیم وضعیت نمایش زیرنویس‌ها (هر دو، فقط فارسی، فقط انگلیسی، خاموش).',
      requiresConfirmation: false,
      validate: (args) => {
        if (!args['mode']) return { valid: false, error: 'Requires "mode" (both/fa/en/off).' };
        return { valid: true };
      },
      execute: async (args, state) => {
        const mode = args['mode'] as 'both' | 'fa' | 'en' | 'off';
        state.subtitleLanguage.set(mode);
        state.showSubtitles.set(mode !== 'off');
        return { success: true, data: { mode } };
      },
    });

    // 30. get_render_settings
    this.registry.set('get_render_settings', {
      name: 'get_render_settings',
      category: 'rendering',
      descriptionEn: 'Get current mastering export codec, color space, and resolution settings.',
      descriptionFa: 'دریافت تنظیمات فعلی خروجی مسترینگ و کدک رندر.',
      requiresConfirmation: false,
      validate: () => ({ valid: true }),
      execute: async (_, state) => {
        return { success: true, data: state.exportSettings() };
      },
    });

    // 31. update_render_settings
    this.registry.set('update_render_settings', {
      name: 'update_render_settings',
      category: 'rendering',
      descriptionEn: 'Update mastering codec (e.g. ProRes 4444 XQ, DCI 4K DCP), color space, or timecode burn-in.',
      descriptionFa: 'تنظیم کدک مسترینگ، فضای رنگ (ACEScc) یا برن‌این تایم‌کد.',
      requiresConfirmation: false,
      validate: () => ({ valid: true }),
      execute: async (args, state) => {
        state.exportSettings.update((curr) => ({
          ...curr,
          codec: (args['codec'] as ExportSettings['codec']) || curr.codec,
          resolution: (args['resolution'] as ExportSettings['resolution']) || curr.resolution,
          colorSpace: (args['colorSpace'] as ExportSettings['colorSpace']) || curr.colorSpace,
          audioFormat: (args['audioFormat'] as ExportSettings['audioFormat']) || curr.audioFormat,
          burnInTimecode: args['burnInTimecode'] !== undefined ? Boolean(args['burnInTimecode']) : curr.burnInTimecode,
        }));
        return { success: true, data: state.exportSettings() };
      },
    });

    // 32. export_video
    this.registry.set('export_video', {
      name: 'export_video',
      category: 'rendering',
      descriptionEn: 'Open export modal and trigger cinema master render pipeline.',
      descriptionFa: 'باز کردن پنجره خروجی و شروع رندر مستر سینمایی.',
      requiresConfirmation: true,
      validate: () => ({ valid: true }),
      execute: async (_, state) => {
        state.isExportModalOpen.set(true);
        state.triggerRender();
        return { success: true, data: { message: 'Master render pipeline dispatched.' } };
      },
    });
  }
}
