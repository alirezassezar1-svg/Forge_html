import { Injectable, signal } from '@angular/core';

interface SpeechRecognitionEvent {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: {
      isFinal?: boolean;
      [index: number]: {
        transcript: string;
      };
    };
  };
}

interface ISpeechRecognition {
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  lang: string;
  start: () => void;
  stop: () => void;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
}

interface WindowWithSpeech {
  SpeechRecognition?: new () => ISpeechRecognition;
  webkitSpeechRecognition?: new () => ISpeechRecognition;
  mozSpeechRecognition?: new () => ISpeechRecognition;
  msSpeechRecognition?: new () => ISpeechRecognition;
}

@Injectable({
  providedIn: 'root',
})
export class VoiceInteractionService {
  readonly isListening = signal<boolean>(false);
  readonly isSpeaking = signal<boolean>(false);
  readonly transcript = signal<string>('');
  readonly isRecognitionSupported = signal<boolean>(false);
  readonly isSynthesisSupported = signal<boolean>(false);
  readonly selectedVoiceLanguage = signal<'fa-IR' | 'en-US'>('fa-IR');

  private recognitionInstance: ISpeechRecognition | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;

  constructor() {
    this.checkBrowserCapabilities();
  }

  private checkBrowserCapabilities(): void {
    if (typeof window === 'undefined') return;

    const win = window as unknown as WindowWithSpeech;
    const SpeechConstructor =
      win.SpeechRecognition ||
      win.webkitSpeechRecognition ||
      win.mozSpeechRecognition ||
      win.msSpeechRecognition;

    if (SpeechConstructor) {
      this.isRecognitionSupported.set(true);
      try {
        this.recognitionInstance = new SpeechConstructor();
        this.recognitionInstance.continuous = false;
        this.recognitionInstance.interimResults = true;
        this.recognitionInstance.maxAlternatives = 1;

        this.recognitionInstance.onresult = (event: SpeechRecognitionEvent) => {
          let current = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            current += event.results[i][0].transcript;
          }
          this.transcript.set(current);
        };

        this.recognitionInstance.onerror = () => {
          this.isListening.set(false);
        };

        this.recognitionInstance.onend = () => {
          this.isListening.set(false);
        };
      } catch {
        this.isRecognitionSupported.set(false);
      }
    }

    if ('speechSynthesis' in window) {
      this.isSynthesisSupported.set(true);
    }
  }

  setVoiceLanguage(lang: 'fa-IR' | 'en-US'): void {
    this.selectedVoiceLanguage.set(lang);
    if (this.recognitionInstance) {
      this.recognitionInstance.lang = lang;
    }
  }

  startListening(onFinalTranscript?: (text: string) => void): void {
    if (!this.isRecognitionSupported() || !this.recognitionInstance) return;

    this.stopSpeaking();
    this.transcript.set('');

    try {
      this.recognitionInstance.lang = this.selectedVoiceLanguage();
      this.recognitionInstance.onresult = (event: SpeechRecognitionEvent) => {
        let text = '';
        let isFinal = false;
        for (let i = event.resultIndex; i < event.results.length; i++) {
          text += event.results[i][0].transcript;
          if (event.results[i].isFinal) isFinal = true;
        }
        this.transcript.set(text);
        if (isFinal && onFinalTranscript && text.trim()) {
          onFinalTranscript(text.trim());
        }
      };

      this.recognitionInstance.start();
      this.isListening.set(true);
    } catch {
      this.isListening.set(false);
    }
  }

  stopListening(): void {
    if (this.recognitionInstance && this.isListening()) {
      try {
        this.recognitionInstance.stop();
      } catch {
        // ignore
      }
      this.isListening.set(false);
    }
  }

  speak(text: string, forceLang?: 'fa-IR' | 'en-US'): void {
    if (!this.isSynthesisSupported() || typeof window === 'undefined') return;

    this.stopSpeaking();

    try {
      const utterance = new SpeechSynthesisUtterance(text);
      const isPersianText = /[\u0600-\u06FF]/.test(text);
      const targetLang = forceLang || (isPersianText ? 'fa-IR' : 'en-US');
      utterance.lang = targetLang;
      utterance.rate = 1.0;
      utterance.pitch = 1.0;

      const voices = window.speechSynthesis.getVoices();
      if (voices && voices.length > 0) {
        const matched = voices.find((v) => v.lang.startsWith(targetLang.split('-')[0]));
        if (matched) utterance.voice = matched;
      }

      utterance.onstart = () => this.isSpeaking.set(true);
      utterance.onend = () => this.isSpeaking.set(false);
      utterance.onerror = () => this.isSpeaking.set(false);

      this.currentUtterance = utterance;
      window.speechSynthesis.speak(utterance);
    } catch {
      this.isSpeaking.set(false);
    }
  }

  stopSpeaking(): void {
    if (this.isSynthesisSupported() && typeof window !== 'undefined') {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // ignore
      }
      this.isSpeaking.set(false);
    }
  }
}
