import { ChangeDetectionStrategy, Component, HostListener, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StudioState } from './services/studio.state';
import { TopBar } from './components/top-bar';
import { PreviewMonitor } from './components/preview-monitor';
import { TimelineEditor } from './components/timeline-editor';
import { StoryboardView } from './components/storyboard-view';
import { ScreenplayEditor } from './components/screenplay-editor';
import { AudioMixer } from './components/audio-mixer';
import { SceneSidebar } from './components/scene-sidebar';
import { ExportModal } from './components/export-modal';
import { VoidAIAssistant } from './components/void-ai-assistant';
import { PwaBar } from './components/pwa-bar';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    MatIconModule,
    TopBar,
    PreviewMonitor,
    TimelineEditor,
    StoryboardView,
    ScreenplayEditor,
    AudioMixer,
    SceneSidebar,
    ExportModal,
    VoidAIAssistant,
    PwaBar,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly state = inject(StudioState);

  constructor() {
    // PWA shortcut: ?open=ai opens the VOID AI drawer directly
    if (typeof location !== 'undefined' && new URLSearchParams(location.search).get('open') === 'ai') {
      this.state.isAIAssistantOpen.set(true);
    }
  }

  @HostListener('window:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent): void {
    // Prevent intercepting when typing in inputs/textareas
    const target = event.target as HTMLElement;
    if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
      return;
    }

    if (event.code === 'Space') {
      event.preventDefault();
      this.state.togglePlay();
    } else if (event.code === 'ArrowLeft') {
      event.preventDefault();
      this.state.stepFrame(-1);
    } else if (event.code === 'ArrowRight') {
      event.preventDefault();
      this.state.stepFrame(1);
    } else if (event.code === 'Home') {
      event.preventDefault();
      this.state.jumpToIn();
    } else if (event.code === 'End') {
      event.preventDefault();
      this.state.jumpToOut();
    }
  }
}
