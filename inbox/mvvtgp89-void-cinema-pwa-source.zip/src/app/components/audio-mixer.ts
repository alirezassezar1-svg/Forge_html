import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StudioState } from '../services/studio.state';
import { AudioChannel } from '../models/studio.model';

@Component({
  selector: 'app-audio-mixer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex flex-col bg-[#050608] border border-[#151C26] rounded-xl overflow-hidden shadow-[0_8px_32px_rgba(0,0,0,0.95)]">
      <!-- Mixer Header Bar -->
      <div class="flex items-center justify-between px-4 py-2.5 bg-[#000000] border-b border-[#151C26] text-xs font-mono-code select-none">
        <div class="flex items-center gap-3">
          <mat-icon class="text-base leading-none text-[#55C8FF]">graphic_eq</mat-icon>
          <span class="font-semibold text-[#A8DFFF] tracking-wider uppercase">CINEMA 5.1 D-MIT CONSOLE</span>
          <span class="text-[#739AB8]">· 24-BIT / 48.0 KHZ LINEAR PCM</span>
        </div>

        <div class="flex items-center gap-3">
          <div class="flex items-center gap-1.5 text-[11px] text-[#739AB8]">
            <span class="w-2 h-2 rounded-full bg-[#55C8FF] shadow-[0_0_6px_#55C8FF]"></span>
            <span>DOLBY ATMOS BUS: ENGAGED</span>
          </div>

          <button
            type="button"
            (click)="resetPeaks()"
            class="px-2.5 py-1 bg-[#090D12] border border-[#151C26] hover:border-[#55C8FF]/40 text-[#B9E5FF] rounded text-[11px] transition-all"
          >
            RESET PEAKS
          </button>
        </div>
      </div>

      <!-- Channel Strips Container -->
      <div class="p-4 md:p-6 bg-[#000000] overflow-x-auto flex items-stretch justify-center gap-3 md:gap-4 select-none">
        @for (channel of state.audioChannels(); track channel.id) {
          <div
            class="flex flex-col w-36 md:w-44 bg-[#050608] border rounded-xl p-3 shrink-0 transition-all font-mono-code"
            [class]="channel.type === 'master'
              ? 'border-[#55C8FF]/60 shadow-[0_0_16px_rgba(85,200,255,0.18)] bg-[#090D12]/40'
              : 'border-[#151C26] hover:border-[#55C8FF]/30'"
          >
            <!-- Channel Title & Type -->
            <div class="flex items-center justify-between pb-2 border-b border-[#151C26] mb-3">
              <span class="text-xs font-bold text-[#B9E5FF] truncate">{{ channel.name }}</span>
              <span class="text-[9px] uppercase px-1 py-0.5 rounded border border-[#151C26] text-[#739AB8]">
                {{ channel.type }}
              </span>
            </div>

            <!-- Pan Control Knob/Slider -->
            <div class="flex flex-col gap-1 mb-4">
              <div class="flex items-center justify-between text-[10px] text-[#739AB8]">
                <span>PAN</span>
                <span class="text-[#55C8FF]">
                  {{ channel.pan === 0 ? 'C' : (channel.pan < 0 ? 'L' + Math.abs(channel.pan) : 'R' + channel.pan) }}
                </span>
              </div>
              <input
                type="range"
                min="-50"
                max="50"
                [value]="channel.pan"
                (input)="onPanChange(channel.id, $event)"
                class="w-full"
              />
            </div>

            <!-- Fader + VU Meter Pair -->
            <div class="flex items-center justify-center gap-3 flex-1 min-h-[220px] py-2">
              <!-- Animated LED VU Meter Bar (Strict pure black & pale ice blue/cyan LEDs) -->
              <div class="flex flex-col items-center gap-0.5 w-4 h-48 bg-[#000000] border border-[#151C26] rounded p-0.5">
                @for (seg of vuSegments; track $index) {
                  <div
                    class="w-full h-2 rounded-[1px] transition-all duration-75"
                    [class]="isSegmentLit(channel, seg.threshold)
                      ? (seg.isPeak ? 'bg-[#55C8FF] shadow-[0_0_6px_#55C8FF]' : 'bg-[#A8DFFF]/80 shadow-[0_0_4px_rgba(168,223,255,0.4)]')
                      : 'bg-[#151C26]/40'"
                  ></div>
                }
              </div>

              <!-- Fader DB Scale -->
              <div class="flex flex-col justify-between h-48 text-[9px] text-[#739AB8] py-1 select-none">
                <span>+6</span>
                <span>0</span>
                <span>-6</span>
                <span>-12</span>
                <span>-24</span>
                <span>-48</span>
                <span>-∞</span>
              </div>

              <!-- Vertical dB Fader Slider -->
              <div class="h-48 flex items-center justify-center">
                <input
                  type="range"
                  min="-60"
                  max="6"
                  step="0.5"
                  [value]="channel.volumeDb"
                  (input)="onFaderChange(channel.id, $event)"
                  class="h-44 -rotate-90 origin-center cursor-pointer"
                  style="width: 176px;"
                />
              </div>
            </div>

            <!-- Readout Level dB -->
            <div class="text-center py-1.5 my-2 bg-[#000000] border border-[#151C26] rounded text-xs font-bold text-[#A8DFFF]">
              {{ channel.volumeDb > 0 ? '+' : '' }}{{ channel.volumeDb.toFixed(1) }} dB
            </div>

            <!-- Mute & Solo Buttons -->
            <div class="grid grid-cols-2 gap-1.5 pt-2 border-t border-[#151C26]">
              <button
                type="button"
                (click)="state.toggleChannelMute(channel.id)"
                [class]="channel.isMuted
                  ? 'bg-[#55C8FF]/20 text-[#55C8FF] border border-[#55C8FF] shadow-[0_0_8px_rgba(85,200,255,0.3)]'
                  : 'bg-[#000000] text-[#739AB8] hover:text-[#B9E5FF] border border-[#151C26]'"
                class="py-1 text-xs font-bold rounded transition-all"
              >
                MUTE
              </button>
              <button
                type="button"
                (click)="state.toggleChannelSolo(channel.id)"
                [class]="channel.isSolo
                  ? 'bg-[#55C8FF]/20 text-[#55C8FF] border border-[#55C8FF] shadow-[0_0_8px_rgba(85,200,255,0.3)]'
                  : 'bg-[#000000] text-[#739AB8] hover:text-[#B9E5FF] border border-[#151C26]'"
                class="py-1 text-xs font-bold rounded transition-all"
              >
                SOLO
              </button>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class AudioMixer {
  readonly state = inject(StudioState);
  readonly Math = Math;

  readonly vuSegments = [
    { threshold: 0.92, isPeak: true },
    { threshold: 0.82, isPeak: true },
    { threshold: 0.72, isPeak: false },
    { threshold: 0.62, isPeak: false },
    { threshold: 0.52, isPeak: false },
    { threshold: 0.42, isPeak: false },
    { threshold: 0.32, isPeak: false },
    { threshold: 0.22, isPeak: false },
    { threshold: 0.12, isPeak: false },
    { threshold: 0.05, isPeak: false },
  ];

  isSegmentLit(channel: AudioChannel, threshold: number): boolean {
    return channel.peakLevel >= threshold;
  }

  onFaderChange(id: string, event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.setChannelVolume(id, val);
  }

  onPanChange(id: string, event: Event): void {
    const val = Number((event.target as HTMLInputElement).value);
    this.state.setChannelPan(id, val);
  }

  resetPeaks(): void {
    // Reset momentary indicators
    this.state.audioChannels.update((channels) =>
      channels.map((ch) => ({ ...ch, peakLevel: 0.1 }))
    );
  }
}
