import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StudioState } from '../services/studio.state';

@Component({
  selector: 'app-scene-sidebar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex flex-col gap-4 font-mono-code text-xs select-none">
      <!-- Active Shot Inspector Card -->
      <div class="flex flex-col bg-[#050608] border border-[#151C26] rounded-xl overflow-hidden p-4 shadow-[0_4px_24px_rgba(0,0,0,0.9)]">
        <div class="flex items-center justify-between pb-2 border-b border-[#151C26] mb-3">
          <span class="text-xs font-bold text-[#A8DFFF] flex items-center gap-1.5 uppercase">
            <mat-icon class="text-sm leading-none text-[#55C8FF]">videocam</mat-icon>
            ACTIVE OPTIC & SENSOR
          </span>
          <span class="text-[10px] text-[#55C8FF] bg-[#090D12] px-2 py-0.5 rounded border border-[#151C26]">
            {{ state.selectedShot().shotCode }}
          </span>
        </div>

        <!-- Shot Detail Rows -->
        <div class="flex flex-col gap-2.5">
          <div class="flex justify-between items-center text-[11px]">
            <span class="text-[#739AB8]">PRIMARY OPTIC</span>
            <span class="text-[#B9E5FF] font-semibold text-right truncate max-w-[170px]" [title]="state.selectedShot().camera.lens">
              {{ state.selectedShot().camera.lens }}
            </span>
          </div>

          <div class="flex justify-between items-center text-[11px]">
            <span class="text-[#739AB8]">T-STOP / SHUTTER</span>
            <span class="text-[#55C8FF] font-semibold">
              {{ state.selectedShot().camera.aperture }} · {{ state.selectedShot().camera.shutterAngle }}
            </span>
          </div>

          <div class="flex justify-between items-center text-[11px]">
            <span class="text-[#739AB8]">CAPTURE SENSOR</span>
            <span class="text-[#B9E5FF] truncate max-w-[170px]">
              {{ state.selectedShot().camera.sensor }}
            </span>
          </div>

          <div class="flex justify-between items-center text-[11px]">
            <span class="text-[#739AB8]">CAMERA RIG</span>
            <span class="text-[#A8DFFF] truncate max-w-[170px]">
              {{ state.selectedShot().camera.movement }}
            </span>
          </div>

          <div class="flex justify-between items-center text-[11px]">
            <span class="text-[#739AB8]">GRADE STATUS</span>
            <span class="text-[#55C8FF] font-semibold">
              {{ state.selectedShot().status }}
            </span>
          </div>
        </div>

        <!-- Director Lighting Field -->
        <div class="mt-3 pt-3 border-t border-[#151C26] flex flex-col gap-1">
          <span class="text-[10px] text-[#739AB8]">LIGHTING SCHEMATIC</span>
          <p class="text-[11px] text-[#B9E5FF] leading-relaxed font-sans">
            {{ state.selectedShot().lightingSetup }}
          </p>
        </div>
      </div>

      <!-- Scene Hierarchy & Reel Navigation -->
      <div class="flex flex-col bg-[#050608] border border-[#151C26] rounded-xl overflow-hidden p-4 shadow-[0_4px_24px_rgba(0,0,0,0.9)]">
        <div class="flex items-center justify-between pb-2 border-b border-[#151C26] mb-3">
          <span class="text-xs font-bold text-[#A8DFFF] flex items-center gap-1.5 uppercase">
            <mat-icon class="text-sm leading-none text-[#55C8FF]">movie</mat-icon>
            SCENE BREAKDOWN
          </span>
          <span class="text-[10px] text-[#739AB8]">REEL 02</span>
        </div>

        <div class="flex flex-col gap-2">
          @for (scene of state.scenes(); track scene.id) {
            <button
              type="button"
              (click)="jumpToScene(scene.number)"
              class="w-full text-left p-2.5 bg-[#000000] border border-[#151C26] hover:border-[#55C8FF]/50 rounded-lg cursor-pointer transition-all flex flex-col gap-1 focus-visible:border-[#55C8FF] outline-none"
            >
              <div class="flex items-center justify-between text-[10px]">
                <span class="text-[#55C8FF] font-bold">SCENE {{ scene.number }}</span>
                <span class="text-[#739AB8]">{{ scene.timeOfDay }} · {{ scene.status }}</span>
              </div>
              <span class="text-xs font-semibold text-[#B9E5FF] truncate">{{ scene.slugline }}</span>
              <span class="text-[10px] text-[#739AB8] line-clamp-1 font-sans">{{ scene.summary }}</span>
            </button>
          }
        </div>
      </div>

      <!-- Quick Shot Strip Reel -->
      <div class="flex flex-col bg-[#050608] border border-[#151C26] rounded-xl overflow-hidden p-4 shadow-[0_4px_24px_rgba(0,0,0,0.9)]">
        <div class="flex items-center justify-between pb-2 border-b border-[#151C26] mb-3">
          <span class="text-xs font-bold text-[#A8DFFF] flex items-center gap-1.5 uppercase">
            <mat-icon class="text-sm leading-none text-[#55C8FF]">auto_awesome_motion</mat-icon>
            SHOT REEL QUEUE
          </span>
          <span class="text-[10px] text-[#739AB8]">{{ state.shots().length }} SHOTS</span>
        </div>

        <div class="grid grid-cols-2 gap-2">
          @for (shot of state.shots(); track shot.id) {
            <button
              type="button"
              (click)="state.selectShot(shot.id)"
              class="w-full text-left relative rounded-lg overflow-hidden border cursor-pointer group aspect-[16/9] transition-all focus-visible:border-[#55C8FF] outline-none"
              [class]="state.activeShotId() === shot.id
                ? 'border-[#55C8FF] shadow-[0_0_12px_rgba(85,200,255,0.35)]'
                : 'border-[#151C26] hover:border-[#55C8FF]/40'"
            >
              <img
                [src]="shot.imageSrc"
                [alt]="shot.title"
                referrerpolicy="no-referrer"
                class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div class="absolute inset-x-0 bottom-0 bg-[#000000]/80 px-1.5 py-0.5 text-[9px] text-[#B9E5FF] truncate">
                {{ shot.shotCode }}
              </div>
            </button>
          }
        </div>
      </div>
    </div>
  `,
})
export class SceneSidebar {
  readonly state = inject(StudioState);

  jumpToScene(sceneNum: number): void {
    if (sceneNum === 14) {
      this.state.selectShot('shot-1');
    } else if (sceneNum === 15) {
      this.state.selectShot('shot-3');
    } else {
      this.state.selectShot('shot-4');
    }
  }
}
