import { ChangeDetectionStrategy, Component, ElementRef, ViewChild, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { VoidAIService } from '../services/void-ai.service';
import { StudioState } from '../services/studio.state';
import { VoiceInteractionService } from '../services/voice-interaction.service';

@Component({
  selector: 'app-void-ai-assistant',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    @if (state.isAIAssistantOpen()) {
      <!-- Backdrop for mobile -->
      <button
        type="button"
        aria-label="Close assistant overlay"
        class="fixed inset-0 bg-[#000000]/80 backdrop-blur-sm z-40 lg:hidden cursor-default border-none p-0"
        (click)="state.isAIAssistantOpen.set(false)"
      ></button>

      <!-- Main Assistant Drawer / Panel -->
      <aside
        class="fixed top-0 bottom-0 right-0 w-full sm:w-[460px] lg:w-[480px] bg-[#030507] border-l border-[#151C26] shadow-[0_0_50px_rgba(0,0,0,0.95)] z-50 flex flex-col font-mono-code select-none overflow-hidden"
      >
        <!-- Panel Header -->
        <div class="px-4 py-3 bg-[#000000] border-b border-[#151C26] flex items-center justify-between shrink-0">
          <div class="flex items-center gap-2.5">
            <div class="relative flex items-center justify-center">
              <span class="w-2.5 h-2.5 rounded-full bg-[#55C8FF] shadow-[0_0_10px_#55C8FF]"></span>
              <span class="absolute w-4 h-4 rounded-full border border-[#55C8FF]/40 animate-ping"></span>
            </div>
            <div class="flex flex-col">
              <span class="text-xs font-bold tracking-wider text-[#A8DFFF] uppercase">
                VOID AI <span class="text-[#739AB8] font-normal">// STUDIO AGENT</span>
              </span>
              <span class="text-[9px] text-[#739AB8] uppercase">
                Mode: Assistant (Human-In-The-Loop)
              </span>
            </div>
          </div>

          <!-- Controls: Language, TTS & Close -->
          <div class="flex items-center gap-1.5">
            <!-- Language Quick Selector -->
            <button
              type="button"
              (click)="toggleLanguagePref()"
              class="px-2 py-0.5 rounded text-[10px] bg-[#090D12] border border-[#151C26] text-[#B9E5FF] hover:border-[#55C8FF]/40 transition-colors"
              title="Voice Recognition Language"
            >
              {{ voice.selectedVoiceLanguage() === 'fa-IR' ? 'فا (FA)' : 'EN (US)' }}
            </button>

            <!-- TTS Speaker Mute Toggle -->
            <button
              type="button"
              (click)="ai.isSpeakingEnabled.set(!ai.isSpeakingEnabled())"
              [class]="ai.isSpeakingEnabled() ? 'text-[#55C8FF] bg-[#090D12] border border-[#55C8FF]/40' : 'text-[#739AB8] border border-transparent'"
              class="p-1 rounded transition-colors"
              title="Toggle Voice Feedback"
            >
              <mat-icon class="text-sm leading-none">{{ ai.isSpeakingEnabled() ? 'volume_up' : 'volume_off' }}</mat-icon>
            </button>

            <!-- Clear History -->
            <button
              type="button"
              (click)="ai.clearHistory()"
              class="p-1 text-[#739AB8] hover:text-[#B9E5FF] rounded transition-colors"
              title="Clear Conversation"
            >
              <mat-icon class="text-sm leading-none">delete_sweep</mat-icon>
            </button>

            <!-- Close Drawer -->
            <button
              type="button"
              (click)="state.isAIAssistantOpen.set(false)"
              class="p-1 text-[#739AB8] hover:text-[#B9E5FF] rounded transition-colors"
              title="Close VOID AI Drawer"
            >
              <mat-icon class="text-base leading-none">close</mat-icon>
            </button>
          </div>
        </div>

        <!-- Chat Transcript Message Area -->
        <div #scrollContainer class="flex-1 p-4 overflow-y-auto flex flex-col gap-3.5 bg-[#030507]">
          @for (msg of ai.messages(); track msg.id) {
            <div
              class="flex flex-col gap-1 max-w-[92%]"
              [class]="msg.role === 'user' ? 'self-end items-end' : 'self-start items-start'"
            >
              <!-- Role & Timestamp header -->
              <div class="flex items-center gap-1.5 text-[9px] text-[#739AB8] px-1">
                @if (msg.role === 'user') {
                  <span>DIRECTOR</span>
                  <span aria-hidden="true">·</span>
                  <span>{{ msg.timestamp }}</span>
                } @else {
                  <span class="text-[#55C8FF] font-semibold">VOID AI</span>
                  <span aria-hidden="true">·</span>
                  <span>{{ msg.timestamp }}</span>
                }
              </div>

              <!-- Message Bubble -->
              <div
                class="p-3 rounded-xl border text-xs leading-relaxed"
                [class]="msg.role === 'user'
                  ? 'bg-[#090D12] border-[#55C8FF]/30 text-[#B9E5FF] rounded-tr-none'
                  : 'bg-[#050608] border-[#151C26] text-[#B9E5FF] rounded-tl-none shadow-[0_4px_16px_rgba(0,0,0,0.8)]'"
                [dir]="msg.language === 'fa' ? 'rtl' : 'ltr'"
              >
                <div class="whitespace-pre-wrap font-sans text-xs select-text">{{ msg.content }}</div>

                <!-- Plan Approval Card if attached -->
                @if (msg.plan; as plan) {
                  <div class="mt-3 pt-3 border-t border-[#151C26] flex flex-col gap-2.5 font-mono-code text-[11px]" dir="ltr">
                    <div class="flex items-center justify-between text-[#739AB8] pb-1 border-b border-[#151C26]/40">
                      <span class="text-[#55C8FF] font-bold text-[10px] uppercase flex items-center gap-1">
                        <mat-icon class="text-xs leading-none">playlist_play</mat-icon>
                        EXECUTION PLAN ({{ plan.actions.length }} ACTIONS)
                      </span>
                      <span class="text-[10px] uppercase text-[#A8DFFF]">{{ plan.status }}</span>
                    </div>

                    <!-- Summary in Persian and English -->
                    <div class="flex flex-col gap-1 p-2 bg-[#000000] rounded-lg border border-[#151C26]">
                      <div class="text-[10px] text-[#B9E5FF]">{{ plan.summaryEn }}</div>
                      <div class="text-[10px] text-[#739AB8] font-sans" dir="rtl">{{ plan.summaryFa }}</div>
                    </div>

                    <!-- Actions Checklist -->
                    <div class="flex flex-col gap-1.5 my-1">
                      @for (act of plan.actions; track act.id) {
                        <div
                          class="p-2 rounded bg-[#090D12] border transition-colors flex items-start justify-between gap-2"
                          [class]="act.status === 'success'
                            ? 'border-[#55C8FF]/60 bg-[#050608]'
                            : (act.status === 'executing'
                              ? 'border-[#55C8FF] shadow-[0_0_10px_rgba(85,200,255,0.3)]'
                              : (act.status === 'failed'
                                ? 'border-[#55C8FF]/40 text-[#55C8FF]'
                                : 'border-[#151C26]'))"
                        >
                          <div class="flex flex-col gap-0.5 truncate flex-1">
                            <div class="flex items-center gap-1.5">
                              <span class="text-[9px] font-bold text-[#55C8FF] bg-[#000000] px-1 rounded border border-[#151C26]">
                                {{ act.tool }}
                              </span>
                              @if (act.requiresConfirmation) {
                                <span class="text-[8px] text-[#739AB8] border border-[#151C26] px-1 rounded">APPROVAL REQUIRED</span>
                              }
                            </div>
                            <span class="text-[10px] text-[#B9E5FF] truncate">{{ act.descriptionEn }}</span>
                            <span class="text-[9px] text-[#739AB8] font-sans truncate" dir="rtl">{{ act.descriptionFa }}</span>
                          </div>

                          <!-- Action status icon -->
                          <div class="shrink-0 flex items-center justify-center w-5 h-5">
                            @switch (act.status) {
                              @case ('pending') {
                                <mat-icon class="text-xs text-[#739AB8]">hourglass_empty</mat-icon>
                              }
                              @case ('executing') {
                                <span class="w-3 h-3 rounded-full border-2 border-[#55C8FF] border-t-transparent animate-spin"></span>
                              }
                              @case ('success') {
                                <mat-icon class="text-xs text-[#55C8FF]">check_circle</mat-icon>
                              }
                              @case ('failed') {
                                <mat-icon class="text-xs text-[#55C8FF]">error_outline</mat-icon>
                              }
                              @case ('cancelled') {
                                <mat-icon class="text-xs text-[#739AB8]">block</mat-icon>
                              }
                            }
                          </div>
                        </div>
                      }
                    </div>

                    <!-- Plan Action Buttons (Human-in-the-loop) -->
                    @if (plan.status === 'awaiting_approval') {
                      <div class="flex items-center gap-2 pt-1">
                        <button
                          type="button"
                          (click)="ai.approveAndExecute(plan)"
                          class="flex-1 py-1.5 px-3 bg-[#000000] border border-[#55C8FF] text-[#B9E5FF] hover:shadow-[0_0_14px_rgba(85,200,255,0.4)] active:scale-95 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5"
                        >
                          <mat-icon class="text-xs leading-none text-[#55C8FF]">check</mat-icon>
                          <span>تایید و اجرا / Approve</span>
                        </button>

                        <button
                          type="button"
                          (click)="ai.cancelPlan(plan)"
                          class="py-1.5 px-3 bg-[#000000] border border-[#151C26] hover:border-[#55C8FF]/40 text-[#739AB8] hover:text-[#B9E5FF] rounded-lg text-xs transition-colors"
                        >
                          لغو / Cancel
                        </button>
                      </div>
                    } @else if (plan.status === 'executing') {
                      <div class="flex items-center justify-between text-[10px] text-[#55C8FF] py-1">
                        <span class="flex items-center gap-1.5">
                          <span class="w-2 h-2 rounded-full bg-[#55C8FF] animate-pulse"></span>
                          Executing operations sequentially...
                        </span>
                        <button
                          type="button"
                          (click)="ai.cancelPlan(plan)"
                          class="text-[#739AB8] hover:text-[#B9E5FF] underline text-[9px]"
                        >
                          Stop Execution
                        </button>
                      </div>
                    }
                  </div>
                }
              </div>
            </div>
          }

          <!-- Live Voice Recognition Preview Bar -->
          @if (voice.isListening()) {
            <div class="p-2.5 rounded-lg bg-[#000000] border border-[#55C8FF] shadow-[0_0_14px_rgba(85,200,255,0.25)] flex items-center gap-2.5">
              <span class="w-2 h-2 rounded-full bg-[#55C8FF] animate-ping"></span>
              <div class="flex flex-col truncate flex-1">
                <span class="text-[9px] text-[#55C8FF] uppercase">
                  Listening ({{ voice.selectedVoiceLanguage() === 'fa-IR' ? 'فارسی' : 'English' }})...
                </span>
                <span class="text-xs text-[#B9E5FF] truncate font-sans">
                  {{ voice.transcript() || 'Speak now...' }}
                </span>
              </div>
              <button
                type="button"
                (click)="stopVoiceAndSubmit()"
                class="px-2 py-1 bg-[#050608] border border-[#55C8FF] text-[10px] text-[#B9E5FF] rounded"
              >
                Send
              </button>
            </div>
          }

          <!-- Processing Thinking Bubble -->
          @if (ai.isProcessing()) {
            <div class="self-start p-3 bg-[#050608] border border-[#151C26] rounded-xl rounded-tl-none flex items-center gap-2 text-xs text-[#739AB8]">
              <span class="w-3 h-3 rounded-full border-2 border-[#55C8FF] border-t-transparent animate-spin"></span>
              <span>VOID AI analyzing studio state and formulating plan...</span>
            </div>
          }
        </div>

        <!-- Quick Cinematic Command Prompts (Bilingual) -->
        <div class="px-3 py-2 bg-[#000000] border-t border-[#151C26] overflow-x-auto flex items-center gap-1.5 shrink-0 select-none">
          @for (cmd of quickCommands; track cmd.text) {
            <button
              type="button"
              (click)="sendQuickCommand(cmd.text)"
              class="px-2.5 py-1 rounded bg-[#050608] border border-[#151C26] hover:border-[#55C8FF]/50 text-[#739AB8] hover:text-[#B9E5FF] text-[10px] whitespace-nowrap shrink-0 transition-colors"
            >
              {{ cmd.label }}
            </button>
          }
        </div>

        <!-- Input Footer Bar -->
        <div class="p-3 bg-[#000000] border-t border-[#151C26] flex items-center gap-2 shrink-0">
          <!-- Voice Record Mic Button -->
          <button
            type="button"
            (click)="toggleVoiceInput()"
            [class]="voice.isListening()
              ? 'bg-[#55C8FF] text-[#000000] shadow-[0_0_16px_#55C8FF]'
              : 'bg-[#050608] text-[#739AB8] hover:text-[#B9E5FF] border border-[#151C26] hover:border-[#55C8FF]/40'"
            class="p-2 rounded-xl transition-all flex items-center justify-center shrink-0"
            [title]="voice.isListening() ? 'Stop listening' : 'Start voice input (Bilingual)'"
          >
            <mat-icon class="text-base leading-none">mic</mat-icon>
          </button>

          <!-- Text Input Field -->
          <input
            #textInput
            type="text"
            [value]="inputText()"
            (input)="inputText.set(textInput.value)"
            (keydown.enter)="submitText()"
            placeholder="دستور به فارسی یا English (e.g. زیرنویس اضافه کن)..."
            class="flex-1 bg-[#050608] border border-[#151C26] focus:border-[#55C8FF] focus:shadow-[0_0_10px_rgba(85,200,255,0.2)] text-[#B9E5FF] text-xs rounded-xl px-3 py-2 outline-none transition-all placeholder:text-[#739AB8]/60 font-sans"
          />

          <!-- Send Button -->
          <button
            type="button"
            (click)="submitText()"
            [disabled]="!inputText().trim() || ai.isProcessing()"
            class="p-2 bg-[#000000] border border-[#55C8FF]/60 hover:border-[#55C8FF] text-[#B9E5FF] hover:shadow-[0_0_12px_rgba(85,200,255,0.3)] disabled:opacity-40 rounded-xl transition-all flex items-center justify-center shrink-0"
            title="Send Instruction"
          >
            <mat-icon class="text-base leading-none text-[#55C8FF]">send</mat-icon>
          </button>
        </div>
      </aside>
    }
  `,
})
export class VoidAIAssistant {
  readonly state = inject(StudioState);
  readonly ai = inject(VoidAIService);
  readonly voice = inject(VoiceInteractionService);

  readonly inputText = signal<string>('');
  @ViewChild('scrollContainer') scrollContainerRef?: ElementRef<HTMLDivElement>;

  readonly quickCommands = [
    { label: 'تقسیم داستان به ۶ صحنه', text: 'این داستان رو به ۶ صحنه سینمایی تبدیل کن' },
    { label: 'سینمایی‌تر کردن صحنه ۳', text: 'صحنه سوم رو سینماییتر کن و نورپردازی نئون فیروزه‌ای اضافه کن' },
    { label: 'تولید زیرنویس فارسی', text: 'زیرنویس فارسی و انگلیسی برای فیلم اضافه کن' },
    { label: 'تنظیم خروجی ProRes', text: 'پایپ‌لاین خروجی رو روی Apple ProRes 4444 XQ تنظیم کن' },
    { label: 'تراز صوتی دیالوگ و موسیقی', text: 'موسیقی رو با ریتم فیلم هماهنگ کن و صدای دیالوگ رو بالانس کن' },
    { label: 'ذخیره پروژه', text: 'پروژه رو در حافظه مرورگر ذخیره کن' },
  ];

  toggleLanguagePref(): void {
    const current = this.voice.selectedVoiceLanguage();
    this.voice.setVoiceLanguage(current === 'fa-IR' ? 'en-US' : 'fa-IR');
  }

  toggleVoiceInput(): void {
    if (this.voice.isListening()) {
      this.stopVoiceAndSubmit();
    } else {
      this.voice.startListening((transcript) => {
        this.inputText.set(transcript);
        this.submitText();
      });
    }
  }

  stopVoiceAndSubmit(): void {
    const transcript = this.voice.transcript();
    this.voice.stopListening();
    if (transcript.trim()) {
      this.inputText.set(transcript.trim());
      this.submitText();
    }
  }

  submitText(): void {
    const text = this.inputText().trim();
    if (!text) return;
    this.inputText.set('');
    this.ai.sendMessage(text);
    setTimeout(() => this.scrollToBottom(), 100);
  }

  sendQuickCommand(cmd: string): void {
    this.ai.sendMessage(cmd);
    setTimeout(() => this.scrollToBottom(), 100);
  }

  private scrollToBottom(): void {
    if (this.scrollContainerRef) {
      const el = this.scrollContainerRef.nativeElement;
      el.scrollTop = el.scrollHeight;
    }
  }
}
