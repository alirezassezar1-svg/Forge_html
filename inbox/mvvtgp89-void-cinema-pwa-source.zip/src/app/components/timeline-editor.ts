import { ChangeDetectionStrategy, Component, ElementRef, ViewChild, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StudioState } from '../services/studio.state';
import { TimelineClip } from '../models/studio.model';

@Component({
  selector: 'app-timeline-editor',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex flex-col bg-[#050608] border border-[#151C26] rounded-xl overflow-hidden shadow-[0_8px_32px_rgba(0,0,0,0.95)]">
      <!-- Timeline Header / Toolbar -->
      <div class="flex items-center justify-between px-4 py-2 bg-[#000000] border-b border-[#151C26] text-xs font-mono-code select-none">
        <!-- Left: Tool Palette -->
        <div class="flex items-center gap-1">
          <button
            type="button"
            (click)="state.selectedTool.set('select')"
            [class]="state.selectedTool() === 'select' ? 'bg-[#090D12] text-[#55C8FF] border border-[#55C8FF]/50 shadow-[0_0_8px_rgba(85,200,255,0.2)]' : 'text-[#739AB8] hover:text-[#B9E5FF] border border-transparent'"
            class="px-2.5 py-1 rounded text-xs flex items-center gap-1 transition-all"
            title="Selection Tool (V)"
          >
            <mat-icon class="text-sm leading-none">near_me</mat-icon>
            <span class="hidden sm:inline">SELECT</span>
          </button>

          <button
            type="button"
            (click)="state.selectedTool.set('blade')"
            [class]="state.selectedTool() === 'blade' ? 'bg-[#090D12] text-[#55C8FF] border border-[#55C8FF]/50 shadow-[0_0_8px_rgba(85,200,255,0.2)]' : 'text-[#739AB8] hover:text-[#B9E5FF] border border-transparent'"
            class="px-2.5 py-1 rounded text-xs flex items-center gap-1 transition-all"
            title="Razor Blade Tool (C)"
          >
            <mat-icon class="text-sm leading-none">content_cut</mat-icon>
            <span class="hidden sm:inline">RAZOR</span>
          </button>

          <button
            type="button"
            (click)="state.selectedTool.set('ripple')"
            [class]="state.selectedTool() === 'ripple' ? 'bg-[#090D12] text-[#55C8FF] border border-[#55C8FF]/50 shadow-[0_0_8px_rgba(85,200,255,0.2)]' : 'text-[#739AB8] hover:text-[#B9E5FF] border border-transparent'"
            class="px-2.5 py-1 rounded text-xs flex items-center gap-1 transition-all"
            title="Ripple Edit Tool (B)"
          >
            <mat-icon class="text-sm leading-none">sync_alt</mat-icon>
            <span class="hidden sm:inline">RIPPLE</span>
          </button>

          <div class="h-4 w-[1px] bg-[#151C26] mx-1"></div>

          <!-- Snapping Toggle -->
          <button
            type="button"
            (click)="state.isSnappingEnabled.set(!state.isSnappingEnabled())"
            [class]="state.isSnappingEnabled() ? 'text-[#55C8FF] bg-[#090D12] border border-[#55C8FF]/40' : 'text-[#739AB8] border border-transparent'"
            class="px-2 py-1 rounded flex items-center gap-1 transition-all"
            title="Magnetic Snapping (S)"
          >
            <mat-icon class="text-sm leading-none">vertical_align_center</mat-icon>
            <span class="hidden md:inline">SNAP</span>
          </button>
        </div>

        <!-- Center: Playhead Position Timecode -->
        <div class="flex items-center gap-2">
          <span class="text-[#739AB8] hidden md:inline">PLAYHEAD:</span>
          <span class="text-[#B9E5FF] font-semibold tracking-wider text-glow-cyan">{{ state.formattedTimecode() }}</span>
          <span class="text-[#739AB8] hidden lg:inline">(@ {{ state.fps() }} FPS)</span>
        </div>

        <!-- Right: Zoom Controls -->
        <div class="flex items-center gap-2">
          <button
            type="button"
            (click)="adjustZoom(-0.2)"
            class="p-1 text-[#739AB8] hover:text-[#B9E5FF] hover:bg-[#090D12] rounded transition-colors"
            title="Zoom Out"
          >
            <mat-icon class="text-sm leading-none">zoom_out</mat-icon>
          </button>
          <span class="text-[11px] text-[#739AB8] w-12 text-center">{{ Math.round(state.timelineZoom() * 100) }}%</span>
          <button
            type="button"
            (click)="adjustZoom(0.2)"
            class="p-1 text-[#739AB8] hover:text-[#B9E5FF] hover:bg-[#090D12] rounded transition-colors"
            title="Zoom In"
          >
            <mat-icon class="text-sm leading-none">zoom_in</mat-icon>
          </button>
        </div>
      </div>

      <!-- Main Timeline Body: Track Controls Column + Scrubbable Lanes Area -->
      <div class="flex overflow-hidden relative" style="height: 270px;">
        <!-- Left: Fixed Track Header Controls (Mute / Solo / Lock) -->
        <div class="w-44 md:w-56 shrink-0 bg-[#000000] border-r border-[#151C26] flex flex-col select-none z-10">
          <!-- Top ruler spacer -->
          <div class="h-7 bg-[#000000] border-b border-[#151C26] px-3 flex items-center text-[10px] text-[#739AB8] font-mono-code font-bold tracking-wider">
            TRACKS // PATCH
          </div>

          <!-- Track Lanes Header Rows -->
          <div class="flex-1 flex flex-col justify-around py-1 divide-y divide-[#151C26]/40">
            @for (track of state.tracks(); track track.id) {
              <div class="px-3 py-1.5 flex items-center justify-between text-xs font-mono-code h-14">
                <div class="flex items-center gap-2 truncate">
                  <span
                    class="text-[10px] font-bold px-1.5 py-0.5 rounded border border-[#151C26]"
                    [class.text-[#55C8FF]]="track.type === 'video'"
                    [class.text-[#A8DFFF]]="track.type === 'audio'"
                  >
                    {{ track.id.toUpperCase() }}
                  </span>
                  <span class="truncate text-[11px] text-[#B9E5FF]">{{ track.name }}</span>
                </div>

                <!-- Track Action Badges -->
                <div class="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    (click)="state.toggleTrackMute(track.id)"
                    [class]="track.isMuted ? 'bg-[#55C8FF]/20 text-[#55C8FF] border border-[#55C8FF]' : 'text-[#739AB8] hover:text-[#B9E5FF] border border-transparent'"
                    class="w-5 h-5 rounded text-[10px] font-bold flex items-center justify-center transition-all"
                    title="Mute Track"
                  >
                    M
                  </button>
                  <button
                    type="button"
                    (click)="state.toggleTrackSolo(track.id)"
                    [class]="track.isSolo ? 'bg-[#55C8FF]/20 text-[#55C8FF] border border-[#55C8FF]' : 'text-[#739AB8] hover:text-[#B9E5FF] border border-transparent'"
                    class="w-5 h-5 rounded text-[10px] font-bold flex items-center justify-center transition-all"
                    title="Solo Track"
                  >
                    S
                  </button>
                  <button
                    type="button"
                    (click)="state.toggleTrackLock(track.id)"
                    [class]="track.isLocked ? 'text-[#55C8FF]' : 'text-[#739AB8] hover:text-[#B9E5FF]'"
                    class="p-0.5 rounded transition-all"
                    title="Lock Track"
                  >
                    <mat-icon class="text-xs leading-none">{{ track.isLocked ? 'lock' : 'lock_open' }}</mat-icon>
                  </button>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Right: Scrollable Timeline Tracks Canvas & Playhead -->
        <div
          #timelineCanvas
          tabindex="0"
          role="region"
          aria-label="Multi-track timeline canvas"
          (click)="onTimelineClick($event)"
          (keydown.arrowright)="state.stepFrame(1)"
          (keydown.arrowleft)="state.stepFrame(-1)"
          class="flex-1 overflow-x-auto overflow-y-hidden relative bg-[#050608] select-none cursor-pointer outline-none focus-visible:ring-1 focus-visible:ring-[#55C8FF]/50"
        >
          <!-- Virtual Timeline Width Container based on Zoom -->
          <div
            class="relative h-full"
            [style.width.px]="getTimelinePixelWidth()"
          >
            <!-- Timecode Ruler Bar -->
            <div class="h-7 bg-[#000000] border-b border-[#151C26] flex items-center relative text-[10px] font-mono-code text-[#739AB8]">
              @for (mark of rulerMarks; track mark.frame) {
                <div
                  class="absolute top-0 bottom-0 border-l border-[#151C26] pl-1.5 flex items-center"
                  [style.left.px]="frameToPixel(mark.frame)"
                >
                  <span class="text-[9px]">{{ mark.timecode }}</span>
                </div>
              }
            </div>

            <!-- Track Lanes -->
            <div class="flex flex-col justify-around py-1 h-[calc(100%-28px)] divide-y divide-[#151C26]/30">
              @for (track of state.tracks(); track track.id) {
                <div class="relative h-14 bg-[#090D12]/30 flex items-center">
                  <!-- Clips belonging to this track -->
                  @for (clip of getClipsForTrack(track.id); track clip.id) {
                    <div
                      role="button"
                      tabindex="0"
                      (click)="onClipClick(clip, $event)"
                      (keydown.enter)="onClipClick(clip, $event)"
                      class="absolute top-1 bottom-1 rounded border overflow-hidden cursor-pointer transition-all flex items-center group select-none outline-none focus-visible:border-[#55C8FF]"
                      [style.left.px]="frameToPixel(clip.startFrame)"
                      [style.width.px]="frameToPixel(clip.durationFrames)"
                      [class]="isClipActive(clip)
                        ? 'border-[#55C8FF] shadow-[0_0_12px_rgba(85,200,255,0.35)] bg-[#090D12]'
                        : 'border-[#151C26] hover:border-[#55C8FF]/50 bg-[#050608]'"
                    >
                      <!-- Video Clip: Thumbnail + Label -->
                      @if (track.type === 'video') {
                        @if (clip.imageSrc) {
                          <img
                            [src]="clip.imageSrc"
                            alt="Clip Thumbnail"
                            referrerpolicy="no-referrer"
                            class="w-12 h-full object-cover shrink-0 opacity-80 group-hover:opacity-100 border-r border-[#151C26]"
                          />
                        }
                        <div class="px-2 flex flex-col justify-center truncate leading-tight">
                          <span class="text-[11px] font-mono-code font-semibold text-[#B9E5FF] truncate">{{ clip.title }}</span>
                          <span class="text-[9px] font-mono-code text-[#739AB8] truncate">{{ clip.colorGrade }} · {{ clip.durationFrames }}f</span>
                        </div>
                      }

                      <!-- Audio Clip: Waveform visualization -->
                      @if (track.type === 'audio') {
                        <div class="w-full h-full flex items-center px-2 gap-1 overflow-hidden">
                          <div class="flex items-center gap-[3px] w-full h-full py-1">
                            @for (bar of clip.audioWaveformData || defaultWaveform; track $index) {
                              <div
                                class="w-[3px] rounded-full transition-all"
                                [style.height.%]="bar"
                                [class]="isClipActive(clip) ? 'bg-[#55C8FF]' : 'bg-[#739AB8]/60'"
                              ></div>
                            }
                          </div>
                          <span class="text-[10px] font-mono-code text-[#B9E5FF] shrink-0 truncate ml-2">{{ clip.title }}</span>
                        </div>
                      }
                    </div>
                  }
                </div>
              }
            </div>

            <!-- Scrubbable Vertical Playhead Needle -->
            <div
              class="absolute top-0 bottom-0 pointer-events-none z-20 flex flex-col items-center -ml-[6px] transition-[left] duration-75"
              [style.left.px]="frameToPixel(state.currentFrame())"
            >
              <!-- Playhead needle head -->
              <div class="w-3 h-3 bg-[#55C8FF] rotate-45 rounded-[2px] shadow-[0_0_10px_#55C8FF]"></div>
              <!-- Vertical glowing hairline line -->
              <div class="w-[1.5px] flex-1 bg-[#55C8FF] shadow-[0_0_8px_rgba(85,200,255,0.8)]"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class TimelineEditor {
  readonly state = inject(StudioState);
  readonly Math = Math;

  @ViewChild('timelineCanvas') timelineCanvasRef!: ElementRef<HTMLDivElement>;

  readonly defaultWaveform = [30, 45, 60, 40, 80, 65, 35, 20, 75, 90, 40, 30, 55, 30, 20];

  // Ruler marks generation
  get rulerMarks() {
    const total = this.state.totalFrames();
    const fps = this.state.fps();
    const stepSeconds = this.state.timelineZoom() > 1.5 ? 2 : 5;
    const stepFrames = stepSeconds * fps;
    const marks = [];

    for (let f = 0; f <= total; f += stepFrames) {
      const sec = Math.floor(f / fps);
      const mm = Math.floor(sec / 60).toString().padStart(2, '0');
      const ss = (sec % 60).toString().padStart(2, '0');
      marks.push({ frame: f, timecode: `00:${mm}:${ss}:00` });
    }
    return marks;
  }

  getTimelinePixelWidth(): number {
    // 24 frames per second * base pixel rate * zoom
    const basePxPerFrame = 2.4;
    return this.state.totalFrames() * basePxPerFrame * this.state.timelineZoom();
  }

  frameToPixel(frame: number): number {
    const basePxPerFrame = 2.4;
    return frame * basePxPerFrame * this.state.timelineZoom();
  }

  pixelToFrame(px: number): number {
    const basePxPerFrame = 2.4;
    return Math.round(px / (basePxPerFrame * this.state.timelineZoom()));
  }

  getClipsForTrack(trackId: string): TimelineClip[] {
    return this.state.clips().filter((c) => c.trackId === trackId);
  }

  isClipActive(clip: TimelineClip): boolean {
    const f = this.state.currentFrame();
    return f >= clip.startFrame && f < clip.startFrame + clip.durationFrames;
  }

  adjustZoom(delta: number): void {
    const current = this.state.timelineZoom();
    const next = Math.max(0.6, Math.min(3.0, current + delta));
    this.state.timelineZoom.set(Math.round(next * 10) / 10);
  }

  onTimelineClick(event: MouseEvent): void {
    const canvas = this.timelineCanvasRef?.nativeElement;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const clickX = event.clientX - rect.left + canvas.scrollLeft;
    const targetFrame = this.pixelToFrame(clickX);
    this.state.scrubToFrame(targetFrame);
  }

  onClipClick(clip: TimelineClip, event: Event): void {
    event.stopPropagation();
    if (this.state.selectedTool() === 'blade') {
      // Split clip at current playhead if inside
      this.splitClipAtPlayhead(clip);
    } else {
      if (clip.shotId) {
        this.state.selectShot(clip.shotId);
      }
      this.state.scrubToFrame(clip.startFrame);
    }
  }

  splitClipAtPlayhead(clip: TimelineClip): void {
    const playhead = this.state.currentFrame();
    if (playhead > clip.startFrame && playhead < clip.startFrame + clip.durationFrames) {
      const firstDuration = playhead - clip.startFrame;
      const secondDuration = clip.durationFrames - firstDuration;

      const splitClipA: TimelineClip = {
        ...clip,
        durationFrames: firstDuration,
      };
      const splitClipB: TimelineClip = {
        ...clip,
        id: clip.id + '-split-' + Date.now(),
        startFrame: playhead,
        durationFrames: secondDuration,
        title: clip.title + ' [Part 2]',
      };

      this.state.clips.update((clips) =>
        clips.map((c) => (c.id === clip.id ? splitClipA : c)).concat(splitClipB)
      );
    }
  }
}
