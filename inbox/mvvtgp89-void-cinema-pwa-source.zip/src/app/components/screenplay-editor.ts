import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StudioState } from '../services/studio.state';
import { ScreenplayLine } from '../models/studio.model';

@Component({
  selector: 'app-screenplay-editor',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex flex-col lg:flex-row gap-4 h-full">
      <!-- Left: Screenplay Page Sheet (Standard Hollywood formatting) -->
      <div class="flex-1 flex flex-col bg-[#050608] border border-[#151C26] rounded-xl overflow-hidden shadow-[0_8px_32px_rgba(0,0,0,0.95)]">
        <!-- Script Toolbar -->
        <div class="flex items-center justify-between px-4 py-2.5 bg-[#000000] border-b border-[#151C26] text-xs font-mono-code select-none">
          <div class="flex items-center gap-2">
            <mat-icon class="text-base leading-none text-[#55C8FF]">history_edu</mat-icon>
            <span class="font-semibold text-[#B9E5FF]">PRODUCTION SHOOTING SCRIPT</span>
            <span class="text-[#739AB8]">· DRAFT 4.2 (OLED SPEC)</span>
          </div>

          <!-- Fast Element Inserters -->
          <div class="flex items-center gap-1">
            <button
              type="button"
              (click)="insertLine('scene-heading', 'EXT. NEW LOCATION - NIGHT')"
              class="px-2 py-1 bg-[#090D12] border border-[#151C26] hover:border-[#55C8FF]/40 text-[#55C8FF] rounded text-[11px] transition-all"
            >
              + SLUG
            </button>
            <button
              type="button"
              (click)="insertLine('action', 'Enter action description...')"
              class="px-2 py-1 bg-[#090D12] border border-[#151C26] hover:border-[#55C8FF]/40 text-[#B9E5FF] rounded text-[11px] transition-all"
            >
              + ACTION
            </button>
            <button
              type="button"
              (click)="insertLine('character', 'CHARACTER NAME')"
              class="px-2 py-1 bg-[#090D12] border border-[#151C26] hover:border-[#55C8FF]/40 text-[#A8DFFF] rounded text-[11px] transition-all"
            >
              + CHAR
            </button>
            <button
              type="button"
              (click)="insertLine('dialogue', 'Spoken dialogue line...')"
              class="px-2 py-1 bg-[#090D12] border border-[#151C26] hover:border-[#55C8FF]/40 text-[#B9E5FF] rounded text-[11px] transition-all"
            >
              + DIAL
            </button>
            <button
              type="button"
              (click)="insertLine('transition', 'CUT TO:')"
              class="px-2 py-1 bg-[#090D12] border border-[#151C26] hover:border-[#55C8FF]/40 text-[#739AB8] rounded text-[11px] transition-all"
            >
              + TRANS
            </button>
          </div>
        </div>

        <!-- The Script Page Container (Pitch black paper feel with pale ice-blue typography) -->
        <div class="flex-1 p-6 md:p-12 overflow-y-auto max-h-[680px] bg-[#000000] font-mono-code">
          <div class="max-w-2xl mx-auto flex flex-col gap-3">
            @for (line of state.screenplayLines(); track line.id) {
              <div class="group relative flex items-start">
                <!-- Delete Line Affordance -->
                <button
                  type="button"
                  (click)="state.deleteScreenplayLine(line.id)"
                  class="absolute -left-7 top-1 opacity-0 group-hover:opacity-100 text-[#739AB8] hover:text-[#55C8FF] p-0.5 rounded transition-opacity"
                  title="Remove Line"
                >
                  <mat-icon class="text-xs leading-none">close</mat-icon>
                </button>

                <!-- Screenplay Format Switcher -->
                @switch (line.type) {
                  @case ('scene-heading') {
                    <div class="w-full text-xs md:text-sm font-bold tracking-wider text-[#55C8FF] uppercase pt-4 pb-1 border-b border-[#151C26]/40">
                      <input
                        type="text"
                        [value]="line.text"
                        (input)="onLineChange(line.id, $event)"
                        class="w-full bg-transparent outline-none focus:bg-[#090D12] px-1 rounded transition-colors"
                      />
                    </div>
                  }
                  @case ('action') {
                    <div class="w-full text-xs md:text-sm text-[#B9E5FF] leading-relaxed py-1">
                      <textarea
                        rows="2"
                        (input)="onLineChange(line.id, $event)"
                        class="w-full bg-transparent resize-none outline-none focus:bg-[#090D12] px-1 rounded transition-colors leading-relaxed"
                      >{{ line.text }}</textarea>
                    </div>
                  }
                  @case ('character') {
                    <div class="w-full text-center text-xs md:text-sm font-semibold tracking-widest text-[#A8DFFF] uppercase pt-3 pb-0.5">
                      <input
                        type="text"
                        [value]="line.text"
                        (input)="onLineChange(line.id, $event)"
                        class="w-48 text-center bg-transparent outline-none focus:bg-[#090D12] px-1 rounded transition-colors mx-auto"
                      />
                    </div>
                  }
                  @case ('parenthetical') {
                    <div class="w-full text-center text-xs text-[#739AB8] italic py-0.5">
                      <input
                        type="text"
                        [value]="line.text"
                        (input)="onLineChange(line.id, $event)"
                        class="w-64 text-center bg-transparent outline-none focus:bg-[#090D12] px-1 rounded transition-colors mx-auto"
                      />
                    </div>
                  }
                  @case ('dialogue') {
                    <div class="w-full max-w-md mx-auto text-xs md:text-sm text-[#B9E5FF] leading-relaxed text-center py-1">
                      <textarea
                        rows="2"
                        (input)="onLineChange(line.id, $event)"
                        class="w-full bg-transparent resize-none outline-none focus:bg-[#090D12] px-1 rounded transition-colors text-center leading-relaxed"
                      >{{ line.text }}</textarea>
                    </div>
                  }
                  @case ('transition') {
                    <div class="w-full text-right text-xs font-bold tracking-wider text-[#739AB8] uppercase pt-3 pb-2">
                      <input
                        type="text"
                        [value]="line.text"
                        (input)="onLineChange(line.id, $event)"
                        class="w-36 text-right bg-transparent outline-none focus:bg-[#090D12] px-1 rounded transition-colors"
                      />
                    </div>
                  }
                }
              </div>
            }
          </div>
        </div>
      </div>

      <!-- Right: Script Telemetry & Scene Breakdown Panel -->
      <div class="w-full lg:w-80 flex flex-col gap-4 shrink-0">
        <!-- Script Stats -->
        <div class="p-4 bg-[#050608] border border-[#151C26] rounded-xl flex flex-col gap-3 font-mono-code text-xs">
          <span class="text-xs font-semibold text-[#A8DFFF] uppercase flex items-center gap-2">
            <mat-icon class="text-sm leading-none text-[#55C8FF]">analytics</mat-icon>
            PAGINATION & RUNTIME
          </span>

          <div class="grid grid-cols-2 gap-2 bg-[#090D12] p-2.5 rounded-lg border border-[#151C26]">
            <div>
              <span class="text-[10px] text-[#739AB8]">EST. PAGES</span>
              <div class="text-sm font-bold text-[#B9E5FF]">3.4 PGS</div>
            </div>
            <div>
              <span class="text-[10px] text-[#739AB8]">SCREEN TIME</span>
              <div class="text-sm font-bold text-[#55C8FF]">~3 MIN 24 SEC</div>
            </div>
            <div>
              <span class="text-[10px] text-[#739AB8]">TOTAL DIALOGUES</span>
              <div class="text-sm font-bold text-[#B9E5FF]">18 LINES</div>
            </div>
            <div>
              <span class="text-[10px] text-[#739AB8]">LOCATIONS</span>
              <div class="text-sm font-bold text-[#A8DFFF]">3 SETUPS</div>
            </div>
          </div>
        </div>

        <!-- Scene Index Quick Nav -->
        <div class="p-4 bg-[#050608] border border-[#151C26] rounded-xl flex flex-col gap-3 font-mono-code text-xs flex-1">
          <span class="text-xs font-semibold text-[#A8DFFF] uppercase flex items-center gap-2">
            <mat-icon class="text-sm leading-none text-[#55C8FF]">format_list_bulleted</mat-icon>
            SCENE INDEX & SLUGLINES
          </span>

          <div class="flex flex-col gap-2">
            @for (scene of state.scenes(); track scene.id) {
              <div class="p-2.5 bg-[#000000] border border-[#151C26] hover:border-[#55C8FF]/50 rounded-lg transition-all flex flex-col gap-1 cursor-pointer">
                <div class="flex items-center justify-between text-[10px]">
                  <span class="text-[#55C8FF] font-bold">SCENE {{ scene.number }}</span>
                  <span class="text-[#739AB8]">{{ scene.status }}</span>
                </div>
                <span class="text-xs font-semibold text-[#B9E5FF] truncate">{{ scene.slugline }}</span>
                <span class="text-[11px] text-[#739AB8] line-clamp-1 font-sans">{{ scene.summary }}</span>
              </div>
            }
          </div>
        </div>
      </div>
    </div>
  `,
})
export class ScreenplayEditor {
  readonly state = inject(StudioState);

  insertLine(type: ScreenplayLine['type'], text: string): void {
    this.state.addScreenplayLine(type, text);
  }

  onLineChange(id: string, event: Event): void {
    const target = event.target as HTMLInputElement | HTMLTextAreaElement;
    this.state.updateScreenplayLine(id, target.value);
  }
}
