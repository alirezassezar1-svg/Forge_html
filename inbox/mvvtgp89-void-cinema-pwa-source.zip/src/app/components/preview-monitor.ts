import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StudioState } from '../services/studio.state';

@Component({
  selector: 'app-preview-monitor',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex flex-col bg-[#050608] border border-[#151C26] rounded-xl overflow-hidden shadow-[0_8px_32px_rgba(0,0,0,0.95)]">
      <!-- Monitor Header Bar -->
      <div class="flex items-center justify-between px-3 py-2 bg-[#000000] border-b border-[#151C26] text-xs text-[#739AB8] font-mono-code select-none">
        <div class="flex items-center gap-3">
          <span class="text-[#55C8FF] font-semibold flex items-center gap-1.5">
            <span class="w-1.5 h-1.5 rounded-full bg-[#55C8FF] animate-pulse"></span>
            PROGRAM SDI-1
          </span>
          <span aria-hidden="true">·</span>
          <span>{{ state.activeAspectRatio() }}</span>
          <span aria-hidden="true">·</span>
          <span>DCI 4K (4096x1716)</span>
          <span aria-hidden="true">·</span>
          <span class="text-[#A8DFFF]">{{ state.activeLUT() }}</span>
        </div>

        <div class="flex items-center gap-2">
          <!-- Subtitles Toggle -->
          <button
            type="button"
            (click)="toggleSubtitles()"
            [class]="state.showSubtitles() ? 'text-[#55C8FF] bg-[#090D12] border border-[#55C8FF]/40' : 'text-[#739AB8] hover:text-[#B9E5FF] border border-transparent'"
            class="px-2 py-0.5 rounded text-[11px] transition-all flex items-center gap-1"
            title="Toggle Subtitles (CC)"
          >
            <mat-icon class="text-sm leading-none">closed_caption</mat-icon>
            <span>CC: {{ state.subtitleLanguage().toUpperCase() }}</span>
          </button>

          <!-- Framing Guide Toggle -->
          <button
            type="button"
            (click)="state.showFramingGuides.set(!state.showFramingGuides())"
            [class]="state.showFramingGuides() ? 'text-[#55C8FF] bg-[#090D12] border border-[#55C8FF]/40' : 'text-[#739AB8] hover:text-[#B9E5FF] border border-transparent'"
            class="px-2 py-0.5 rounded text-[11px] transition-all flex items-center gap-1"
            title="Toggle Safe Framing Guides"
          >
            <mat-icon class="text-sm leading-none">crop_free</mat-icon>
            <span>GUIDES</span>
          </button>

          <!-- Scope Switcher -->
          <div class="flex items-center bg-[#090D12] border border-[#151C26] rounded p-0.5 text-[10px]">
            <button
              type="button"
              (click)="toggleScope('none')"
              [class]="state.activeScope() === 'none' ? 'bg-[#151C26] text-[#B9E5FF]' : 'text-[#739AB8] hover:text-[#B9E5FF]'"
              class="px-1.5 py-0.5 rounded"
            >
              CLEAN
            </button>
            <button
              type="button"
              (click)="toggleScope('waveform')"
              [class]="state.activeScope() === 'waveform' ? 'bg-[#151C26] text-[#55C8FF]' : 'text-[#739AB8] hover:text-[#B9E5FF]'"
              class="px-1.5 py-0.5 rounded"
            >
              WAVEFORM
            </button>
            <button
              type="button"
              (click)="toggleScope('histogram')"
              [class]="state.activeScope() === 'histogram' ? 'bg-[#151C26] text-[#55C8FF]' : 'text-[#739AB8] hover:text-[#B9E5FF]'"
              class="px-1.5 py-0.5 rounded"
            >
              HISTO
            </button>
          </div>

          <!-- Aspect Ratio Switcher -->
          <select
            [value]="state.activeAspectRatio()"
            (change)="setAspectRatio($event)"
            class="bg-[#090D12] border border-[#151C26] text-[#B9E5FF] text-[11px] rounded px-1.5 py-0.5 outline-none hover:border-[#55C8FF]/40 focus:border-[#55C8FF]"
          >
            <option value="2.39:1">2.39:1 Scope</option>
            <option value="1.85:1">1.85:1 Flat</option>
            <option value="16:9">16:9 UHD</option>
          </select>
        </div>
      </div>

      <!-- Cinema Screen Viewport -->
      <div class="relative w-full bg-[#000000] flex items-center justify-center overflow-hidden min-h-[260px] md:min-h-[380px] lg:min-h-[440px] p-2 md:p-4 select-none">
        <!-- 2.39:1 / 1.85:1 Framing Container -->
        <div
          class="relative w-full transition-all duration-300 flex items-center justify-center bg-[#000000] overflow-hidden rounded shadow-[0_0_40px_rgba(0,0,0,1)]"
          [style.aspect-ratio]="getAspectRatioValue()"
          [style.max-height]="'440px'"
        >
          <!-- Active Still Frame Image -->
          <img
            [src]="state.activePreviewImage()"
            alt="Cinematic Preview Monitor Frame"
            referrerpolicy="no-referrer"
            class="w-full h-full object-cover transition-opacity duration-200"
            [class.opacity-95]="state.isPlaying()"
            [style.filter]="getLUTFilter()"
          />

          <!-- CinemaScope Matte Bars (if 2.39:1) -->
          @if (state.activeAspectRatio() === '2.39:1') {
            <div class="pointer-events-none absolute inset-x-0 top-0 h-[6%] bg-[#000000] border-b border-[#151C26]/60"></div>
            <div class="pointer-events-none absolute inset-x-0 bottom-0 h-[6%] bg-[#000000] border-t border-[#151C26]/60"></div>
          }

          <!-- Safe Framing Guides (Action & Title) -->
          @if (state.showFramingGuides()) {
            <div class="pointer-events-none absolute inset-[7%] border border-[#55C8FF]/25">
              <span class="absolute top-1 left-1.5 text-[9px] font-mono-code text-[#55C8FF]/60 uppercase">93% Action</span>
            </div>
            <div class="pointer-events-none absolute inset-[12%] border border-dashed border-[#55C8FF]/20">
              <span class="absolute top-1 left-1.5 text-[9px] font-mono-code text-[#55C8FF]/50 uppercase">80% Title</span>
            </div>
            <!-- Center Crosshair -->
            <div class="pointer-events-none absolute inset-0 flex items-center justify-center">
              <div class="w-4 h-0.5 bg-[#55C8FF]/40"></div>
              <div class="w-0.5 h-4 bg-[#55C8FF]/40 -ml-2.25"></div>
            </div>
            <!-- Thirds lines -->
            <div class="pointer-events-none absolute inset-y-0 left-1/3 w-[1px] bg-[#55C8FF]/10"></div>
            <div class="pointer-events-none absolute inset-y-0 right-1/3 w-[1px] bg-[#55C8FF]/10"></div>
            <div class="pointer-events-none absolute inset-x-0 top-1/3 h-[1px] bg-[#55C8FF]/10"></div>
            <div class="pointer-events-none absolute inset-x-0 bottom-1/3 h-[1px] bg-[#55C8FF]/10"></div>
          }

          <!-- Live Cinema Scopes Simulation Overlay -->
          @if (state.activeScope() === 'waveform') {
            <div class="absolute inset-y-4 right-4 w-48 bg-[#000000]/90 border border-[#151C26] rounded p-2 pointer-events-none backdrop-blur-sm z-10 flex flex-col justify-between">
              <div class="flex items-center justify-between text-[10px] font-mono-code text-[#739AB8] pb-1 border-b border-[#151C26]">
                <span class="text-[#55C8FF]">IRE WAVEFORM</span>
                <span>100 IRE</span>
              </div>
              <!-- Waveform SVG signal display -->
              <svg class="w-full h-28" viewBox="0 0 200 100" fill="none" preserveAspectRatio="none">
                <!-- Grid Lines -->
                <line x1="0" y1="20" x2="200" y2="20" stroke="#151C26" stroke-dasharray="2,2" />
                <line x1="0" y1="50" x2="200" y2="50" stroke="#151C26" stroke-dasharray="2,2" />
                <line x1="0" y1="80" x2="200" y2="80" stroke="#151C26" stroke-dasharray="2,2" />
                <!-- Trace -->
                <path d="M 0 85 Q 30 75, 50 60 T 90 35 T 130 50 T 170 30 T 200 70" stroke="#55C8FF" stroke-width="1.5" opacity="0.8" />
                <path d="M 0 90 Q 25 80, 55 70 T 95 45 T 135 60 T 175 40 T 200 80" stroke="#B9E5FF" stroke-width="1" opacity="0.5" />
                <path d="M 0 78 Q 35 65, 65 50 T 105 30 T 145 42 T 185 25 T 200 65" stroke="#739AB8" stroke-width="1" opacity="0.6" />
              </svg>
              <div class="flex items-center justify-between text-[9px] font-mono-code text-[#739AB8] pt-1 border-t border-[#151C26]">
                <span>0 IRE</span>
                <span class="text-[#A8DFFF]">RGB PARADE</span>
              </div>
            </div>
          }

          @if (state.activeScope() === 'histogram') {
            <div class="absolute inset-y-4 right-4 w-48 bg-[#000000]/90 border border-[#151C26] rounded p-2 pointer-events-none backdrop-blur-sm z-10 flex flex-col justify-between">
              <div class="flex items-center justify-between text-[10px] font-mono-code text-[#739AB8] pb-1 border-b border-[#151C26]">
                <span class="text-[#55C8FF]">RGB HISTOGRAM</span>
                <span>LOG-C</span>
              </div>
              <svg class="w-full h-28" viewBox="0 0 200 100" fill="none" preserveAspectRatio="none">
                <path d="M 0 95 Q 20 90, 35 60 T 70 30 T 110 50 T 150 75 T 200 95 L 200 100 L 0 100 Z" fill="#55C8FF" fill-opacity="0.2" stroke="#55C8FF" stroke-width="1" />
                <path d="M 0 95 Q 30 85, 45 70 T 80 40 T 120 45 T 160 80 T 200 95 L 200 100 L 0 100 Z" fill="#B9E5FF" fill-opacity="0.15" stroke="#B9E5FF" stroke-width="1" />
              </svg>
              <div class="flex items-center justify-between text-[9px] font-mono-code text-[#739AB8] pt-1 border-t border-[#151C26]">
                <span>SHADOWS</span>
                <span>HIGHLIGHTS</span>
              </div>
            </div>
          }

          <!-- Live Subtitles Display (Bilingual Persian & English) -->
          @if (state.activeSubtitleCue(); as cue) {
            <div class="absolute bottom-10 inset-x-4 md:inset-x-12 flex flex-col items-center justify-center pointer-events-none z-20">
              <div class="px-3.5 py-1.5 bg-[#000000]/85 border border-[#55C8FF]/40 rounded-lg shadow-[0_4px_24px_rgba(0,0,0,0.95)] max-w-xl text-center flex flex-col gap-1">
                @if (state.subtitleLanguage() === 'both' || state.subtitleLanguage() === 'en') {
                  <span class="text-xs md:text-sm font-semibold tracking-wide text-[#B9E5FF] select-none font-mono-code">
                    {{ cue.textEn }}
                  </span>
                }
                @if (state.subtitleLanguage() === 'both' || state.subtitleLanguage() === 'fa') {
                  <span class="text-xs md:text-sm font-sans font-medium text-[#A8DFFF] select-none" dir="rtl">
                    {{ cue.textFa }}
                  </span>
                }
              </div>
            </div>
          }

          <!-- HUD Telemetry Lower Left: Camera Lens info -->
          <div class="absolute bottom-2 left-3 pointer-events-none text-[11px] font-mono-code text-[#B9E5FF] drop-shadow-[0_2px_4px_rgba(0,0,0,1)] bg-[#000000]/60 px-2 py-1 rounded border border-[#151C26]/80 flex items-center gap-2">
            <span class="text-[#55C8FF]">{{ state.selectedShot().shotCode }}</span>
            <span aria-hidden="true" class="text-[#739AB8]">/</span>
            <span>{{ state.selectedShot().camera.lens }}</span>
            <span aria-hidden="true" class="text-[#739AB8]">/</span>
            <span class="text-[#A8DFFF]">{{ state.selectedShot().camera.aperture }}</span>
          </div>

          <!-- HUD Telemetry Lower Right: Current Clip Title -->
          <div class="absolute bottom-2 right-3 pointer-events-none text-[11px] font-mono-code text-[#B9E5FF] drop-shadow-[0_2px_4px_rgba(0,0,0,1)] bg-[#000000]/60 px-2 py-1 rounded border border-[#151C26]/80 flex items-center gap-2">
            <span>{{ state.currentActiveClip().title }}</span>
          </div>
        </div>
      </div>

      <!-- Monitor Scrub Bar -->
      <div class="px-3 pt-2 pb-1 bg-[#050608] border-t border-[#151C26] flex items-center gap-3">
        <span class="text-[11px] font-mono-code text-[#739AB8] shrink-0">00:00:00:00</span>
        <div class="relative w-full flex items-center">
          <input
            type="range"
            min="0"
            [max]="state.totalFrames() - 1"
            [value]="state.currentFrame()"
            (input)="onScrub($event)"
            class="w-full cursor-pointer"
          />
        </div>
        <span class="text-[11px] font-mono-code text-[#739AB8] shrink-0">00:02:00:00</span>
      </div>

      <!-- Playback Transport Bar -->
      <div class="flex items-center justify-between px-4 py-2.5 bg-[#000000] border-t border-[#151C26] select-none">
        <!-- Left: SMPTE Timecode & Frame Readout -->
        <div class="flex items-center gap-3">
          <div class="px-2.5 py-1 bg-[#050608] border border-[#151C26] rounded-md font-mono-code text-sm md:text-base font-semibold tracking-wider text-[#A8DFFF] shadow-[0_0_10px_rgba(85,200,255,0.12)]">
            {{ state.formattedTimecode() }}
          </div>
          <div class="hidden sm:flex flex-col text-[10px] font-mono-code text-[#739AB8]">
            <span>FRAME: <strong class="text-[#B9E5FF]">{{ state.currentFrame() }}</strong> / {{ state.totalFrames() }}</span>
            <span>SPEED: <strong class="text-[#55C8FF]">{{ state.playbackSpeed() }}x</strong></span>
          </div>
        </div>

        <!-- Center: Primary Transport Controls -->
        <div class="flex items-center gap-1 md:gap-2">
          <!-- Jump In -->
          <button
            type="button"
            (click)="state.jumpToIn()"
            class="p-1.5 text-[#739AB8] hover:text-[#B9E5FF] hover:bg-[#090D12] rounded transition-colors"
            title="Jump to Start (Home)"
          >
            <mat-icon class="text-lg leading-none">first_page</mat-icon>
          </button>

          <!-- Step Back 1 Frame -->
          <button
            type="button"
            (click)="state.stepFrame(-1)"
            class="p-1.5 text-[#739AB8] hover:text-[#B9E5FF] hover:bg-[#090D12] rounded transition-colors"
            title="Previous Frame (Left Arrow)"
          >
            <mat-icon class="text-lg leading-none">skip_previous</mat-icon>
          </button>

          <!-- Play / Pause Button with Neon Blue Outline -->
          <button
            type="button"
            (click)="state.togglePlay()"
            class="px-4 py-1.5 bg-[#000000] border border-[#55C8FF] text-[#B9E5FF] hover:shadow-[0_0_16px_rgba(85,200,255,0.35)] active:scale-95 rounded-lg transition-all flex items-center gap-1.5 font-mono-code text-xs font-semibold"
            title="Play / Pause (Space)"
          >
            @if (state.isPlaying()) {
              <mat-icon class="text-base leading-none text-[#55C8FF]">pause</mat-icon>
              <span>PAUSE</span>
            } @else {
              <mat-icon class="text-base leading-none text-[#55C8FF]">play_arrow</mat-icon>
              <span>PLAY</span>
            }
          </button>

          <!-- Step Forward 1 Frame -->
          <button
            type="button"
            (click)="state.stepFrame(1)"
            class="p-1.5 text-[#739AB8] hover:text-[#B9E5FF] hover:bg-[#090D12] rounded transition-colors"
            title="Next Frame (Right Arrow)"
          >
            <mat-icon class="text-lg leading-none">skip_next</mat-icon>
          </button>

          <!-- Jump Out -->
          <button
            type="button"
            (click)="state.jumpToOut()"
            class="p-1.5 text-[#739AB8] hover:text-[#B9E5FF] hover:bg-[#090D12] rounded transition-colors"
            title="Jump to End (End)"
          >
            <mat-icon class="text-lg leading-none">last_page</mat-icon>
          </button>

          <!-- Loop Toggle -->
          <button
            type="button"
            (click)="state.loopPlayback.set(!state.loopPlayback())"
            [class]="state.loopPlayback() ? 'text-[#55C8FF] bg-[#090D12] border border-[#55C8FF]/40' : 'text-[#739AB8] border border-transparent'"
            class="p-1.5 rounded transition-colors ml-1"
            title="Loop Playback"
          >
            <mat-icon class="text-lg leading-none">repeat</mat-icon>
          </button>
        </div>

        <!-- Right: LUT Selection & Speed -->
        <div class="flex items-center gap-2">
          <div class="hidden md:flex items-center gap-1 bg-[#090D12] border border-[#151C26] rounded px-1 py-0.5 text-[10px] font-mono-code">
            <button
              type="button"
              (click)="state.setPlaybackSpeed(1)"
              [class]="state.playbackSpeed() === 1 ? 'text-[#55C8FF] font-bold' : 'text-[#739AB8]'"
              class="px-1.5 py-0.5 rounded"
            >
              1X
            </button>
            <button
              type="button"
              (click)="state.setPlaybackSpeed(2)"
              [class]="state.playbackSpeed() === 2 ? 'text-[#55C8FF] font-bold' : 'text-[#739AB8]'"
              class="px-1.5 py-0.5 rounded"
            >
              2X
            </button>
          </div>

          <select
            [value]="state.activeLUT()"
            (change)="setLUT($event)"
            class="bg-[#090D12] border border-[#151C26] text-[#B9E5FF] text-xs rounded px-2 py-1 outline-none hover:border-[#55C8FF]/40 focus:border-[#55C8FF]"
          >
            <option value="Cyan Night 500T">LUT: Cyan Night 500T</option>
            <option value="OLED True 709">LUT: OLED True 709</option>
            <option value="Monolith 2383 Kodak">LUT: Monolith 2383 Kodak</option>
            <option value="Pure Log-C">LUT: Pure Log-C (Flat)</option>
          </select>
        </div>
      </div>
    </div>
  `,
})
export class PreviewMonitor {
  readonly state = inject(StudioState);

  getAspectRatioValue(): string {
    switch (this.state.activeAspectRatio()) {
      case '2.39:1':
        return '2.39 / 1';
      case '1.85:1':
        return '1.85 / 1';
      case '16:9':
      default:
        return '16 / 9';
    }
  }

  getLUTFilter(): string {
    switch (this.state.activeLUT()) {
      case 'Cyan Night 500T':
        return 'contrast(1.15) saturate(0.9) hue-rotate(-8deg) brightness(0.95)';
      case 'Monolith 2383 Kodak':
        return 'contrast(1.25) saturate(1.1) brightness(0.92)';
      case 'Pure Log-C':
        return 'contrast(0.75) saturate(0.7) brightness(1.1)';
      case 'OLED True 709':
      default:
        return 'contrast(1.08) saturate(1.0) brightness(1.0)';
    }
  }

  toggleScope(scope: 'none' | 'waveform' | 'histogram'): void {
    this.state.activeScope.set(scope);
  }

  toggleSubtitles(): void {
    const current = this.state.subtitleLanguage();
    if (current === 'both') {
      this.state.subtitleLanguage.set('fa');
      this.state.showSubtitles.set(true);
    } else if (current === 'fa') {
      this.state.subtitleLanguage.set('en');
      this.state.showSubtitles.set(true);
    } else if (current === 'en') {
      this.state.subtitleLanguage.set('off');
      this.state.showSubtitles.set(false);
    } else {
      this.state.subtitleLanguage.set('both');
      this.state.showSubtitles.set(true);
    }
  }

  setAspectRatio(event: Event): void {
    const val = (event.target as HTMLSelectElement).value as '2.39:1' | '1.85:1' | '16:9';
    this.state.activeAspectRatio.set(val);
  }

  setLUT(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.state.activeLUT.set(val);
  }

  onScrub(event: Event): void {
    const frame = Number((event.target as HTMLInputElement).value);
    this.state.scrubToFrame(frame);
  }
}
