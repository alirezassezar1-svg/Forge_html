import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { StudioState } from '../services/studio.state';

@Component({
  selector: 'app-top-bar',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <header class="flex items-center justify-between gap-4 md:gap-8 px-4 md:px-6 py-2.5 bg-[#000000] border-b border-[#151C26] shrink-0 z-30 select-none">
      <!-- Zone 1: Single element brand wordmark with reel info -->
      <div class="flex items-center gap-3 shrink-0">
        <div class="flex items-center gap-2">
          <div class="w-2.5 h-2.5 rounded-full bg-[#55C8FF] shadow-[0_0_8px_#55C8FF]"></div>
          <span class="text-sm md:text-base font-semibold tracking-wider text-[#A8DFFF] uppercase font-mono-code">
            VOID CINEMA <span class="text-[#739AB8] font-normal">// OBSIDIAN ICE</span>
          </span>
        </div>
        <div class="hidden xl:flex items-center gap-2 text-xs text-[#739AB8] font-mono-code pl-2 border-l border-[#151C26]">
          <span>{{ state.projectTitle() }}</span>
          <span aria-hidden="true">·</span>
          <span>{{ state.projectReel() }}</span>
          <span aria-hidden="true">·</span>
          <span class="text-[#55C8FF]">{{ state.fps() }}.00 FPS</span>
        </div>
      </div>

      <!-- Zone 2: 4 clean single-line workspace navigation links -->
      <nav class="flex items-center gap-1 md:gap-2">
        <button
          type="button"
          (click)="state.activeWorkspace.set('editing')"
          [class]="state.activeWorkspace() === 'editing'
            ? 'px-3 py-1.5 text-xs font-medium tracking-wide text-[#B9E5FF] bg-[#050608] border border-[#55C8FF] shadow-[0_0_12px_rgba(85,200,255,0.25)] rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0'
            : 'px-3 py-1.5 text-xs font-medium tracking-wide text-[#739AB8] hover:text-[#B9E5FF] hover:border-[#151C26] border border-transparent rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0'"
        >
          <mat-icon class="text-base leading-none">timeline</mat-icon>
          <span>Timeline Suite</span>
        </button>

        <button
          type="button"
          (click)="state.activeWorkspace.set('storyboard')"
          [class]="state.activeWorkspace() === 'storyboard'
            ? 'px-3 py-1.5 text-xs font-medium tracking-wide text-[#B9E5FF] bg-[#050608] border border-[#55C8FF] shadow-[0_0_12px_rgba(85,200,255,0.25)] rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0'
            : 'px-3 py-1.5 text-xs font-medium tracking-wide text-[#739AB8] hover:text-[#B9E5FF] hover:border-[#151C26] border border-transparent rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0'"
        >
          <mat-icon class="text-base leading-none">view_carousel</mat-icon>
          <span>Storyboard Wall</span>
        </button>

        <button
          type="button"
          (click)="state.activeWorkspace.set('screenplay')"
          [class]="state.activeWorkspace() === 'screenplay'
            ? 'px-3 py-1.5 text-xs font-medium tracking-wide text-[#B9E5FF] bg-[#050608] border border-[#55C8FF] shadow-[0_0_12px_rgba(85,200,255,0.25)] rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0'
            : 'px-3 py-1.5 text-xs font-medium tracking-wide text-[#739AB8] hover:text-[#B9E5FF] hover:border-[#151C26] border border-transparent rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0'"
        >
          <mat-icon class="text-base leading-none">description</mat-icon>
          <span>Screenplay Desk</span>
        </button>

        <button
          type="button"
          (click)="state.activeWorkspace.set('mixer')"
          [class]="state.activeWorkspace() === 'mixer'
            ? 'px-3 py-1.5 text-xs font-medium tracking-wide text-[#B9E5FF] bg-[#050608] border border-[#55C8FF] shadow-[0_0_12px_rgba(85,200,255,0.25)] rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0'
            : 'px-3 py-1.5 text-xs font-medium tracking-wide text-[#739AB8] hover:text-[#B9E5FF] hover:border-[#151C26] border border-transparent rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0'"
        >
          <mat-icon class="text-base leading-none">equalizer</mat-icon>
          <span>Audio Console</span>
        </button>
      </nav>

      <!-- Zone 3: VOID AI Agent & Master Delivery -->
      <div class="flex items-center gap-2 shrink-0">
        <!-- VOID AI Agent Button with Pulse -->
        <button
          type="button"
          (click)="state.isAIAssistantOpen.set(!state.isAIAssistantOpen())"
          [class]="state.isAIAssistantOpen()
            ? 'px-3 py-1.5 text-xs font-semibold tracking-wider uppercase text-[#B9E5FF] bg-[#090D12] border border-[#55C8FF] shadow-[0_0_14px_rgba(85,200,255,0.4)] rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0'
            : 'px-3 py-1.5 text-xs font-semibold tracking-wider uppercase text-[#55C8FF] bg-[#000000] border border-[#55C8FF]/40 hover:border-[#55C8FF] hover:shadow-[0_0_12px_rgba(85,200,255,0.25)] rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0'"
        >
          <span class="w-2 h-2 rounded-full bg-[#55C8FF] animate-pulse"></span>
          <mat-icon class="text-base leading-none">smart_toy</mat-icon>
          <span>VOID AI</span>
        </button>

        <button
          type="button"
          (click)="state.isExportModalOpen.set(true)"
          class="hidden sm:flex px-3.5 py-1.5 text-xs font-semibold tracking-wider uppercase text-[#B9E5FF] bg-[#000000] border border-[#55C8FF]/50 hover:border-[#55C8FF] hover:shadow-[0_0_14px_rgba(85,200,255,0.3)] active:scale-[0.98] rounded-lg transition-all items-center gap-2 whitespace-nowrap shrink-0"
        >
          <mat-icon class="text-base leading-none text-[#55C8FF]">movie_filter</mat-icon>
          <span>Deliver Master</span>
        </button>
      </div>
    </header>
  `,
})
export class TopBar {
  readonly state = inject(StudioState);
}
