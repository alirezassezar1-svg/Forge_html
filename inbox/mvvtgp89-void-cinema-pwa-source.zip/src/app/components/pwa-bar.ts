import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { PwaService } from '../services/pwa.service';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-pwa-bar',
  imports: [MatIconModule],
  template: `
    <div
      class="fixed z-[60] left-3 right-3 sm:left-auto sm:right-4 bottom-[calc(env(safe-area-inset-bottom)+12px)] sm:w-[360px] flex flex-col gap-2 pointer-events-none"
      aria-live="polite"
    >
      @if (!pwa.isOnline()) {
        <div class="pointer-events-auto flex items-center gap-2 px-3 py-2 rounded border border-[#151C26] bg-[#050608] text-xs font-mono-code text-[#A8DFFF]">
          <span class="w-2 h-2 rounded-full bg-[#739AB8]"></span>
          <span>OFFLINE — local planner active / حالت آفلاین</span>
        </div>
      }

      @if (pwa.updateReady()) {
        <div class="pointer-events-auto flex items-center justify-between gap-3 px-3 py-2.5 rounded border border-[#55C8FF]/50 bg-[#000000] glow-cyan-sm">
          <span class="text-xs text-[#B9E5FF]">نسخه جدید آماده است · New version ready</span>
          <button type="button" (click)="pwa.applyUpdate()" class="text-[11px] font-semibold text-[#000] bg-[#55C8FF] px-2.5 py-1 rounded">
            UPDATE
          </button>
        </div>
      }

      @if (pwa.canInstall()) {
        <div class="pointer-events-auto flex items-center justify-between gap-3 px-3 py-2.5 rounded border border-[#55C8FF]/50 bg-[#000000] glow-cyan-sm">
          <div class="flex items-center gap-2 text-xs text-[#B9E5FF]">
            <mat-icon class="!w-5 !h-5 !text-[20px] text-[#55C8FF]">install_mobile</mat-icon>
            <span>نصب VOID CINEMA · Install app</span>
          </div>
          <div class="flex items-center gap-2">
            <button type="button" (click)="pwa.dismissInstall()" class="text-[11px] text-[#739AB8] px-1.5 py-1">LATER</button>
            <button type="button" (click)="pwa.install()" class="text-[11px] font-semibold text-[#000] bg-[#55C8FF] px-2.5 py-1 rounded">INSTALL</button>
          </div>
        </div>
      }

      @if (pwa.showIosHint()) {
        <div class="pointer-events-auto flex items-start justify-between gap-3 px-3 py-2.5 rounded border border-[#55C8FF]/50 bg-[#000000]">
          <span class="text-xs text-[#B9E5FF] leading-relaxed">
            برای نصب: دکمه Share ← Add to Home Screen<br />
            To install: tap Share → Add to Home Screen
          </span>
          <button type="button" (click)="pwa.dismissInstall()" class="text-[#739AB8]" aria-label="Dismiss">
            <mat-icon class="!w-5 !h-5 !text-[18px]">close</mat-icon>
          </button>
        </div>
      }
    </div>
  `,
})
export class PwaBar {
  readonly pwa = inject(PwaService);
}
