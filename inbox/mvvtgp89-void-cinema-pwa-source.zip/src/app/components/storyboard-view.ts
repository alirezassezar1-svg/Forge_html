import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StudioState } from '../services/studio.state';
import { Shot } from '../models/studio.model';

@Component({
  selector: 'app-storyboard-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="flex flex-col gap-4">
      <!-- Storyboard Control Bar -->
      <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-4 bg-[#050608] border border-[#151C26] rounded-xl">
        <div class="flex items-center gap-3">
          <span class="text-sm font-semibold tracking-wider text-[#A8DFFF] uppercase font-mono-code flex items-center gap-2">
            <mat-icon class="text-[#55C8FF] text-base leading-none">view_quilt</mat-icon>
            DIRECTOR STORYBOARD WALL
          </span>
          <span class="text-xs text-[#739AB8] font-mono-code">({{ state.shots().length }} SHOTS · 2.39:1 CINEMASCOPE)</span>
        </div>

        <div class="flex items-center gap-2 w-full sm:w-auto">
          <!-- Filter by Scene -->
          <select
            (change)="onFilterScene($event)"
            class="bg-[#000000] border border-[#151C26] text-[#B9E5FF] text-xs rounded-lg px-2.5 py-1.5 outline-none hover:border-[#55C8FF]/40 focus:border-[#55C8FF]"
          >
            <option value="ALL">All Scenes (Act II - III)</option>
            <option value="14A">Scene 14A · Ext. Tokyo Sector 9</option>
            <option value="14B">Scene 14B · Ext. Orbital Station</option>
            <option value="15A">Scene 15A · Int. Interrogation</option>
            <option value="15B">Scene 15B · Ext. Obsidian Monolith</option>
          </select>

          <!-- Add Shot Button -->
          <button
            type="button"
            (click)="addNewShot()"
            class="px-3 py-1.5 text-xs font-semibold text-[#B9E5FF] bg-[#000000] border border-[#55C8FF]/50 hover:border-[#55C8FF] hover:shadow-[0_0_12px_rgba(85,200,255,0.25)] rounded-lg transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <mat-icon class="text-sm leading-none text-[#55C8FF]">add</mat-icon>
            <span>Add Setup</span>
          </button>
        </div>
      </div>

      <!-- Storyboard Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        @for (shot of filteredShots(); track shot.id) {
          <div
            role="button"
            tabindex="0"
            (click)="selectShot(shot)"
            (keydown.enter)="selectShot(shot)"
            (keydown.space)="selectShot(shot)"
            class="flex flex-col bg-[#050608] border rounded-xl overflow-hidden cursor-pointer transition-all duration-200 group relative focus-visible:border-[#55C8FF] outline-none"
            [class]="state.activeShotId() === shot.id
              ? 'border-[#55C8FF] shadow-[0_0_20px_rgba(85,200,255,0.25)]'
              : 'border-[#151C26] hover:border-[#55C8FF]/40 hover:shadow-[0_4px_20px_rgba(0,0,0,0.8)]'"
          >
            <!-- Card Image with Aspect Ratio and Cinema Guides -->
            <div class="relative w-full aspect-[16/9] bg-[#000000] overflow-hidden">
              <img
                [src]="shot.imageSrc"
                [alt]="shot.title"
                referrerpolicy="no-referrer"
                class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />

              <!-- Top Left Shot ID Tag -->
              <div class="absolute top-2 left-2 bg-[#000000]/80 backdrop-blur-sm border border-[#151C26] px-2 py-0.5 rounded text-[11px] font-mono-code font-bold text-[#55C8FF]">
                {{ shot.shotCode }}
              </div>

              <!-- Top Right Duration -->
              <div class="absolute top-2 right-2 bg-[#000000]/80 backdrop-blur-sm border border-[#151C26] px-2 py-0.5 rounded text-[10px] font-mono-code text-[#B9E5FF]">
                {{ shot.durationSeconds.toFixed(1) }}s
              </div>

              <!-- Bottom Overlay Indicator -->
              <div class="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#000000] via-[#000000]/70 to-transparent p-2.5 pt-6 flex items-end justify-between">
                <span class="text-xs font-semibold text-[#B9E5FF] truncate font-mono-code">{{ shot.title }}</span>
                <span class="text-[10px] text-[#A8DFFF] font-mono-code shrink-0">{{ shot.status }}</span>
              </div>
            </div>

            <!-- Card Body: Technical Camera & Scene Specs -->
            <div class="p-3.5 flex flex-col gap-2.5 bg-[#050608] text-xs">
              <!-- Technical Specs Grid -->
              <div class="grid grid-cols-2 gap-2 text-[11px] font-mono-code bg-[#090D12] p-2 rounded-lg border border-[#151C26]">
                <div class="flex flex-col">
                  <span class="text-[#739AB8] text-[9px]">LENS PACKAGE</span>
                  <span class="text-[#B9E5FF] truncate" [title]="shot.camera.lens">{{ shot.camera.lens }}</span>
                </div>
                <div class="flex flex-col">
                  <span class="text-[#739AB8] text-[9px]">APERTURE / ANGLE</span>
                  <span class="text-[#55C8FF] font-semibold">{{ shot.camera.aperture }} · {{ shot.camera.shutterAngle }}</span>
                </div>
                <div class="flex flex-col">
                  <span class="text-[#739AB8] text-[9px]">CAMERA MOVEMENT</span>
                  <span class="text-[#B9E5FF] truncate" [title]="shot.camera.movement">{{ shot.camera.movement }}</span>
                </div>
                <div class="flex flex-col">
                  <span class="text-[#739AB8] text-[9px]">SENSOR / ISO</span>
                  <span class="text-[#A8DFFF]">{{ shot.camera.sensor }} (ISO {{ shot.camera.iso }})</span>
                </div>
              </div>

              <!-- Lighting & Rigging Setup -->
              <div class="flex flex-col text-[11px]">
                <span class="text-[#739AB8] text-[9px] font-mono-code">LIGHTING SETUP</span>
                <p class="text-[#B9E5FF] line-clamp-2 text-[11px] leading-relaxed">{{ shot.lightingSetup }}</p>
              </div>

              <!-- Dialogue / Director's Beat -->
              <div class="border-t border-[#151C26] pt-2 text-[11px] font-mono-code text-[#A8DFFF]/90 italic line-clamp-2">
                "{{ shot.dialoguePreview }}"
              </div>

              <!-- Action Bar -->
              <div class="flex items-center justify-between pt-1 border-t border-[#151C26]/60">
                <button
                  type="button"
                  (click)="loadInMonitor(shot, $event)"
                  class="text-[11px] font-mono-code text-[#55C8FF] hover:underline flex items-center gap-1"
                >
                  <mat-icon class="text-xs leading-none">play_circle_outline</mat-icon>
                  <span>Load into Monitor</span>
                </button>

                <div class="flex items-center gap-1">
                  <button
                    type="button"
                    (click)="moveShot(shot, -1, $event)"
                    class="p-1 text-[#739AB8] hover:text-[#B9E5FF] rounded transition-colors"
                    title="Move Order Left"
                  >
                    <mat-icon class="text-sm leading-none">chevron_left</mat-icon>
                  </button>
                  <button
                    type="button"
                    (click)="moveShot(shot, 1, $event)"
                    class="p-1 text-[#739AB8] hover:text-[#B9E5FF] rounded transition-colors"
                    title="Move Order Right"
                  >
                    <mat-icon class="text-sm leading-none">chevron_right</mat-icon>
                  </button>
                </div>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class StoryboardView {
  readonly state = inject(StudioState);
  readonly selectedFilter = signal<string>('ALL');

  filteredShots(): Shot[] {
    const filter = this.selectedFilter();
    if (filter === 'ALL') {
      return this.state.shots();
    }
    return this.state.shots().filter((s) => s.sceneNumber === filter);
  }

  onFilterScene(event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.selectedFilter.set(val);
  }

  selectShot(shot: Shot): void {
    this.state.selectShot(shot.id);
  }

  loadInMonitor(shot: Shot, event: MouseEvent): void {
    event.stopPropagation();
    this.state.selectShot(shot.id);
    this.state.activeWorkspace.set('editing');
  }

  moveShot(shot: Shot, delta: number, event: MouseEvent): void {
    event.stopPropagation();
    const current = [...this.state.shots()];
    const idx = current.findIndex((s) => s.id === shot.id);
    if (idx === -1) return;
    const targetIdx = idx + delta;
    if (targetIdx < 0 || targetIdx >= current.length) return;

    const [removed] = current.splice(idx, 1);
    current.splice(targetIdx, 0, removed);
    this.state.shots.set(current);
  }

  addNewShot(): void {
    const count = this.state.shots().length + 1;
    const newShot: Shot = {
      id: 'shot-' + Date.now(),
      sceneNumber: '16A',
      shotCode: `S16A-0${count}`,
      title: 'Monolith Breach Interior',
      description: 'Int. Monolith Sub-Level. Deep obsidian corridors pulsating with pale blue fiber-optic veins.',
      imageSrc: 'assets/images/film_frame_orbital_monolith_1793404716142.jpg',
      durationSeconds: 5.5,
      camera: {
        lens: 'Panavision Primo 21mm Anamorphic',
        aperture: 'T1.9',
        shutterAngle: '180.0°',
        iso: 800,
        sensor: 'Arri Alexa 65',
        movement: 'Steadicam Low Mode Forward Tracking',
        aspectRatio: '2.39:1 CinemaScope',
      },
      lightingSetup: 'Cold cyan ground floor spill, zero fill, silhouette actors.',
      dialoguePreview: 'KAELEN: Do not touch the perimeter glass.',
      status: 'Storyboarded',
    };
    this.state.shots.update((shots) => [...shots, newShot]);
  }
}
