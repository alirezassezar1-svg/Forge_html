import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StudioState } from '../services/studio.state';

@Component({
  selector: 'app-export-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    @if (state.isExportModalOpen()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#000000]/85 backdrop-blur-md select-none">
        <div class="w-full max-w-xl bg-[#050608] border border-[#55C8FF]/50 rounded-2xl shadow-[0_0_40px_rgba(85,200,255,0.15)] overflow-hidden flex flex-col font-mono-code">
          <!-- Modal Header -->
          <div class="flex items-center justify-between px-5 py-3.5 bg-[#000000] border-b border-[#151C26]">
            <div class="flex items-center gap-2.5">
              <mat-icon class="text-base text-[#55C8FF] leading-none">movie_filter</mat-icon>
              <span class="text-sm font-bold tracking-wider text-[#A8DFFF] uppercase">
                DELIVER MASTER // CINEMA DCP & PRORES
              </span>
            </div>
            <button
              type="button"
              (click)="state.isExportModalOpen.set(false)"
              class="text-[#739AB8] hover:text-[#B9E5FF] p-1 rounded transition-colors"
            >
              <mat-icon class="text-base leading-none">close</mat-icon>
            </button>
          </div>

          <!-- Modal Body -->
          <div class="p-6 flex flex-col gap-4 text-xs">
            <!-- Format Preset Selector -->
            <div class="flex flex-col gap-1.5">
              <label for="exportCodec" class="text-[#739AB8] text-[11px] font-semibold">MASTERING ENCODER CODEC</label>
              <select
                id="exportCodec"
                [value]="state.exportSettings().codec"
                (change)="updateSetting('codec', $event)"
                class="bg-[#000000] border border-[#151C26] text-[#B9E5FF] rounded-lg px-3 py-2 outline-none hover:border-[#55C8FF]/40 focus:border-[#55C8FF]"
              >
                <option value="ProRes 4444 XQ">Apple ProRes 4444 XQ (12-bit 4:4:4 RGB Cinema Master)</option>
                <option value="ProRes 422 HQ">Apple ProRes 422 HQ (10-bit Production Master)</option>
                <option value="Avid DNxHR HQX">Avid DNxHR HQX (12-bit Mastering Spec)</option>
                <option value="DCI Cinema DCP 4K">DCI Cinema DCP 4K (JPEG 2000 / SMPTE Package)</option>
              </select>
            </div>

            <!-- Resolution & Aspect Ratio -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div class="flex flex-col gap-1.5">
                <label for="exportResolution" class="text-[#739AB8] text-[11px] font-semibold">CANVAS RESOLUTION</label>
                <select
                  id="exportResolution"
                  [value]="state.exportSettings().resolution"
                  (change)="updateSetting('resolution', $event)"
                  class="bg-[#000000] border border-[#151C26] text-[#B9E5FF] rounded-lg px-3 py-2 outline-none hover:border-[#55C8FF]/40 focus:border-[#55C8FF]"
                >
                  <option value="4096x1716 (2.39:1 CinemaScope)">4096x1716 (2.39:1 CinemaScope)</option>
                  <option value="3840x2160 (16:9 UHD)">3840x2160 (16:9 UHD)</option>
                  <option value="2048x858 (2K Scope)">2048x858 (2K Scope)</option>
                  <option value="1920x1080 (HD)">1920x1080 (HD Preview)</option>
                </select>
              </div>

              <div class="flex flex-col gap-1.5">
                <label for="exportColorSpace" class="text-[#739AB8] text-[11px] font-semibold">COLOR SPACE TRANSFORM</label>
                <select
                  id="exportColorSpace"
                  [value]="state.exportSettings().colorSpace"
                  (change)="updateSetting('colorSpace', $event)"
                  class="bg-[#000000] border border-[#151C26] text-[#B9E5FF] rounded-lg px-3 py-2 outline-none hover:border-[#55C8FF]/40 focus:border-[#55C8FF]"
                >
                  <option value="ACEScc (Cinema Spec)">ACEScc (Cinema Spec)</option>
                  <option value="P3-DCI Cinema">P3-DCI Cinema Laser</option>
                  <option value="Rec.709 (OLED True)">Rec.709 (OLED True Black)</option>
                  <option value="ST 2084 PQ (HDR)">ST 2084 PQ (HDR 1000 nits)</option>
                </select>
              </div>
            </div>

            <!-- Audio & Metadata -->
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div class="flex flex-col gap-1.5">
                <label for="exportAudio" class="text-[#739AB8] text-[11px] font-semibold">AUDIO DISPATCH</label>
                <select
                  id="exportAudio"
                  [value]="state.exportSettings().audioFormat"
                  (change)="updateSetting('audioFormat', $event)"
                  class="bg-[#000000] border border-[#151C26] text-[#B9E5FF] rounded-lg px-3 py-2 outline-none hover:border-[#55C8FF]/40 focus:border-[#55C8FF]"
                >
                  <option value="Linear PCM 24-bit 48kHz (5.1 Surround)">Linear PCM 24-bit 48kHz (5.1 Surround)</option>
                  <option value="Dolby Atmos Cinema Bed">Dolby Atmos Cinema Bed</option>
                  <option value="Stereo 24-bit PCM">Stereo 24-bit PCM</option>
                </select>
              </div>

              <div class="flex flex-col gap-1.5">
                <label for="exportFps" class="text-[#739AB8] text-[11px] font-semibold">FRAME RATE TIMELINE</label>
                <select
                  id="exportFps"
                  [value]="state.exportSettings().frameRate"
                  (change)="updateSetting('frameRate', $event)"
                  class="bg-[#000000] border border-[#151C26] text-[#B9E5FF] rounded-lg px-3 py-2 outline-none hover:border-[#55C8FF]/40 focus:border-[#55C8FF]"
                >
                  <option value="24.00 fps (SMPTE Film)">24.00 fps (SMPTE Film Standard)</option>
                  <option value="23.976 fps">23.976 fps (NTSC Cinema)</option>
                  <option value="48.00 fps (HFR)">48.00 fps (High Frame Rate)</option>
                </select>
              </div>
            </div>

            <!-- Toggles (Burn-in Timecode & Anamorphic) -->
            <div class="flex items-center justify-between p-3 bg-[#090D12] rounded-lg border border-[#151C26]">
              <label class="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  [checked]="state.exportSettings().burnInTimecode"
                  (change)="toggleBurnIn()"
                  class="accent-[#55C8FF]"
                />
                <span class="text-[#B9E5FF] text-xs">Burn-In SMPTE Timecode Window</span>
              </label>

              <span class="text-[10px] text-[#739AB8]">EST. SIZE: ~4.8 GB</span>
            </div>

            <!-- Render Status & Progress Indicator -->
            @if (state.isRendering() || state.renderProgress() > 0) {
              <div class="flex flex-col gap-2 p-3 bg-[#000000] border border-[#151C26] rounded-lg">
                <div class="flex items-center justify-between text-[11px]">
                  <span class="text-[#55C8FF] flex items-center gap-1.5">
                    @if (state.isRendering()) {
                      <span class="w-2 h-2 rounded-full bg-[#55C8FF] animate-pulse"></span>
                      ENCODING ACEScc 4K FRAMES...
                    } @else {
                      <mat-icon class="text-sm leading-none text-[#55C8FF]">check_circle</mat-icon>
                      RENDER COMPLETE · READY FOR ARCHIVE
                    }
                  </span>
                  <span class="text-[#A8DFFF] font-bold">{{ state.renderProgress() }}%</span>
                </div>

                <div class="w-full h-2 bg-[#090D12] border border-[#151C26] rounded-full overflow-hidden">
                  <div
                    class="h-full bg-[#55C8FF] shadow-[0_0_10px_#55C8FF] transition-all duration-150"
                    [style.width.%]="state.renderProgress()"
                  ></div>
                </div>

                <div class="flex items-center justify-between text-[10px] text-[#739AB8]">
                  <span>FRAMES: {{ Math.round((state.renderProgress() / 100) * state.totalFrames()) }} / {{ state.totalFrames() }}</span>
                  <span>BITRATE: ~492 Mbps</span>
                </div>
              </div>
            }
          </div>

          <!-- Modal Footer Actions -->
          <div class="flex items-center justify-end gap-3 px-6 py-3.5 bg-[#000000] border-t border-[#151C26]">
            <button
              type="button"
              (click)="state.isExportModalOpen.set(false)"
              class="px-4 py-2 text-xs font-semibold text-[#739AB8] hover:text-[#B9E5FF] transition-colors"
            >
              Cancel
            </button>

            <button
              type="button"
              [disabled]="state.isRendering()"
              (click)="state.triggerRender()"
              class="px-5 py-2 text-xs font-bold tracking-wider uppercase text-[#B9E5FF] bg-[#000000] border border-[#55C8FF] hover:shadow-[0_0_16px_rgba(85,200,255,0.4)] active:scale-95 disabled:opacity-50 rounded-lg transition-all flex items-center gap-2"
            >
              <mat-icon class="text-sm leading-none text-[#55C8FF]">cloud_upload</mat-icon>
              <span>{{ state.isRendering() ? 'Rendering Master...' : 'Start Render' }}</span>
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class ExportModal {
  readonly state = inject(StudioState);
  readonly Math = Math;

  updateSetting(key: keyof import('../models/studio.model').ExportSettings, event: Event): void {
    const val = (event.target as HTMLSelectElement).value;
    this.state.exportSettings.update((curr) => ({
      ...curr,
      [key]: val,
    }));
  }

  toggleBurnIn(): void {
    this.state.exportSettings.update((curr) => ({
      ...curr,
      burnInTimecode: !curr.burnInTimecode,
    }));
  }
}
