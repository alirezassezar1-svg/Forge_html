# VOID CINEMA — Professional Post-Production & Film Studio
## With VOID AI: Personal AI Film Director & Studio Agent
### Design System: Obsidian Ice

VOID CINEMA is a high-end cinematic filmmaking workstation with an extreme pure black (`#000000`) OLED aesthetic and pale neon ice-blue typography (`#A8DFFF`, `#B9E5FF`, `#55C8FF`).

It includes **VOID AI**, an autonomous, bilingual (Persian & English) film director and studio agent operating under a strict **Human-in-the-Loop** mode with real tool calling capabilities connected to the studio's state and rendering engines.

---

## 1. Key Capabilities

### A. VOID AI Film Director Agent
- **Bilingual Natural Language & Voice**:
  - Automatically detects Persian (`fa-IR`) and English (`en-US`).
  - Supports RTL layouts for Persian text and LTR for English.
  - Browser-native speech recognition (`SpeechRecognition`) and text-to-speech (`SpeechSynthesis`) with interruptible voice feedback and Safari fallbacks.
- **Human-in-the-Loop Operating Mode**:
  - Understands director intentions before modifying the project.
  - Formulates a structured execution plan with distinct technical operations.
  - Presents interactive **Approval Cards** with status badges and parameter previews.
  - Executes operations sequentially upon approval.
  - Supports on-the-fly workflow cancellation.
  - Reports honest operation success and error metrics.
- **Direct Application State Awareness**:
  - Reads real studio timecodes, tracks, clips, screenplay lines, storyboard setups, and audio fader levels.

---

## 2. Centralized Tool Calling Registry

VOID AI accesses real application capabilities across 32 dedicated tools:

| Category | Tools | Description |
|---|---|---|
| **Project** | `get_project_state`, `update_project_title`, `save_project`, `load_project`, `reset_project` | Complete project metadata, persistence to browser localStorage, and baseline reset. |
| **Screenplay** | `get_screenplay`, `write_screenplay`, `rewrite_screenplay`, `split_story_into_scenes`, `update_scene_text` | Hollywood-standard shooting script editor, automatic beat division, and scene sluglines. |
| **Storyboard** | `get_storyboard`, `create_scene_shot`, `delete_scene_shot`, `update_scene_shot`, `set_shot_duration` | Optics packages (e.g. Panavision Anamorphic T1.4, Atlas Orion), lighting setups, and shot duration. |
| **Timeline** | `get_timeline`, `add_timeline_clip`, `split_clip`, `move_clip`, `set_track_mute`, `set_track_solo` | Multi-track timeline (V1, V2, A1, A2) with razor blade splitting and magnetic snapping. |
| **Audio** | `get_audio_state`, `set_audio_volume`, `set_audio_pan`, `toggle_audio_mute`, `toggle_audio_solo` | 5.1 console faders (-60 to +6 dB), animated ice-blue LED VU meters, and pan controls. |
| **Subtitles** | `get_subtitles`, `generate_subtitles`, `update_subtitles` | Real-time bilingual English & Persian subtitles with on-screen CinemaScope banner overlay. |
| **Mastering** | `get_render_settings`, `update_render_settings`, `export_video` | Apple ProRes 4444 XQ, ProRes 422 HQ, DCI Cinema DCP 4K, and ACEScc color space export. |

---

## 3. Architecture & Tech Stack

- **Framework**: Angular 21 (Zoneless, Standalone Components, Signal State Architecture)
- **Styling**: Tailwind CSS v4 + Pure Black OLED / Obsidian Ice tokens
- **Backend / SSR**: Express 5 on Node.js with Angular SSR (`AngularNodeAppEngine`)
- **AI Engine**: `@google/genai` TypeScript SDK (`gemini-3.8-flash`) + Local Deterministic Semantic Planner fallback for offline/no-key reliability
- **Audio & Media**: Web Audio APIs, native speech synthesis, HTML5 range faders, and high-resolution anamorphic 2.39:1 film stills

---

## 4. Setup & Running Locally

### Prerequisites
- Node.js >= 20.x
- npm >= 10.x

### Quickstart
```bash
# 1. Install dependencies
npm install

# 2. Configure environment (optional, automatically provided in AI Studio)
cp .env.example .env
# Set GEMINI_API_KEY in .env if running outside AI Studio

# 3. Launch Development Server (port 3000)
npm run dev

# 4. Production Build & SSR
npm run build
```

---

## 5. Bilingual Test Commands

### Persian (`fa-IR`):
1. `این داستان رو به ۶ صحنه سینمایی تبدیل کن.` (Divides screenplay into 6 cinematic scenes)
2. `صحنه سوم رو سینماییتر کن و نورپردازی نئون فیروزه‌ای اضافه کن.` (Upgrades optic and lighting on scene 3)
3. `زیرنویس فارسی و انگلیسی برای فیلم اضافه کن.` (Generates and enables bilingual subtitles)
4. `موسیقی رو با ریتم فیلم هماهنگ کن و صدای دیالوگ رو بالانس کن.` (Calibrates A1 dialogue and A2 score faders)
5. `پایپ‌لاین خروجی رو روی Apple ProRes 4444 XQ تنظیم کن.` (Configures master export settings)
6. `پروژه رو در حافظه مرورگر ذخیره کن.` (Persists project snapshot)

### English (`en-US`):
1. `Convert this screenplay into 8 dramatic scenes.`
2. `Improve the pacing of scene three to 6.2 seconds.`
3. `Generate bilingual subtitles and show on monitor.`
4. `Set master audio limiter and adjust score volume to -7 dB.`
5. `Prepare project for 4K CinemaScope export.`
