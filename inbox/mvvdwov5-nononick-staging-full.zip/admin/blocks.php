<?php
/**
 * Nononik Admin — مدیریت بلوک‌ها
 * اضافه/کم/جابه‌جا کردن کامپوننت و ابزار در صفحهٔ اصلی، فوتر و داشبورد؛
 * با پیست کد یا ورود از لینک؛ پیش‌نمایش ایزوله و برگشت به نسخهٔ قبل.
 */
require_once __DIR__ . '/includes/auth.php';
require_permission('blocks.manage');

$schemaOk  = blocks_ensure_schema();
$pageTitle = 'بلوک‌ها';

/* ------------------------------------------------------------------ */
/*  کمکی‌ها                                                            */
/* ------------------------------------------------------------------ */

/** ورودی فرم را اعتبارسنجی می‌کند: [داده، پیام خطا] */
function nb_collect(array $in): array
{
    $title   = trim((string) ($in['title'] ?? ''));
    $zone    = (string) ($in['zone'] ?? '');
    $kind    = (string) ($in['kind'] ?? 'html');
    $content = str_replace("\r\n", "\n", (string) ($in['content'] ?? ''));
    $url     = trim((string) ($in['source_url'] ?? ''));
    $display = (string) ($in['display'] ?? 'card');
    $height  = (int) ($in['embed_height'] ?? 480);

    if ($title === '' || mb_strlen($title) > 190) {
        return [null, 'عنوان الزامی است و حداکثر ۱۹۰ نویسه.'];
    }
    if (!blocks_zone_valid($zone)) {
        return [null, 'ناحیهٔ انتخاب‌شده معتبر نیست.'];
    }
    if (!in_array($kind, ['html', 'link'], true)) {
        return [null, 'نوع بلوک معتبر نیست.'];
    }
    if (!in_array($display, ['card', 'embed', 'both'], true)) {
        $display = 'card';
    }
    $height = max(120, min(2000, $height));

    if ($zone === 'home_page' && $kind !== 'html') {
        return [null, 'برای «جایگزین کل صفحهٔ اصلی» فقط بلوک کد (HTML) مجاز است.'];
    }
    if ($kind === 'link') {
        if (blocks_safe_url($url) === null) {
            return [null, 'آدرس لینک باید یک آدرس معتبر با https باشد.'];
        }
        $content = null;
    } else {
        if (trim($content) === '') {
            return [null, 'کد (HTML) نمی‌تواند خالی باشد.'];
        }
        if (strlen($content) > BLOCK_MAX_BYTES) {
            return [null, 'حجم کد بیشتر از ۲ مگابایت است.'];
        }
        if ($url !== '' && blocks_safe_url($url) === null) {
            return [null, 'لینک مرجع باید یک آدرس معتبر با https باشد.'];
        }
    }
    return [[
        'title' => $title, 'zone' => $zone, 'kind' => $kind, 'content' => $content,
        'source_url' => $url !== '' ? $url : null, 'display' => $display, 'embed_height' => $height,
        'isolated' => !empty($in['isolated']) ? 1 : 0, 'is_active' => !empty($in['is_active']) ? 1 : 0,
    ], null];
}

function nb_next_order(string $zone): int
{
    $st = db()->prepare('SELECT COALESCE(MAX(`sort_order`), 0) + 10 FROM `blocks` WHERE `zone` = ?');
    $st->execute([$zone]);
    return (int) $st->fetchColumn();
}

function nb_get(int $id): ?array
{
    $st = db()->prepare('SELECT * FROM `blocks` WHERE `id` = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}

/** دکمه‌ای که با یک فرم POST کوچک اکشن را اجرا می‌کند. */
function nb_btn(string $action, int $id, string $icon, string $title, array $extra = [], string $confirm = '', string $style = ''): string
{
    $h = '<form method="post" class="nb-inline"' . ($confirm !== '' ? ' onsubmit="return confirm(\'' . e($confirm) . '\')"' : '') . '>'
        . '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">'
        . '<input type="hidden" name="action" value="' . e($action) . '">'
        . '<input type="hidden" name="id" value="' . $id . '">';
    foreach ($extra as $k => $v) {
        $h .= '<input type="hidden" name="' . e($k) . '" value="' . e((string) $v) . '">';
    }
    return $h . '<button type="submit" class="btn-icon btn-sm" title="' . e($title) . '" style="' . e($style) . '"><i class="' . e($icon) . '"></i></button></form>';
}

/* ------------------------------------------------------------------ */
/*  عملیات (POST)                                                      */
/* ------------------------------------------------------------------ */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $schemaOk) {
    $action = (string) ($_POST['action'] ?? '');

    // ---- جابه‌جایی با کشیدن و رها کردن (AJAX) ----
    if ($action === 'reorder') {
        header('Content-Type: application/json; charset=utf-8');
        if (!hash_equals($_SESSION['csrf_token'] ?? '', (string) ($_POST['csrf_token'] ?? ''))) {
            http_response_code(419);
            echo json_encode(['ok' => false, 'error' => 'csrf']);
            exit;
        }
        $lists = json_decode((string) ($_POST['lists'] ?? ''), true);
        if (!is_array($lists)) {
            echo json_encode(['ok' => false, 'error' => 'bad-input']);
            exit;
        }
        $rejected = false;
        $kindSt = db()->prepare('SELECT `kind` FROM `blocks` WHERE `id` = ?');
        $upSt   = db()->prepare('UPDATE `blocks` SET `zone` = ?, `sort_order` = ? WHERE `id` = ?');
        foreach ($lists as $zone => $ids) {
            if (!blocks_zone_valid((string) $zone) || !is_array($ids)) {
                continue;
            }
            $n = 10;
            foreach ($ids as $bid) {
                $bid = (int) $bid;
                $kindSt->execute([$bid]);
                $kind = $kindSt->fetchColumn();
                if ($kind === false) {
                    continue;
                }
                if ($zone === 'home_page' && $kind !== 'html') {
                    $rejected = true; // بلوک لینک نمی‌تواند کل صفحه شود
                    continue;
                }
                $upSt->execute([$zone, $n, $bid]);
                $n += 10;
            }
        }
        echo json_encode(['ok' => !$rejected, 'error' => $rejected ? 'link-not-allowed-in-home_page' : null]);
        exit;
    }

    csrf_check();

    if ($action === 'save') {
        $id = (int) ($_POST['id'] ?? 0);
        [$d, $err] = nb_collect($_POST);
        if ($err) {
            set_flash('error', $err);
            redirect($id ? "blocks.php?edit={$id}" : 'blocks.php?new=1');
        }
        if ($id) {
            $old = nb_get($id);
            if (!$old) {
                set_flash('error', 'بلوک پیدا نشد.');
                redirect('blocks.php');
            }
            blocks_save_version($id);
            $order = $old['zone'] === $d['zone'] ? (int) $old['sort_order'] : nb_next_order($d['zone']);
            db()->prepare('UPDATE `blocks` SET `title`=?, `zone`=?, `kind`=?, `content`=?, `source_url`=?, `display`=?, `embed_height`=?, `isolated`=?, `is_active`=?, `sort_order`=? WHERE `id`=?')
                ->execute([$d['title'], $d['zone'], $d['kind'], $d['content'], $d['source_url'], $d['display'], $d['embed_height'], $d['isolated'], $d['is_active'], $order, $id]);
            set_flash('success', 'بلوک ذخیره شد. نسخهٔ قبلی در «تاریخچه» نگه داشته شد.');
        } else {
            db()->prepare('INSERT INTO `blocks` (`title`,`zone`,`kind`,`content`,`source_url`,`display`,`embed_height`,`isolated`,`is_active`,`sort_order`) VALUES (?,?,?,?,?,?,?,?,?,?)')
                ->execute([$d['title'], $d['zone'], $d['kind'], $d['content'], $d['source_url'], $d['display'], $d['embed_height'], $d['isolated'], $d['is_active'], nb_next_order($d['zone'])]);
            set_flash('success', 'بلوک جدید اضافه شد.');
        }
        redirect('blocks.php');
    }

    if ($action === 'import') {
        $url   = trim((string) ($_POST['import_url'] ?? ''));
        $zone  = (string) ($_POST['zone'] ?? 'home_bottom');
        $title = trim((string) ($_POST['title'] ?? ''));
        if (!blocks_zone_valid($zone)) {
            $zone = 'home_bottom';
        }
        try {
            $content = blocks_fetch_url($url);
        } catch (RuntimeException $e) {
            security_log('blocks_import_failed', $e->getMessage());
            set_flash('error', $e->getMessage());
            redirect('blocks.php');
        }
        if ($title === '') {
            if (preg_match('~<title[^>]*>(.*?)</title>~is', $content, $m) && trim(strip_tags($m[1])) !== '') {
                $title = mb_substr(trim(html_entity_decode(strip_tags($m[1]), ENT_QUOTES, 'UTF-8')), 0, 190);
            } else {
                $title = (string) (parse_url(blocks_normalize_source_url($url), PHP_URL_HOST) ?: 'بلوک واردشده');
            }
        }
        // چرا: بلوکِ واردشده همیشه «پیش‌نویس» (غیرفعال) ساخته می‌شود تا ادمین اول پیش‌نمایش ببیند
        db()->prepare('INSERT INTO `blocks` (`title`,`zone`,`kind`,`content`,`source_url`,`display`,`embed_height`,`isolated`,`is_active`,`sort_order`) VALUES (?,?,?,?,?,?,?,?,0,?)')
            ->execute([$title, $zone, 'html', $content, blocks_normalize_source_url($url), 'card', 480, !empty($_POST['isolated']) ? 1 : 0, nb_next_order($zone)]);
        $newId = (int) db()->lastInsertId();
        security_log('blocks_import', "id={$newId} url=" . blocks_normalize_source_url($url));
        set_flash('success', 'از لینک گرفته شد و به‌صورت پیش‌نویس (غیرفعال) ذخیره شد. پیش‌نمایش را ببینید، بعد «فعال‌سازی» را بزنید.');
        redirect("blocks.php?preview={$newId}");
    }

    if ($action === 'refresh') {
        $id = (int) ($_POST['id'] ?? 0);
        $b  = nb_get($id);
        if (!$b || $b['kind'] !== 'html' || !$b['source_url']) {
            set_flash('error', 'این بلوک لینک مرجع ندارد.');
            redirect('blocks.php');
        }
        try {
            $content = blocks_fetch_url((string) $b['source_url']);
        } catch (RuntimeException $e) {
            security_log('blocks_refresh_failed', $e->getMessage());
            set_flash('error', $e->getMessage());
            redirect('blocks.php');
        }
        blocks_save_version($id);
        db()->prepare('UPDATE `blocks` SET `content` = ? WHERE `id` = ?')->execute([$content, $id]);
        security_log('blocks_refresh', "id={$id}");
        set_flash('success', 'محتوا از لینک بروزرسانی شد. نسخهٔ قبلی در «تاریخچه» هست.');
        redirect('blocks.php');
    }

    if ($action === 'toggle') {
        $id = (int) ($_POST['id'] ?? 0);
        $to = !empty($_POST['to']) ? 1 : 0;
        db()->prepare('UPDATE `blocks` SET `is_active` = ? WHERE `id` = ?')->execute([$to, $id]);
        set_flash('success', $to ? 'بلوک فعال شد و روی سایت دیده می‌شود.' : 'بلوک غیرفعال شد.');
        redirect('blocks.php');
    }

    if ($action === 'move') {
        $id  = (int) ($_POST['id'] ?? 0);
        $dir = ($_POST['dir'] ?? '') === 'up' ? -1 : 1;
        $b   = nb_get($id);
        if ($b) {
            blocks_renumber_zone($b['zone']);
            $st = db()->prepare('SELECT `id` FROM `blocks` WHERE `zone` = ? ORDER BY `sort_order` ASC, `id` ASC');
            $st->execute([$b['zone']]);
            $ids = array_map('intval', array_column($st->fetchAll(), 'id'));
            $i = array_search($id, $ids, true);
            $j = $i === false ? false : $i + $dir;
            if ($i !== false && $j >= 0 && $j < count($ids)) {
                [$ids[$i], $ids[$j]] = [$ids[$j], $ids[$i]];
                $up = db()->prepare('UPDATE `blocks` SET `sort_order` = ? WHERE `id` = ?');
                foreach ($ids as $k => $bid) {
                    $up->execute([($k + 1) * 10, $bid]);
                }
            }
        }
        redirect('blocks.php#zone-' . ($b['zone'] ?? ''));
    }

    if ($action === 'set_zone') {
        $id   = (int) ($_POST['id'] ?? 0);
        $zone = (string) ($_POST['zone'] ?? '');
        $b    = nb_get($id);
        if (!$b || !blocks_zone_valid($zone)) {
            set_flash('error', 'ناحیه معتبر نیست.');
        } elseif ($zone === 'home_page' && $b['kind'] !== 'html') {
            set_flash('error', 'بلوک لینک نمی‌تواند «جایگزین کل صفحهٔ اصلی» شود.');
        } else {
            db()->prepare('UPDATE `blocks` SET `zone` = ?, `sort_order` = ? WHERE `id` = ?')->execute([$zone, nb_next_order($zone), $id]);
            set_flash('success', 'بلوک به ناحیهٔ جدید منتقل شد.');
        }
        redirect('blocks.php');
    }

    if ($action === 'delete') {
        $id = (int) ($_POST['id'] ?? 0);
        $b  = nb_get($id);
        db()->prepare('DELETE FROM `block_versions` WHERE `block_id` = ?')->execute([$id]);
        db()->prepare('DELETE FROM `blocks` WHERE `id` = ?')->execute([$id]);
        if ($b) {
            blocks_renumber_zone($b['zone']);
        }
        set_flash('success', 'بلوک حذف شد.');
        redirect('blocks.php');
    }

    if ($action === 'restore') {
        $id  = (int) ($_POST['id'] ?? 0);
        $vid = (int) ($_POST['version_id'] ?? 0);
        $st  = db()->prepare('SELECT * FROM `block_versions` WHERE `id` = ? AND `block_id` = ?');
        $st->execute([$vid, $id]);
        $v = $st->fetch();
        if (!$v || !nb_get($id)) {
            set_flash('error', 'نسخه پیدا نشد.');
            redirect('blocks.php');
        }
        blocks_save_version($id);
        db()->prepare('UPDATE `blocks` SET `title` = ?, `content` = ?, `source_url` = ? WHERE `id` = ?')
            ->execute([$v['title'], $v['content'], $v['source_url'], $id]);
        set_flash('success', 'به نسخهٔ انتخاب‌شده برگشت. وضعیت فعلیِ قبل از برگشت هم در تاریخچه ماند.');
        redirect('blocks.php?history=' . $id);
    }

    if ($action === 'save_hosts') {
        $lines = preg_split('/[\s,]+/', strtolower((string) ($_POST['hosts'] ?? '')), -1, PREG_SPLIT_NO_EMPTY) ?: [];
        $valid = [];
        $bad   = [];
        foreach ($lines as $l) {
            if (preg_match('/^(\*\.)?([a-z0-9-]+\.)+[a-z]{2,}$/', $l)) {
                $valid[] = $l;
            } else {
                $bad[] = $l;
            }
        }
        if ($bad) {
            set_flash('error', 'این موارد دامنهٔ معتبر نیستند: ' . implode('، ', $bad));
        } else {
            set_setting('blocks_allowed_hosts', implode("\n", array_unique($valid)));
            set_flash('success', 'دامنه‌های مجاز ذخیره شد.');
        }
        redirect('blocks.php#hosts');
    }

    redirect('blocks.php');
}

/* ------------------------------------------------------------------ */
/*  نمای پیش‌نمایش (صفحهٔ مستقل و ایزوله)                              */
/* ------------------------------------------------------------------ */

if ($schemaOk && (isset($_GET['preview']) || isset($_GET['preview_version']))) {
    $b = null;
    $label = '';
    if (isset($_GET['preview'])) {
        $b = nb_get((int) $_GET['preview']);
        $label = 'پیش‌نمایش';
    } else {
        $st = db()->prepare('SELECT v.*, b.zone, b.kind, b.display, b.embed_height FROM `block_versions` v JOIN `blocks` b ON b.id = v.block_id WHERE v.id = ?');
        $st->execute([(int) $_GET['preview_version']]);
        $b = $st->fetch() ?: null;
        $label = 'پیش‌نمایش نسخهٔ قدیمی';
    }
    if (!$b) {
        set_flash('error', 'بلوک پیدا نشد.');
        redirect('blocks.php');
    }
    $isFull = ($b['zone'] ?? '') === 'home_page';
    $backId = (int) ($b['block_id'] ?? $b['id']);
    ?><!DOCTYPE html>
<html lang="fa" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow"><title><?= e($label) ?> | <?= e($b['title']) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
body{margin:0;background:#0e0b1f;color:#fff;font-family:system-ui,Vazirmatn,sans-serif}
.bar{position:sticky;top:0;z-index:5;display:flex;flex-wrap:wrap;gap:10px;align-items:center;padding:10px 14px;background:#1a1533;border-bottom:1px solid rgba(255,255,255,.1)}
.bar a,.bar button{color:#fff;background:rgba(139,92,246,.35);border:0;border-radius:999px;padding:8px 14px;text-decoration:none;font:inherit;font-size:13px;cursor:pointer}
.bar span{font-size:13px;opacity:.8;flex:1;min-width:140px}
.stage{padding:<?= $isFull ? '0' : '18px 14px' ?>}
.nb-frame{display:block;width:100%;border:0;border-radius:<?= $isFull ? '0' : '16px' ?>;background:#fff}
.nb-card{display:flex;align-items:center;gap:14px;padding:16px;border-radius:18px;text-decoration:none;color:inherit;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.06)}
.nb-card-ic{width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:rgba(139,92,246,.22)}
.nb-card-tx{flex:1;display:flex;flex-direction:column}.nb-card-tx small{opacity:.65}
.nb-card-go{padding:7px 14px;border-radius:999px;background:rgba(139,92,246,.28);font-size:12.5px}
.nb-note{font-size:12px;opacity:.65}
</style></head><body>
<div class="bar">
  <a href="blocks.php">← بازگشت</a>
  <span><?= e($label) ?> ایزوله — «<?= e($b['title']) ?>» · این پیش‌نمایش جدا از سایت و پنل اجرا می‌شود.</span>
  <?php if (isset($_GET['preview']) && empty($b['is_active'])): ?>
  <form method="post" action="blocks.php" style="margin:0">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= (int) $b['id'] ?>"><input type="hidden" name="to" value="1">
    <button type="submit"><i class="fa-solid fa-circle-check"></i> فعال‌سازی روی سایت</button>
  </form>
  <?php endif; ?>
  <?php if (isset($_GET['preview_version'])): ?>
  <form method="post" action="blocks.php" style="margin:0" onsubmit="return confirm('به این نسخه برگردد؟')">
    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
    <input type="hidden" name="action" value="restore"><input type="hidden" name="id" value="<?= $backId ?>"><input type="hidden" name="version_id" value="<?= (int) $_GET['preview_version'] ?>">
    <button type="submit"><i class="fa-solid fa-rotate-left"></i> برگشت به این نسخه</button>
  </form>
  <?php endif; ?>
</div>
<div class="stage">
<?php
    $pv = $b;
    if ($isFull) {
        $pv['embed_height'] = 2000;
    }
    echo blocks_render_one($pv, true);
    ?>
</div>
<?php if ($isFull): ?><script>document.querySelector('.nb-frame').style.height = (window.innerHeight - 52) + 'px';</script><?php endif; ?>
</body></html><?php
    exit;
}

/* ------------------------------------------------------------------ */
/*  داده‌های صفحه                                                       */
/* ------------------------------------------------------------------ */

$view = 'list';
$edit = null;
if ($schemaOk && isset($_GET['edit'])) {
    $edit = nb_get((int) $_GET['edit']);
    if (!$edit) {
        set_flash('error', 'بلوک پیدا نشد.');
        redirect('blocks.php');
    }
    $view = 'form';
} elseif ($schemaOk && isset($_GET['new'])) {
    $view = 'form';
    $z = (string) ($_GET['zone'] ?? 'home_bottom');
    $edit = [
        'id' => 0, 'title' => '', 'zone' => blocks_zone_valid($z) ? $z : 'home_bottom', 'kind' => 'html', 'content' => '',
        'source_url' => '', 'display' => 'card', 'embed_height' => 480, 'isolated' => 0, 'is_active' => 1,
    ];
} elseif ($schemaOk && isset($_GET['history'])) {
    $edit = nb_get((int) $_GET['history']);
    if (!$edit) {
        redirect('blocks.php');
    }
    $view = 'history';
}

$grouped = [];
$versionCounts = [];
if ($schemaOk && $view === 'list') {
    foreach (array_keys(BLOCK_ZONES) as $z) {
        $grouped[$z] = [];
    }
    $rows = db()->query('SELECT `id`,`title`,`zone`,`kind`,`display`,`source_url`,`isolated`,`is_active`,`sort_order`,`updated_at`, LENGTH(`content`) AS size FROM `blocks` ORDER BY `sort_order` ASC, `id` ASC')->fetchAll();
    foreach ($rows as $r) {
        $grouped[$r['zone']][] = $r;
    }
    foreach (db()->query('SELECT `block_id`, COUNT(*) c FROM `block_versions` GROUP BY `block_id`')->fetchAll() as $r) {
        $versionCounts[(int) $r['block_id']] = (int) $r['c'];
    }
}

require __DIR__ . '/includes/header.php';
?>
<style>
.nb-note-box{font-size:13px;line-height:1.9;color:var(--text-2)}
.nb-zone h3{margin:0}
.nb-zone .zone-tag{font-size:11.5px;color:var(--text-2);margin-top:2px}
.nb-list{list-style:none;margin:14px 0 0;padding:0;display:flex;flex-direction:column;gap:10px;min-height:44px}
.nb-item{display:flex;flex-wrap:wrap;align-items:center;gap:10px;padding:12px 14px;border-radius:14px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.04)}
.nb-item.dragging{opacity:.45}
.nb-item.off{opacity:.62}
.nb-grip{cursor:grab;color:var(--text-2);padding:0 4px;touch-action:none}
.nb-main{flex:1;min-width:150px}
.nb-main b{display:block;font-size:14px}
.nb-chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:4px}
.nb-chip{font-size:11px;padding:2px 9px;border-radius:999px;background:rgba(139,92,246,.2)}
.nb-chip.off{background:rgba(248,113,113,.2)}.nb-chip.on{background:rgba(52,211,153,.2)}
.nb-actions{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
.nb-inline{display:inline;margin:0}
.nb-actions select{max-width:150px;font-size:12px;padding:6px 8px}
.nb-empty{font-size:12.5px;color:var(--text-2);padding:10px 2px}
.nb-form textarea{font-family:ui-monospace,Menlo,monospace;font-size:12.5px;direction:ltr;text-align:left;min-height:260px}
.nb-form .row2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
@media(max-width:640px){.nb-form .row2{grid-template-columns:1fr}}
</style>
<div class="app">
    <?php require __DIR__ . '/includes/sidebar.php'; ?>
    <div class="main">
        <?php require __DIR__ . '/includes/topbar.php'; ?>
        <div class="content">
            <?php if ($f = get_flash()): ?>
                <div class="alert alert-<?= $f['type'] === 'success' ? 'success' : 'error' ?>"><i class="fa-solid fa-circle-check"></i> <?= e($f['message']) ?></div>
            <?php endif; ?>

            <?php if (!$schemaOk): ?>
            <div class="alert alert-error">ساخت جدول‌های بلوک‌ها ناموفق بود. دسترسی کاربر دیتابیس برای ساخت جدول (CREATE) را بررسی کنید؛ جزئیات در logs/security.log هست.</div>
            <?php elseif ($view === 'list'): ?>

            <div class="page-head">
                <div><h2>بلوک‌ها</h2><p class="breadcrumb">پنل <b>/ بلوک‌ها</b></p></div>
                <a class="btn btn-primary" style="width:auto" href="blocks.php?new=1"><i class="fa-solid fa-plus"></i> بلوک جدید</a>
            </div>

            <div class="card glass" style="margin-bottom:18px;">
                <div class="card-head"><h3>چطور کار می‌کند؟</h3></div>
                <div class="nb-note-box">
                    هر بلوک یک تکه از سایت است: <b>کد</b> (HTML/CSS/JS که پیست می‌کنید) یا <b>لینک</b> (نمایش به‌صورت کارت، کادر داخل صفحه، یا هر دو).
                    بلوک را در یکی از ناحیه‌های پایین می‌گذارید و با ▲▼ یا کشیدن جابه‌جا می‌کنید.
                    «گرفتن از لینک» یک <b>اسنپ‌شات</b> می‌گیرد و پیش‌نویس می‌سازد؛ تا شما فعالش نکنید روی سایت دیده نمی‌شود.
                    هر تغییر، نسخهٔ قبلی را در «تاریخچه» نگه می‌دارد. پیش‌نمایش‌ها همیشه جدا از سایت و پنل اجرا می‌شوند.
                </div>
            </div>

            <div class="card glass" style="margin-bottom:18px;">
                <div class="card-head"><h3><i class="fa-solid fa-link"></i> گرفتن از لینک</h3></div>
                <form method="post" class="nb-form">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="import">
                    <div class="form-group"><label>لینک فایل (https) — لینک صفحهٔ GitHub هم قبول است</label>
                        <input type="url" name="import_url" class="form-control" dir="ltr" placeholder="https://raw.githubusercontent.com/user/repo/main/footer.html" required></div>
                    <div class="row2">
                        <div class="form-group"><label>عنوان (اختیاری)</label><input type="text" name="title" class="form-control" placeholder="اگر خالی باشد از تگ title خوانده می‌شود"></div>
                        <div class="form-group"><label>ناحیه</label>
                            <select name="zone" class="form-control">
                                <?php foreach (BLOCK_ZONES as $zk => $zl): ?><option value="<?= e($zk) ?>" <?= $zk === 'home_bottom' ? 'selected' : '' ?>><?= e($zl) ?></option><?php endforeach; ?>
                            </select></div>
                    </div>
                    <div class="form-group"><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="isolated" value="1" checked> نمایش داخل کادر ایزوله (امن‌تر؛ برای محتوای واردشده پیشنهاد می‌شود. برای «جایگزین کل صفحه» اثری ندارد)</label></div>
                    <button type="submit" class="btn btn-primary" style="width:auto"><i class="fa-solid fa-cloud-arrow-down"></i> بگیر و پیش‌نویس بساز</button>
                </form>
            </div>

            <?php foreach (BLOCK_ZONES as $zk => $zl): ?>
            <div class="card glass nb-zone" id="zone-<?= e($zk) ?>" style="margin-bottom:18px;">
                <div class="card-head">
                    <div><h3><?= e($zl) ?></h3>
                        <?php if ($zk === 'home_page'): ?><div class="zone-tag">اگر یک بلوک فعال اینجا باشد، کل صفحهٔ اصلی با آن عوض می‌شود (فقط اولی). برای دیدن صفحهٔ قبلی: <span dir="ltr">/?classic=1</span> (فقط وقتی وارد پنل هستید)</div><?php endif; ?>
                    </div>
                    <a class="link" href="blocks.php?new=1&zone=<?= e($zk) ?>">+ افزودن</a>
                </div>
                <ul class="nb-list" data-zone="<?= e($zk) ?>">
                    <?php foreach ($grouped[$zk] as $b): $bid = (int) $b['id']; ?>
                    <li class="nb-item <?= $b['is_active'] ? '' : 'off' ?>" data-id="<?= $bid ?>" draggable="true">
                        <span class="nb-grip" title="بکشید"><i class="fa-solid fa-grip-vertical"></i></span>
                        <div class="nb-main">
                            <b><?= e($b['title']) ?></b>
                            <div class="nb-chips">
                                <span class="nb-chip"><?= $b['kind'] === 'link' ? 'لینک · ' . ['card' => 'کارت', 'embed' => 'کادر', 'both' => 'کارت+کادر'][$b['display']] : 'کد' ?></span>
                                <?php if ($b['kind'] === 'html' && $b['isolated']): ?><span class="nb-chip">ایزوله</span><?php endif; ?>
                                <?php if ($b['kind'] === 'html'): ?><span class="nb-chip"><?= number_format(((int) $b['size']) / 1024, 1) ?> KB</span><?php endif; ?>
                                <span class="nb-chip <?= $b['is_active'] ? 'on' : 'off' ?>"><?= $b['is_active'] ? 'فعال' : 'پیش‌نویس/غیرفعال' ?></span>
                            </div>
                        </div>
                        <div class="nb-actions">
                            <?= nb_btn('move', $bid, 'fa-solid fa-chevron-up', 'بالا', ['dir' => 'up']) ?>
                            <?= nb_btn('move', $bid, 'fa-solid fa-chevron-down', 'پایین', ['dir' => 'down']) ?>
                            <form method="post" class="nb-inline">
                                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                                <input type="hidden" name="action" value="set_zone"><input type="hidden" name="id" value="<?= $bid ?>">
                                <select name="zone" class="form-control" onchange="this.form.submit()" title="انتقال به ناحیه">
                                    <?php foreach (BLOCK_ZONES as $zk2 => $zl2): ?><option value="<?= e($zk2) ?>" <?= $zk2 === $zk ? 'selected' : '' ?>><?= e($zl2) ?></option><?php endforeach; ?>
                                </select>
                            </form>
                            <?= $b['is_active']
                                ? nb_btn('toggle', $bid, 'fa-solid fa-eye-slash', 'غیرفعال کن', ['to' => 0])
                                : nb_btn('toggle', $bid, 'fa-solid fa-circle-check', 'فعال کن', ['to' => 1], '', 'color:#34d399') ?>
                            <a class="btn-icon btn-sm" href="blocks.php?preview=<?= $bid ?>" title="پیش‌نمایش ایزوله"><i class="fa-solid fa-eye"></i></a>
                            <a class="btn-icon btn-sm" href="blocks.php?edit=<?= $bid ?>" title="ویرایش"><i class="fa-solid fa-pen"></i></a>
                            <?php if (!empty($versionCounts[$bid])): ?>
                            <a class="btn-icon btn-sm" href="blocks.php?history=<?= $bid ?>" title="تاریخچه (<?= $versionCounts[$bid] ?>)"><i class="fa-solid fa-clock-rotate-left"></i></a>
                            <?php endif; ?>
                            <?php if ($b['kind'] === 'html' && $b['source_url']): ?>
                            <?= nb_btn('refresh', $bid, 'fa-solid fa-cloud-arrow-down', 'بروزرسانی از لینک', [], 'محتوا از لینک دوباره گرفته می‌شود و جایگزین کد فعلی می‌شود (نسخهٔ قبلی در تاریخچه می‌ماند). ادامه؟') ?>
                            <?php endif; ?>
                            <?= nb_btn('delete', $bid, 'fa-solid fa-trash', 'حذف', [], 'این بلوک و تاریخچه‌اش حذف شود؟', 'color:#f87171') ?>
                        </div>
                    </li>
                    <?php endforeach; ?>
                    <?php if (!$grouped[$zk]): ?><li class="nb-empty" data-empty>بلوکی اینجا نیست.</li><?php endif; ?>
                </ul>
            </div>
            <?php endforeach; ?>

            <div class="card glass" id="hosts" style="margin-bottom:18px;">
                <div class="card-head"><h3><i class="fa-solid fa-shield-halved"></i> دامنه‌های مجاز برای «گرفتن از لینک»</h3></div>
                <form method="post" class="nb-form">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="save_hosts">
                    <div class="form-group">
                        <label>هر خط یک دامنه (می‌توانید <span dir="ltr">*.github.io</span> بنویسید). سرور فقط از این دامنه‌ها فایل می‌گیرد.</label>
                        <textarea name="hosts" class="form-control" dir="ltr" style="min-height:110px"><?= e(implode("\n", blocks_allowed_hosts())) ?></textarea>
                    </div>
                    <button type="submit" class="btn btn-outline" style="width:auto"><i class="fa-solid fa-check"></i> ذخیرهٔ دامنه‌ها</button>
                </form>
                <p class="nb-note-box" style="margin-top:12px">
                    <b>کلید اضطراری:</b> اگر بلوکی سایت را خراب کرد و به پنل دسترسی نداشتید، در File Manager داخل پوشهٔ <span dir="ltr">config</span> یک فایل خالی به نام
                    <span dir="ltr">blocks.disable</span> بسازید؛ همهٔ بلوک‌ها فوراً خاموش می‌شوند. با پاک‌کردنش دوباره روشن می‌شوند.
                </p>
            </div>

            <?php elseif ($view === 'form'): ?>
            <div class="page-head">
                <div><h2><?= $edit['id'] ? 'ویرایش بلوک' : 'بلوک جدید' ?></h2><p class="breadcrumb"><a href="blocks.php">بلوک‌ها</a> <b>/ <?= $edit['id'] ? e($edit['title']) : 'جدید' ?></b></p></div>
            </div>
            <div class="card glass">
                <form method="post" class="nb-form">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <input type="hidden" name="action" value="save">
                    <input type="hidden" name="id" value="<?= (int) $edit['id'] ?>">
                    <div class="row2">
                        <div class="form-group"><label>عنوان</label><input type="text" name="title" class="form-control" value="<?= e($edit['title']) ?>" required></div>
                        <div class="form-group"><label>ناحیه</label>
                            <select name="zone" class="form-control">
                                <?php foreach (BLOCK_ZONES as $zk => $zl): ?><option value="<?= e($zk) ?>" <?= $zk === $edit['zone'] ? 'selected' : '' ?>><?= e($zl) ?></option><?php endforeach; ?>
                            </select></div>
                    </div>
                    <div class="form-group"><label>نوع</label>
                        <select name="kind" id="f_kind" class="form-control" onchange="nbSync()">
                            <option value="html" <?= $edit['kind'] === 'html' ? 'selected' : '' ?>>کد (HTML / CSS / JS)</option>
                            <option value="link" <?= $edit['kind'] === 'link' ? 'selected' : '' ?>>لینک (کارت / کادر داخل صفحه)</option>
                        </select></div>

                    <div class="form-group"><label id="l_url">لینک</label>
                        <input type="url" name="source_url" class="form-control" dir="ltr" value="<?= e((string) $edit['source_url']) ?>" placeholder="https://..."></div>

                    <div class="form-group" data-kind="html"><label>کد</label>
                        <textarea name="content" class="form-control"><?= e((string) $edit['content']) ?></textarea></div>
                    <div class="form-group" data-kind="html"><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="isolated" value="1" <?= $edit['isolated'] ? 'checked' : '' ?>> نمایش داخل کادر ایزوله (اسکریپت‌ها از سایت و نشست ادمین جدا اجرا می‌شوند؛ برای «جایگزین کل صفحه» اثری ندارد)</label></div>

                    <div class="row2">
                        <div class="form-group" data-kind="link"><label>شکل نمایش</label>
                            <select name="display" class="form-control">
                                <option value="card" <?= $edit['display'] === 'card' ? 'selected' : '' ?>>کارت</option>
                                <option value="embed" <?= $edit['display'] === 'embed' ? 'selected' : '' ?>>کادر داخل صفحه (iframe)</option>
                                <option value="both" <?= $edit['display'] === 'both' ? 'selected' : '' ?>>هر دو (کارت + کادر)</option>
                            </select></div>
                        <div class="form-group"><label>ارتفاع کادر (پیکسل)</label><input type="number" name="embed_height" class="form-control" min="120" max="2000" value="<?= (int) $edit['embed_height'] ?>"></div>
                    </div>
                    <div class="form-group"><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="is_active" value="1" <?= $edit['is_active'] ? 'checked' : '' ?>> فعال (روی سایت دیده شود)</label></div>
                    <div class="form-actions">
                        <a class="btn btn-outline" href="blocks.php" style="width:auto">انصراف</a>
                        <button type="submit" class="btn btn-primary" style="width:auto"><i class="fa-solid fa-check"></i> ذخیره</button>
                    </div>
                </form>
            </div>
            <script>
            function nbSync() {
                var k = document.getElementById('f_kind').value;
                document.querySelectorAll('[data-kind]').forEach(function (el) { el.style.display = el.getAttribute('data-kind') === k ? '' : 'none'; });
                document.getElementById('l_url').textContent = k === 'link' ? 'آدرس لینک (https)' : 'لینک مرجع (اختیاری — برای «بروزرسانی از لینک»)';
            }
            nbSync();
            </script>

            <?php elseif ($view === 'history'): ?>
            <?php
            $vs = db()->prepare('SELECT `id`,`title`,`source_url`,`created_at`, LENGTH(`content`) AS size FROM `block_versions` WHERE `block_id` = ? ORDER BY `id` DESC');
            $vs->execute([(int) $edit['id']]);
            $versions = $vs->fetchAll();
            ?>
            <div class="page-head">
                <div><h2>تاریخچهٔ «<?= e($edit['title']) ?>»</h2><p class="breadcrumb"><a href="blocks.php">بلوک‌ها</a> <b>/ تاریخچه</b></p></div>
            </div>
            <div class="card glass">
                <?php if (!$versions): ?><p class="nb-empty">هنوز نسخهٔ قدیمی‌ای نیست.</p><?php endif; ?>
                <ul class="nb-list">
                    <?php foreach ($versions as $v): ?>
                    <li class="nb-item">
                        <div class="nb-main"><b><?= e($v['title']) ?></b>
                            <div class="nb-chips"><span class="nb-chip" dir="ltr"><?= e($v['created_at']) ?></span><span class="nb-chip"><?= number_format(((int) $v['size']) / 1024, 1) ?> KB</span></div></div>
                        <div class="nb-actions">
                            <a class="btn-icon btn-sm" href="blocks.php?preview_version=<?= (int) $v['id'] ?>" title="پیش‌نمایش"><i class="fa-solid fa-eye"></i></a>
                            <?= nb_btn('restore', (int) $edit['id'], 'fa-solid fa-rotate-left', 'برگرد به این نسخه', ['version_id' => (int) $v['id']], 'به این نسخه برگردد؟') ?>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if ($schemaOk && $view === 'list'): ?>
<script>
// کشیدن و رها کردن (روی کامپیوتر). در آیفون از دکمه‌های ▲▼ و منوی انتقال استفاده کنید.
(function () {
  var dragged = null;
  function lists() { return Array.prototype.slice.call(document.querySelectorAll('.nb-list[data-zone]')); }
  document.addEventListener('dragstart', function (e) {
    var li = e.target.closest && e.target.closest('.nb-item[data-id]');
    if (!li) return;
    dragged = li; li.classList.add('dragging');
    e.dataTransfer.effectAllowed = 'move';
    try { e.dataTransfer.setData('text/plain', li.getAttribute('data-id')); } catch (x) {}
  });
  document.addEventListener('dragend', function () { if (dragged) dragged.classList.remove('dragging'); dragged = null; });
  lists().forEach(function (ul) {
    ul.addEventListener('dragover', function (e) {
      if (!dragged) return;
      e.preventDefault();
      var after = null, y = e.clientY;
      Array.prototype.slice.call(ul.querySelectorAll('.nb-item[data-id]:not(.dragging)')).forEach(function (el) {
        var r = el.getBoundingClientRect();
        if (y < r.top + r.height / 2 && !after) after = el;
      });
      var empty = ul.querySelector('[data-empty]'); if (empty) empty.remove();
      if (after) ul.insertBefore(dragged, after); else ul.appendChild(dragged);
    });
    ul.addEventListener('drop', function (e) {
      e.preventDefault();
      var payload = {};
      lists().forEach(function (l) {
        payload[l.getAttribute('data-zone')] = Array.prototype.slice.call(l.querySelectorAll('.nb-item[data-id]')).map(function (li) { return li.getAttribute('data-id'); });
      });
      var fd = new FormData();
      fd.append('action', 'reorder'); fd.append('csrf_token', window.CSRF_TOKEN || '<?= e(csrf_token()) ?>');
      fd.append('lists', JSON.stringify(payload));
      fetch('blocks.php', { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (res) { if (!res.ok) { alert('این جابه‌جایی مجاز نبود (بلوک لینک نمی‌تواند کل صفحه شود).'); } location.reload(); })
        .catch(function () { alert('ذخیرهٔ ترتیب ناموفق بود.'); location.reload(); });
    });
  });
})();
</script>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
