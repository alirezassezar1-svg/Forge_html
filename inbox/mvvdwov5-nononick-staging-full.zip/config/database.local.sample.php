<?php
/**
 * نمونهٔ تنظیمات دیتابیس.
 * ۱) این فایل را Copy کنید و اسم کپی را database.local.php بگذارید.
 * ۲) مقدارهای زیر را با اطلاعات دیتابیسی که در cPanel ساخته‌اید جایگزین کنید.
 * این فایل (sample) هیچ اثری ندارد و رمزی داخلش نیست.
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'CPANELUSER_dbname');
define('DB_USER', 'CPANELUSER_dbuser');
define('DB_PASS', 'CHANGE_ME');
