<?php
/**
 * Nononik
 * Database connection (PDO / MySQL)
 *
 * چرا: اطلاعات اتصال به دیتابیس دیگر داخل این فایل نیست. آن‌ها را در فایل
 * config/database.local.php می‌نویسید (نمونه: database.local.sample.php) تا با
 * هر بار آپلودِ نسخهٔ جدید سایت، تنظیمات شما پاک نشود و رمز دیتابیس داخل zip نباشد.
 */

if (is_file(__DIR__ . '/database.local.php')) {
    require __DIR__ . '/database.local.php';
}

defined('DB_HOST')    || define('DB_HOST', 'localhost');
defined('DB_NAME')    || define('DB_NAME', '');
defined('DB_USER')    || define('DB_USER', '');
defined('DB_PASS')    || define('DB_PASS', '');
defined('DB_CHARSET') || define('DB_CHARSET', 'utf8mb4');

define('BASE_URL', '/'); // change if the app lives in a different sub-folder
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_URL', BASE_URL . 'uploads/');

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        if (DB_NAME === '' || DB_USER === '') {
            http_response_code(503);
            header('Content-Type: text/html; charset=utf-8');
            die('<!DOCTYPE html><meta charset="utf-8"><div dir="rtl" style="font-family:sans-serif;padding:32px;line-height:2">'
                . '<h2>تنظیمات دیتابیس هنوز انجام نشده</h2>'
                . '<p>فایل <b dir="ltr">config/database.local.sample.php</b> را کپی کنید و اسمش را <b dir="ltr">database.local.php</b> بگذارید، '
                . 'بعد نام دیتابیس، کاربر و رمز را داخلش بنویسید.</p></div>');
        }
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            // چرا: متن خطای PDO ممکن است نام کاربر/دیتابیس را فاش کند؛ فقط در لاگ سرور ثبت می‌شود.
            error_log('DB connection failed: ' . $e->getMessage());
            http_response_code(503);
            die('خطا در اتصال به پایگاه داده. اطلاعات داخل config/database.local.php را بررسی کنید.');
        }
    }
    return $pdo;
}
