<?php
/**
 * Nononik — سیستم بلوک‌ها (Blocks)
 * چرا: ادمین بتواند بدون دست‌زدن به فایل‌های PHP، کامپوننت/ابزار/صفحهٔ آماده را
 * (با پیست کد یا با لینک) به صفحهٔ اصلی، فوتر یا داشبورد اضافه کند، جابه‌جا کند،
 * پیش‌نمایش ببیند و در صورت خطا به نسخهٔ قبل برگردد.
 *
 * اصول امنیتی:
 *  - هیچ محتوایی هرگز include/eval نمی‌شود؛ فقط به‌عنوان متن/HTML چاپ می‌شود.
 *  - «ورود از لینک» یک اسنپ‌شات می‌گیرد (نه نمایش زنده)؛ تا ادمین دوباره بروزرسانی
 *    نکند، تغییرِ لینک روی سایت اثری ندارد.
 *  - دریافت از لینک فقط https، فقط دامنه‌های مجاز، با جلوگیری از SSRF.
 *  - کلید اضطراری: ساختن فایل config/blocks.disable همهٔ بلوک‌ها را خاموش می‌کند.
 */

const BLOCK_ZONES = [
    'home_page'       => 'جایگزین کل صفحهٔ اصلی',
    'home_top'        => 'صفحهٔ اصلی — بالا (بعد از هیرو)',
    'home_bottom'     => 'صفحهٔ اصلی — پایین (قبل از دعوت به همکاری)',
    'footer'          => 'فوتر سایت',
    'admin_dashboard' => 'داشبورد پنل ادمین',
];

const BLOCK_DEFAULT_HOSTS = "raw.githubusercontent.com\ngist.githubusercontent.com\n*.github.io\ncdn.jsdelivr.net";
const BLOCK_MAX_BYTES     = 2097152; // 2MB
const BLOCK_MAX_VERSIONS  = 15;

/* ------------------------------------------------------------------ */
/*  وضعیت و ساخت جدول‌ها                                               */
/* ------------------------------------------------------------------ */

function blocks_disabled(): bool
{
    return is_file(__DIR__ . '/../config/blocks.disable');
}

function blocks_zone_valid(string $zone): bool
{
    return array_key_exists($zone, BLOCK_ZONES);
}

/**
 * ساخت جدول‌ها و مجوز «blocks.manage» (فقط از صفحهٔ مدیریت صدا زده می‌شود).
 */
function blocks_ensure_schema(): bool
{
    static $done = null;
    if ($done !== null) {
        return $done;
    }
    try {
        $pdo = db();
        $pdo->exec("CREATE TABLE IF NOT EXISTS `blocks` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `title` VARCHAR(190) NOT NULL,
            `zone` VARCHAR(40) NOT NULL,
            `kind` ENUM('html','link') NOT NULL DEFAULT 'html',
            `content` MEDIUMTEXT NULL,
            `source_url` VARCHAR(1000) NULL,
            `display` ENUM('card','embed','both') NOT NULL DEFAULT 'card',
            `embed_height` SMALLINT UNSIGNED NOT NULL DEFAULT 480,
            `isolated` TINYINT(1) NOT NULL DEFAULT 0,
            `is_active` TINYINT(1) NOT NULL DEFAULT 1,
            `sort_order` INT NOT NULL DEFAULT 0,
            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_zone` (`zone`, `is_active`, `sort_order`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `block_versions` (
            `id` INT NOT NULL AUTO_INCREMENT,
            `block_id` INT NOT NULL,
            `title` VARCHAR(190) NOT NULL,
            `content` MEDIUMTEXT NULL,
            `source_url` VARCHAR(1000) NULL,
            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_block` (`block_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // مجوز برای نقش‌های غیر از «مدیر کل» (مدیر کل همیشه دسترسی کامل دارد)
        $pdo->prepare("INSERT IGNORE INTO `permissions` (`name`, `slug`, `group`) VALUES (?, ?, ?)")
            ->execute(['مدیریت بلوک‌ها', 'blocks.manage', 'blocks']);

        return $done = true;
    } catch (Throwable $e) {
        if (function_exists('security_log')) {
            security_log('blocks_schema', $e->getMessage());
        }
        return $done = false;
    }
}

/* ------------------------------------------------------------------ */
/*  خواندن و نمایش                                                     */
/* ------------------------------------------------------------------ */

/** بلوک‌های فعالِ یک ناحیه به ترتیب نمایش. اگر جدول نبود، آرایهٔ خالی (سایت نمی‌شکند). */
function blocks_for_zone(string $zone): array
{
    static $cache = [];
    if (blocks_disabled()) {
        return [];
    }
    if (!isset($cache[$zone])) {
        try {
            $st = db()->prepare('SELECT * FROM `blocks` WHERE `zone` = ? AND `is_active` = 1 ORDER BY `sort_order` ASC, `id` ASC');
            $st->execute([$zone]);
            $cache[$zone] = $st->fetchAll();
        } catch (Throwable $e) {
            $cache[$zone] = [];
        }
    }
    return $cache[$zone];
}

/** فقط آدرس https معتبر را برمی‌گرداند؛ در غیر این صورت null. */
function blocks_safe_url(string $url): ?string
{
    $url = trim($url);
    if ($url === '' || strlen($url) > 1000 || preg_match('/[\s<>"\'`\\\\]/', $url)) {
        return null;
    }
    $p = parse_url($url);
    if (!$p || strtolower($p['scheme'] ?? '') !== 'https' || empty($p['host']) || isset($p['user']) || isset($p['pass'])) {
        return null;
    }
    return $url;
}

function blocks_css(): void
{
    static $printed = false;
    if ($printed) {
        return;
    }
    $printed = true;
    echo <<<'CSS'
<style>
.nb-block{margin:0 0 18px}
.nb-block:last-child{margin-bottom:0}
.nb-frame{display:block;width:100%;border:0;border-radius:16px;background:#fff;margin-top:14px}
.nb-card{display:flex;align-items:center;gap:14px;padding:16px 18px;border-radius:18px;text-decoration:none;color:inherit;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.06);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);transition:transform .2s ease,border-color .2s ease}
.nb-card:hover{transform:translateY(-2px);border-color:rgba(167,139,250,.6)}
.nb-card-ic{flex:0 0 42px;height:42px;border-radius:12px;display:grid;place-items:center;background:rgba(139,92,246,.22);color:#c4b5fd}
.nb-card-tx{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}
.nb-card-tx b{font-size:15px}
.nb-card-tx small{opacity:.65;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:right}
.nb-card-go{font-size:12.5px;padding:7px 14px;border-radius:999px;background:rgba(139,92,246,.28);white-space:nowrap}
.nb-note{font-size:12px;opacity:.65;margin-top:8px}
.nb-footer{padding-top:8px}
</style>
CSS;
}

/**
 * یک بلوک را به HTML تبدیل می‌کند.
 * $forceIsolated: برای پیش‌نمایش (همیشه داخل iframe ایزوله).
 */
function blocks_render_one(array $b, bool $forceIsolated = false): string
{
    $id    = (int) ($b['id'] ?? 0);
    $h     = max(120, min(2000, (int) ($b['embed_height'] ?? 480)));
    $title = htmlspecialchars((string) ($b['title'] ?? ''), ENT_QUOTES, 'UTF-8');

    if (($b['kind'] ?? 'html') === 'link') {
        $url = blocks_safe_url((string) ($b['source_url'] ?? ''));
        if ($url === null) {
            return '';
        }
        $eurl    = htmlspecialchars($url, ENT_QUOTES, 'UTF-8');
        $host    = htmlspecialchars((string) (parse_url($url, PHP_URL_HOST) ?: ''), ENT_QUOTES, 'UTF-8');
        $display = $b['display'] ?? 'card';
        $out     = '<div class="nb-block nb-link" data-block-id="' . $id . '">';
        if ($display === 'card' || $display === 'both') {
            $out .= '<a class="nb-card" href="' . $eurl . '" target="_blank" rel="noopener noreferrer">'
                . '<span class="nb-card-ic"><i class="fa-solid fa-arrow-up-right-from-square"></i></span>'
                . '<span class="nb-card-tx"><b>' . $title . '</b><small dir="ltr">' . $host . '</small></span>'
                . '<span class="nb-card-go">باز کردن</span></a>';
        }
        if ($display === 'embed' || $display === 'both') {
            $out .= '<iframe class="nb-frame" src="' . $eurl . '" title="' . $title . '" loading="lazy" style="height:' . $h . 'px"'
                . ' sandbox="allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox allow-forms"'
                . ' referrerpolicy="no-referrer"></iframe>';
            if ($display === 'embed') {
                $out .= '<p class="nb-note">اگر کادر بالا خالی ماند، سایت مقصد اجازهٔ نمایش داخل صفحه را نمی‌دهد؛ '
                    . '<a href="' . $eurl . '" target="_blank" rel="noopener noreferrer">در تب جدید باز کنید</a>.</p>';
            }
        }
        return $out . '</div>';
    }

    $content = (string) ($b['content'] ?? '');
    if ($forceIsolated || !empty($b['isolated'])) {
        $srcdoc = htmlspecialchars($content, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        return '<div class="nb-block" data-block-id="' . $id . '"><iframe class="nb-frame" title="' . $title . '" loading="lazy"'
            . ' style="height:' . $h . 'px" sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox allow-forms"'
            . ' srcdoc="' . $srcdoc . '"></iframe></div>';
    }
    return '<div class="nb-block" data-block-id="' . $id . '">' . $content . '</div>';
}

/** نمایش همهٔ بلوک‌های فعالِ یک ناحیه، با قاب مناسب همان ناحیه. */
function render_blocks(string $zone): void
{
    $blocks = blocks_for_zone($zone);
    if (!$blocks) {
        return;
    }
    blocks_css();
    switch ($zone) {
        case 'home_top':
        case 'home_bottom':
            foreach ($blocks as $b) {
                echo '<section class="section nb-section"><div class="wrap">' . blocks_render_one($b) . '</div></section>' . "\n";
            }
            break;
        case 'footer':
            echo '<div class="wrap nb-footer">';
            foreach ($blocks as $b) {
                echo blocks_render_one($b);
            }
            echo "</div>\n";
            break;
        case 'admin_dashboard':
            foreach ($blocks as $b) {
                echo '<div class="card glass nb-admin" style="margin-bottom:18px;">' . blocks_render_one($b) . "</div>\n";
            }
            break;
    }
}

/**
 * اگر بلوکی در ناحیهٔ «جایگزین کل صفحهٔ اصلی» فعال باشد، HTML کامل آن را برمی‌گرداند.
 * ادمین واردشده با ?classic=1 همیشه صفحهٔ اصلیِ قبلی را می‌بیند.
 */
function blocks_fullpage_html(): ?string
{
    if (!empty($_SESSION['admin_id']) && isset($_GET['classic'])) {
        return null;
    }
    foreach (blocks_for_zone('home_page') as $b) {
        if (($b['kind'] ?? '') === 'html' && trim((string) $b['content']) !== '') {
            return (string) $b['content'];
        }
    }
    return null;
}

/* ------------------------------------------------------------------ */
/*  دریافت امن از لینک                                                 */
/* ------------------------------------------------------------------ */

function blocks_allowed_hosts(): array
{
    $raw = function_exists('setting') ? setting('blocks_allowed_hosts', '') : '';
    if (trim($raw) === '') {
        $raw = BLOCK_DEFAULT_HOSTS;
    }
    $list = preg_split('/[\s,]+/', strtolower($raw), -1, PREG_SPLIT_NO_EMPTY) ?: [];
    return array_values(array_unique($list));
}

function blocks_host_allowed(string $host, array $allowed): bool
{
    $host = strtolower($host);
    foreach ($allowed as $a) {
        if ($a === $host) {
            return true;
        }
        if (str_starts_with($a, '*.')) {
            $suffix = substr($a, 1); // ".github.io"
            if (strlen($host) > strlen($suffix) && str_ends_with($host, $suffix)) {
                return true;
            }
        }
    }
    return false;
}

/** لینک صفحهٔ GitHub (blob) را به لینک خام (raw) تبدیل می‌کند. */
function blocks_normalize_source_url(string $url): string
{
    $url = trim($url);
    $url = preg_replace('/#.*$/', '', $url) ?? $url;
    if (preg_match('#^https://github\.com/([^/]+)/([^/]+)/blob/(.+)$#i', $url, $m)) {
        $rest = preg_replace('/\?.*$/', '', $m[3]) ?? $m[3];
        return 'https://raw.githubusercontent.com/' . $m[1] . '/' . $m[2] . '/' . $rest;
    }
    return $url;
}

/** دامنه را resolve می‌کند و فقط اگر همهٔ IPها عمومی باشند، یکی را برمی‌گرداند. */
function blocks_resolve_public_ip(string $host): string
{
    if (filter_var($host, FILTER_VALIDATE_IP)) {
        throw new RuntimeException('استفاده‌ی مستقیم از IP مجاز نیست.');
    }
    $v4 = [];
    $v6 = [];
    foreach ((@dns_get_record($host, DNS_A) ?: []) as $r) {
        if (!empty($r['ip'])) {
            $v4[] = $r['ip'];
        }
    }
    foreach ((@dns_get_record($host, DNS_AAAA) ?: []) as $r) {
        if (!empty($r['ipv6'])) {
            $v6[] = $r['ipv6'];
        }
    }
    if (!$v4) {
        foreach ((@gethostbynamel($host) ?: []) as $ip) {
            $v4[] = $ip;
        }
    }
    $all = array_merge($v4, $v6);
    if (!$all) {
        throw new RuntimeException('این دامنه پیدا نشد.');
    }
    foreach ($all as $ip) {
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            throw new RuntimeException('این آدرس به شبکهٔ داخلی اشاره می‌کند و مجاز نیست.');
        }
    }
    return $v4 ? $v4[0] : '[' . $v6[0] . ']';
}

/**
 * متن یک لینک را می‌گیرد. در صورت هر مشکل RuntimeException با پیام فارسی می‌اندازد.
 */
function blocks_fetch_url(string $url): string
{
    $url     = blocks_normalize_source_url($url);
    $allowed = blocks_allowed_hosts();

    for ($hop = 0; $hop < 4; $hop++) {
        $p = parse_url($url);
        if (!$p || strtolower($p['scheme'] ?? '') !== 'https' || empty($p['host']) || isset($p['user']) || isset($p['pass'])) {
            throw new RuntimeException('فقط لینک https معتبر پذیرفته می‌شود.');
        }
        if (isset($p['port']) && (int) $p['port'] !== 443) {
            throw new RuntimeException('فقط پورت استاندارد 443 مجاز است.');
        }
        $host = strtolower($p['host']);
        if (!blocks_host_allowed($host, $allowed)) {
            throw new RuntimeException("دامنهٔ «{$host}» در فهرست دامنه‌های مجاز نیست. اول آن را در بخش «دامنه‌های مجاز» اضافه کنید.");
        }
        $ip = blocks_resolve_public_ip($host);

        $body = '';
        $size = 0;
        $ctype = '';
        $location = '';
        $tooBig = false;

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_PROTOCOLS      => CURLPROTO_HTTPS,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_USERAGENT      => 'NononikBlocks/1.0',
            CURLOPT_HTTPHEADER     => ['Accept: text/html,text/plain,text/css,application/javascript;q=0.9,*/*;q=0.5'],
            CURLOPT_RESOLVE        => [$host . ':443:' . $ip], // جلوگیری از DNS rebinding
            CURLOPT_HEADERFUNCTION => function ($c, $line) use (&$ctype, &$location) {
                if (stripos($line, 'content-type:') === 0) {
                    $ctype = strtolower(trim(substr($line, 13)));
                } elseif (stripos($line, 'location:') === 0) {
                    $location = trim(substr($line, 9));
                }
                return strlen($line);
            },
            CURLOPT_WRITEFUNCTION  => function ($c, $chunk) use (&$body, &$size, &$tooBig) {
                $size += strlen($chunk);
                if ($size > BLOCK_MAX_BYTES) {
                    $tooBig = true;
                    return 0;
                }
                $body .= $chunk;
                return strlen($chunk);
            },
        ]);
        $ok     = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);

        if ($tooBig) {
            throw new RuntimeException('حجم فایل بیشتر از ۲ مگابایت است.');
        }
        if ($ok === false) {
            throw new RuntimeException('اتصال به لینک ناموفق بود: ' . curl_error($ch));
        }

        if (in_array($status, [301, 302, 303, 307, 308], true) && $location !== '') {
            // آدرس نسبی را به مطلق تبدیل می‌کنیم و دور بعد دوباره همهٔ بررسی‌ها انجام می‌شود
            if (str_starts_with($location, '/')) {
                $location = 'https://' . $host . $location;
            }
            $url = $location;
            continue;
        }
        if ($status !== 200) {
            throw new RuntimeException("سرور مقصد کد {$status} برگرداند. لینک را بررسی کنید.");
        }
        if ($ctype !== '' && !preg_match('#^(text/|application/(javascript|x-javascript|json|xml|xhtml\+xml))#', $ctype)) {
            throw new RuntimeException('نوع فایل پشتیبانی نمی‌شود (' . $ctype . '). فقط HTML، CSS، JS یا متن.');
        }
        $body = str_replace("\0", '', $body);
        if (str_starts_with($body, "\xEF\xBB\xBF")) {
            $body = substr($body, 3);
        }
        if (!mb_check_encoding($body, 'UTF-8')) {
            throw new RuntimeException('فایل UTF-8 نیست. آن را با کدگذاری UTF-8 ذخیره کنید.');
        }
        if (trim($body) === '') {
            throw new RuntimeException('فایل خالی است.');
        }
        return $body;
    }
    throw new RuntimeException('تعداد ریدایرکت‌ها بیش از حد است.');
}

/* ------------------------------------------------------------------ */
/*  نسخه‌ها و ترتیب                                                    */
/* ------------------------------------------------------------------ */

/** وضعیت فعلیِ بلوک را قبل از هر تغییر ذخیره می‌کند (برای «برگشت به نسخهٔ قبل»). */
function blocks_save_version(int $id): void
{
    $pdo = db();
    $st = $pdo->prepare('SELECT `title`, `content`, `source_url` FROM `blocks` WHERE `id` = ?');
    $st->execute([$id]);
    $row = $st->fetch();
    if (!$row) {
        return;
    }
    $pdo->prepare('INSERT INTO `block_versions` (`block_id`, `title`, `content`, `source_url`) VALUES (?,?,?,?)')
        ->execute([$id, $row['title'], $row['content'], $row['source_url']]);
    $pdo->prepare('DELETE FROM `block_versions` WHERE `block_id` = ? AND `id` NOT IN (
            SELECT `id` FROM (SELECT `id` FROM `block_versions` WHERE `block_id` = ? ORDER BY `id` DESC LIMIT ' . BLOCK_MAX_VERSIONS . ') t
        )')->execute([$id, $id]);
}

/** ترتیب بلوک‌های یک ناحیه را به ۱۰، ۲۰، ۳۰... بازنویسی می‌کند. */
function blocks_renumber_zone(string $zone): void
{
    $pdo = db();
    $st = $pdo->prepare('SELECT `id` FROM `blocks` WHERE `zone` = ? ORDER BY `sort_order` ASC, `id` ASC');
    $st->execute([$zone]);
    $n = 10;
    $up = $pdo->prepare('UPDATE `blocks` SET `sort_order` = ? WHERE `id` = ?');
    foreach ($st->fetchAll() as $r) {
        $up->execute([$n, (int) $r['id']]);
        $n += 10;
    }
}
