# Nexus Studio

Reconstructed website from https://api-ready-frontend-p-z30u.bolt.host/

## Capture Details
- **Source URL**: https://api-ready-frontend-p-z30u.bolt.host/
- **Capture Date**: 2026-10-19T14:53:19.337Z
- **Similarity Score**: 100.00%
- **Technologies**: None detected

## Structure
- `index.html` - Main page
- `assets/css/` - Stylesheets
- `assets/js/` - JavaScript files
- `assets/fonts/` - Font files
- `project.json` - Editable project data
- `manifest.json` - Project manifest

## Usage
Open `index.html` in a browser to view the reconstructed website.
