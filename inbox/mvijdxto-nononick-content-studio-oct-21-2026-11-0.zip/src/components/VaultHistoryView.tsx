import React, { useState } from 'react';
import {
  Archive,
  Maximize2,
  Trash2,
  Star,
  Download,
  Calendar,
  Layers,
  Sparkles,
  Camera,
  Film,
  Search,
} from 'lucide-react';
import { GeneratedMediaItem } from '../types/media';

interface VaultHistoryViewProps {
  history: GeneratedMediaItem[];
  onSelectForInspect: (item: GeneratedMediaItem) => void;
  onDeleteItem: (id: string) => void;
  onToggleFavorite: (id: string) => void;
}

export const VaultHistoryView: React.FC<VaultHistoryViewProps> = ({
  history,
  onSelectForInspect,
  onDeleteItem,
  onToggleFavorite,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterFav, setFilterFav] = useState(false);

  const filteredHistory = history.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.promptEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.promptFa.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFav = filterFav ? item.isFavorite : true;
    return matchesSearch && matchesFav;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/40 to-slate-900 border border-slate-800 p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-mono uppercase tracking-widest bg-indigo-950 text-indigo-300 border border-indigo-800/60 font-bold">
                PRODUCTION ASSET VAULT
              </span>
              <span className="text-xs text-slate-400 font-mono">{history.length} Master Renders Stored</span>
            </div>
            <h1 className="text-2xl font-black text-white tracking-tight">
              Render Vault & Production Queue History
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-3xl leading-relaxed">
              Permanent studio vault holding 16-bit float masters, 3D camera trajectory metadata, multi-pass layers, and reproducibility seeds.
            </p>
          </div>

          <button
            onClick={() => {
              const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(history, null, 2));
              const downloadAnchor = document.createElement('a');
              downloadAnchor.setAttribute('href', dataStr);
              downloadAnchor.setAttribute('download', `aetheris_production_vault_${Date.now()}.json`);
              document.body.appendChild(downloadAnchor);
              downloadAnchor.click();
              downloadAnchor.remove();
            }}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono flex items-center gap-2 transition-colors border border-slate-700"
          >
            <Download className="w-4 h-4 text-cyan-400" />
            <span>Export Full Vault Manifest</span>
          </button>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mt-6 pt-4 border-t border-slate-800/80">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by prompt keywords, Persian concept or camera..."
              className="w-full bg-slate-950/80 border border-slate-700/80 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <button
            onClick={() => setFilterFav(!filterFav)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all border ${
              filterFav
                ? 'bg-amber-950/80 text-amber-300 border-amber-600/60'
                : 'bg-slate-900/60 text-slate-400 border-slate-800 hover:text-white'
            }`}
          >
            <Star className={`w-3.5 h-3.5 ${filterFav ? 'fill-amber-400 text-amber-400' : ''}`} />
            <span>Favorites Only</span>
          </button>
        </div>
      </div>

      {/* Grid of Vault Items */}
      {filteredHistory.length === 0 ? (
        <div className="glass-panel rounded-2xl p-12 text-center border border-slate-800 space-y-3">
          <Archive className="w-12 h-12 text-slate-600 mx-auto" />
          <h3 className="text-base font-bold text-white">Vault is Ready</h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto">
            Your generated 8K images and cinematic video clips will be saved here automatically with complete metadata.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredHistory.map((item) => (
            <div
              key={item.id}
              className="group glass-panel rounded-2xl overflow-hidden border border-slate-800 hover:border-indigo-500/50 transition-all flex flex-col shadow-xl"
            >
              <div className="relative aspect-video bg-black overflow-hidden">
                <img
                  src={item.passes.compositeUrl}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                />

                <div className="absolute top-3 left-3 px-2 py-0.5 rounded bg-black/80 text-[10px] font-mono text-cyan-300 font-bold border border-white/10">
                  {item.resolution}
                </div>

                <button
                  onClick={() => onToggleFavorite(item.id)}
                  className="absolute top-3 right-3 p-1.5 rounded-lg bg-black/80 text-slate-300 hover:text-amber-400 transition-colors"
                >
                  <Star className={`w-3.5 h-3.5 ${item.isFavorite ? 'fill-amber-400 text-amber-400' : ''}`} />
                </button>
              </div>

              <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                <div className="space-y-1.5">
                  <h4 className="text-sm font-bold text-white line-clamp-1">{item.title}</h4>
                  <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                    {item.promptEn}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400">
                  <span>Score: <strong className="text-emerald-400">{item.aestheticScore.predictedPhotorealism}</strong></span>
                  <span>Seed: <strong className="text-purple-300">{item.seed}</strong></span>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => onSelectForInspect(item)}
                    className="flex-1 py-1.5 px-3 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span>8K Loupe</span>
                  </button>
                  <button
                    onClick={() => onDeleteItem(item.id)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950/80 text-slate-400 hover:text-rose-400 transition-colors border border-slate-700"
                    title="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
