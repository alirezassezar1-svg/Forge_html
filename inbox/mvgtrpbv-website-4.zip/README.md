# NonoFlow — The Website Editing Engine

Reconstructed website from https://nonoflow-editor-2l0w.bolt.host/

## Capture Details
- **Source URL**: https://nonoflow-editor-2l0w.bolt.host/
- **Capture Date**: 2026-10-20T15:13:09.589Z
- **Similarity Score**: 100.00%
- **Technologies**: None detected

## Structure
- `index.html` - Main page
- `assets/css/` - Stylesheets
- `assets/js/` - JavaScript files
- `assets/fonts/` - Font files
- `project.json` - Editable project data
- `manifest.json` - Project manifest

## Usage
Open `index.html` in a browser to view the reconstructed website.
