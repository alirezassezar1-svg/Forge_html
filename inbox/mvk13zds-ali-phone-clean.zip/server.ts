import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Google Gemini AI client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// ALI Assistant Chat endpoint
app.post('/api/assistant/chat', async (req, res) => {
  try {
    const { prompt, history, language = 'fa', systemContext = {} } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const systemInstruction = `
You are "ALI Intelligence" (دستیار هوشمند علی), the ultra-advanced AI built into the iPhone 16 Pro Max ("ALI phone").
You respond in a polite, super-fast, intelligent, and helpful tone in the user's language (Persian by default, or English if asked).
You have deep integration with the ALI phone hardware & software:
- You know the device is an iPhone 16 Pro Max with A18 Pro chip, 1TB Titanium storage, iOS 18.2 / ALI OS.
- You can help users manage and install products, launch apps (Phone, Messages, Camera, Photos, Safari, Notes, Calculator, Music, Weather, Clock, Settings, Store, Product Manager), calculate finances, draft invoices, write notes, or answer general knowledge questions.
- Current active phone context: ${JSON.stringify(systemContext)}.
- If the user asks you to open an app or execute an action, you can include an action tag in your answer like [ACTION:open_app:camera], [ACTION:open_app:products], [ACTION:open_app:notes], [ACTION:open_app:calculator], [ACTION:open_app:music], [ACTION:open_app:settings], [ACTION:open_app:store], [ACTION:open_app:phone], [ACTION:open_app:safari], [ACTION:flashlight:toggle], [ACTION:take_photo].
Keep responses crisp, high quality, and elegant.
`;

    // Construct contents
    const contents: any[] = [];
    if (history && Array.isArray(history)) {
      for (const msg of history.slice(-6)) {
        contents.push({
          role: msg.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: msg.text }],
        });
      }
    }
    contents.push({
      role: 'user',
      parts: [{ text: prompt }],
    });

    const response = await ai.models.generateContent({
      model: 'gemini-2.0-flash',
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const replyText = response.text || 'پاسخی دریافت نشد.';

    // Extract any action if present
    const actionMatch = replyText.match(/\[ACTION:([^\]]+)\]/);
    const action = actionMatch ? actionMatch[1] : null;
    const cleanReply = replyText.replace(/\[ACTION:[^\]]+\]/g, '').trim();

    return res.json({
      reply: cleanReply,
      action,
      timestamp: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in /api/assistant/chat:', error);
    return res.status(500).json({
      error: 'Failed to communicate with ALI Intelligence',
      details: error.message || 'Unknown error',
    });
  }
});

// Check phone status
app.get('/api/status', (req, res) => {
  res.json({
    device: 'ALI phone - iPhone 16 Pro Max',
    chip: 'Apple A18 Pro',
    os: 'ALI OS 18.2',
    status: 'online',
    time: new Date().toISOString(),
  });
});

// Vite Middleware for dev or static serving for prod
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(
      express.static(path.resolve(__dirname, 'dist'), {
        setHeaders: (res, file) => {
          if (file.endsWith('sw.js') || file.endsWith('index.html')) res.setHeader('Cache-Control', 'no-cache');
          if (file.endsWith('.webmanifest')) res.setHeader('Content-Type', 'application/manifest+json');
          if (/\/assets\//.test(file)) res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
        },
      })
    );
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`ALI phone server running at http://0.0.0.0:${port}`);
  });
}

startServer();
