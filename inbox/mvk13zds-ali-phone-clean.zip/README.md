# ALI phone — iPhone 16 Pro Max Simulator

شبیه‌ساز فوق‌واقع‌گرایانه آیفون ۱۶ پرو مکس به صورت Progressive Web App (PWA).

قابلیت‌ها:
- Dynamic Island، Control Center، Lock Screen، Home Screen
- دستیار هوشمند **ALI Intelligence** (قدرت‌گرفته از Gemini)
- اپ‌های کامل: Phone، Messages، Safari، Camera، Photos، Notes، Calculator، Music، Weather، Clock، Settings
- **Product Manager** و مدیریت محصولات
- **Cloud Android Streaming** (شبیه‌ساز داخلی + iframe واقعی Appetize.io + ترمینال ADB شبیه‌سازی‌شده)
- پشتیبانی چندزبانه (فارسی پیش‌فرض + انگلیسی، عربی، آلمانی، فرانسوی، ترکی)
- تقویم شمسی / میلادی / اسلامی و اعداد فارسی
- قاب تیتانیوم (Desert / Black / Natural / White)
- قابل نصب روی گوشی و دسکتاپ (PWA)

## پیش‌نیازها

- Node.js 20+ 
- یک Gemini API Key از [Google AI Studio](https://aistudio.google.com/apikey)

## نصب و اجرا

```bash
# نصب وابستگی‌ها
npm install

# تنظیم کلید API
cp .env.example .env.local
# سپس فایل .env.local را باز کنید و GEMINI_API_KEY را وارد کنید

# اجرای حالت توسعه
npm run dev
```

سرور روی `http://localhost:3000` اجرا می‌شود.

## ساخت نسخه Production و PWA

```bash
npm run build
NODE_ENV=production npm start
```

- باید روی **HTTPS** یا `localhost` سرو شود تا قابلیت نصب PWA فعال باشد.
- Android / Chrome / Edge: دکمه «نصب برنامه»
- iPhone / Safari: Share → Add to Home Screen

## نکات استفاده روی گوشی

- تمام‌صفحه و بدون قاب اجرا می‌شود
- کشیدن از بالا به پایین = Control Center
- دوبار تپ بالا = قفل صفحه
- نگه‌داشتن نوار پایین = Siri / ALI Intelligence
- داده‌های واقعی: باتری، شبکه، ساعت، آب‌وهوا (Open-Meteo)، دوربین، چراغ‌قوه

## ساختار پروژه

```
├── server.ts              # Express + Gemini API + Vite middleware
├── src/
│   ├── App.tsx            # هسته اصلی
│   ├── components/
│   │   ├── apps/          # تمام اپ‌های داخلی
│   │   ├── hardware/      # قاب آیفون
│   │   └── os/            # Dynamic Island, HomeScreen, ...
│   ├── types/
│   └── utils/             # i18n, device APIs, sounds, ...
├── public/                # آیکون‌ها، wallpapers، manifest، service worker
└── package.json
```

## لایسنس

این پروژه برای استفاده شخصی و آموزشی است.
